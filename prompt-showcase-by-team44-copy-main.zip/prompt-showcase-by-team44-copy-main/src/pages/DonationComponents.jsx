import React, { useState } from "react";
import { motion } from "framer-motion";
import { Coffee, Heart, DollarSign, Gift } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import { useQuery } from "@tanstack/react-query";

const donationComponents = [
  {
    id: 1,
    title: "Classic Coffee Button",
    description: "Simple buy me a coffee button",
    code: `<button className="flex items-center gap-2 px-6 py-3 bg-amber-500 hover:bg-amber-600 rounded-lg text-white font-semibold">
  <Coffee className="w-5 h-5" />
  Buy Me a Coffee
</button>`,
    component: () => (
      <button className="flex items-center gap-2 px-6 py-3 bg-amber-500 hover:bg-amber-600 rounded-lg text-white font-semibold transition">
        <Coffee className="w-5 h-5" />
        Buy Me a Coffee
      </button>
    )
  },
  {
    id: 2,
    title: "Neon Glow Button",
    description: "Glowing button with hover effect",
    code: `<button className="px-6 py-3 bg-gradient-to-r from-violet-600 to-fuchsia-600 rounded-lg text-white font-bold shadow-lg shadow-violet-500/50 hover:shadow-violet-500/70">
  ✨ Support the Project
</button>`,
    component: () => (
      <button className="px-6 py-3 bg-gradient-to-r from-violet-600 to-fuchsia-600 rounded-lg text-white font-bold shadow-lg shadow-violet-500/50 hover:shadow-violet-500/70 transition">
        ✨ Support the Project
      </button>
    )
  },
  {
    id: 3,
    title: "Heart Pulse Button",
    description: "Animated heart donation button",
    code: `<button className="flex items-center gap-2 px-6 py-3 bg-red-500 hover:bg-red-600 rounded-full">
  <Heart className="w-5 h-5 animate-pulse" />
  <span>Donate</span>
</button>`,
    component: () => (
      <motion.button whileHover={{ scale: 1.05 }} className="flex items-center gap-2 px-6 py-3 bg-red-500 hover:bg-red-600 rounded-full text-white font-semibold transition">
        <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 1, repeat: Infinity }}>
          <Heart className="w-5 h-5" />
        </motion.div>
        <span>Donate</span>
      </motion.button>
    )
  },
  {
    id: 4,
    title: "Gradient Card",
    description: "Card with gradient background",
    code: `<div className="p-6 rounded-xl bg-gradient-to-br from-pink-500 to-orange-500 text-white text-center">
  <h3 className="text-2xl font-bold mb-2">☕ Support Us</h3>
  <p className="mb-4">Your support keeps us caffeinated!</p>
  <button className="px-6 py-2 bg-white text-pink-600 rounded-lg font-bold">
    Donate $5
  </button>
</div>`,
    component: () => (
      <div className="p-6 rounded-xl bg-gradient-to-br from-pink-500 to-orange-500 text-white text-center max-w-sm">
        <h3 className="text-2xl font-bold mb-2">☕ Support Us</h3>
        <p className="mb-4 text-sm">Your support keeps us caffeinated!</p>
        <button className="px-6 py-2 bg-white text-pink-600 rounded-lg font-bold hover:bg-pink-50 transition">
          Donate $5
        </button>
      </div>
    )
  },
  {
    id: 5,
    title: "Multiple Amount Options",
    description: "Choose donation amount",
    code: `<div className="space-y-3">
  {[5, 10, 20, 50].map(amount => (
    <button key={amount} className="w-full px-4 py-2 bg-slate-800 hover:bg-violet-600 rounded-lg">
      $\{amount}
    </button>
  ))}
</div>`,
    component: function MultipleAmounts() {
      const [selected, setSelected] = useState(10);
      return (
        <div className="space-y-2">
          {[5, 10, 20, 50].map(amount => (
            <button key={amount} onClick={() => setSelected(amount)} className={`w-full px-4 py-2 rounded-lg transition ${selected === amount ? 'bg-violet-600 text-white' : 'bg-slate-800 text-white hover:bg-slate-700'}`}>
              ${amount}
            </button>
          ))}
        </div>
      );
    }
  },
  {
    id: 6,
    title: "Progress Goal Card",
    description: "Show funding progress",
    code: `<div className="p-4 bg-slate-900 rounded-xl">
  <h3 className="text-white font-bold mb-2">Monthly Goal</h3>
  <div className="w-full h-2 bg-slate-700 rounded-full mb-2">
    <div className="h-full bg-green-500 rounded-full" style={{width: '60%'}} />
  </div>
  <p className="text-slate-400 text-sm">$600 / $1000</p>
</div>`,
    component: () => (
      <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
        <h3 className="text-white font-bold mb-2">Monthly Goal</h3>
        <div className="w-full h-2 bg-slate-700 rounded-full mb-2">
          <motion.div initial={{ width: 0 }} animate={{ width: '60%' }} transition={{ duration: 1 }} className="h-full bg-green-500 rounded-full" />
        </div>
        <p className="text-slate-400 text-sm">$600 / $1000</p>
      </div>
    )
  },
  {
    id: 7,
    title: "Sponsor Tiers",
    description: "Multiple sponsorship levels",
    code: `<div className="grid grid-cols-3 gap-4">
  {['Bronze', 'Silver', 'Gold'].map(tier => (
    <div key={tier} className="p-4 bg-slate-900 rounded-xl text-center">
      <h4 className="text-white font-bold">{tier}</h4>
      <p className="text-2xl font-bold text-violet-400 my-2">$10</p>
      <button className="w-full px-4 py-2 bg-violet-600 rounded-lg">Select</button>
    </div>
  ))}
</div>`,
    component: () => (
      <div className="grid grid-cols-3 gap-3">
        {[{name: 'Bronze', price: 5, color: 'from-orange-600 to-orange-800'}, 
          {name: 'Silver', price: 10, color: 'from-gray-400 to-gray-600'},
          {name: 'Gold', price: 20, color: 'from-yellow-500 to-yellow-700'}].map(tier => (
          <div key={tier.name} className={`p-3 bg-gradient-to-br ${tier.color} rounded-xl text-center`}>
            <h4 className="text-white font-bold text-sm">{tier.name}</h4>
            <p className="text-xl font-bold text-white my-1">${tier.price}</p>
            <button className="w-full px-3 py-1 bg-white/20 hover:bg-white/30 rounded-lg text-white text-xs transition">Select</button>
          </div>
        ))}
      </div>
    )
  },
  {
    id: 8,
    title: "Floating Coffee Icon",
    description: "Sticky donation button",
    code: `<div className="fixed bottom-4 right-4 p-4 bg-amber-500 rounded-full shadow-lg cursor-pointer hover:scale-110 transition">
  <Coffee className="w-6 h-6 text-white" />
</div>`,
    component: () => (
      <motion.div whileHover={{ scale: 1.1, rotate: 10 }} className="p-4 bg-amber-500 rounded-full shadow-lg cursor-pointer">
        <Coffee className="w-6 h-6 text-white" />
      </motion.div>
    )
  },
  {
    id: 9,
    title: "Thank You Message",
    description: "Post-donation appreciation",
    code: `<div className="p-6 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl text-white text-center">
  <h2 className="text-2xl font-bold mb-2">Thank You! 🎉</h2>
  <p>Your support means the world to us.</p>
</div>`,
    component: () => (
      <div className="p-6 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl text-white text-center">
        <motion.h2 initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-2xl font-bold mb-2">Thank You! 🎉</motion.h2>
        <p>Your support means the world to us.</p>
      </div>
    )
  },
  {
    id: 10,
    title: "Coffee Counter",
    description: "Show total coffees bought",
    code: `<div className="flex items-center gap-3 p-4 bg-slate-900 rounded-xl">
  <Coffee className="w-8 h-8 text-amber-500" />
  <div>
    <p className="text-2xl font-bold text-white">127</p>
    <p className="text-slate-400 text-sm">Coffees Bought</p>
  </div>
</div>`,
    component: () => (
      <div className="flex items-center gap-3 p-4 bg-slate-900 rounded-xl border border-slate-800">
        <Coffee className="w-8 h-8 text-amber-500" />
        <div>
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-2xl font-bold text-white">127</motion.p>
          <p className="text-slate-400 text-sm">Coffees Bought</p>
        </div>
      </div>
    )
  },
  {
    id: 11,
    title: "Crypto Donation",
    description: "Bitcoin/Ethereum donation",
    code: `<div className="p-4 bg-slate-900 rounded-xl">
  <h3 className="text-white font-bold mb-3">Crypto Donations</h3>
  <button className="w-full px-4 py-2 bg-orange-500 rounded-lg mb-2">₿ Bitcoin</button>
  <button className="w-full px-4 py-2 bg-purple-500 rounded-lg">Ξ Ethereum</button>
</div>`,
    component: () => (
      <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
        <h3 className="text-white font-bold mb-3 text-sm">Crypto Donations</h3>
        <button className="w-full px-4 py-2 bg-orange-500 hover:bg-orange-600 rounded-lg mb-2 text-white transition">₿ Bitcoin</button>
        <button className="w-full px-4 py-2 bg-purple-500 hover:bg-purple-600 rounded-lg text-white transition">Ξ Ethereum</button>
      </div>
    )
  },
  {
    id: 12,
    title: "One-Time vs Monthly",
    description: "Toggle donation frequency",
    code: `<div className="flex gap-2 mb-4">
  <button className="flex-1 px-4 py-2 bg-violet-600 rounded-lg">One-Time</button>
  <button className="flex-1 px-4 py-2 bg-slate-800 rounded-lg">Monthly</button>
</div>`,
    component: function FrequencyToggle() {
      const [mode, setMode] = useState('one-time');
      return (
        <div className="flex gap-2">
          <button onClick={() => setMode('one-time')} className={`flex-1 px-4 py-2 rounded-lg transition ${mode === 'one-time' ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}>One-Time</button>
          <button onClick={() => setMode('monthly')} className={`flex-1 px-4 py-2 rounded-lg transition ${mode === 'monthly' ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}>Monthly</button>
        </div>
      );
    }
  },
  {
    id: 13,
    title: "Supporter Wall",
    description: "Show recent supporters",
    code: `<div className="p-4 bg-slate-900 rounded-xl">
  <h3 className="text-white font-bold mb-3">Recent Supporters</h3>
  {supporters.map(s => (
    <div key={s.id} className="flex items-center gap-2 mb-2">
      <div className="w-8 h-8 rounded-full bg-violet-500" />
      <span className="text-white text-sm">{s.name}</span>
    </div>
  ))}
</div>`,
    component: () => (
      <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
        <h3 className="text-white font-bold mb-3 text-sm">Recent Supporters ❤️</h3>
        {['Alice', 'Bob', 'Charlie'].map((name, i) => (
          <motion.div key={name} initial={{ x: -20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: i * 0.1 }} className="flex items-center gap-2 mb-2">
            <div className={`w-6 h-6 rounded-full ${i === 0 ? 'bg-violet-500' : i === 1 ? 'bg-pink-500' : 'bg-cyan-500'}`} />
            <span className="text-white text-xs">{name}</span>
          </motion.div>
        ))}
      </div>
    )
  },
  {
    id: 14,
    title: "Custom Amount Input",
    description: "Enter custom donation amount",
    code: `<div className="space-y-2">
  <label className="text-white">Enter Amount</label>
  <input type="number" placeholder="$10" className="w-full px-4 py-2 bg-slate-800 rounded-lg text-white" />
  <button className="w-full px-4 py-2 bg-green-600 rounded-lg">Donate</button>
</div>`,
    component: () => (
      <div className="space-y-2">
        <label className="text-white text-sm">Enter Amount</label>
        <input type="number" placeholder="$10" className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white" />
        <button className="w-full px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg text-white transition">Donate</button>
      </div>
    )
  },
  {
    id: 15,
    title: "Animated Coffee Cup",
    description: "Filling coffee animation",
    code: `<div className="relative w-24 h-32 bg-amber-100 rounded-b-2xl">
  <div className="absolute bottom-0 w-full bg-amber-600 rounded-b-2xl transition-all" style={{height: '70%'}} />
</div>`,
    component: () => (
      <div className="relative w-20 h-28 bg-amber-100 rounded-b-2xl border-2 border-amber-300">
        <motion.div initial={{ height: 0 }} animate={{ height: '70%' }} transition={{ duration: 2 }} className="absolute bottom-0 w-full bg-amber-600 rounded-b-2xl" />
      </div>
    )
  },
  {
    id: 16,
    title: "PayPal Button",
    description: "PayPal integration style",
    code: `<button className="w-full px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg text-white font-bold">
  Pay with PayPal
</button>`,
    component: () => (
      <button className="w-full px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg text-white font-bold transition">
        Pay with PayPal
      </button>
    )
  },
  {
    id: 17,
    title: "Stripe Card",
    description: "Stripe-style donation card",
    code: `<div className="p-6 bg-white rounded-xl border border-gray-300">
  <h3 className="text-gray-900 font-bold mb-4">Support the Project</h3>
  <input placeholder="Card Number" className="w-full px-4 py-2 border rounded mb-2" />
  <button className="w-full px-4 py-2 bg-black text-white rounded">Donate</button>
</div>`,
    component: () => (
      <div className="p-6 bg-white rounded-xl border border-gray-300">
        <h3 className="text-gray-900 font-bold mb-4 text-sm">Support the Project</h3>
        <input placeholder="Card Number" className="w-full px-4 py-2 border rounded mb-2 text-sm" />
        <button className="w-full px-4 py-2 bg-black text-white rounded hover:bg-gray-800 transition text-sm">Donate</button>
      </div>
    )
  },
  {
    id: 18,
    title: "GitHub Sponsors Style",
    description: "GitHub-inspired sponsor button",
    code: `<button className="flex items-center gap-2 px-4 py-2 bg-pink-600 hover:bg-pink-700 rounded-md text-white">
  <Heart className="w-4 h-4" />
  Sponsor
</button>`,
    component: () => (
      <button className="flex items-center gap-2 px-4 py-2 bg-pink-600 hover:bg-pink-700 rounded-md text-white transition">
        <Heart className="w-4 h-4" />
        Sponsor
      </button>
    )
  },
  {
    id: 19,
    title: "Ko-fi Style",
    description: "Ko-fi inspired design",
    code: `<button className="px-6 py-3 bg-[#FF5E5B] hover:bg-[#FF4744] rounded-lg text-white font-bold">
  ☕ Support me on Ko-fi
</button>`,
    component: () => (
      <button className="px-6 py-3 bg-[#FF5E5B] hover:bg-[#FF4744] rounded-lg text-white font-bold transition">
        ☕ Support me on Ko-fi
      </button>
    )
  },
  {
    id: 20,
    title: "Confetti Celebration",
    description: "Confetti after donation",
    code: `<button onClick={triggerConfetti} className="px-6 py-3 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-lg text-white font-bold">
  🎉 Celebrate with Us!
</button>`,
    component: function ConfettiButton() {
      const [celebrate, setCelebrate] = useState(false);
      return (
        <button onClick={() => setCelebrate(true)} className="px-6 py-3 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-lg text-white font-bold hover:scale-105 transition">
          🎉 Celebrate with Us!
        </button>
      );
    }
  },
  {
    id: 21,
    title: "Social Proof Counter",
    description: "Show supporter count",
    code: `<div className="flex items-center gap-2 px-4 py-2 bg-slate-900 rounded-full">
  <div className="flex -space-x-2">
    {[1,2,3].map(i => (
      <div key={i} className="w-8 h-8 rounded-full bg-violet-500 border-2 border-slate-900" />
    ))}
  </div>
  <span className="text-white">+127 supporters</span>
</div>`,
    component: () => (
      <div className="flex items-center gap-2 px-4 py-2 bg-slate-900 rounded-full border border-slate-800">
        <div className="flex -space-x-2">
          {[1,2,3].map(i => (
            <div key={i} className={`w-6 h-6 rounded-full border-2 border-slate-900 ${i === 1 ? 'bg-violet-500' : i === 2 ? 'bg-pink-500' : 'bg-cyan-500'}`} />
          ))}
        </div>
        <span className="text-white text-xs">+127 supporters</span>
      </div>
    )
  },
  {
    id: 22,
    title: "Minimal Text Link",
    description: "Simple underlined link",
    code: `<a href="#" className="text-violet-400 hover:text-violet-300 underline">
  Buy me a coffee ☕
</a>`,
    component: () => (
      <a href="#" className="text-violet-400 hover:text-violet-300 underline transition">
        Buy me a coffee ☕
      </a>
    )
  },
  {
    id: 23,
    title: "Badge with Stats",
    description: "Donation badge with metrics",
    code: `<div className="inline-flex items-center gap-2 px-3 py-1 bg-green-500/20 border border-green-500 rounded-full">
  <span className="text-green-400 text-sm">✓ Funded</span>
  <span className="text-green-300 text-xs">120%</span>
</div>`,
    component: () => (
      <div className="inline-flex items-center gap-2 px-3 py-1 bg-green-500/20 border border-green-500 rounded-full">
        <span className="text-green-400 text-sm">✓ Funded</span>
        <span className="text-green-300 text-xs">120%</span>
      </div>
    )
  },
  {
    id: 24,
    title: "QR Code Donation",
    description: "QR code for mobile donations",
    code: `<div className="p-4 bg-slate-900 rounded-xl text-center">
  <div className="w-32 h-32 bg-white mx-auto mb-2" />
  <p className="text-slate-400 text-sm">Scan to donate</p>
</div>`,
    component: () => (
      <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 text-center">
        <div className="w-24 h-24 bg-gradient-to-br from-violet-500 to-pink-500 mx-auto mb-2 rounded" />
        <p className="text-slate-400 text-xs">Scan to donate</p>
      </div>
    )
  },
  {
    id: 25,
    title: "Subscription Card",
    description: "Monthly subscription option",
    code: `<div className="p-6 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl text-white">
  <h3 className="text-xl font-bold mb-2">Premium Supporter</h3>
  <p className="text-3xl font-bold mb-4">$10<span className="text-sm">/mo</span></p>
  <button className="w-full px-4 py-2 bg-white text-indigo-600 rounded-lg font-bold">Subscribe</button>
</div>`,
    component: () => (
      <div className="p-6 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl text-white max-w-xs">
        <h3 className="text-lg font-bold mb-2">Premium Supporter</h3>
        <p className="text-2xl font-bold mb-4">$10<span className="text-sm">/mo</span></p>
        <button className="w-full px-4 py-2 bg-white text-indigo-600 rounded-lg font-bold hover:bg-gray-100 transition">Subscribe</button>
      </div>
    )
  },
  {
    id: 26,
    title: "Gift Icon Button",
    description: "Gift-themed donation",
    code: `<button className="flex items-center gap-2 px-6 py-3 bg-rose-500 hover:bg-rose-600 rounded-lg text-white">
  <Gift className="w-5 h-5" />
  Send a Gift
</button>`,
    component: () => (
      <button className="flex items-center gap-2 px-6 py-3 bg-rose-500 hover:bg-rose-600 rounded-lg text-white transition">
        <Gift className="w-5 h-5" />
        Send a Gift
      </button>
    )
  },
  {
    id: 27,
    title: "Impact Statement",
    description: "Show donation impact",
    code: `<div className="p-4 bg-slate-900 rounded-xl">
  <p className="text-white font-bold mb-2">Your $5 donation will:</p>
  <ul className="text-slate-400 text-sm space-y-1">
    <li>✓ Host the server for 1 day</li>
    <li>✓ Support 100 users</li>
    <li>✓ Keep the lights on!</li>
  </ul>
</div>`,
    component: () => (
      <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
        <p className="text-white font-bold mb-2 text-sm">Your $5 donation will:</p>
        <ul className="text-slate-400 text-xs space-y-1">
          <li>✓ Host the server for 1 day</li>
          <li>✓ Support 100 users</li>
          <li>✓ Keep the lights on!</li>
        </ul>
      </div>
    )
  },
  {
    id: 28,
    title: "Sliding Donate Bar",
    description: "Slide-in donation prompt",
    code: `<div className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-violet-600 to-pink-600 p-4">
  <div className="flex items-center justify-between max-w-4xl mx-auto">
    <p className="text-white">Enjoying this? Consider supporting us!</p>
    <button className="px-6 py-2 bg-white text-violet-600 rounded-lg font-bold">Donate</button>
  </div>
</div>`,
    component: () => (
      <motion.div initial={{ y: 50 }} animate={{ y: 0 }} className="w-full bg-gradient-to-r from-violet-600 to-pink-600 p-4 rounded-xl">
        <div className="flex items-center justify-between">
          <p className="text-white text-sm">Enjoying this? Support us!</p>
          <button className="px-4 py-1 bg-white text-violet-600 rounded-lg font-bold text-sm hover:bg-gray-100 transition">Donate</button>
        </div>
      </motion.div>
    )
  },
  {
    id: 29,
    title: "Dollar Sign Icon",
    description: "Simple dollar donation button",
    code: `<button className="flex items-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 rounded-lg text-white font-bold">
  <DollarSign className="w-5 h-5" />
  Contribute
</button>`,
    component: () => (
      <button className="flex items-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 rounded-lg text-white font-bold transition">
        <DollarSign className="w-5 h-5" />
        Contribute
      </button>
    )
  },
  {
    id: 30,
    title: "Animated Pulse Button",
    description: "Pulsing attention-grabbing button",
    code: `<button className="relative px-6 py-3 bg-red-500 rounded-lg text-white font-bold">
  Donate Now
  <span className="absolute inset-0 rounded-lg bg-red-500 animate-ping opacity-75" />
</button>`,
    component: () => (
      <div className="relative">
        <button className="relative z-10 px-6 py-3 bg-red-500 hover:bg-red-600 rounded-lg text-white font-bold transition">
          Donate Now
        </button>
        <motion.span animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }} transition={{ duration: 2, repeat: Infinity }} className="absolute inset-0 rounded-lg bg-red-500" />
      </div>
    )
  }
];

export default function DonationComponents() {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredComponents = donationComponents.filter(comp =>
    comp.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    comp.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-950">
      <CategoryHeader
        icon={Coffee}
        title="Donation Components"
        description="30 donation and Buy Me a Coffee components ready to use"
        gradient="rgb(245, 158, 11), rgb(234, 88, 12)"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="mb-8">
          <input
            type="text"
            placeholder="Search donation components..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {filteredComponents.map(comp => {
            const PreviewComponent = comp.component;
            return (
              <EffectCard
                key={comp.id}
                title={comp.title}
                description={comp.description}
                code={comp.code}
              >
                <PreviewComponent />
              </EffectCard>
            );
          })}
        </div>
      </div>
    </div>
  );
}