import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ShoppingCart, CreditCard, Truck, Package, MapPin, Gift, Percent, ChevronRight, Plus, Minus, Trash2, Check, Lock, Shield, Clock, ArrowLeft, Wallet, Banknote, Building, Star, Tag } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// Cart Item Row
function CartItemEffect() {
  const [qty, setQty] = useState(2);
  return (
    <EffectCard title="Cart Item Row" description="Product in cart with controls" whenToUse="Shopping cart, order summary.">
      <div className="flex gap-4 p-3 bg-slate-800 rounded-xl w-full">
        <div className="w-20 h-20 bg-gradient-to-br from-violet-500/30 to-pink-500/30 rounded-lg flex-shrink-0" />
        <div className="flex-1">
          <div className="flex justify-between mb-1">
            <h4 className="text-white font-medium text-sm">Premium Widget Pro</h4>
            <button className="text-slate-500 hover:text-red-400"><Trash2 className="w-4 h-4" /></button>
          </div>
          <p className="text-slate-500 text-xs mb-2">Color: Midnight Blue • Size: Large</p>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button onClick={() => setQty(Math.max(1, qty - 1))} className="w-7 h-7 bg-slate-700 rounded flex items-center justify-center"><Minus className="w-3 h-3 text-white" /></button>
              <span className="text-white w-6 text-center">{qty}</span>
              <button onClick={() => setQty(qty + 1)} className="w-7 h-7 bg-slate-700 rounded flex items-center justify-center"><Plus className="w-3 h-3 text-white" /></button>
            </div>
            <span className="text-white font-bold">${(79.99 * qty).toFixed(2)}</span>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Order Summary
function OrderSummaryEffect() {
  return (
    <EffectCard title="Order Summary" description="Price breakdown card" whenToUse="Cart, checkout pages.">
      <div className="w-full bg-slate-800 rounded-xl p-4 space-y-3">
        <h4 className="text-white font-medium">Order Summary</h4>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between"><span className="text-slate-400">Subtotal (3 items)</span><span className="text-white">$239.97</span></div>
          <div className="flex justify-between"><span className="text-slate-400">Shipping</span><span className="text-green-400">Free</span></div>
          <div className="flex justify-between"><span className="text-slate-400">Tax</span><span className="text-white">$19.20</span></div>
          <div className="flex justify-between text-violet-400"><span>Discount (SAVE20)</span><span>-$47.99</span></div>
        </div>
        <div className="border-t border-slate-700 pt-3 flex justify-between">
          <span className="text-white font-medium">Total</span>
          <span className="text-white text-xl font-bold">$211.18</span>
        </div>
        <button className="w-full py-3 bg-violet-500 rounded-lg text-white font-medium flex items-center justify-center gap-2">
          <Lock className="w-4 h-4" /> Secure Checkout
        </button>
      </div>
    </EffectCard>
  );
}

// Checkout Steps
function CheckoutStepsEffect() {
  const [step, setStep] = useState(1);
  const steps = ["Cart", "Shipping", "Payment", "Confirm"];
  return (
    <EffectCard title="Checkout Steps" description="Multi-step progress" whenToUse="Checkout flow, wizards.">
      <div className="w-full">
        <div className="flex items-center justify-between mb-4">
          {steps.map((s, i) => (
            <React.Fragment key={s}>
              <motion.button onClick={() => setStep(i)} animate={{ scale: i === step ? 1.1 : 1 }} className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium ${i < step ? "bg-green-500 text-white" : i === step ? "bg-violet-500 text-white" : "bg-slate-700 text-slate-400"}`}>
                {i < step ? <Check className="w-4 h-4" /> : i + 1}
              </motion.button>
              {i < steps.length - 1 && <div className={`flex-1 h-1 mx-2 rounded ${i < step ? "bg-green-500" : "bg-slate-700"}`} />}
            </React.Fragment>
          ))}
        </div>
        <div className="flex justify-between text-xs text-slate-500">
          {steps.map((s, i) => <span key={s} className={i === step ? "text-violet-400" : ""}>{s}</span>)}
        </div>
      </div>
    </EffectCard>
  );
}

// Payment Method Selector
function PaymentMethodEffect() {
  const [method, setMethod] = useState("card");
  const methods = [
    { id: "card", icon: CreditCard, label: "Credit Card" },
    { id: "paypal", icon: Wallet, label: "PayPal" },
    { id: "apple", icon: Wallet, label: "Apple Pay" },
    { id: "bank", icon: Building, label: "Bank Transfer" }
  ];
  return (
    <EffectCard title="Payment Methods" description="Payment option selector" whenToUse="Checkout payment selection.">
      <div className="grid grid-cols-2 gap-2 w-full">
        {methods.map(m => (
          <motion.button key={m.id} onClick={() => setMethod(m.id)} whileHover={{ scale: 1.02 }} className={`p-3 rounded-lg flex items-center gap-2 ${method === m.id ? "bg-violet-500/20 border-2 border-violet-500" : "bg-slate-800 border-2 border-transparent"}`}>
            <m.icon className={`w-5 h-5 ${method === m.id ? "text-violet-400" : "text-slate-400"}`} />
            <span className={method === m.id ? "text-white" : "text-slate-400"} style={{ fontSize: "0.8rem" }}>{m.label}</span>
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Shipping Address Card
function ShippingAddressEffect() {
  const [selected, setSelected] = useState(0);
  return (
    <EffectCard title="Shipping Address" description="Saved address selector" whenToUse="Checkout, address management.">
      <div className="space-y-2 w-full">
        {[
          { name: "Home", address: "123 Main St, San Francisco, CA 94102" },
          { name: "Work", address: "456 Market St, San Francisco, CA 94103" }
        ].map((addr, i) => (
          <motion.div key={i} onClick={() => setSelected(i)} whileHover={{ x: 4 }} className={`p-3 rounded-lg cursor-pointer ${selected === i ? "bg-violet-500/20 border border-violet-500" : "bg-slate-800 border border-transparent"}`}>
            <div className="flex items-center justify-between mb-1">
              <span className={`font-medium ${selected === i ? "text-violet-400" : "text-white"}`}>{addr.name}</span>
              {selected === i && <Check className="w-4 h-4 text-violet-400" />}
            </div>
            <p className="text-slate-500 text-xs">{addr.address}</p>
          </motion.div>
        ))}
        <button className="flex items-center gap-2 text-violet-400 text-sm"><Plus className="w-4 h-4" /> Add new address</button>
      </div>
    </EffectCard>
  );
}

// Shipping Options
function ShippingOptionsEffect() {
  const [selected, setSelected] = useState("express");
  const options = [
    { id: "standard", label: "Standard", time: "5-7 days", price: "Free" },
    { id: "express", label: "Express", time: "2-3 days", price: "$9.99" },
    { id: "overnight", label: "Overnight", time: "Next day", price: "$24.99" }
  ];
  return (
    <EffectCard title="Shipping Options" description="Delivery speed selector" whenToUse="Checkout shipping selection.">
      <div className="space-y-2 w-full">
        {options.map(opt => (
          <motion.div key={opt.id} onClick={() => setSelected(opt.id)} whileHover={{ x: 4 }} className={`p-3 rounded-lg cursor-pointer flex items-center justify-between ${selected === opt.id ? "bg-violet-500/20 border border-violet-500" : "bg-slate-800 border border-transparent"}`}>
            <div className="flex items-center gap-3">
              <Truck className={`w-5 h-5 ${selected === opt.id ? "text-violet-400" : "text-slate-500"}`} />
              <div>
                <p className={selected === opt.id ? "text-white" : "text-slate-300"}>{opt.label}</p>
                <p className="text-slate-500 text-xs">{opt.time}</p>
              </div>
            </div>
            <span className={`font-medium ${opt.price === "Free" ? "text-green-400" : "text-white"}`}>{opt.price}</span>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Credit Card Input
function CreditCardInputEffect() {
  return (
    <EffectCard title="Credit Card Input" description="Card number with formatting" whenToUse="Payment forms, checkout.">
      <div className="w-full space-y-3">
        <div>
          <label className="text-slate-400 text-xs mb-1 block">Card Number</label>
          <div className="flex items-center gap-2 px-3 py-2 bg-slate-800 rounded-lg border border-slate-700">
            <CreditCard className="w-5 h-5 text-slate-400" />
            <input type="text" placeholder="4242 4242 4242 4242" className="flex-1 bg-transparent text-white outline-none font-mono" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-slate-400 text-xs mb-1 block">Expiry</label>
            <input type="text" placeholder="MM/YY" className="w-full px-3 py-2 bg-slate-800 rounded-lg border border-slate-700 text-white outline-none font-mono" />
          </div>
          <div>
            <label className="text-slate-400 text-xs mb-1 block">CVC</label>
            <input type="text" placeholder="123" className="w-full px-3 py-2 bg-slate-800 rounded-lg border border-slate-700 text-white outline-none font-mono" />
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Promo Code Applied
function PromoAppliedEffect() {
  return (
    <EffectCard title="Promo Applied" description="Discount code badge" whenToUse="Cart summary, checkout.">
      <div className="flex items-center justify-between p-3 bg-green-500/10 border border-green-500/30 rounded-lg w-full">
        <div className="flex items-center gap-2">
          <Tag className="w-5 h-5 text-green-400" />
          <div>
            <span className="text-green-400 font-mono font-medium">SAVE20</span>
            <span className="text-slate-400 text-sm ml-2">20% off applied</span>
          </div>
        </div>
        <button className="text-slate-400 hover:text-red-400 text-sm">Remove</button>
      </div>
    </EffectCard>
  );
}

// Trust Badges
function TrustBadgesEffect() {
  return (
    <EffectCard title="Trust Badges" description="Security and trust indicators" whenToUse="Checkout footer, payment area.">
      <div className="flex items-center justify-center gap-6 text-slate-500">
        <div className="flex items-center gap-1 text-xs"><Lock className="w-4 h-4" /> SSL Secure</div>
        <div className="flex items-center gap-1 text-xs"><Shield className="w-4 h-4" /> Buyer Protection</div>
        <div className="flex items-center gap-1 text-xs"><Truck className="w-4 h-4" /> Free Returns</div>
      </div>
    </EffectCard>
  );
}

// Empty Cart
function EmptyCartEffect() {
  return (
    <EffectCard title="Empty Cart" description="No items state" whenToUse="Cart page when empty.">
      <div className="text-center py-8">
        <motion.div animate={{ y: [0, -8, 0] }} transition={{ duration: 2, repeat: Infinity }} className="w-20 h-20 bg-slate-800 rounded-full mx-auto mb-4 flex items-center justify-center">
          <ShoppingCart className="w-10 h-10 text-slate-600" />
        </motion.div>
        <h3 className="text-white font-medium mb-1">Your cart is empty</h3>
        <p className="text-slate-500 text-sm mb-4">Looks like you haven't added anything yet</p>
        <button className="px-6 py-2 bg-violet-500 rounded-lg text-white text-sm">Start Shopping</button>
      </div>
    </EffectCard>
  );
}

// Order Confirmation
function OrderConfirmationEffect() {
  return (
    <EffectCard title="Order Confirmation" description="Success state with order details" whenToUse="Post-checkout confirmation.">
      <div className="text-center w-full">
        <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring" }} className="w-16 h-16 bg-green-500 rounded-full mx-auto mb-4 flex items-center justify-center">
          <Check className="w-8 h-8 text-white" />
        </motion.div>
        <h3 className="text-white text-xl font-bold mb-1">Order Confirmed!</h3>
        <p className="text-slate-400 text-sm mb-4">Order #12345 • Confirmation sent to email</p>
        <div className="bg-slate-800 rounded-lg p-4 text-left">
          <div className="flex items-center gap-3 text-sm">
            <Truck className="w-5 h-5 text-violet-400" />
            <div>
              <p className="text-white">Estimated delivery</p>
              <p className="text-slate-400">Dec 8-10, 2024</p>
            </div>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Mini Cart Dropdown
function MiniCartEffect() {
  const [open, setOpen] = useState(false);
  return (
    <EffectCard title="Mini Cart" description="Header cart dropdown" whenToUse="Navigation cart preview.">
      <div className="relative">
        <button onClick={() => setOpen(!open)} className="relative p-3 bg-slate-800 rounded-lg">
          <ShoppingCart className="w-6 h-6 text-white" />
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-violet-500 rounded-full text-white text-xs flex items-center justify-center">3</span>
        </button>
        <AnimatePresence>
          {open && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }} className="absolute top-full right-0 mt-2 w-72 bg-slate-800 rounded-xl shadow-xl border border-slate-700 p-4 z-10">
              <div className="space-y-3 mb-4">
                {[1, 2].map(i => (
                  <div key={i} className="flex gap-3">
                    <div className="w-12 h-12 bg-slate-700 rounded-lg" />
                    <div className="flex-1">
                      <p className="text-white text-sm">Product {i}</p>
                      <p className="text-slate-400 text-xs">Qty: 1</p>
                    </div>
                    <span className="text-white text-sm">$79.99</span>
                  </div>
                ))}
              </div>
              <div className="border-t border-slate-700 pt-3">
                <div className="flex justify-between mb-3">
                  <span className="text-slate-400">Subtotal</span>
                  <span className="text-white font-bold">$159.98</span>
                </div>
                <button className="w-full py-2 bg-violet-500 rounded-lg text-white text-sm font-medium">Checkout</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Saved for Later
function SavedForLaterEffect() {
  return (
    <EffectCard title="Saved for Later" description="Wishlist in cart section" whenToUse="Cart page secondary items.">
      <div className="w-full">
        <h4 className="text-slate-400 text-sm mb-3">Saved for later (2)</h4>
        <div className="flex gap-3">
          {[1, 2].map(i => (
            <div key={i} className="flex-1 bg-slate-800 rounded-lg p-3">
              <div className="h-16 bg-slate-700 rounded-lg mb-2" />
              <p className="text-white text-xs truncate">Product Name</p>
              <p className="text-violet-400 text-sm font-bold">$49.99</p>
              <button className="mt-2 text-xs text-violet-400">Move to Cart</button>
            </div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Gift Wrap Option
function GiftWrapEffect() {
  const [gift, setGift] = useState(false);
  return (
    <EffectCard title="Gift Wrap Option" description="Add gift wrapping toggle" whenToUse="Cart, checkout options.">
      <motion.div onClick={() => setGift(!gift)} whileHover={{ scale: 1.02 }} className={`flex items-center gap-4 p-4 rounded-xl cursor-pointer w-full ${gift ? "bg-violet-500/20 border border-violet-500" : "bg-slate-800 border border-transparent"}`}>
        <Gift className={`w-8 h-8 ${gift ? "text-violet-400" : "text-slate-500"}`} />
        <div className="flex-1">
          <p className={gift ? "text-white" : "text-slate-300"}>Add gift wrapping</p>
          <p className="text-slate-500 text-xs">Include a personal message</p>
        </div>
        <span className="text-white font-medium">+$4.99</span>
      </motion.div>
    </EffectCard>
  );
}

// Estimated Delivery
function EstimatedDeliveryEffect() {
  return (
    <EffectCard title="Estimated Delivery" description="Delivery date preview" whenToUse="Cart, checkout, product page.">
      <div className="flex items-center gap-4 p-4 bg-slate-800 rounded-xl w-full">
        <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
          <Truck className="w-6 h-6 text-green-400" />
        </div>
        <div>
          <p className="text-green-400 font-medium">Free Delivery</p>
          <p className="text-slate-400 text-sm">Estimated: <span className="text-white">Dec 8-10</span></p>
        </div>
      </div>
    </EffectCard>
  );
}

// Quantity Stepper
function QuantityStepperEffect() {
  const [qty, setQty] = useState(1);
  return (
    <EffectCard title="Quantity Stepper" description="Inline quantity control" whenToUse="Product pages, cart items.">
      <div className="flex items-center">
        <button onClick={() => setQty(Math.max(1, qty - 1))} className="w-12 h-12 bg-slate-800 rounded-l-lg flex items-center justify-center border border-slate-700 hover:bg-slate-700">
          <Minus className="w-4 h-4 text-white" />
        </button>
        <div className="w-16 h-12 bg-slate-900 flex items-center justify-center border-y border-slate-700">
          <motion.span key={qty} initial={{ scale: 0.5 }} animate={{ scale: 1 }} className="text-white font-bold">{qty}</motion.span>
        </div>
        <button onClick={() => setQty(qty + 1)} className="w-12 h-12 bg-slate-800 rounded-r-lg flex items-center justify-center border border-slate-700 hover:bg-slate-700">
          <Plus className="w-4 h-4 text-white" />
        </button>
      </div>
    </EffectCard>
  );
}

// Order Timeline
function OrderTimelineEffect() {
  return (
    <EffectCard title="Order Timeline" description="Order status tracking" whenToUse="Order details, tracking page.">
      <div className="space-y-4 w-full">
        {[
          { status: "Order placed", time: "Dec 2, 10:30 AM", done: true },
          { status: "Payment confirmed", time: "Dec 2, 10:31 AM", done: true },
          { status: "Shipped", time: "Dec 3, 2:15 PM", done: true },
          { status: "Out for delivery", time: "Pending", done: false },
          { status: "Delivered", time: "", done: false }
        ].map((step, i, arr) => (
          <div key={i} className="flex gap-4">
            <div className="flex flex-col items-center">
              <div className={`w-4 h-4 rounded-full ${step.done ? "bg-green-500" : "bg-slate-700"}`} />
              {i < arr.length - 1 && <div className={`w-0.5 flex-1 ${step.done ? "bg-green-500" : "bg-slate-700"}`} />}
            </div>
            <div className="pb-4">
              <p className={step.done ? "text-white" : "text-slate-500"}>{step.status}</p>
              <p className="text-slate-500 text-xs">{step.time}</p>
            </div>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Checkout Button
function CheckoutButtonEffect() {
  const [loading, setLoading] = useState(false);
  return (
    <EffectCard title="Checkout Button" description="Primary checkout CTA" whenToUse="Cart, checkout pages.">
      <motion.button onClick={() => { setLoading(true); setTimeout(() => setLoading(false), 2000); }} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} disabled={loading} className="w-full py-4 bg-gradient-to-r from-violet-500 to-pink-500 rounded-xl text-white font-bold flex items-center justify-center gap-2">
        {loading ? (
          <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-5 h-5 border-2 border-white border-t-transparent rounded-full" />
        ) : (
          <>
            <Lock className="w-5 h-5" />
            Complete Order • $211.18
          </>
        )}
      </motion.button>
    </EffectCard>
  );
}

// Express Checkout
function ExpressCheckoutEffect() {
  return (
    <EffectCard title="Express Checkout" description="Quick payment options" whenToUse="Cart page top section.">
      <div className="w-full space-y-2">
        <p className="text-slate-500 text-xs text-center mb-3">Express checkout</p>
        <div className="flex gap-2">
          <button className="flex-1 py-3 bg-black rounded-lg flex items-center justify-center gap-2">
            <Wallet className="w-5 h-5 text-white" />
            <span className="text-white font-medium">Pay</span>
          </button>
          <button className="flex-1 py-3 bg-amber-400 rounded-lg flex items-center justify-center">
            <span className="text-slate-900 font-bold">PayPal</span>
          </button>
        </div>
        <div className="flex items-center gap-2 text-slate-500 text-xs">
          <div className="flex-1 h-px bg-slate-700" />
          <span>or continue below</span>
          <div className="flex-1 h-px bg-slate-700" />
        </div>
      </div>
    </EffectCard>
  );
}

// Billing Toggle
function BillingSameToggleEffect() {
  const [same, setSame] = useState(true);
  return (
    <EffectCard title="Billing Address Toggle" description="Same as shipping checkbox" whenToUse="Checkout billing section.">
      <motion.div onClick={() => setSame(!same)} whileHover={{ x: 2 }} className="flex items-center gap-3 p-3 bg-slate-800 rounded-lg cursor-pointer w-full">
        <div className={`w-5 h-5 rounded border-2 flex items-center justify-center ${same ? "bg-violet-500 border-violet-500" : "border-slate-500"}`}>
          {same && <Check className="w-3 h-3 text-white" />}
        </div>
        <span className="text-white text-sm">Billing address same as shipping</span>
      </motion.div>
    </EffectCard>
  );
}

// Recently Viewed
function RecentlyViewedEffect() {
  return (
    <EffectCard title="Recently Viewed" description="Product recommendations" whenToUse="Cart page footer.">
      <div className="w-full">
        <h4 className="text-white font-medium mb-3">Recently Viewed</h4>
        <div className="flex gap-3 overflow-x-auto pb-2">
          {[1, 2, 3, 4].map(i => (
            <motion.div key={i} whileHover={{ y: -4 }} className="flex-shrink-0 w-28">
              <div className="h-28 bg-slate-800 rounded-lg mb-2" />
              <p className="text-slate-400 text-xs truncate">Product Name</p>
              <p className="text-white text-sm font-medium">$49.99</p>
            </motion.div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

export default function CartCheckout() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <CartItemEffect />, name: "Cart Item Row" },
    { component: <OrderSummaryEffect />, name: "Order Summary" },
    { component: <CheckoutStepsEffect />, name: "Checkout Steps" },
    { component: <PaymentMethodEffect />, name: "Payment Methods" },
    { component: <ShippingAddressEffect />, name: "Shipping Address" },
    { component: <ShippingOptionsEffect />, name: "Shipping Options" },
    { component: <CreditCardInputEffect />, name: "Credit Card Input" },
    { component: <PromoAppliedEffect />, name: "Promo Applied" },
    { component: <TrustBadgesEffect />, name: "Trust Badges" },
    { component: <EmptyCartEffect />, name: "Empty Cart" },
    { component: <OrderConfirmationEffect />, name: "Order Confirmation" },
    { component: <MiniCartEffect />, name: "Mini Cart" },
    { component: <SavedForLaterEffect />, name: "Saved for Later" },
    { component: <GiftWrapEffect />, name: "Gift Wrap Option" },
    { component: <EstimatedDeliveryEffect />, name: "Estimated Delivery" },
    { component: <QuantityStepperEffect />, name: "Quantity Stepper" },
    { component: <OrderTimelineEffect />, name: "Order Timeline" },
    { component: <CheckoutButtonEffect />, name: "Checkout Button" },
    { component: <ExpressCheckoutEffect />, name: "Express Checkout" },
    { component: <BillingSameToggleEffect />, name: "Billing Toggle" },
    { component: <RecentlyViewedEffect />, name: "Recently Viewed" },
  ];

  const filtered = effects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={ShoppingCart} title="Cart & Checkout" description="25 components for shopping carts, checkout flows, and order management" gradient="#f59e0b, #f97316" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((effect, i) => <motion.div key={effect.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>{effect.component}</motion.div>)}
        </div>
      </div>
    </div>
  );
}