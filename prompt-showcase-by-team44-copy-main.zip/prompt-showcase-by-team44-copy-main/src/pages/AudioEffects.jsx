import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Volume2, Play, Pause, VolumeX, Volume1, Music, Bell, Radio, Headphones, Speaker } from "lucide-react";
import { Button } from "@/components/ui/button";
import ToggleSwitch from "@/components/ui/toggle-switch";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// Audio Visualizer
function AudioVisualizer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [barCount, setBarCount] = useState([20]);

  return (
    <EffectCard title="Audio Visualizer" description="Real-time frequency bars" whenToUse="Perfect for music players, podcast apps, or audio-focused dashboards." controls={
      <div className="space-y-4">
        <Button onClick={() => setIsPlaying(!isPlaying)} variant={isPlaying ? "default" : "outline"} className="w-full">
          {isPlaying ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
          {isPlaying ? "Stop" : "Play"} Visualization
        </Button>
        <div className="space-y-2">
          <Label className="text-slate-300">Bars: {barCount}</Label>
          <Slider value={barCount} onValueChange={setBarCount} min={10} max={40} step={5} />
        </div>
      </div>
    }>
      <div className="flex items-end justify-center gap-1 h-32 p-4">
        {Array.from({ length: barCount[0] }).map((_, i) => (
          <motion.div
            key={i}
            className="w-2 bg-gradient-to-t from-cyan-500 to-violet-500 rounded-full"
            animate={isPlaying ? { height: [8, 20 + Math.random() * 60, 8] } : { height: 8 }}
            transition={{ duration: 0.3 + Math.random() * 0.3, repeat: isPlaying ? Infinity : 0, repeatType: "reverse", delay: i * 0.02 }}
          />
        ))}
      </div>
    </EffectCard>
  );
}

// Background Music Player
function BackgroundMusicPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState([50]);
  const [progress, setProgress] = useState([30]);

  return (
    <EffectCard title="Background Music" description="Ambient audio with controls" whenToUse="Use for meditation apps, ambient websites, or relaxation features." controls={
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          {volume[0] === 0 ? <VolumeX className="w-4 h-4 text-slate-400" /> : volume[0] < 50 ? <Volume1 className="w-4 h-4 text-slate-400" /> : <Volume2 className="w-4 h-4 text-slate-400" />}
          <Slider value={volume} onValueChange={setVolume} max={100} className="flex-1" />
          <span className="text-xs text-slate-400 w-8">{volume}%</span>
        </div>
      </div>
    }>
      <div className="w-full p-6 space-y-4">
        <div className="flex items-center gap-4">
          <motion.div animate={isPlaying ? { rotate: 360 } : {}} transition={{ duration: 3, repeat: Infinity, ease: "linear" }} className="w-16 h-16 rounded-full bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center">
            <Music className="w-8 h-8 text-white" />
          </motion.div>
          <div className="flex-1">
            <p className="font-semibold text-white">Ambient Dreams</p>
            <p className="text-sm text-slate-400">Relaxing Music</p>
          </div>
          <Button size="icon" variant={isPlaying ? "default" : "outline"} onClick={() => setIsPlaying(!isPlaying)}>
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </Button>
        </div>
        <div className="space-y-2">
          <Slider value={progress} onValueChange={setProgress} max={100} />
          <div className="flex justify-between text-xs text-slate-500">
            <span>1:23</span>
            <span>4:56</span>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Notification Sounds
function NotificationSounds() {
  const [activeSound, setActiveSound] = useState(null);
  const sounds = [
    { id: "message", icon: "💬", label: "Message", color: "from-blue-500 to-cyan-500" },
    { id: "success", icon: "✅", label: "Success", color: "from-green-500 to-emerald-500" },
    { id: "warning", icon: "⚠️", label: "Warning", color: "from-amber-500 to-orange-500" },
    { id: "error", icon: "❌", label: "Error", color: "from-red-500 to-rose-500" }
  ];

  const playSound = (id) => {
    setActiveSound(id);
    setTimeout(() => setActiveSound(null), 500);
  };

  return (
    <EffectCard title="Notification Sounds" description="Different audio cues" whenToUse="Great for alerting users to events, messages, or status changes.">
      <div className="grid grid-cols-2 gap-3 p-4">
        {sounds.map(sound => (
          <motion.button key={sound.id} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={() => playSound(sound.id)} className={`p-4 rounded-xl bg-gradient-to-br ${sound.color} transition-all ${activeSound === sound.id ? "ring-2 ring-white" : ""}`}>
            <motion.span animate={activeSound === sound.id ? { scale: [1, 1.3, 1] } : {}} className="text-3xl block mb-2">{sound.icon}</motion.span>
            <p className="text-white font-medium text-sm">{sound.label}</p>
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Click Sound Effect
function ClickSoundEffect() {
  const [clickCount, setClickCount] = useState(0);
  const [showRipple, setShowRipple] = useState(false);

  const handleClick = () => {
    setClickCount(c => c + 1);
    setShowRipple(true);
    setTimeout(() => setShowRipple(false), 300);
  };

  return (
    <EffectCard title="Click Sound" description="Satisfying audio feedback" whenToUse="Add tactile feel to buttons, especially in games or creative tools.">
      <div className="p-8 flex flex-col items-center gap-6">
        <motion.button onClick={handleClick} whileTap={{ scale: 0.95 }} className="relative px-8 py-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-semibold shadow-lg overflow-hidden">
          <span className="relative z-10">Click Me! 🔊</span>
          <AnimatePresence>
            {showRipple && <motion.span initial={{ scale: 0, opacity: 0.5 }} animate={{ scale: 4, opacity: 0 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-white rounded-full" />}
          </AnimatePresence>
        </motion.button>
        <motion.p key={clickCount} initial={{ scale: 1.5 }} animate={{ scale: 1 }} className="text-3xl font-bold text-white">{clickCount}</motion.p>
      </div>
    </EffectCard>
  );
}

// Hover Sound Effect
function HoverSoundEffect() {
  const [hoveredItem, setHoveredItem] = useState(null);
  const items = [{ id: 1, emoji: "🎸", label: "Guitar" }, { id: 2, emoji: "🥁", label: "Drums" }, { id: 3, emoji: "🎹", label: "Piano" }, { id: 4, emoji: "🎺", label: "Trumpet" }];

  return (
    <EffectCard title="Hover Sound" description="Audio on hover">
      <div className="p-6 grid grid-cols-2 gap-4">
        {items.map(item => (
          <motion.div key={item.id} onHoverStart={() => setHoveredItem(item.id)} onHoverEnd={() => setHoveredItem(null)} whileHover={{ scale: 1.05, y: -4 }} className={`p-4 rounded-xl border transition-all cursor-pointer ${hoveredItem === item.id ? "border-violet-500 bg-violet-500/10" : "border-slate-700 bg-slate-800/50"}`}>
            <motion.span animate={hoveredItem === item.id ? { rotate: [0, -10, 10, 0] } : {}} className="text-4xl block mb-2 text-center">{item.emoji}</motion.span>
            <p className="text-sm text-slate-300 text-center">{item.label}</p>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Audio Fade
function AudioFadeEffect() {
  const [fadeState, setFadeState] = useState("idle");
  const [progress, setProgress] = useState(0);

  const startFade = (direction) => {
    setFadeState(direction === "in" ? "fadingIn" : "fadingOut");
    setProgress(direction === "in" ? 0 : 100);
    const interval = setInterval(() => {
      setProgress(p => {
        const newP = direction === "in" ? p + 5 : p - 5;
        if ((direction === "in" && newP >= 100) || (direction === "out" && newP <= 0)) {
          clearInterval(interval);
          setFadeState(direction === "in" ? "playing" : "idle");
          return direction === "in" ? 100 : 0;
        }
        return newP;
      });
    }, 50);
  };

  return (
    <EffectCard title="Audio Fade" description="Smooth fade transitions" controls={
      <div className="flex gap-2">
        <Button onClick={() => startFade("in")} disabled={fadeState !== "idle"} variant="outline" className="flex-1">Fade In</Button>
        <Button onClick={() => startFade("out")} disabled={fadeState !== "playing"} variant="outline" className="flex-1">Fade Out</Button>
      </div>
    }>
      <div className="p-8 flex flex-col items-center gap-6">
        <div className="relative w-32 h-32">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="8" className="text-slate-800" />
            <motion.circle cx="50" cy="50" r="45" fill="none" stroke="url(#fadeGradient)" strokeWidth="8" strokeLinecap="round" strokeDasharray={`${2 * Math.PI * 45}`} strokeDashoffset={2 * Math.PI * 45 * (1 - progress / 100)} />
            <defs><linearGradient id="fadeGradient" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stopColor="#8b5cf6" /><stop offset="100%" stopColor="#06b6d4" /></linearGradient></defs>
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <Volume2 className="w-10 h-10 text-violet-400" style={{ opacity: 0.3 + (progress / 100) * 0.7 }} />
          </div>
        </div>
        <p className="text-2xl font-bold text-white">{progress}%</p>
      </div>
    </EffectCard>
  );
}

// Sound Wave
function SoundWaveEffect() {
  const [isActive, setIsActive] = useState(false);

  return (
    <EffectCard title="Sound Wave" description="Animated waveform" controls={
      <Button onClick={() => setIsActive(!isActive)} variant={isActive ? "default" : "outline"} className="w-full">
        {isActive ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
        {isActive ? "Stop" : "Play"}
      </Button>
    }>
      <div className="p-8 flex items-center justify-center">
        <div className="flex items-center gap-[3px]">
          {Array.from({ length: 40 }).map((_, i) => {
            const baseHeight = Math.sin((i / 40) * Math.PI * 2) * 20 + 25;
            return (
              <motion.div key={i} className="w-1 rounded-full bg-gradient-to-t from-pink-500 to-rose-400" animate={isActive ? { height: [baseHeight, baseHeight + Math.random() * 30, baseHeight] } : { height: 4 }} transition={{ duration: 0.2 + Math.random() * 0.3, repeat: isActive ? Infinity : 0, repeatType: "reverse" }} />
            );
          })}
        </div>
      </div>
    </EffectCard>
  );
}

// Equalizer
function EqualizerEffect() {
  const [bands, setBands] = useState([50, 70, 40, 80, 60, 45, 75]);
  const frequencies = ["60Hz", "250Hz", "1kHz", "4kHz", "8kHz", "12kHz", "16kHz"];

  return (
    <EffectCard title="Equalizer" description="Frequency band controls">
      <div className="p-4 flex gap-4 justify-center items-end h-40">
        {bands.map((value, i) => (
          <div key={i} className="flex flex-col items-center gap-2">
            <motion.div className="w-4 rounded-full bg-gradient-to-t from-violet-500 to-cyan-400" style={{ height: `${value}%` }} whileHover={{ scale: 1.1 }} />
            <span className="text-xs text-slate-500">{frequencies[i]}</span>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Volume Meter
function VolumeMeter() {
  const [level, setLevel] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setLevel(Math.random() * 100);
    }, 100);
    return () => clearInterval(interval);
  }, []);

  return (
    <EffectCard title="Volume Meter" description="Real-time level indicator">
      <div className="p-6 flex flex-col items-center gap-4">
        <div className="flex gap-1 h-32">
          {Array.from({ length: 20 }).map((_, i) => {
            const threshold = (i / 20) * 100;
            const isActive = level > threshold;
            const color = threshold > 80 ? "bg-red-500" : threshold > 60 ? "bg-yellow-500" : "bg-green-500";
            return <motion.div key={i} className={`w-3 rounded-sm ${isActive ? color : "bg-slate-700"}`} animate={{ opacity: isActive ? 1 : 0.3 }} />;
          })}
        </div>
        <p className="text-slate-300 text-sm">Level: {Math.round(level)}%</p>
      </div>
    </EffectCard>
  );
}

// Audio Spectrum
function AudioSpectrum() {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <EffectCard title="Circular Spectrum" description="Radial audio visualization" controls={
      <Button onClick={() => setIsPlaying(!isPlaying)} variant={isPlaying ? "default" : "outline"} className="w-full">
        {isPlaying ? "Stop" : "Start"} Spectrum
      </Button>
    }>
      <div className="p-8 flex items-center justify-center">
        <div className="relative w-32 h-32">
          {Array.from({ length: 24 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 bg-gradient-to-t from-violet-500 to-cyan-400 rounded-full origin-bottom"
              style={{ left: "50%", bottom: "50%", transform: `translateX(-50%) rotate(${i * 15}deg)` }}
              animate={isPlaying ? { height: [20, 30 + Math.random() * 30, 20] } : { height: 20 }}
              transition={{ duration: 0.3 + Math.random() * 0.2, repeat: isPlaying ? Infinity : 0, repeatType: "reverse", delay: i * 0.02 }}
            />
          ))}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center">
              <Speaker className="w-6 h-6 text-violet-400" />
            </div>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Podcast Player
function PodcastPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState("1x");
  const speeds = ["0.5x", "1x", "1.5x", "2x"];

  return (
    <EffectCard title="Podcast Player" description="Episode player UI" whenToUse="Essential for podcast platforms, audio content apps, or course players.">
      <div className="w-full p-4 space-y-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center">
            <Headphones className="w-8 h-8 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-white truncate">Episode 42: The Future</p>
            <p className="text-sm text-slate-400">Tech Talk Podcast</p>
          </div>
        </div>
        <div className="space-y-2">
          <Slider defaultValue={[35]} max={100} />
          <div className="flex justify-between text-xs text-slate-500"><span>12:45</span><span>45:30</span></div>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex gap-2">
            {speeds.map(s => (
              <button key={s} onClick={() => setSpeed(s)} className={`px-2 py-1 rounded text-xs ${speed === s ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400"}`}>{s}</button>
            ))}
          </div>
          <Button size="icon" onClick={() => setIsPlaying(!isPlaying)} className="bg-violet-500 hover:bg-violet-600">
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </Button>
        </div>
      </div>
    </EffectCard>
  );
}

// Radio Tuner
function RadioTuner() {
  const [frequency, setFrequency] = useState([98.5]);
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <EffectCard title="Radio Tuner" description="FM frequency dial">
      <div className="w-full p-6 space-y-6">
        <div className="text-center">
          <p className="text-4xl font-bold text-white font-mono">{frequency[0].toFixed(1)}</p>
          <p className="text-sm text-slate-400">FM MHz</p>
        </div>
        <div className="relative">
          <Slider value={frequency} onValueChange={setFrequency} min={87.5} max={108} step={0.1} />
          <div className="flex justify-between mt-1 text-xs text-slate-500">
            <span>87.5</span>
            <span>108.0</span>
          </div>
        </div>
        <div className="flex items-center justify-center gap-4">
          <Radio className={`w-6 h-6 ${isPlaying ? "text-green-400" : "text-slate-400"}`} />
          <Button onClick={() => setIsPlaying(!isPlaying)} variant={isPlaying ? "default" : "outline"}>
            {isPlaying ? "Stop" : "Tune In"}
          </Button>
        </div>
      </div>
    </EffectCard>
  );
}

// Beat Visualizer
function BeatVisualizer() {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <EffectCard title="Beat Visualizer" description="Rhythm-synced animation" controls={
      <Button onClick={() => setIsPlaying(!isPlaying)} variant={isPlaying ? "default" : "outline"} className="w-full">
        {isPlaying ? "Stop" : "Start"} Beat
      </Button>
    }>
      <div className="p-8 flex items-center justify-center">
        <motion.div
          animate={isPlaying ? { scale: [1, 1.2, 1], borderRadius: ["20%", "50%", "20%"] } : {}}
          transition={{ duration: 0.5, repeat: Infinity }}
          className="w-24 h-24 bg-gradient-to-br from-pink-500 to-violet-500 flex items-center justify-center shadow-lg shadow-pink-500/30"
        >
          <motion.span animate={isPlaying ? { scale: [1, 0.8, 1] } : {}} transition={{ duration: 0.5, repeat: Infinity }} className="text-4xl">🎵</motion.span>
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Audio Toggle
function AudioToggle() {
  const [isMuted, setIsMuted] = useState(false);

  return (
    <EffectCard title="Mute Toggle" description="Sound on/off switch">
      <div className="p-8 flex flex-col items-center gap-4">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsMuted(!isMuted)}
          className={`w-20 h-20 rounded-full flex items-center justify-center transition-colors ${isMuted ? "bg-slate-700" : "bg-gradient-to-br from-violet-500 to-cyan-500"}`}
        >
          <motion.div animate={isMuted ? {} : { scale: [1, 1.1, 1] }} transition={{ duration: 1, repeat: Infinity }}>
            {isMuted ? <VolumeX className="w-10 h-10 text-slate-400" /> : <Volume2 className="w-10 h-10 text-white" />}
          </motion.div>
        </motion.button>
        <p className="text-slate-300">{isMuted ? "Sound Off" : "Sound On"}</p>
      </div>
    </EffectCard>
  );
}

// Playlist UI
function PlaylistUI() {
  const [currentTrack, setCurrentTrack] = useState(0);
  const tracks = [
    { title: "Summer Vibes", artist: "DJ Cool", duration: "3:24" },
    { title: "Night Drive", artist: "Synth Wave", duration: "4:12" },
    { title: "Morning Light", artist: "Ambient", duration: "5:30" },
  ];

  return (
    <EffectCard title="Playlist" description="Track list UI">
      <div className="w-full p-2 space-y-1">
        {tracks.map((track, i) => (
          <motion.button
            key={i}
            whileHover={{ x: 4 }}
            onClick={() => setCurrentTrack(i)}
            className={`w-full p-3 rounded-lg flex items-center gap-3 transition-colors ${currentTrack === i ? "bg-violet-500/20 border border-violet-500/30" : "hover:bg-slate-800"}`}
          >
            <div className={`w-8 h-8 rounded flex items-center justify-center ${currentTrack === i ? "bg-violet-500" : "bg-slate-700"}`}>
              {currentTrack === i ? <Play className="w-4 h-4 text-white" fill="white" /> : <span className="text-slate-400 text-sm">{i + 1}</span>}
            </div>
            <div className="flex-1 text-left">
              <p className={`text-sm ${currentTrack === i ? "text-white font-medium" : "text-slate-300"}`}>{track.title}</p>
              <p className="text-xs text-slate-500">{track.artist}</p>
            </div>
            <span className="text-xs text-slate-500">{track.duration}</span>
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

export default function AudioEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <AudioVisualizer />, name: "Audio Visualizer" },
    { component: <BackgroundMusicPlayer />, name: "Background Music" },
    { component: <NotificationSounds />, name: "Notification Sounds" },
    { component: <ClickSoundEffect />, name: "Click Sound" },
    { component: <HoverSoundEffect />, name: "Hover Sound" },
    { component: <AudioFadeEffect />, name: "Audio Fade" },
    { component: <SoundWaveEffect />, name: "Sound Wave" },
    { component: <EqualizerEffect />, name: "Equalizer" },
    { component: <VolumeMeter />, name: "Volume Meter" },
    { component: <AudioSpectrum />, name: "Circular Spectrum" },
    { component: <PodcastPlayer />, name: "Podcast Player" },
    { component: <RadioTuner />, name: "Radio Tuner" },
    { component: <BeatVisualizer />, name: "Beat Visualizer" },
    { component: <AudioToggle />, name: "Mute Toggle" },
    { component: <PlaylistUI />, name: "Playlist" },
  ];

  const filtered = effects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={Volume2} title="Audio Effects" description="Sound feedback, music controls, and audio visualizations" gradient="#06b6d4" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="mb-8 p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
          <p className="text-amber-400 text-sm">🔊 Note: This is a visual demonstration. In production, integrate the Web Audio API for actual sound playback.</p>
        </div>
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((effect, i) => <div key={i}>{effect.component}</div>)}
        </div>
      </div>
    </div>
  );
}