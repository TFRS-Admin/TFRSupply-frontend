import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Eye, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import ToggleSwitch from "@/components/ui/toggle-switch";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// VHS/CRT Effect
function VHSEffect() {
  const [scanlines, setScanlines] = useState(true);
  const [staticNoise, setStaticNoise] = useState(true);
  const [intensity, setIntensity] = useState([50]);

  return (
    <EffectCard
      title="VHS/CRT Effect"
      description="Retro TV aesthetic with scanlines and static"
      whenToUse="Perfect for retro-themed apps, nostalgic content, or vintage media players."
      code={`<div className="relative">
  <img src="..." className="w-full" />
  {/* Scanlines */}
  <div style={{
    background: \`repeating-linear-gradient(
      0deg, rgba(0,0,0,0.3), rgba(0,0,0,0.3) 1px,
      transparent 1px, transparent 2px
    )\`
  }} className="absolute inset-0" />
</div>`}
      prompt="Create a VHS/CRT effect with scanlines and static noise overlay using CSS. Include toggles for scanlines and noise intensity."
      controls={
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label className="text-slate-300">Scanlines</Label>
            <ToggleSwitch checked={scanlines} onCheckedChange={setScanlines} />
          </div>
          <div className="flex items-center justify-between">
            <Label className="text-slate-300">Static Noise</Label>
            <ToggleSwitch checked={staticNoise} onCheckedChange={setStaticNoise} />
          </div>
          <div className="space-y-2">
            <Label className="text-slate-300">Intensity: {intensity}%</Label>
            <Slider value={intensity} onValueChange={setIntensity} max={100} step={1} />
          </div>
        </div>
      }
    >
      <div className="relative w-full h-full min-h-[200px] overflow-hidden">
        <img src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=400&h=300&fit=crop" alt="Retro" className="w-full h-full object-cover" />
        {scanlines && (
          <div className="absolute inset-0 pointer-events-none" style={{
            background: `repeating-linear-gradient(0deg, rgba(0,0,0,${intensity[0]/200}), rgba(0,0,0,${intensity[0]/200}) 1px, transparent 1px, transparent 2px)`
          }} />
        )}
        {staticNoise && (
          <div className="absolute inset-0 pointer-events-none mix-blend-overlay animate-pulse" style={{
            opacity: intensity[0] / 200,
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`
          }} />
        )}
      </div>
    </EffectCard>
  );
}

// Film Grain with Motion
function FilmGrainMotion() {
  const [enabled, setEnabled] = useState(true);
  const [intensity, setIntensity] = useState([40]);
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!enabled || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let animationId;

    const drawGrain = () => {
      const imageData = ctx.createImageData(canvas.width, canvas.height);
      for (let i = 0; i < imageData.data.length; i += 4) {
        const noise = Math.random() * 255 * (intensity[0] / 100);
        imageData.data[i] = noise;
        imageData.data[i + 1] = noise;
        imageData.data[i + 2] = noise;
        imageData.data[i + 3] = 30;
      }
      ctx.putImageData(imageData, 0, 0);
      animationId = requestAnimationFrame(drawGrain);
    };

    drawGrain();
    return () => cancelAnimationFrame(animationId);
  }, [enabled, intensity]);

  return (
    <EffectCard
      title="Film Grain (Motion)"
      description="Animated film grain texture overlay"
      whenToUse="Use for cinematic feel, photography apps, or adding texture to hero sections."
      controls={
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label className="text-slate-300">Enable</Label>
            <ToggleSwitch checked={enabled} onCheckedChange={setEnabled} />
          </div>
          <div className="space-y-2">
            <Label className="text-slate-300">Intensity: {intensity}%</Label>
            <Slider value={intensity} onValueChange={setIntensity} max={100} step={1} />
          </div>
        </div>
      }
    >
      <div className="relative w-full h-full min-h-[200px] overflow-hidden">
        <img src="https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=300&fit=crop" alt="Cinematic" className="w-full h-full object-cover grayscale contrast-110" />
        {enabled && <canvas ref={canvasRef} width={400} height={300} className="absolute inset-0 w-full h-full mix-blend-overlay" />}
      </div>
    </EffectCard>
  );
}

// Glitch Effect
function GlitchEffect() {
  const [isGlitching, setIsGlitching] = useState(false);
  const triggerGlitch = () => { setIsGlitching(true); setTimeout(() => setIsGlitching(false), 500); };

  return (
    <EffectCard title="Glitch Effect" description="Digital distortion with RGB splitting" whenToUse="Great for cyberpunk themes, error states, or edgy brand aesthetics." controls={
      <Button onClick={triggerGlitch} variant="outline" className="w-full">
        <RefreshCw className="w-4 h-4 mr-2" /> Trigger Glitch
      </Button>
    }>
      <div className="relative flex items-center justify-center p-8">
        <motion.h2
          animate={isGlitching ? { x: [0, -5, 5, -3, 3, 0], textShadow: ["0 0 0 transparent", "-2px 0 #ff0000, 2px 0 #00ffff", "2px 0 #ff0000, -2px 0 #00ffff", "-1px 0 #ff0000, 1px 0 #00ffff", "0 0 0 transparent"] } : {}}
          transition={{ duration: 0.5 }}
          className="text-4xl font-bold text-white relative"
        >
          GLITCH
        </motion.h2>
      </div>
    </EffectCard>
  );
}

// Image Glitch Effect
function ImageGlitchEffect() {
  const [isGlitching, setIsGlitching] = useState(false);

  return (
    <EffectCard title="Image Glitch" description="Glitch distortion on images" controls={
      <Button onClick={() => { setIsGlitching(true); setTimeout(() => setIsGlitching(false), 1000); }} variant="outline" className="w-full">
        Trigger Image Glitch
      </Button>
    }>
      <div className="relative w-full h-[200px] overflow-hidden">
        <motion.img
          src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=300&fit=crop"
          alt="Portrait"
          className="w-full h-full object-cover"
          animate={isGlitching ? { x: [0, -5, 5, -3, 0], filter: ["hue-rotate(0deg)", "hue-rotate(90deg)", "hue-rotate(-90deg)", "hue-rotate(45deg)", "hue-rotate(0deg)"] } : {}}
          transition={{ duration: 0.3, repeat: isGlitching ? 3 : 0 }}
        />
        {isGlitching && (
          <>
            <motion.div className="absolute inset-0 bg-red-500 mix-blend-multiply" animate={{ opacity: [0, 0.3, 0] }} transition={{ duration: 0.1, repeat: 5 }} />
            <motion.div className="absolute inset-0 bg-cyan-500 mix-blend-multiply" animate={{ opacity: [0, 0.3, 0], x: [0, 3, -3, 0] }} transition={{ duration: 0.1, repeat: 5, delay: 0.05 }} />
          </>
        )}
      </div>
    </EffectCard>
  );
}

// Particle System
function ParticleSystem() {
  const [particleType, setParticleType] = useState("snow");
  const [count, setCount] = useState([30]);
  const particles = Array.from({ length: count[0] }, (_, i) => ({ id: i, x: Math.random() * 100, delay: Math.random() * 5, duration: 3 + Math.random() * 4, size: particleType === "snow" ? 2 + Math.random() * 4 : 4 + Math.random() * 6 }));

  return (
    <EffectCard title="Particle System" description="Snow, fireflies, or custom particles" whenToUse="Add ambiance to landing pages, seasonal themes, or celebrations." controls={
      <div className="space-y-4">
        <div className="flex gap-2">
          <Button variant={particleType === "snow" ? "default" : "outline"} size="sm" onClick={() => setParticleType("snow")}>❄️ Snow</Button>
          <Button variant={particleType === "fireflies" ? "default" : "outline"} size="sm" onClick={() => setParticleType("fireflies")}>✨ Fireflies</Button>
        </div>
        <div className="space-y-2">
          <Label className="text-slate-300">Count: {count}</Label>
          <Slider value={count} onValueChange={setCount} min={10} max={60} step={5} />
        </div>
      </div>
    }>
      <div className="relative w-full h-full min-h-[200px] overflow-hidden bg-gradient-to-b from-slate-900 to-slate-950">
        {particles.map((particle) => (
          <motion.div
            key={particle.id}
            className={particleType === "snow" ? "bg-white rounded-full" : "bg-yellow-400 rounded-full blur-sm"}
            style={{ width: particle.size, height: particle.size, left: `${particle.x}%`, position: "absolute" }}
            initial={{ y: -20, opacity: 0 }}
            animate={particleType === "snow" ? { y: ["-10%", "110%"], opacity: [0, 1, 1, 0], x: [0, Math.sin(particle.id) * 20, 0] } : { y: ["80%", "20%", "80%"], opacity: [0.2, 1, 0.2], x: [0, Math.sin(particle.id) * 30, 0], scale: [1, 1.5, 1] }}
            transition={{ duration: particle.duration, delay: particle.delay, repeat: Infinity, ease: "linear" }}
          />
        ))}
      </div>
    </EffectCard>
  );
}

// Neon Glow
function NeonGlowEffect() {
  const [color, setColor] = useState("violet");
  const [pulse, setPulse] = useState(true);
  const colors = { violet: { text: "text-violet-400", shadow: "#8b5cf6", bg: "bg-violet-500/20" }, cyan: { text: "text-cyan-400", shadow: "#06b6d4", bg: "bg-cyan-500/20" }, pink: { text: "text-pink-400", shadow: "#ec4899", bg: "bg-pink-500/20" }, green: { text: "text-green-400", shadow: "#22c55e", bg: "bg-green-500/20" } };

  return (
    <EffectCard title="Neon Glow" description="Glowing text with color options" whenToUse="Ideal for nightlife themes, gaming UIs, or highlighting key content." controls={
      <div className="space-y-4">
        <div className="flex gap-2">
          {Object.keys(colors).map((c) => <button key={c} onClick={() => setColor(c)} className={`w-8 h-8 rounded-full ${colors[c].bg} ${color === c ? "ring-2 ring-white" : ""}`} />)}
        </div>
        <div className="flex items-center justify-between">
          <Label className="text-slate-300">Pulse</Label>
          <ToggleSwitch checked={pulse} onCheckedChange={setPulse} />
        </div>
      </div>
    }>
      <motion.h2
        animate={pulse ? { textShadow: [`0 0 10px ${colors[color].shadow}, 0 0 20px ${colors[color].shadow}`, `0 0 20px ${colors[color].shadow}, 0 0 40px ${colors[color].shadow}`, `0 0 10px ${colors[color].shadow}, 0 0 20px ${colors[color].shadow}`] } : { textShadow: `0 0 10px ${colors[color].shadow}, 0 0 20px ${colors[color].shadow}` }}
        transition={{ duration: 1.5, repeat: Infinity }}
        className={`text-5xl font-bold ${colors[color].text}`}
      >
        NEON
      </motion.h2>
    </EffectCard>
  );
}

// Frosted Glass
function FrostedGlassEffect() {
  const [blur, setBlur] = useState([12]);
  const [opacity, setOpacity] = useState([50]);

  return (
    <EffectCard title="Frosted Glass" description="Glassmorphism with backdrop blur" whenToUse="Perfect for modern cards, overlays, or Apple-style interfaces." controls={
      <div className="space-y-4">
        <div className="space-y-2">
          <Label className="text-slate-300">Blur: {blur}px</Label>
          <Slider value={blur} onValueChange={setBlur} max={24} step={1} />
        </div>
        <div className="space-y-2">
          <Label className="text-slate-300">Opacity: {opacity}%</Label>
          <Slider value={opacity} onValueChange={setOpacity} max={100} step={5} />
        </div>
      </div>
    }>
      <div className="relative w-full h-full min-h-[200px] p-6">
        <img src="https://images.unsplash.com/photo-1519681393784-d120267933ba?w=400&h=300&fit=crop" alt="Mountain" className="absolute inset-0 w-full h-full object-cover" />
        <div className="relative z-10 p-6 rounded-2xl border border-white/20" style={{ backdropFilter: `blur(${blur[0]}px)`, backgroundColor: `rgba(255, 255, 255, ${opacity[0] / 400})` }}>
          <h3 className="text-white font-semibold text-lg mb-2">Frosted Glass Card</h3>
          <p className="text-white/80 text-sm">Uses backdrop-filter for the glass effect.</p>
        </div>
      </div>
    </EffectCard>
  );
}

// Skeleton Loading
function SkeletonLoading() {
  const [isLoading, setIsLoading] = useState(true);

  return (
    <EffectCard title="Skeleton Loading" description="Animated placeholder while loading" whenToUse="Use during data fetching to improve perceived performance." controls={
      <Button onClick={() => setIsLoading(!isLoading)} variant="outline" className="w-full">
        {isLoading ? "Show Content" : "Show Skeleton"}
      </Button>
    }>
      <div className="w-full p-4">
        <AnimatePresence mode="wait">
          {isLoading ? (
            <motion.div key="skeleton" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-slate-700 animate-pulse" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-slate-700 rounded animate-pulse w-3/4" />
                  <div className="h-3 bg-slate-700 rounded animate-pulse w-1/2" />
                </div>
              </div>
              <div className="h-32 bg-slate-700 rounded-xl animate-pulse" />
              <div className="space-y-2">
                <div className="h-3 bg-slate-700 rounded animate-pulse" />
                <div className="h-3 bg-slate-700 rounded animate-pulse w-5/6" />
              </div>
            </motion.div>
          ) : (
            <motion.div key="content" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
              <div className="flex items-center gap-3">
                <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop" alt="Avatar" className="w-12 h-12 rounded-full object-cover" />
                <div>
                  <p className="font-semibold text-white">John Doe</p>
                  <p className="text-sm text-slate-400">Developer</p>
                </div>
              </div>
              <img src="https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=200&fit=crop" alt="Cover" className="w-full h-32 rounded-xl object-cover" />
              <p className="text-slate-300 text-sm">Content loaded successfully!</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Marquee
function MarqueeEffect() {
  const [speed, setSpeed] = useState([20]);
  const items = ["🚀 New Features", "⭐ Special Offer", "🔥 Hot Deal", "💎 Premium", "🎉 Celebrate"];

  return (
    <EffectCard title="Marquee" description="Scrolling text or images" controls={
      <div className="space-y-2">
        <Label className="text-slate-300">Speed: {speed}s</Label>
        <Slider value={speed} onValueChange={setSpeed} min={5} max={40} step={5} />
      </div>
    }>
      <div className="w-full overflow-hidden py-4">
        <motion.div
          animate={{ x: ["0%", "-50%"] }}
          transition={{ duration: speed[0], repeat: Infinity, ease: "linear" }}
          className="flex gap-8 whitespace-nowrap"
        >
          {[...items, ...items].map((item, i) => (
            <span key={i} className="text-xl font-semibold text-white px-4 py-2 bg-slate-800 rounded-full">{item}</span>
          ))}
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Screen Shake
function ScreenShakeEffect() {
  const [isShaking, setIsShaking] = useState(false);
  const triggerShake = () => { setIsShaking(true); setTimeout(() => setIsShaking(false), 500); };

  return (
    <EffectCard title="Screen Shake" description="Impact shake animation" controls={
      <Button onClick={triggerShake} variant="outline" className="w-full">💥 Trigger Shake</Button>
    }>
      <motion.div animate={isShaking ? { x: [0, -10, 10, -8, 8, -5, 5, 0], y: [0, -5, 5, -3, 3, -2, 2, 0] } : {}} transition={{ duration: 0.5 }} className="p-8">
        <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-red-500 to-orange-500 flex items-center justify-center shadow-lg">
          <span className="text-4xl">💣</span>
        </div>
      </motion.div>
    </EffectCard>
  );
}

// Spotlight
function SpotlightEffect() {
  const containerRef = useRef(null);
  const [mousePos, setMousePos] = useState({ x: 50, y: 50 });

  return (
    <EffectCard title="Spotlight" description="Cursor-following reveal">
      <div ref={containerRef} onMouseMove={(e) => { if (!containerRef.current) return; const rect = containerRef.current.getBoundingClientRect(); setMousePos({ x: ((e.clientX - rect.left) / rect.width) * 100, y: ((e.clientY - rect.top) / rect.height) * 100 }); }} className="relative w-full h-full min-h-[200px] cursor-none overflow-hidden">
        <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop" alt="Portrait" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black transition-all duration-75" style={{ maskImage: `radial-gradient(circle 80px at ${mousePos.x}% ${mousePos.y}%, transparent 0%, black 100%)`, WebkitMaskImage: `radial-gradient(circle 80px at ${mousePos.x}% ${mousePos.y}%, transparent 0%, black 100%)` }} />
        <p className="absolute bottom-4 left-4 text-white/60 text-sm">Move cursor</p>
      </div>
    </EffectCard>
  );
}

// Duotone
function DuotoneEffect() {
  const [colorPair, setColorPair] = useState("purple-cyan");
  const pairs = { "purple-cyan": { from: "#8b5cf6", to: "#06b6d4" }, "pink-orange": { from: "#ec4899", to: "#f97316" }, "green-blue": { from: "#22c55e", to: "#3b82f6" } };

  return (
    <EffectCard title="Duotone Filter" description="Two-color image filter" controls={
      <div className="flex gap-2 flex-wrap">
        {Object.keys(pairs).map((pair) => <button key={pair} onClick={() => setColorPair(pair)} className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${colorPair === pair ? "bg-white text-slate-900" : "bg-slate-800 text-slate-300"}`}>{pair}</button>)}
      </div>
    }>
      <div className="relative w-full h-full min-h-[200px] overflow-hidden">
        <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=300&fit=crop" alt="Portrait" className="w-full h-full object-cover grayscale contrast-110" />
        <div className="absolute inset-0 mix-blend-color" style={{ background: `linear-gradient(135deg, ${pairs[colorPair].from}, ${pairs[colorPair].to})` }} />
      </div>
    </EffectCard>
  );
}

// Gradient Border
function GradientBorderEffect() {
  const [animate, setAnimate] = useState(true);

  return (
    <EffectCard title="Gradient Border" description="Animated gradient border" controls={
      <div className="flex items-center justify-between">
        <Label className="text-slate-300">Animate</Label>
        <ToggleSwitch checked={animate} onCheckedChange={setAnimate} />
      </div>
    }>
      <div className="p-8">
        <motion.div
          animate={animate ? { backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] } : {}}
          transition={{ duration: 3, repeat: Infinity }}
          className="p-[2px] rounded-xl"
          style={{ background: "linear-gradient(90deg, #8b5cf6, #06b6d4, #ec4899, #8b5cf6)", backgroundSize: "300% 300%" }}
        >
          <div className="bg-slate-900 rounded-xl p-6">
            <p className="text-white font-medium">Gradient Border Card</p>
            <p className="text-slate-400 text-sm">With animated background</p>
          </div>
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Color Shifting
function ColorShiftEffect() {
  return (
    <EffectCard title="Color Shift" description="Hue rotation animation">
      <motion.div
        animate={{ filter: ["hue-rotate(0deg)", "hue-rotate(360deg)"] }}
        transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
        className="w-32 h-32 rounded-2xl bg-gradient-to-br from-violet-500 via-pink-500 to-cyan-500 shadow-2xl"
      />
    </EffectCard>
  );
}

// Blur Reveal
function BlurRevealEffect() {
  const [isRevealed, setIsRevealed] = useState(false);

  return (
    <EffectCard title="Blur Reveal" description="Content reveals on interaction" controls={
      <Button onClick={() => setIsRevealed(!isRevealed)} variant="outline" className="w-full">
        {isRevealed ? "Hide" : "Reveal"} Content
      </Button>
    }>
      <div className="relative">
        <motion.div animate={{ filter: isRevealed ? "blur(0px)" : "blur(10px)" }} transition={{ duration: 0.5 }}>
          <img src="https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=400&h=200&fit=crop" alt="Nature" className="w-full h-48 object-cover rounded-xl" />
        </motion.div>
        {!isRevealed && <div className="absolute inset-0 flex items-center justify-center"><span className="text-white bg-slate-800/80 px-4 py-2 rounded-lg">Click to reveal</span></div>}
      </div>
    </EffectCard>
  );
}

// Parallax Tilt
function ParallaxTiltEffect() {
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const cardRef = useRef(null);

  const handleMouseMove = (e) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setRotateX(-y * 20);
    setRotateY(x * 20);
  };

  return (
    <EffectCard title="Parallax Tilt" description="3D card tilt on hover" whenToUse="Great for product cards, portfolio items, or interactive galleries.">
      <div className="p-8" style={{ perspective: "1000px" }}>
        <motion.div
          ref={cardRef}
          onMouseMove={handleMouseMove}
          onMouseLeave={() => { setRotateX(0); setRotateY(0); }}
          animate={{ rotateX, rotateY }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="w-48 h-32 rounded-xl bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center cursor-pointer shadow-xl"
        >
          <span className="text-white font-bold">Hover Me</span>
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Text Gradient Animation
function TextGradientAnimation() {
  return (
    <EffectCard title="Animated Text Gradient" description="Moving gradient on text">
      <motion.h2
        animate={{ backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] }}
        transition={{ duration: 3, repeat: Infinity }}
        className="text-4xl font-bold bg-clip-text text-transparent"
        style={{ backgroundImage: "linear-gradient(90deg, #8b5cf6, #06b6d4, #ec4899, #8b5cf6)", backgroundSize: "300% 300%" }}
      >
        GRADIENT
      </motion.h2>
    </EffectCard>
  );
}

// Vignette Effect
function VignetteEffect() {
  const [intensity, setIntensity] = useState([50]);

  return (
    <EffectCard title="Vignette" description="Darkened corners effect" controls={
      <div className="space-y-2">
        <Label className="text-slate-300">Intensity: {intensity}%</Label>
        <Slider value={intensity} onValueChange={setIntensity} max={100} step={5} />
      </div>
    }>
      <div className="relative w-full h-[200px]">
        <img src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop" alt="Mountain" className="w-full h-full object-cover" />
        <div className="absolute inset-0" style={{ background: `radial-gradient(ellipse at center, transparent 30%, rgba(0,0,0,${intensity[0]/100}) 100%)` }} />
      </div>
    </EffectCard>
  );
}

// Morphing Shape
function MorphingShapeEffect() {
  return (
    <EffectCard title="Morphing Shape" description="Smooth shape transitions">
      <motion.div
        animate={{ borderRadius: ["20%", "50%", "30%", "50%", "20%"], rotate: [0, 90, 180, 270, 360] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        className="w-24 h-24 bg-gradient-to-br from-pink-500 to-violet-500"
      />
    </EffectCard>
  );
}

// Floating Elements
function FloatingElements() {
  return (
    <EffectCard title="Floating Elements" description="Gentle floating animation">
      <div className="relative h-40 w-full">
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            animate={{ y: [0, -15, 0], x: [0, i % 2 === 0 ? 10 : -10, 0] }}
            transition={{ duration: 3 + i, repeat: Infinity, delay: i * 0.5 }}
            className="absolute"
            style={{ left: `${20 + i * 30}%`, top: "30%" }}
          >
            <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${["from-violet-400 to-purple-500", "from-cyan-400 to-blue-500", "from-pink-400 to-rose-500"][i]} shadow-lg`} />
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Noise Texture
function NoiseTextureEffect() {
  const [opacity, setOpacity] = useState([20]);

  return (
    <EffectCard title="Noise Texture" description="Subtle noise overlay" controls={
      <div className="space-y-2">
        <Label className="text-slate-300">Opacity: {opacity}%</Label>
        <Slider value={opacity} onValueChange={setOpacity} max={50} step={5} />
      </div>
    }>
      <div className="relative w-full h-[200px] bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center">
        <h3 className="text-white text-2xl font-bold z-10">Noise Overlay</h3>
        <div className="absolute inset-0" style={{ opacity: opacity[0] / 100, backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")` }} />
      </div>
    </EffectCard>
  );
}

// Pulsing Ring
function PulsingRingEffect() {
  return (
    <EffectCard title="Pulsing Ring" description="Expanding ring animation">
      <div className="relative flex items-center justify-center">
        <div className="w-16 h-16 rounded-full bg-violet-500 z-10 flex items-center justify-center">
          <span className="text-white text-2xl">✦</span>
        </div>
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            className="absolute w-16 h-16 rounded-full border-2 border-violet-500"
            animate={{ scale: [1, 2.5], opacity: [0.6, 0] }}
            transition={{ duration: 2, repeat: Infinity, delay: i * 0.6 }}
          />
        ))}
      </div>
    </EffectCard>
  );
}

// Scan Line Animation
function ScanLineEffect() {
  return (
    <EffectCard title="Scan Line" description="Moving scan line effect">
      <div className="relative w-full h-[200px] overflow-hidden">
        <img src="https://images.unsplash.com/photo-1518770660439-4636190af475?w=400&h=300&fit=crop" alt="Tech" className="w-full h-full object-cover" />
        <motion.div
          animate={{ y: ["-100%", "200%"] }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          className="absolute left-0 right-0 h-1 bg-gradient-to-b from-transparent via-cyan-400 to-transparent"
        />
      </div>
    </EffectCard>
  );
}

// Chromatic Aberration
function ChromaticAberrationEffect() {
  const [intensity, setIntensity] = useState([3]);

  return (
    <EffectCard title="Chromatic Aberration" description="RGB channel separation" controls={
      <div className="space-y-2">
        <Label className="text-slate-300">Intensity: {intensity}px</Label>
        <Slider value={intensity} onValueChange={setIntensity} max={10} step={1} />
      </div>
    }>
      <div className="relative">
        <h2 className="text-4xl font-bold text-white relative">
          <span className="absolute" style={{ color: "#ff0000", left: `-${intensity[0]}px`, opacity: 0.5 }}>CHROME</span>
          <span className="absolute" style={{ color: "#00ff00" }}>CHROME</span>
          <span className="absolute" style={{ color: "#0000ff", left: `${intensity[0]}px`, opacity: 0.5 }}>CHROME</span>
          <span className="invisible">CHROME</span>
        </h2>
      </div>
    </EffectCard>
  );
}

// Matrix Rain
function MatrixRainEffect() {
  const chars = "アイウエオカキクケコサシスセソタチツテト0123456789";
  const columns = 15;

  return (
    <EffectCard title="Matrix Rain" description="Digital rain effect">
      <div className="relative w-full h-[200px] overflow-hidden bg-black font-mono">
        {Array.from({ length: columns }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute text-green-500 text-xs"
            style={{ left: `${(i / columns) * 100}%` }}
            animate={{ y: ["-100%", "400%"] }}
            transition={{ duration: 2 + Math.random() * 2, repeat: Infinity, delay: Math.random() * 2 }}
          >
            {Array.from({ length: 15 }).map((_, j) => (
              <div key={j} style={{ opacity: 1 - j * 0.06 }}>{chars[Math.floor(Math.random() * chars.length)]}</div>
            ))}
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Liquid Distortion
function LiquidDistortion() {
  return (
    <EffectCard title="Liquid Distortion" description="Wavy liquid effect" whenToUse="Water themes, fluid animations, or dynamic backgrounds.">
      <div className="relative w-full h-[200px] overflow-hidden rounded-xl">
        <img src="https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=300&fit=crop" alt="Ocean" className="w-full h-full object-cover" />
        {[0, 1].map(i => (
          <motion.div
            key={i}
            animate={{ 
              backgroundPosition: ["0% 0%", "100% 100%", "0% 0%"],
              opacity: [0.3, 0.5, 0.3]
            }}
            transition={{ duration: 4 + i, repeat: Infinity, ease: "easeInOut" }}
            className="absolute inset-0"
            style={{
              background: `linear-gradient(${45 + i * 90}deg, transparent 40%, rgba(255,255,255,0.15) 50%, transparent 60%)`,
              backgroundSize: "200% 200%",
              mixBlendMode: "soft-light"
            }}
          />
        ))}
      </div>
    </EffectCard>
  );
}

// Holographic Effect
function HolographicEffect() {
  return (
    <EffectCard title="Holographic" description="Iridescent rainbow effect" whenToUse="Premium UI, futuristic themes, or eye-catching cards.">
      <div className="flex items-center justify-center p-6">
        <motion.div
          animate={{ backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] }}
          transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
          className="w-48 h-32 rounded-2xl flex items-center justify-center shadow-2xl"
          style={{
            background: "linear-gradient(135deg, #ff0080, #ff8c00, #40e0d0, #7928ca, #ff0080)",
            backgroundSize: "400% 400%"
          }}
        >
          <span className="text-white font-bold text-xl mix-blend-difference">HOLOGRAPHIC</span>
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Pixelate Effect
function PixelateEffect() {
  const [pixelSize, setPixelSize] = useState([8]);

  return (
    <EffectCard title="Pixelate" description="Retro pixel effect" whenToUse="8-bit themes, retro gaming, or privacy blur effects." controls={
      <div className="space-y-2">
        <Label className="text-slate-300">Pixel Size: {pixelSize}px</Label>
        <Slider value={pixelSize} onValueChange={setPixelSize} min={1} max={20} step={1} />
      </div>
    }>
      <div className="relative w-full h-[200px] rounded-xl overflow-hidden">
        <div 
          className="w-full h-full" 
          style={{ 
            backgroundImage: "url(https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=300&fit=crop)",
            backgroundSize: "cover",
            backgroundPosition: "center",
            imageRendering: pixelSize[0] > 5 ? "pixelated" : "auto",
            filter: `blur(${Math.max(0, (pixelSize[0] - 1) * 0.3)}px) contrast(1.1)`
          }} 
        />
      </div>
    </EffectCard>
  );
}

// Smoke Effect
function SmokeEffect() {
  const smokeParticles = Array.from({ length: 8 }, (_, i) => ({
    id: i,
    size: 60 + Math.random() * 40,
    left: Math.random() * 100,
    duration: 4 + Math.random() * 2,
    delay: i * 0.5,
    xOffset: Math.random() * 100 - 50
  }));

  return (
    <EffectCard title="Smoke" description="Floating smoke particles" whenToUse="Atmospheric effects, magical themes, or subtle backgrounds.">
      <div className="relative w-full h-[200px] overflow-hidden bg-gradient-to-b from-slate-900 to-slate-950 rounded-xl">
        {smokeParticles.map((particle) => (
          <motion.div
            key={particle.id}
            className="absolute rounded-full bg-slate-400/30 blur-2xl"
            style={{
              width: particle.size,
              height: particle.size,
              left: `${particle.left}%`
            }}
            initial={{ y: "120%", opacity: 0 }}
            animate={{
              y: "-20%",
              opacity: [0, 0.6, 0],
              x: [0, particle.xOffset * 0.5, particle.xOffset]
            }}
            transition={{
              duration: particle.duration,
              repeat: Infinity,
              delay: particle.delay,
              ease: "easeInOut"
            }}
          />
        ))}
      </div>
    </EffectCard>
  );
}

// Energy Wave
function EnergyWave() {
  return (
    <EffectCard title="Energy Wave" description="Expanding ring animation">
      <div className="flex items-center justify-center h-40">
        <div className="relative">
          <div className="w-4 h-4 rounded-full bg-cyan-400" />
          {[0, 1, 2].map(i => (
            <motion.div
              key={i}
              className="absolute inset-0 rounded-full border-2 border-cyan-400"
              animate={{ scale: [1, 4], opacity: [0.8, 0] }}
              transition={{ duration: 2, repeat: Infinity, delay: i * 0.6 }}
            />
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Prism Light
function PrismLight() {
  return (
    <EffectCard title="Prism Light" description="Rainbow refraction">
      <div className="relative h-40 flex items-center justify-center overflow-hidden">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
          className="w-32 h-32"
          style={{
            background: "conic-gradient(from 0deg, #ff0000, #ff8000, #ffff00, #80ff00, #00ff00, #00ff80, #00ffff, #0080ff, #0000ff, #8000ff, #ff00ff, #ff0080, #ff0000)",
            filter: "blur(20px)",
            opacity: 0.6
          }}
        />
        <div className="absolute w-16 h-16 bg-white/20 backdrop-blur-sm rotate-45" />
      </div>
    </EffectCard>
  );
}

// Lightning Effect
function LightningEffect() {
  const [flash, setFlash] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setFlash(true);
      setTimeout(() => setFlash(false), 200);
    }, 3000 + Math.random() * 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <EffectCard title="Lightning" description="Random flash effect">
      <div className="relative w-full h-[200px] bg-slate-900 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-slate-800 to-slate-900" />
        <AnimatePresence>
          {flash && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: [0, 1, 0.3, 1, 0] }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="absolute inset-0 bg-white/80"
            />
          )}
        </AnimatePresence>
        <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-slate-950 to-transparent" />
        <p className="absolute bottom-4 left-4 text-slate-500 text-xs">Watch for lightning...</p>
      </div>
    </EffectCard>
  );
}

// Kaleidoscope
function KaleidoscopeEffect() {
  return (
    <EffectCard title="Kaleidoscope" description="Symmetric pattern rotation">
      <div className="h-40 flex items-center justify-center overflow-hidden">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="relative w-40 h-40"
        >
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="absolute inset-0"
              style={{ transform: `rotate(${i * 60}deg)` }}
            >
              <div className="w-20 h-20 bg-gradient-to-br from-violet-500 to-transparent" style={{ clipPath: "polygon(50% 0%, 100% 100%, 0% 100%)" }} />
            </div>
          ))}
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Ink Bleed
function InkBleedEffect() {
  const [isActive, setIsActive] = useState(false);

  return (
    <EffectCard title="Ink Bleed" description="Spreading ink animation" controls={
      <Button onClick={() => setIsActive(!isActive)} variant="outline" className="w-full">
        {isActive ? "Reset" : "Drop Ink"}
      </Button>
    }>
      <div className="h-40 flex items-center justify-center bg-slate-100 rounded-xl">
        <AnimatePresence>
          {isActive && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 3 }}
              exit={{ scale: 0 }}
              transition={{ duration: 2 }}
              className="w-10 h-10 rounded-full bg-slate-900"
              style={{ filter: "blur(5px)" }}
            />
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Heat Distortion
function HeatDistortion() {
  return (
    <EffectCard title="Heat Distortion" description="Wavy heat shimmer" whenToUse="Desert themes, hot content, or dynamic atmospheric effects.">
      <div className="relative w-full h-[200px] overflow-hidden rounded-xl">
        <img src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop" alt="Desert" className="w-full h-full object-cover" />
        {[0, 1, 2, 3].map(i => (
          <motion.div
            key={i}
            animate={{ 
              y: [0, -8, 0, 8, 0],
              scaleY: [1, 1.05, 1, 0.95, 1]
            }}
            transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.2 }}
            className="absolute inset-0 opacity-30"
            style={{
              background: `repeating-linear-gradient(${90 + i * 5}deg, transparent, transparent 3px, rgba(255,255,255,0.05) 3px, rgba(255,255,255,0.05) 6px)`,
              mixBlendMode: "overlay"
            }}
          />
        ))}
      </div>
    </EffectCard>
  );
}

// Starburst
function StarburstEffect() {
  return (
    <EffectCard title="Starburst" description="Radiating light rays">
      <div className="h-40 flex items-center justify-center">
        <div className="relative">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="w-32 h-32"
          >
            {[...Array(12)].map((_, i) => (
              <div
                key={i}
                className="absolute top-1/2 left-1/2 w-1 h-16 bg-gradient-to-t from-yellow-400 to-transparent origin-bottom"
                style={{ transform: `translateX(-50%) rotate(${i * 30}deg)` }}
              />
            ))}
          </motion.div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-yellow-400 blur-sm" />
        </div>
      </div>
    </EffectCard>
  );
}

// Water Ripple
function WaterRippleEffect() {
  const [ripples, setRipples] = useState([]);

  const addRipple = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const id = Date.now();
    setRipples(prev => [...prev, { id, x, y }]);
    setTimeout(() => setRipples(prev => prev.filter(r => r.id !== id)), 2000);
  };

  return (
    <EffectCard title="Water Ripple" description="Click to create ripples">
      <div onClick={addRipple} className="relative w-full h-[200px] bg-gradient-to-b from-cyan-600 to-blue-800 cursor-pointer overflow-hidden rounded-xl">
        {ripples.map(ripple => (
          <motion.div
            key={ripple.id}
            initial={{ scale: 0, opacity: 0.8 }}
            animate={{ scale: 4, opacity: 0 }}
            transition={{ duration: 2 }}
            className="absolute w-20 h-20 border-2 border-white/50 rounded-full"
            style={{ left: ripple.x - 40, top: ripple.y - 40 }}
          />
        ))}
        <p className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white/60 text-sm">Click anywhere</p>
      </div>
    </EffectCard>
  );
}

// Neon Grid
function NeonGridEffect() {
  return (
    <EffectCard title="Neon Grid" description="Retro synthwave grid">
      <div className="relative w-full h-[200px] overflow-hidden bg-slate-950" style={{ perspective: "500px" }}>
        <motion.div
          animate={{ backgroundPositionY: ["0px", "50px"] }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="absolute inset-0"
          style={{
            backgroundImage: "linear-gradient(0deg, transparent 24%, rgba(236, 72, 153, 0.3) 25%, rgba(236, 72, 153, 0.3) 26%, transparent 27%), linear-gradient(90deg, transparent 24%, rgba(236, 72, 153, 0.3) 25%, rgba(236, 72, 153, 0.3) 26%, transparent 27%)",
            backgroundSize: "50px 50px",
            transform: "rotateX(60deg)",
            transformOrigin: "top"
          }}
        />
        <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-slate-950 to-transparent" />
        <div className="absolute bottom-1/3 left-0 right-0 h-0.5 bg-pink-500 blur-sm" />
      </div>
    </EffectCard>
  );
}

// Radar Sweep
function RadarSweepEffect() {
  return (
    <EffectCard title="Radar Sweep" description="Scanning radar animation">
      <div className="h-40 flex items-center justify-center">
        <div className="relative w-32 h-32">
          {/* Grid circles */}
          {[1, 2, 3].map(i => (
            <div key={i} className="absolute inset-0 border border-green-500/30 rounded-full" style={{ transform: `scale(${i / 3})` }} />
          ))}
          {/* Sweep line */}
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0"
          >
            <div className="absolute top-1/2 left-1/2 w-1/2 h-0.5 bg-gradient-to-r from-green-500 to-transparent origin-left" />
            <div className="absolute top-0 left-1/2 w-1/2 h-1/2 bg-gradient-to-br from-green-500/30 to-transparent origin-bottom-left" style={{ clipPath: "polygon(0 100%, 100% 0, 100% 100%)" }} />
          </motion.div>
          {/* Center dot */}
          <div className="absolute top-1/2 left-1/2 w-2 h-2 -translate-x-1/2 -translate-y-1/2 bg-green-400 rounded-full" />
          {/* Blips */}
          {[[30, 40], [60, 70], [20, 80]].map(([x, y], i) => (
            <motion.div key={i} animate={{ opacity: [0, 1, 0] }} transition={{ duration: 2, repeat: Infinity, delay: i * 0.5 }} className="absolute w-1 h-1 bg-green-400 rounded-full" style={{ top: `${y}%`, left: `${x}%` }} />
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// NEW VISUAL EFFECTS

// Glowing Orb
function GlowingOrbEffect() {
  return (
    <EffectCard title="Glowing Orb" description="Pulsing energy sphere" whenToUse="Loading states, magical/fantasy themes, or energy indicators.">
      <div className="h-40 flex items-center justify-center">
        <motion.div
          animate={{ 
            scale: [1, 1.1, 1],
            boxShadow: ["0 0 20px #8b5cf6", "0 0 60px #8b5cf6", "0 0 20px #8b5cf6"]
          }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-20 h-20 rounded-full bg-gradient-to-br from-violet-400 to-purple-600"
        />
      </div>
    </EffectCard>
  );
}

// ASCII Art Effect
function ASCIIArtEffect() {
  const chars = ".:-=+*#%@";
  return (
    <EffectCard title="ASCII Art" description="Text-based art style" whenToUse="Retro terminals, developer tools, or creative text displays.">
      <div className="h-40 flex items-center justify-center font-mono text-green-400 text-xs leading-none">
        <div className="space-y-0">
          {[...Array(8)].map((_, y) => (
            <div key={y} className="flex">
              {[...Array(16)].map((_, x) => {
                const dist = Math.sqrt(Math.pow(x - 8, 2) + Math.pow(y - 4, 2));
                const charIdx = Math.min(chars.length - 1, Math.floor(dist / 1.5));
                return <span key={x}>{chars[chars.length - 1 - charIdx]}</span>;
              })}
            </div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Heartbeat Monitor
function HeartbeatMonitorEffect() {
  return (
    <EffectCard title="Heartbeat Monitor" description="ECG line animation" whenToUse="Health apps, status monitors, or live data visualizations.">
      <div className="h-40 flex items-center justify-center bg-slate-950">
        <svg width="200" height="80" className="text-green-500">
          <motion.path
            d="M0,40 L30,40 L40,20 L50,60 L60,30 L70,50 L80,40 L200,40"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: [0, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </svg>
      </div>
    </EffectCard>
  );
}

// Magnetic Field Lines
function MagneticFieldEffect() {
  return (
    <EffectCard title="Magnetic Field" description="Flowing field lines" whenToUse="Science apps, physics visualizations, or abstract backgrounds.">
      <div className="h-40 flex items-center justify-center overflow-hidden">
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            animate={{ 
              rotate: [0, 360],
              scale: [1, 1.2, 1]
            }}
            transition={{ duration: 4 + i, repeat: Infinity, ease: "linear" }}
            className="absolute w-20 h-20 border border-cyan-500/30 rounded-full"
            style={{ width: 40 + i * 20, height: 40 + i * 20 }}
          />
        ))}
      </div>
    </EffectCard>
  );
}

// Retro TV Static
function RetroTVStaticEffect() {
  const [channel, setChannel] = useState(false);
  return (
    <EffectCard title="Retro TV Static" description="Channel change static" whenToUse="Retro themes, error states, or nostalgic transitions." controls={
      <Button onClick={() => { setChannel(true); setTimeout(() => setChannel(false), 500); }} variant="outline" className="w-full">Change Channel</Button>
    }>
      <div className="relative h-40 bg-slate-900 rounded-lg overflow-hidden">
        {channel && (
          <motion.div
            initial={{ opacity: 1 }}
            animate={{ opacity: [1, 0.8, 1, 0.7, 1] }}
            className="absolute inset-0"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`
            }}
          />
        )}
        <div className="absolute inset-0 flex items-center justify-center text-slate-500 text-sm">
          {channel ? "📺 Changing..." : "Click to change channel"}
        </div>
      </div>
    </EffectCard>
  );
}

// Bubble Rise
function BubbleRiseEffect() {
  return (
    <EffectCard title="Bubble Rise" description="Underwater bubbles" whenToUse="Aquatic themes, loading states, or playful backgrounds.">
      <div className="relative h-40 bg-gradient-to-b from-blue-900 to-blue-700 rounded-lg overflow-hidden">
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-white/20 border border-white/30"
            style={{
              width: 8 + Math.random() * 12,
              height: 8 + Math.random() * 12,
              left: `${10 + Math.random() * 80}%`
            }}
            initial={{ bottom: -20 }}
            animate={{ 
              bottom: "110%",
              x: [0, 10, -10, 0]
            }}
            transition={{ 
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: i * 0.3
            }}
          />
        ))}
      </div>
    </EffectCard>
  );
}

// Rotating Cube
function RotatingCubeEffect() {
  return (
    <EffectCard title="3D Rotating Cube" description="Perspective rotation" whenToUse="Product showcases, interactive 3D elements, or brand identity.">
      <div className="h-40 flex items-center justify-center" style={{ perspective: "400px" }}>
        <motion.div
          animate={{ rotateX: 360, rotateY: 360 }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          className="relative w-16 h-16"
          style={{ transformStyle: "preserve-3d" }}
        >
          {[
            { transform: "translateZ(32px)", bg: "from-violet-500 to-violet-600" },
            { transform: "translateZ(-32px) rotateY(180deg)", bg: "from-cyan-500 to-cyan-600" },
            { transform: "translateX(-32px) rotateY(-90deg)", bg: "from-pink-500 to-pink-600" },
            { transform: "translateX(32px) rotateY(90deg)", bg: "from-emerald-500 to-emerald-600" },
            { transform: "translateY(-32px) rotateX(90deg)", bg: "from-amber-500 to-amber-600" },
            { transform: "translateY(32px) rotateX(-90deg)", bg: "from-red-500 to-red-600" }
          ].map((face, i) => (
            <div key={i} className={`absolute w-16 h-16 bg-gradient-to-br ${face.bg} opacity-90`} style={{ transform: face.transform, backfaceVisibility: "hidden" }} />
          ))}
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Text Reveal Mask
function TextRevealMaskEffect() {
  return (
    <EffectCard title="Text Reveal Mask" description="Gradient text reveal" whenToUse="Hero sections, headlines, or attention-grabbing text.">
      <div className="h-40 flex items-center justify-center bg-slate-950 rounded-xl">
        <div className="relative text-4xl font-bold">
          <div className="text-slate-700">REVEAL</div>
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-violet-500 to-cyan-500 bg-clip-text text-transparent"
            initial={{ clipPath: "inset(0 100% 0 0)" }}
            animate={{ clipPath: "inset(0 0% 0 0)" }}
            transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
            style={{ WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}
          >
            REVEAL
          </motion.div>
        </div>
      </div>
    </EffectCard>
  );
}

// Ripple Background
function RippleBackgroundEffect() {
  return (
    <EffectCard title="Ripple Background" description="Continuous ripples" whenToUse="Ambient backgrounds, meditation apps, or calm interfaces.">
      <div className="relative h-40 flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-950 overflow-hidden rounded-xl">
        <div className="absolute inset-0 flex items-center justify-center">
          {[0, 1, 2, 3].map(i => (
            <motion.div
              key={i}
              className="absolute border-2 border-violet-500/30 rounded-full"
              animate={{ 
                scale: [0.5, 3.5],
                opacity: [0.6, 0]
              }}
              transition={{ 
                duration: 4,
                repeat: Infinity,
                delay: i * 1,
                ease: "easeOut"
              }}
              style={{ width: 60, height: 60 }}
            />
          ))}
        </div>
        <span className="relative z-10 text-white/40 text-sm">Endless ripples...</span>
      </div>
    </EffectCard>
  );
}

// Fire Flames
function FireFlamesEffect() {
  return (
    <EffectCard title="Fire Flames" description="Animated fire effect" whenToUse="Hot deals, trending content, or energetic themes.">
      <div className="h-40 flex items-end justify-center pb-4 bg-slate-950 rounded-lg overflow-hidden">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="mx-0.5"
            style={{
              width: 20 + Math.random() * 10,
              background: "linear-gradient(to top, #ff4400, #ff8800, #ffcc00, transparent)",
              borderRadius: "50% 50% 20% 20%"
            }}
            animate={{ 
              height: [40, 60 + Math.random() * 20, 40],
              opacity: [0.7, 1, 0.7]
            }}
            transition={{ 
              duration: 0.3 + Math.random() * 0.2,
              repeat: Infinity,
              delay: i * 0.1
            }}
          />
        ))}
      </div>
    </EffectCard>
  );
}

// Falling Stars
function FallingStarsEffect() {
  return (
    <EffectCard title="Falling Stars" description="Shooting star animation" whenToUse="Night themes, wish features, or magical moments.">
      <div className="relative h-40 bg-slate-950 rounded-lg overflow-hidden">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-0.5 h-8 bg-gradient-to-b from-white to-transparent"
            style={{ 
              top: `${Math.random() * 30}%`,
              left: `${Math.random() * 100}%`,
              transform: "rotate(45deg)"
            }}
            animate={{ 
              x: [0, 100],
              y: [0, 100],
              opacity: [0, 1, 0]
            }}
            transition={{ 
              duration: 1,
              repeat: Infinity,
              delay: i * 0.8 + Math.random() * 2,
              repeatDelay: 2
            }}
          />
        ))}
        {/* Static stars */}
        {[...Array(20)].map((_, i) => (
          <div
            key={`star-${i}`}
            className="absolute w-1 h-1 bg-white rounded-full"
            style={{ top: `${Math.random() * 100}%`, left: `${Math.random() * 100}%`, opacity: 0.3 + Math.random() * 0.7 }}
          />
        ))}
      </div>
    </EffectCard>
  );
}

// Equalizer Bars
function EqualizerBarsEffect() {
  return (
    <EffectCard title="Equalizer Bars" description="Audio visualizer style" whenToUse="Music apps, audio players, or sound-related features.">
      <div className="h-40 flex items-end justify-center gap-1 pb-4">
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            className="w-3 bg-gradient-to-t from-violet-500 to-cyan-400 rounded-t"
            animate={{ 
              height: [20, 40 + Math.random() * 60, 20]
            }}
            transition={{ 
              duration: 0.4 + Math.random() * 0.3,
              repeat: Infinity,
              delay: i * 0.05
            }}
          />
        ))}
      </div>
    </EffectCard>
  );
}

// DNA Helix
function DNAHelixEffect() {
  return (
    <EffectCard title="DNA Helix" description="Rotating double helix" whenToUse="Biotech apps, science themes, or unique loading animations.">
      <div className="h-40 flex items-center justify-center overflow-hidden bg-slate-950 rounded-xl" style={{ perspective: "600px" }}>
        <motion.div 
          animate={{ rotateY: 360 }} 
          transition={{ duration: 6, repeat: Infinity, ease: "linear" }} 
          className="relative w-32 h-32" 
          style={{ transformStyle: "preserve-3d" }}
        >
          {[...Array(12)].map((_, i) => {
            const angle = i * 0.5;
            const y = (i - 6) * 10;
            return (
              <div key={i} className="absolute left-1/2 top-1/2" style={{ transform: `translateY(${y}px)` }}>
                <motion.div
                  className="w-4 h-4 bg-cyan-400 rounded-full shadow-lg shadow-cyan-400/50"
                  style={{ 
                    transform: `translateX(${Math.sin(angle) * 30}px) translateZ(${Math.cos(angle) * 30}px) translateX(-50%) translateY(-50%)`,
                    position: "absolute"
                  }}
                />
                <motion.div
                  className="w-4 h-4 bg-pink-400 rounded-full shadow-lg shadow-pink-400/50"
                  style={{ 
                    transform: `translateX(${-Math.sin(angle) * 30}px) translateZ(${-Math.cos(angle) * 30}px) translateX(-50%) translateY(-50%)`,
                    position: "absolute"
                  }}
                />
                {/* Connection line */}
                <div 
                  className="absolute h-0.5 bg-gradient-to-r from-cyan-400 to-pink-400 opacity-30"
                  style={{
                    width: Math.abs(Math.sin(angle) * 60),
                    left: Math.sin(angle) > 0 ? -Math.abs(Math.sin(angle) * 30) : Math.abs(Math.sin(angle) * 30) - Math.abs(Math.sin(angle) * 60),
                    top: "50%",
                    transform: "translateY(-50%)"
                  }}
                />
              </div>
            );
          })}
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Electric Arc
function ElectricArcEffect() {
  const [flash, setFlash] = useState(false);
  useEffect(() => {
    const interval = setInterval(() => {
      setFlash(true);
      setTimeout(() => setFlash(false), 100);
    }, 2000 + Math.random() * 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <EffectCard title="Electric Arc" description="Tesla coil sparks" whenToUse="Energy themes, power features, or dramatic effects.">
      <div className="h-40 flex items-center justify-center bg-slate-950">
        <div className="relative w-full h-full flex items-center justify-center">
          {flash && (
            <svg className="absolute w-32 h-20">
              <motion.path
                d="M0,40 Q30,20 60,40 Q90,60 120,40"
                fill="none"
                stroke="#00ffff"
                strokeWidth="2"
                initial={{ pathLength: 0, opacity: 0 }}
                animate={{ pathLength: 1, opacity: [0, 1, 0] }}
                transition={{ duration: 0.1 }}
              />
            </svg>
          )}
          <div className="w-4 h-4 bg-cyan-400 rounded-full animate-pulse" />
        </div>
      </div>
    </EffectCard>
  );
}

// Morph Text
function MorphTextEffect() {
  const words = ["Hello", "World", "React", "Magic"];
  const [index, setIndex] = useState(0);
  
  useEffect(() => {
    const interval = setInterval(() => setIndex(i => (i + 1) % words.length), 2500);
    return () => clearInterval(interval);
  }, []);

  return (
    <EffectCard title="Morph Text" description="Smooth text transitions" whenToUse="Taglines, feature highlights, or dynamic headings.">
      <div className="h-40 flex items-center justify-center bg-slate-950 rounded-xl">
        <AnimatePresence mode="wait">
          <motion.span
            key={words[index]}
            initial={{ opacity: 0, y: 30, filter: "blur(10px)", scale: 0.8 }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)", scale: 1 }}
            exit={{ opacity: 0, y: -30, filter: "blur(10px)", scale: 0.8 }}
            transition={{ duration: 0.5 }}
            className="text-5xl font-black bg-gradient-to-r from-violet-400 to-cyan-400 bg-clip-text text-transparent"
            style={{ WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}
          >
            {words[index]}
          </motion.span>
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

export default function VisualEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    // Animation
    { component: <GlitchEffect />, name: "Glitch", category: "animation" },
    { component: <ImageGlitchEffect />, name: "Image Glitch", category: "animation" },
    { component: <ScreenShakeEffect />, name: "Screen Shake", category: "animation" },
    { component: <MarqueeEffect />, name: "Marquee", category: "animation" },
    { component: <FloatingElements />, name: "Floating Elements", category: "animation" },
    { component: <MorphingShapeEffect />, name: "Morphing Shape", category: "animation" },
    { component: <PulsingRingEffect />, name: "Pulsing Ring", category: "animation" },
    { component: <ScanLineEffect />, name: "Scan Line", category: "animation" },
    { component: <LightningEffect />, name: "Lightning", category: "animation" },
    { component: <InkBleedEffect />, name: "Ink Bleed", category: "animation" },
    { component: <FallingStarsEffect />, name: "Falling Stars", category: "animation" },
    { component: <BubbleRiseEffect />, name: "Bubble Rise", category: "animation" },
    { component: <FireFlamesEffect />, name: "Fire Flames", category: "animation" },
    { component: <EqualizerBarsEffect />, name: "Equalizer Bars", category: "animation" },
    { component: <ElectricArcEffect />, name: "Electric Arc", category: "animation" },
    
    // Filters
    { component: <VHSEffect />, name: "VHS/CRT", category: "filter" },
    { component: <FilmGrainMotion />, name: "Film Grain", category: "filter" },
    { component: <DuotoneEffect />, name: "Duotone", category: "filter" },
    { component: <ColorShiftEffect />, name: "Color Shift", category: "filter" },
    { component: <BlurRevealEffect />, name: "Blur Reveal", category: "filter" },
    { component: <VignetteEffect />, name: "Vignette", category: "filter" },
    { component: <ChromaticAberrationEffect />, name: "Chromatic Aberration", category: "filter" },
    { component: <PixelateEffect />, name: "Pixelate", category: "filter" },
    { component: <RetroTVStaticEffect />, name: "Retro TV Static", category: "filter" },
    
    // Backgrounds
    { component: <ParticleSystem />, name: "Particles", category: "background" },
    { component: <MatrixRainEffect />, name: "Matrix Rain", category: "background" },
    { component: <SmokeEffect />, name: "Smoke", category: "background" },
    { component: <NeonGridEffect />, name: "Neon Grid", category: "background" },
    { component: <RadarSweepEffect />, name: "Radar Sweep", category: "background" },
    { component: <MagneticFieldEffect />, name: "Magnetic Field", category: "background" },
    { component: <RippleBackgroundEffect />, name: "Ripple Background", category: "background" },
    { component: <DNAHelixEffect />, name: "DNA Helix", category: "background" },
    
    // Textures
    { component: <NoiseTextureEffect />, name: "Noise Texture", category: "texture" },
    { component: <FrostedGlassEffect />, name: "Frosted Glass", category: "texture" },
    { component: <GradientBorderEffect />, name: "Gradient Border", category: "texture" },
    { component: <LiquidDistortion />, name: "Liquid Distortion", category: "texture" },
    { component: <HeatDistortion />, name: "Heat Distortion", category: "texture" },
    { component: <HolographicEffect />, name: "Holographic", category: "texture" },
    
    // Shapes
    { component: <GlowingOrbEffect />, name: "Glowing Orb", category: "shape" },
    { component: <RotatingCubeEffect />, name: "3D Rotating Cube", category: "shape" },
    { component: <KaleidoscopeEffect />, name: "Kaleidoscope", category: "shape" },
    { component: <PrismLight />, name: "Prism Light", category: "shape" },
    { component: <StarburstEffect />, name: "Starburst", category: "shape" },
    
    // Text Effects
    { component: <NeonGlowEffect />, name: "Neon Glow", category: "text" },
    { component: <TextGradientAnimation />, name: "Text Gradient", category: "text" },
    { component: <TextRevealMaskEffect />, name: "Text Reveal Mask", category: "text" },
    { component: <MorphTextEffect />, name: "Morph Text", category: "text" },
    { component: <ASCIIArtEffect />, name: "ASCII Art", category: "text" },
    
    // Interactive
    { component: <SpotlightEffect />, name: "Spotlight", category: "interactive" },
    { component: <ParallaxTiltEffect />, name: "Parallax Tilt", category: "interactive" },
    { component: <WaterRippleEffect />, name: "Water Ripple", category: "interactive" },
    
    // Loading
    { component: <SkeletonLoading />, name: "Skeleton Loading", category: "loading" },
    { component: <HeartbeatMonitorEffect />, name: "Heartbeat Monitor", category: "loading" },
    { component: <EnergyWave />, name: "Energy Wave", category: "loading" },
  ];

  const visualCategories = [
    { id: "all", label: "All" },
    { id: "animation", label: "Animation" },
    { id: "filter", label: "Filters" },
    { id: "background", label: "Backgrounds" },
    { id: "texture", label: "Textures" },
    { id: "shape", label: "Shapes" },
    { id: "text", label: "Text" },
    { id: "interactive", label: "Interactive" },
    { id: "loading", label: "Loading" },
  ];

  const filteredEffects = effects.filter(e => {
    const matchesSearch = e.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === "all" || e.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={Eye} title="Visual Effects" description="55+ stunning screen effects, filters, and visual enhancements" gradient="#8b5cf6" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* Category Pills */}
        <div className="mb-6 flex flex-wrap gap-2">
          {visualCategories.map(cat => (
            <button key={cat.id} onClick={() => setActiveCategory(cat.id)} className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${activeCategory === cat.id ? "bg-gradient-to-r from-violet-500 to-purple-500 text-white shadow-lg" : "bg-slate-800 text-slate-400 hover:bg-slate-700"}`}>
              {cat.label}
            </button>
          ))}
        </div>
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filteredEffects.length} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredEffects.map((effect, i) => <div key={i}>{effect.component}</div>)}
        </div>
      </div>
    </div>
  );
}