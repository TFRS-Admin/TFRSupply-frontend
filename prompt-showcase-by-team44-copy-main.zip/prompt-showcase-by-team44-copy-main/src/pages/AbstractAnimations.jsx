import React, { useState } from "react";
import { motion } from "framer-motion";
import { Wand2 } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// Liquid Morph Effect
function LiquidMorph() {
  return (
    <div className="relative w-full h-48 flex items-center justify-center">
      <svg viewBox="0 0 200 200" className="w-32 h-32">
        <defs>
          <linearGradient id="liquid-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#8b5cf6" />
            <stop offset="100%" stopColor="#06b6d4" />
          </linearGradient>
        </defs>
        <motion.path
          fill="url(#liquid-grad)"
          animate={{
            d: [
              "M50,100 Q75,50 100,100 Q125,150 150,100 Q125,50 100,100 Q75,150 50,100",
              "M50,100 Q100,25 150,100 Q100,175 50,100",
              "M75,75 Q100,50 125,75 Q150,100 125,125 Q100,150 75,125 Q50,100 75,75",
              "M50,100 Q75,50 100,100 Q125,150 150,100 Q125,50 100,100 Q75,150 50,100",
            ],
          }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        />
      </svg>
    </div>
  );
}

// Geometric Dance
function GeometricDance() {
  const shapes = [
    { type: "circle", color: "#8b5cf6", size: 30, delay: 0 },
    { type: "square", color: "#06b6d4", size: 25, delay: 0.2 },
    { type: "triangle", color: "#ec4899", size: 35, delay: 0.4 },
  ];

  return (
    <div className="relative w-full h-48 flex items-center justify-center gap-8">
      {shapes.map((shape, i) => (
        <motion.div
          key={i}
          animate={{
            y: [0, -30, 0],
            rotate: [0, 180, 360],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 2,
            delay: shape.delay,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          style={{
            width: shape.size,
            height: shape.size,
            backgroundColor: shape.color,
            borderRadius: shape.type === "circle" ? "50%" : shape.type === "square" ? "4px" : "0",
            clipPath: shape.type === "triangle" ? "polygon(50% 0%, 0% 100%, 100% 100%)" : "none",
          }}
        />
      ))}
    </div>
  );
}

// Color Bloom
function ColorBloom() {
  return (
    <div className="relative w-full h-48 flex items-center justify-center">
      {[0, 1, 2, 3, 4].map((i) => (
        <motion.div
          key={i}
          className="absolute rounded-full"
          style={{
            width: 100 - i * 15,
            height: 100 - i * 15,
            background: `hsl(${260 + i * 20}, 80%, ${50 + i * 5}%)`,
          }}
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.8, 0.4, 0.8],
          }}
          transition={{
            duration: 2,
            delay: i * 0.2,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
}

// Wave Distortion
function WaveDistortion() {
  return (
    <div className="relative w-full h-48 overflow-hidden">
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-full h-2"
          style={{
            top: `${i * 12.5}%`,
            background: `linear-gradient(90deg, transparent, hsl(${260 + i * 10}, 80%, 60%), transparent)`,
          }}
          animate={{
            x: ["-100%", "100%"],
            scaleY: [1, 2, 1],
          }}
          transition={{
            duration: 3,
            delay: i * 0.1,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
}

// Kaleidoscope
function Kaleidoscope() {
  return (
    <div className="relative w-full h-48 flex items-center justify-center">
      <motion.div
        className="relative w-32 h-32"
        animate={{ rotate: 360 }}
        transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
      >
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-full h-full"
            style={{
              transform: `rotate(${i * 60}deg)`,
            }}
          >
            <div
              className="absolute top-0 left-1/2 -translate-x-1/2 w-4 h-16"
              style={{
                background: `linear-gradient(to bottom, hsl(${i * 60}, 80%, 60%), transparent)`,
                clipPath: "polygon(50% 0%, 0% 100%, 100% 100%)",
              }}
            />
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}

// Particle Vortex
function ParticleVortex() {
  return (
    <div className="relative w-full h-48 flex items-center justify-center overflow-hidden">
      {[...Array(30)].map((_, i) => {
        const angle = (i / 30) * Math.PI * 2;
        const radius = 40 + (i % 3) * 20;
        return (
          <motion.div
            key={i}
            className="absolute w-2 h-2 rounded-full bg-violet-500"
            style={{
              boxShadow: "0 0 10px #8b5cf6",
            }}
            animate={{
              x: [
                Math.cos(angle) * radius,
                Math.cos(angle + Math.PI) * radius,
                Math.cos(angle) * radius,
              ],
              y: [
                Math.sin(angle) * radius,
                Math.sin(angle + Math.PI) * radius,
                Math.sin(angle) * radius,
              ],
              scale: [1, 1.5, 1],
              opacity: [0.5, 1, 0.5],
            }}
            transition={{
              duration: 3 + (i % 3),
              repeat: Infinity,
              ease: "easeInOut",
              delay: i * 0.05,
            }}
          />
        );
      })}
    </div>
  );
}

// Neon Pulse Grid
function NeonPulseGrid() {
  return (
    <div className="relative w-full h-48 grid grid-cols-5 grid-rows-4 gap-2 p-4">
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="rounded-lg"
          style={{
            background: `hsl(${260 + (i % 5) * 20}, 80%, 50%)`,
            boxShadow: `0 0 10px hsl(${260 + (i % 5) * 20}, 80%, 50%)`,
          }}
          animate={{
            opacity: [0.3, 1, 0.3],
            scale: [0.9, 1, 0.9],
          }}
          transition={{
            duration: 1.5,
            delay: i * 0.1,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
}

// Infinity Loop
function InfinityLoop() {
  return (
    <div className="relative w-full h-48 flex items-center justify-center">
      <svg viewBox="0 0 200 100" className="w-48 h-24">
        <motion.path
          d="M50,50 C50,25 75,25 100,50 C125,75 150,75 150,50 C150,25 125,25 100,50 C75,75 50,75 50,50"
          fill="none"
          stroke="url(#infinity-grad)"
          strokeWidth="4"
          strokeLinecap="round"
          initial={{ pathLength: 0, pathOffset: 0 }}
          animate={{ pathLength: 1, pathOffset: 1 }}
          transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
        />
        <defs>
          <linearGradient id="infinity-grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#8b5cf6" />
            <stop offset="50%" stopColor="#06b6d4" />
            <stop offset="100%" stopColor="#ec4899" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

// More abstract effects
function SpiralGalaxy() {
  return (
    <div className="relative w-full h-48 flex items-center justify-center bg-black overflow-hidden">
      {[...Array(100)].map((_, i) => {
        const angle = (i / 100) * Math.PI * 8;
        const radius = 10 + i * 0.8;
        return (
          <motion.div key={i} className="absolute w-1 h-1 bg-white rounded-full" style={{ left: "50%", top: "50%" }}
            animate={{ x: [Math.cos(angle) * radius, Math.cos(angle + Math.PI * 2) * radius], y: [Math.sin(angle) * radius, Math.sin(angle + Math.PI * 2) * radius], opacity: [0.3, 1, 0.3] }}
            transition={{ duration: 10, repeat: Infinity, delay: i * 0.02 }} />
        );
      })}
    </div>
  );
}

function PrismRefraction() {
  return (
    <div className="relative w-full h-48 flex items-center justify-center">
      <motion.div className="w-0 h-0 border-l-[40px] border-r-[40px] border-b-[70px] border-transparent border-b-white/20" animate={{ rotate: 360 }} transition={{ duration: 20, repeat: Infinity, ease: "linear" }} />
      {["#ff0000", "#ff7700", "#ffff00", "#00ff00", "#0077ff", "#8800ff"].map((c, i) => (
        <motion.div key={i} className="absolute w-20 h-1" style={{ background: c, transformOrigin: "left center" }}
          animate={{ rotate: [20 + i * 8, 40 + i * 8, 20 + i * 8], x: [60, 80, 60] }}
          transition={{ duration: 3, repeat: Infinity, delay: i * 0.1 }} />
      ))}
    </div>
  );
}

function FloatingOrbs() {
  return (
    <div className="relative w-full h-48 overflow-hidden">
      {[...Array(6)].map((_, i) => (
        <motion.div key={i} className="absolute rounded-full" style={{ width: 20 + i * 10, height: 20 + i * 10, background: `radial-gradient(circle, hsl(${i * 60}, 80%, 60%), transparent)`, left: `${15 + i * 15}%` }}
          animate={{ y: [0, -30, 0], scale: [1, 1.2, 1] }}
          transition={{ duration: 2 + i * 0.5, repeat: Infinity, delay: i * 0.3 }} />
      ))}
    </div>
  );
}

function DNAHelix() {
  return (
    <div className="relative w-full h-48 flex items-center justify-center">
      {[...Array(20)].map((_, i) => (
        <motion.div key={i} className="absolute flex gap-16" style={{ top: `${i * 5}%` }}
          animate={{ rotateY: [0, 360] }}
          transition={{ duration: 4, repeat: Infinity, delay: i * 0.1, ease: "linear" }}>
          <div className="w-3 h-3 rounded-full bg-violet-500" />
          <div className="w-3 h-3 rounded-full bg-cyan-500" />
        </motion.div>
      ))}
    </div>
  );
}

function SoundWaveform() {
  return (
    <div className="w-full h-48 flex items-center justify-center gap-1">
      {[...Array(30)].map((_, i) => (
        <motion.div key={i} className="w-2 bg-gradient-to-t from-violet-500 to-cyan-500 rounded-full"
          animate={{ height: [10, 30 + Math.random() * 50, 10] }}
          transition={{ duration: 0.5 + Math.random() * 0.5, repeat: Infinity, delay: i * 0.05 }} />
      ))}
    </div>
  );
}

function ConcentricRipples() {
  return (
    <div className="relative w-full h-48 flex items-center justify-center">
      {[...Array(5)].map((_, i) => (
        <motion.div key={i} className="absolute border-2 border-cyan-500 rounded-full"
          animate={{ width: [0, 200], height: [0, 200], opacity: [1, 0] }}
          transition={{ duration: 3, repeat: Infinity, delay: i * 0.6 }} />
      ))}
    </div>
  );
}

function GlowingCube() {
  return (
    <div className="w-full h-48 flex items-center justify-center" style={{ perspective: "200px" }}>
      <motion.div className="relative w-16 h-16" style={{ transformStyle: "preserve-3d" }}
        animate={{ rotateX: 360, rotateY: 360 }}
        transition={{ duration: 8, repeat: Infinity, ease: "linear" }}>
        {[0, 90, 180, 270].map((r, i) => (
          <div key={i} className="absolute w-16 h-16 bg-violet-500/30 border border-violet-500" style={{ transform: `rotateY(${r}deg) translateZ(32px)`, boxShadow: "0 0 20px #8b5cf6" }} />
        ))}
      </motion.div>
    </div>
  );
}

function FluidMesh() {
  return (
    <div className="w-full h-48 relative overflow-hidden">
      {[...Array(16)].map((_, i) => (
        <motion.div key={i} className="absolute w-full h-1" style={{ top: `${i * 6.5}%`, background: `linear-gradient(90deg, transparent, hsl(${260 + i * 5}, 80%, 60%), transparent)` }}
          animate={{ x: ["-50%", "50%", "-50%"] }}
          transition={{ duration: 4, repeat: Infinity, delay: i * 0.15, ease: "easeInOut" }} />
      ))}
    </div>
  );
}

function AtomOrbit() {
  return (
    <div className="w-full h-48 flex items-center justify-center">
      <div className="relative">
        <div className="w-6 h-6 rounded-full bg-gradient-to-br from-violet-500 to-cyan-500" style={{ boxShadow: "0 0 20px #8b5cf6" }} />
        {[0, 60, 120].map((r, i) => (
          <motion.div key={i} className="absolute w-24 h-24 border border-slate-600 rounded-full" style={{ left: -36, top: -36, transform: `rotate(${r}deg)` }}
            animate={{ rotate: [r, r + 360] }}
            transition={{ duration: 3 + i, repeat: Infinity, ease: "linear" }}>
            <motion.div className="absolute w-3 h-3 rounded-full bg-cyan-400" style={{ top: -6, left: "50%" }} />
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function MorphingPolygon() {
  return (
    <div className="w-full h-48 flex items-center justify-center">
      <motion.div className="w-24 h-24 bg-gradient-to-br from-pink-500 to-violet-500"
        animate={{ borderRadius: ["0%", "50%", "20%", "50%", "0%"], rotate: [0, 180, 360] }}
        transition={{ duration: 6, repeat: Infinity }} />
    </div>
  );
}

function LaserGrid() {
  return (
    <div className="w-full h-48 relative overflow-hidden bg-black">
      <div className="absolute inset-0" style={{ background: "linear-gradient(transparent 95%, #06b6d4 95%), linear-gradient(90deg, transparent 95%, #06b6d4 95%)", backgroundSize: "20px 20px", transform: "perspective(200px) rotateX(60deg)", transformOrigin: "top" }} />
      <motion.div className="absolute bottom-0 w-full h-1 bg-cyan-500" style={{ boxShadow: "0 0 30px #06b6d4" }}
        animate={{ y: [0, -150, 0] }}
        transition={{ duration: 2, repeat: Infinity }} />
    </div>
  );
}

function PlasmaField() {
  return (
    <div className="w-full h-48 relative overflow-hidden">
      {[...Array(20)].map((_, i) => (
        <motion.div key={i} className="absolute rounded-full blur-xl" style={{ width: 50 + Math.random() * 50, height: 50 + Math.random() * 50, background: `hsl(${Math.random() * 60 + 260}, 80%, 50%)`, left: `${Math.random() * 100}%`, top: `${Math.random() * 100}%` }}
          animate={{ x: [0, Math.random() * 40 - 20], y: [0, Math.random() * 40 - 20], scale: [1, 1.5, 1] }}
          transition={{ duration: 3 + Math.random() * 2, repeat: Infinity }} />
      ))}
    </div>
  );
}

function DigitalRain() {
  return (
    <div className="w-full h-48 relative overflow-hidden bg-black font-mono text-green-500 text-xs">
      {[...Array(20)].map((_, i) => (
        <motion.div key={i} className="absolute" style={{ left: `${i * 5}%` }}
          animate={{ y: ["-100%", "200%"] }}
          transition={{ duration: 2 + Math.random() * 2, repeat: Infinity, delay: Math.random() * 2 }}>
          {[...Array(10)].map((_, j) => (<div key={j} style={{ opacity: 1 - j * 0.1 }}>{String.fromCharCode(0x30A0 + Math.random() * 96)}</div>))}
        </motion.div>
      ))}
    </div>
  );
}

function PulseStar() {
  return (
    <div className="w-full h-48 flex items-center justify-center">
      <motion.div className="relative" animate={{ rotate: 360 }} transition={{ duration: 20, repeat: Infinity, ease: "linear" }}>
        {[...Array(8)].map((_, i) => (
          <motion.div key={i} className="absolute w-1 h-20 bg-gradient-to-t from-amber-500 to-transparent origin-bottom" style={{ transform: `rotate(${i * 45}deg)` }}
            animate={{ scaleY: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 1, repeat: Infinity, delay: i * 0.1 }} />
        ))}
        <div className="w-6 h-6 rounded-full bg-amber-500" style={{ boxShadow: "0 0 30px #f59e0b" }} />
      </motion.div>
    </div>
  );
}

function HexagonTiles() {
  const hexSize = 30;
  return (
    <div className="w-full h-48 flex items-center justify-center">
      <div className="grid grid-cols-5 gap-1">
        {[...Array(15)].map((_, i) => (
          <motion.div key={i} className="w-8 h-8" style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)", background: `hsl(${260 + i * 8}, 70%, 50%)` }}
            animate={{ scale: [1, 1.1, 1], opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 1.5, delay: i * 0.1, repeat: Infinity }} />
        ))}
      </div>
    </div>
  );
}

function BubbleRise() {
  return (
    <div className="w-full h-48 relative overflow-hidden bg-gradient-to-b from-blue-900 to-blue-600">
      {[...Array(15)].map((_, i) => (
        <motion.div key={i} className="absolute rounded-full bg-white/20 border border-white/30" style={{ width: 10 + Math.random() * 20, height: 10 + Math.random() * 20, left: `${Math.random() * 100}%` }}
          animate={{ y: ["120%", "-20%"], x: [0, Math.random() * 20 - 10] }}
          transition={{ duration: 3 + Math.random() * 2, repeat: Infinity, delay: Math.random() * 2 }} />
      ))}
    </div>
  );
}

function FireEmbers() {
  return (
    <div className="w-full h-48 relative overflow-hidden bg-gradient-to-t from-orange-900 to-black">
      {[...Array(30)].map((_, i) => (
        <motion.div key={i} className="absolute w-1 h-1 rounded-full" style={{ background: `hsl(${Math.random() * 30 + 15}, 100%, 50%)`, left: `${Math.random() * 100}%`, bottom: 0 }}
          animate={{ y: [0, -200], opacity: [1, 0], scale: [1, 0] }}
          transition={{ duration: 2 + Math.random() * 2, repeat: Infinity, delay: Math.random() * 2 }} />
      ))}
    </div>
  );
}

function TwistingBands() {
  return (
    <div className="w-full h-48 flex items-center justify-center" style={{ perspective: "300px" }}>
      {[...Array(5)].map((_, i) => (
        <motion.div key={i} className="absolute w-40 h-2 rounded-full" style={{ background: `hsl(${260 + i * 20}, 80%, 60%)`, transformStyle: "preserve-3d" }}
          animate={{ rotateX: [0, 360], rotateY: [i * 30, i * 30 + 360] }}
          transition={{ duration: 4 + i, repeat: Infinity, ease: "linear" }} />
      ))}
    </div>
  );
}

function CircuitPulse() {
  return (
    <div className="w-full h-48 relative bg-slate-950 overflow-hidden">
      <div className="absolute inset-0" style={{ backgroundImage: "linear-gradient(#334155 1px, transparent 1px), linear-gradient(90deg, #334155 1px, transparent 1px)", backgroundSize: "20px 20px" }} />
      {[...Array(5)].map((_, i) => (
        <motion.div key={i} className="absolute h-1 bg-cyan-500" style={{ top: `${20 + i * 15}%`, left: 0, boxShadow: "0 0 10px #06b6d4" }}
          animate={{ width: ["0%", "100%", "0%"], left: ["0%", "0%", "100%"] }}
          transition={{ duration: 2, delay: i * 0.3, repeat: Infinity }} />
      ))}
    </div>
  );
}

function GlowOrbit() {
  return (
    <div className="w-full h-48 flex items-center justify-center">
      <div className="relative w-32 h-32">
        <motion.div className="absolute w-4 h-4 rounded-full bg-violet-500" style={{ boxShadow: "0 0 20px #8b5cf6, 0 0 40px #8b5cf6" }}
          animate={{ rotate: 360 }}
          transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          style={{ transformOrigin: "64px 64px" }} />
        <motion.div className="absolute w-3 h-3 rounded-full bg-cyan-500" style={{ boxShadow: "0 0 15px #06b6d4" }}
          animate={{ rotate: -360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          style={{ transformOrigin: "64px 64px", left: 20 }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white" style={{ boxShadow: "0 0 30px white" }} />
      </div>
    </div>
  );
}

const effects = [
  { id: 1, title: "Liquid Morph", description: "Smooth morphing blob animation", component: LiquidMorph },
  { id: 2, title: "Geometric Dance", description: "Dancing shapes with rotation", component: GeometricDance },
  { id: 3, title: "Color Bloom", description: "Pulsing color circles", component: ColorBloom },
  { id: 4, title: "Wave Distortion", description: "Flowing wave patterns", component: WaveDistortion },
  { id: 5, title: "Kaleidoscope", description: "Rotating symmetrical pattern", component: Kaleidoscope },
  { id: 6, title: "Particle Vortex", description: "Swirling particle system", component: ParticleVortex },
  { id: 7, title: "Neon Pulse Grid", description: "Animated grid with glow", component: NeonPulseGrid },
  { id: 8, title: "Infinity Loop", description: "Endless loop animation", component: InfinityLoop },
  { id: 9, title: "Spiral Galaxy", description: "Rotating star spiral", component: SpiralGalaxy },
  { id: 10, title: "Prism Refraction", description: "Rainbow light split", component: PrismRefraction },
  { id: 11, title: "Floating Orbs", description: "Bouncing gradient orbs", component: FloatingOrbs },
  { id: 12, title: "DNA Helix", description: "Rotating double helix", component: DNAHelix },
  { id: 13, title: "Sound Waveform", description: "Audio visualizer bars", component: SoundWaveform },
  { id: 14, title: "Concentric Ripples", description: "Expanding water rings", component: ConcentricRipples },
  { id: 15, title: "Glowing Cube", description: "3D rotating cube", component: GlowingCube },
  { id: 16, title: "Fluid Mesh", description: "Flowing gradient lines", component: FluidMesh },
  { id: 17, title: "Atom Orbit", description: "Electron orbits", component: AtomOrbit },
  { id: 18, title: "Morphing Polygon", description: "Shape transitions", component: MorphingPolygon },
  { id: 19, title: "Laser Grid", description: "Retro perspective grid", component: LaserGrid },
  { id: 20, title: "Plasma Field", description: "Blurred color blobs", component: PlasmaField },
  { id: 21, title: "Digital Rain", description: "Matrix code fall", component: DigitalRain },
  { id: 22, title: "Pulse Star", description: "Radiating star burst", component: PulseStar },
  { id: 23, title: "Hexagon Tiles", description: "Pulsing hex pattern", component: HexagonTiles },
  { id: 24, title: "Bubble Rise", description: "Underwater bubbles", component: BubbleRise },
  { id: 25, title: "Fire Embers", description: "Rising fire sparks", component: FireEmbers },
  { id: 26, title: "Twisting Bands", description: "3D rotating ribbons", component: TwistingBands },
  { id: 27, title: "Circuit Pulse", description: "Tech circuit animation", component: CircuitPulse },
  { id: 28, title: "Glow Orbit", description: "Orbital light trails", component: GlowOrbit },
];

export default function AbstractAnimations() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const filteredEffects = effects.filter((e) =>
    e.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen">
      <CategoryHeader
        icon={Wand2}
        title="Abstract Animations"
        description="Mesmerizing abstract visual effects and animations"
        gradient="#8b5cf6, #ec4899"
      />
      <div className="max-w-7xl mx-auto px-4 pb-20">
        <SearchFilter
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          activeCategory={activeCategory}
          setActiveCategory={setActiveCategory}
          resultCount={filteredEffects.length}
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredEffects.map((effect) => (
            <EffectCard
              key={effect.id}
              title={effect.title}
              description={effect.description}
            >
              <effect.component />
            </EffectCard>
          ))}
        </div>
      </div>
    </div>
  );
}