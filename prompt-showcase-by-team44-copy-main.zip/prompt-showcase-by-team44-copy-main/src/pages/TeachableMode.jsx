import React, { useState, createContext, useContext } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { GraduationCap, Eye, EyeOff, Info, Lightbulb, Play } from "lucide-react";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import CategoryHeader from "@/components/effects/CategoryHeader";
import { useQuery } from "@tanstack/react-query";

// Comprehensive UI terminology definitions
const uiTerminology = [
  {
    category: "Containers",
    terms: [
      { name: "Card", description: "A container with border and background that groups related content, creating visual hierarchy.", useCase: "Product displays, user profiles, dashboard widgets" },
      { name: "Modal", description: "An overlay dialog that focuses user attention on specific content or actions, blocking the background.", useCase: "Confirmations, forms, detailed views, alerts" },
      { name: "Drawer", description: "A panel that slides in from the edge of the screen, usually for navigation or secondary content.", useCase: "Mobile menus, settings panels, filters" },
      { name: "Accordion", description: "Collapsible sections that expand/collapse to show/hide content, saving vertical space.", useCase: "FAQs, settings, nested navigation" },
      { name: "Panel", description: "A distinct section of the interface, often with its own scroll or functionality.", useCase: "Split views, sidebars, tool panels" },
    ]
  },
  {
    category: "Navigation",
    terms: [
      { name: "Tabs", description: "Navigation elements that switch between different views within the same context.", useCase: "Content organization, settings pages, dashboards" },
      { name: "Breadcrumb", description: "A navigation aid showing the current location within a site hierarchy.", useCase: "E-commerce, file managers, deep navigation" },
      { name: "Navbar", description: "The primary navigation bar, usually at the top of the page with main links.", useCase: "Site-wide navigation, branding" },
      { name: "Sidebar", description: "A vertical navigation panel on the side of the content area.", useCase: "Dashboards, admin panels, documentation" },
      { name: "Pagination", description: "Controls for navigating through pages of content.", useCase: "Search results, data tables, galleries" },
    ]
  },
  {
    category: "Inputs",
    terms: [
      { name: "Input Field", description: "A text entry area where users can type information.", useCase: "Forms, search bars, settings" },
      { name: "Textarea", description: "A multi-line text input for longer content.", useCase: "Comments, descriptions, messages" },
      { name: "Checkbox", description: "A toggle for boolean choices, allows multiple selections.", useCase: "Settings, filters, agreements" },
      { name: "Radio Button", description: "Selects one option from a mutually exclusive group.", useCase: "Single-choice questions, shipping options" },
      { name: "Toggle Switch", description: "A binary control for switching between two states (on/off).", useCase: "Settings, preferences, feature flags" },
      { name: "Dropdown/Select", description: "A collapsible list that reveals options when activated.", useCase: "Selection menus, filters, country selectors" },
      { name: "Slider", description: "A control for selecting a value from a range by dragging a handle.", useCase: "Volume controls, price filters, settings" },
      { name: "Date Picker", description: "A calendar interface for selecting dates.", useCase: "Booking, scheduling, filters" },
    ]
  },
  {
    category: "Feedback",
    terms: [
      { name: "Toast", description: "A brief notification that appears temporarily, usually at screen edge.", useCase: "Success messages, errors, updates" },
      { name: "Tooltip", description: "A small popup that provides extra information on hover.", useCase: "Help text, abbreviations, previews" },
      { name: "Progress Bar", description: "A visual indicator showing completion status of a task or process.", useCase: "File uploads, onboarding, skill levels" },
      { name: "Spinner/Loader", description: "An animated indicator showing that something is loading.", useCase: "Page loads, form submissions, data fetching" },
      { name: "Skeleton", description: "A placeholder that mimics content shape while loading.", useCase: "Content loading, perceived performance" },
      { name: "Alert/Banner", description: "A prominent message for important information or errors.", useCase: "Warnings, announcements, errors" },
    ]
  },
  {
    category: "Visual Elements",
    terms: [
      { name: "Badge", description: "A small label that highlights status, count, or category information.", useCase: "Notification counts, status indicators, tags" },
      { name: "Icon Badge", description: "A small rounded container with an icon, used to represent categories visually.", useCase: "Category indicators, feature highlights, visual shortcuts" },
      { name: "Avatar", description: "A visual representation of a user, typically a profile picture or initials.", useCase: "User profiles, comments, team displays" },
      { name: "Chip/Tag", description: "A compact element representing input, attribute, or action.", useCase: "Tags, filters, selections, skills" },
      { name: "Divider", description: "A horizontal or vertical line separating content sections.", useCase: "Lists, forms, content separation" },
    ]
  },
  {
    category: "Actions",
    terms: [
      { name: "Button", description: "An interactive element that triggers an action when clicked.", useCase: "Form submissions, navigation, toggling states" },
      { name: "Icon Button", description: "A button that uses only an icon, no text.", useCase: "Toolbars, compact actions, toggles" },
      { name: "FAB (Floating Action Button)", description: "A prominent circular button floating over content for primary actions.", useCase: "Compose, create, primary mobile actions" },
      { name: "Link", description: "Text that navigates to another location when clicked.", useCase: "Navigation, references, external resources" },
      { name: "Menu", description: "A list of actions or options that appears on interaction.", useCase: "Context menus, dropdowns, settings" },
    ]
  },
];

// Live demo components for preview
const termDemos = {
  "Card": () => (
    <div className="p-3 rounded-xl bg-slate-700 border border-slate-600 w-32">
      <div className="w-8 h-8 rounded-full bg-violet-500 mb-2" />
      <div className="h-2 bg-slate-500 rounded mb-1 w-full" />
      <div className="h-2 bg-slate-600 rounded w-2/3" />
    </div>
  ),
  "Modal": () => (
    <div className="relative w-40 h-24 bg-slate-800/50 rounded-lg flex items-center justify-center">
      <div className="bg-slate-700 rounded-lg p-3 border border-slate-600 shadow-xl">
        <div className="h-2 bg-violet-500 rounded w-16 mb-2" />
        <div className="flex gap-1">
          <div className="h-4 w-8 bg-slate-600 rounded" />
          <div className="h-4 w-8 bg-violet-500 rounded" />
        </div>
      </div>
    </div>
  ),
  "Button": () => (
    <motion.div whileHover={{ scale: 1.05 }} className="px-4 py-2 bg-violet-500 rounded-lg text-white text-sm font-medium">
      Click Me
    </motion.div>
  ),
  "Toggle Switch": () => (
    <div className="w-12 h-6 bg-violet-500 rounded-full p-1">
      <motion.div animate={{ x: 24 }} className="w-4 h-4 bg-white rounded-full" />
    </div>
  ),
  "Toast": () => (
    <motion.div initial={{ y: 10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="px-3 py-2 bg-emerald-500 text-white text-xs rounded-lg flex items-center gap-2">
      ✓ Success!
    </motion.div>
  ),
  "Spinner/Loader": () => (
    <div className="w-6 h-6 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" />
  ),
  "Badge": () => (
    <span className="px-2 py-1 bg-violet-500/20 text-violet-400 text-xs rounded-full">New</span>
  ),
  "Tooltip": () => (
    <div className="relative">
      <div className="w-6 h-6 bg-slate-600 rounded" />
      <div className="absolute -top-8 left-1/2 -translate-x-1/2 px-2 py-1 bg-slate-700 text-white text-xs rounded">Tooltip</div>
    </div>
  ),
};

function TermCard({ term }) {
  const [isExpanded, setIsExpanded] = useState(false);
  const DemoComponent = termDemos[term.name];
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-violet-500/50 transition-colors cursor-pointer"
      onClick={() => setIsExpanded(!isExpanded)}
    >
      <div className="flex items-start justify-between gap-2">
        <h4 className="font-semibold text-white">{term.name}</h4>
        <div className="flex items-center gap-1">
          {DemoComponent && (
            <HoverCard openDelay={100} closeDelay={100}>
              <HoverCardTrigger asChild>
                <button onClick={(e) => e.stopPropagation()} className="p-1 rounded hover:bg-slate-700 text-cyan-400">
                  <Play className="w-4 h-4" />
                </button>
              </HoverCardTrigger>
              <HoverCardContent side="top" className="w-auto bg-slate-900 border-slate-700 p-4">
                <p className="text-xs text-slate-400 mb-2">Live Preview:</p>
                <DemoComponent />
              </HoverCardContent>
            </HoverCard>
          )}
          <Info className="w-4 h-4 text-slate-500 flex-shrink-0" />
        </div>
      </div>
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-3 pt-3 border-t border-slate-700"
          >
            <p className="text-sm text-slate-300 mb-2">{term.description}</p>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 text-xs rounded bg-teal-500/20 text-teal-400">Use cases</span>
              <span className="text-xs text-slate-400">{term.useCase}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function TeachableMode() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  
  const filteredTerms = uiTerminology.flatMap(cat => 
    (activeCategory === "all" || cat.category === activeCategory)
      ? cat.terms.filter(t => 
          t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          t.description.toLowerCase().includes(searchQuery.toLowerCase())
        ).map(t => ({ ...t, category: cat.category }))
      : []
  );

  return (
    <div>
      <CategoryHeader 
        icon={GraduationCap} 
        title="Hover & Learn" 
        description="Learn UI/UX terminology - click any term to learn what it's called and when to use it" 
        gradient="#8b5cf6" 
      />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* Info Card */}
        <Card className="bg-gradient-to-r from-violet-500/10 to-cyan-500/10 border-violet-500/20 mb-8">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-xl bg-violet-500/20">
                <Lightbulb className="w-6 h-6 text-violet-400" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">🎓 Teachable Moments</h3>
                <p className="text-slate-300 text-sm mb-3">
                  Ever wondered what that little icon box is called? Or what's the difference between a Modal and a Drawer? 
                  This page teaches you the proper terminology for all UI elements!
                </p>
                <p className="text-slate-400 text-sm">
                  <strong className="text-violet-400">About Icon Badges:</strong> Those small square icons with rounded corners 
                  you see on the Home page cards (like the Eye icon for Visual Effects) are called <strong className="text-cyan-400">Icon Badges</strong>. 
                  They're used to visually represent categories at a glance!
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Category Tabs */}
        <div className="flex flex-wrap gap-2 mb-6">
          <button
            onClick={() => setActiveCategory("all")}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeCategory === "all" ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            All ({uiTerminology.flatMap(c => c.terms).length})
          </button>
          {uiTerminology.map(cat => (
            <button
              key={cat.category}
              onClick={() => setActiveCategory(cat.category)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeCategory === cat.category ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              {cat.category} ({cat.terms.length})
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative mb-8">
          <input
            type="text"
            placeholder="Search terms..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder:text-slate-500 focus:border-violet-500 focus:outline-none"
          />
        </div>

        {/* Terms Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTerms.map((term, i) => (
            <TermCard key={term.name} term={term} />
          ))}
        </div>

        {filteredTerms.length === 0 && (
          <div className="text-center py-12">
            <p className="text-slate-400">No terms found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );
}