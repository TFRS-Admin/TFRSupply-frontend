import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Gamepad2, Zap, MousePointerClick } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import * as GameKit from "@/components/gaming/ReactGameKit";
import { useQuery } from "@tanstack/react-query";
import LazyRender from "@/components/utils/LazyRender";
import EffectErrorBoundary from "@/components/utils/EffectErrorBoundary";

// ===== RETRO GAMING EFFECTS =====
function PixelArt8Bit() {
  const pixels = [[0,0,1,1,1,1,0,0],[0,1,2,2,2,2,1,0],[1,2,3,2,2,3,2,1],[1,2,2,2,2,2,2,1],[1,2,1,2,2,1,2,1],[0,1,2,1,1,2,1,0],[0,0,1,2,2,1,0,0],[0,0,0,1,1,0,0,0]];
  const colors = ["transparent", "#2d2d2d", "#ffcc00", "#ff6b6b"];
  return (
    <div className="flex items-center justify-center h-48 bg-slate-900 rounded-lg">
      <motion.div className="grid gap-0.5" style={{ gridTemplateColumns: "repeat(8, 1fr)" }} animate={{ scale: [1, 1.1, 1] }} transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 1 }}>
        {pixels.flat().map((p, i) => (<motion.div key={i} className="w-4 h-4 rounded-sm" style={{ backgroundColor: colors[p] }} animate={{ opacity: [0.8, 1, 0.8] }} transition={{ duration: 0.3, delay: i * 0.02 }} />))}
      </motion.div>
    </div>
  );
}

function CRTMonitor() {
  const [text, setText] = useState("GAME OVER");
  const [flicker, setFlicker] = useState(false);
  const [scanlinePos, setScanlinePos] = useState(0);
  
  useEffect(() => {
    const texts = ["GAME OVER", "INSERT COIN", "PRESS START", "PLAYER 1", "HIGH SCORE", "LEVEL UP!", "CONTINUE?"];
    let i = 0;
    const textInterval = setInterval(() => { 
      i = (i + 1) % texts.length; 
      setText(texts[i]); 
      setFlicker(true); 
      setTimeout(() => setFlicker(false), 150); 
    }, 2500);
    
    // Animated scanline
    const scanInterval = setInterval(() => {
      setScanlinePos(p => (p + 2) % 100);
    }, 50);
    
    return () => { clearInterval(textInterval); clearInterval(scanInterval); };
  }, []);
  
  return (
    <div className="relative w-full h-48 overflow-hidden rounded-xl bg-gradient-to-b from-slate-700 to-slate-800 p-3">
      {/* Monitor bezel */}
      <div className="absolute inset-3 bg-black rounded-lg overflow-hidden border-4 border-slate-600" style={{ boxShadow: "inset 0 0 50px rgba(0,0,0,0.9), 0 0 20px rgba(0,0,0,0.5)" }}>
        {/* Screen content */}
        <div className="absolute inset-0 flex items-center justify-center bg-black">
          <motion.span 
            key={text} 
            initial={{ opacity: 0, scale: 0.8 }} 
            animate={{ opacity: flicker ? 0.3 : 1, scale: 1 }} 
            transition={{ duration: 0.15 }} 
            className="text-3xl font-mono text-green-400 font-bold tracking-wider" 
            style={{ textShadow: "0 0 20px #22c55e, 0 0 40px #22c55e, 0 0 60px #22c55e" }}
          >
            {text}
          </motion.span>
        </div>
        
        {/* Static scanlines */}
        <div className="absolute inset-0 pointer-events-none" style={{ 
          background: "repeating-linear-gradient(0deg, rgba(0,0,0,0.4) 0px, rgba(0,0,0,0.4) 1px, transparent 1px, transparent 3px)" 
        }} />
        
        {/* Moving scanline */}
        <motion.div 
          className="absolute left-0 right-0 h-1 bg-gradient-to-b from-transparent via-green-400/30 to-transparent pointer-events-none" 
          style={{ top: `${scanlinePos}%` }}
        />
        
        {/* Random flicker */}
        <motion.div 
          className="absolute inset-0 bg-white pointer-events-none" 
          animate={{ opacity: [0, 0.03, 0, 0.02, 0] }} 
          transition={{ duration: 0.2, repeat: Infinity, repeatDelay: 2 + Math.random() * 3 }} 
        />
        
        {/* CRT curvature effect */}
        <div className="absolute inset-0 pointer-events-none" style={{ 
          background: "radial-gradient(ellipse at center, transparent 50%, rgba(0,0,0,0.7) 100%)",
          borderRadius: "10px"
        }} />
        
        {/* Chromatic aberration on edges */}
        <div className="absolute inset-0 pointer-events-none mix-blend-screen" style={{
          background: "linear-gradient(90deg, rgba(255,0,0,0.03) 0%, transparent 5%, transparent 95%, rgba(0,255,255,0.03) 100%)"
        }} />
      </div>
      
      {/* Power LED and controls */}
      <div className="absolute bottom-1 left-1/2 -translate-x-1/2 flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-red-500 shadow-lg shadow-red-500/50" />
        <div className="w-2 h-2 rounded-full bg-green-500 shadow-lg shadow-green-500/50 animate-pulse" />
        <span className="text-[8px] text-slate-500 ml-2 font-mono">CRT-9000</span>
      </div>
    </div>
  );
}

function ArcadeScore() {
  const [score, setScore] = useState(0);
  useEffect(() => { const i = setInterval(() => setScore(s => s + Math.floor(Math.random() * 100)), 100); return () => clearInterval(i); }, []);
  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center bg-black rounded-lg border-2 border-yellow-500/30">
      <p className="text-xs text-yellow-500 font-mono mb-2 tracking-widest">HIGH SCORE</p>
      <motion.p className="text-4xl font-mono text-yellow-400 font-bold" style={{ textShadow: "0 0 15px #fbbf24" }} animate={{ scale: [1, 1.02, 1] }} transition={{ duration: 0.2 }} key={Math.floor(score / 1000)}>{score.toString().padStart(8, '0')}</motion.p>
    </div>
  );
}

function CoinCollector() {
  const [coins, setCoins] = useState([]);
  const [total, setTotal] = useState(0);
  const [sparkles, setSparkles] = useState([]);
  
  useEffect(() => {
    const coinInterval = setInterval(() => {
      const id = Date.now();
      const x = Math.random() * 60 + 20;
      setCoins(c => [...c.slice(-8), { id, x }]);
      setTotal(t => t + 1);
      // Add sparkle effect
      setSparkles(s => [...s.slice(-5), { id, x }]);
      setTimeout(() => setSparkles(s => s.filter(sp => sp.id !== id)), 800);
    }, 500);
    return () => clearInterval(coinInterval);
  }, []);

  return (
    <div className="relative w-full h-48 bg-gradient-to-b from-indigo-900 via-blue-900 to-slate-900 rounded-lg overflow-hidden">
      {/* Ground */}
      <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-amber-800 to-amber-900" />
      
      {/* Coins falling */}
      {coins.map(coin => (
        <motion.div 
          key={coin.id} 
          className="absolute text-4xl z-10" 
          style={{ left: `${coin.x}%` }} 
          initial={{ top: -40, opacity: 1, scale: 1, rotateY: 0 }} 
          animate={{ top: 120, opacity: [1, 1, 0], scale: [1, 1.2, 0.8], rotateY: 1080 }} 
          transition={{ duration: 1.2, ease: "easeIn" }}
        >
          🪙
        </motion.div>
      ))}
      
      {/* Sparkle effects */}
      {sparkles.map(sp => (
        <motion.div 
          key={sp.id + "sp"} 
          className="absolute text-xl z-20" 
          style={{ left: `${sp.x + 2}%`, top: "60%" }} 
          initial={{ opacity: 1, scale: 0 }} 
          animate={{ opacity: 0, scale: 2, y: -30 }} 
          transition={{ duration: 0.5 }}
        >
          ✨
        </motion.div>
      ))}
      
      {/* Score display */}
      <div className="absolute bottom-12 right-3 flex items-center gap-2 bg-black/80 px-4 py-2 rounded-full border-2 border-yellow-500 shadow-lg shadow-yellow-500/30">
        <motion.span 
          className="text-3xl" 
          animate={{ rotate: [0, 15, -15, 0] }} 
          transition={{ duration: 0.3, repeat: Infinity, repeatDelay: 0.5 }}
        >
          🪙
        </motion.span>
        <motion.span 
          key={total} 
          initial={{ scale: 1.5 }} 
          animate={{ scale: 1 }} 
          className="text-2xl font-mono text-yellow-400 font-bold"
        >
          x{total}
        </motion.span>
      </div>
      
      <p className="absolute top-3 left-3 text-sm text-white font-mono bg-black/70 px-3 py-1.5 rounded-lg border border-yellow-500/30">
        🎮 COLLECT COINS!
      </p>
    </div>
  );
}

function GameControllerUI() {
  const [pressed, setPressed] = useState(null);
  const [lastAction, setLastAction] = useState("");
  const handlePress = (key) => { setPressed(key); setLastAction(key); setTimeout(() => setPressed(null), 150); };
  return (
    <div className="w-full h-full min-h-[300px] flex items-center justify-center bg-slate-900 rounded-lg cursor-pointer group relative">
      <div className="absolute top-2 right-2 p-1 bg-white/10 rounded-full opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20">
        <MousePointerClick className="w-4 h-4 text-white/70" />
      </div>
      <div className="relative bg-gradient-to-b from-slate-700 to-slate-800 rounded-3xl p-8 shadow-2xl w-64">
        {/* D-Pad */}
        <div className="absolute left-6 top-1/2 -translate-y-1/2">
          <div className="relative w-16 h-16">
            {[{ d: "↑", pos: "top-0 left-1/2 -translate-x-1/2" }, { d: "↓", pos: "bottom-0 left-1/2 -translate-x-1/2" }, { d: "←", pos: "left-0 top-1/2 -translate-y-1/2" }, { d: "→", pos: "right-0 top-1/2 -translate-y-1/2" }].map(({ d, pos }) => (
              <motion.button key={d} onClick={() => handlePress(d)} whileTap={{ scale: 0.85 }} className={`absolute ${pos} w-5 h-5 bg-slate-600 rounded flex items-center justify-center text-white text-xs font-bold ${pressed === d ? "bg-violet-500" : ""}`}>{d}</motion.button>
            ))}
            <div className="absolute inset-0 m-auto w-4 h-4 bg-slate-900 rounded" />
          </div>
        </div>
        {/* Action Buttons */}
        <div className="absolute right-4 top-1/2 -translate-y-1/2 flex gap-3">
          {[{ l: "A", c: "#ef4444" }, { l: "B", c: "#3b82f6" }].map(btn => (
            <motion.button key={btn.l} onClick={() => handlePress(btn.l)} whileTap={{ scale: 0.85 }} className={`w-10 h-10 rounded-full text-white font-bold shadow-lg ${pressed === btn.l ? "brightness-150" : ""}`} style={{ backgroundColor: btn.c }}>{btn.l}</motion.button>
          ))}
        </div>
        <p className="text-center text-slate-400 text-xs mt-10">{lastAction ? `Last: ${lastAction}` : "Press buttons!"}</p>
      </div>
    </div>
  );
}

function HealthBarRPG() {
  const [health, setHealth] = useState(100);
  useEffect(() => { const i = setInterval(() => setHealth(h => h <= 0 ? 100 : h - 8), 400); return () => clearInterval(i); }, []);
  const color = health > 60 ? "#22c55e" : health > 30 ? "#f59e0b" : "#ef4444";
  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center gap-4 bg-slate-950 rounded-lg p-6">
      <div className="flex items-center gap-2"><span className="text-red-500 text-xl">❤️</span><span className="text-white font-bold">PLAYER 1</span></div>
      <div className="w-full max-w-xs h-8 bg-slate-800 rounded-full overflow-hidden border-2 border-slate-600 relative">
        <motion.div className="h-full transition-all" style={{ background: `linear-gradient(90deg, ${color}, ${color}dd)`, boxShadow: `0 0 15px ${color}` }} animate={{ width: `${health}%` }} transition={{ duration: 0.3 }} />
        <span className="absolute inset-0 flex items-center justify-center text-white font-mono font-bold text-sm">{health}/100 HP</span>
      </div>
    </div>
  );
}

function PowerUpItem() {
  const items = [{ emoji: "⭐", name: "Star", color: "#fbbf24" }, { emoji: "🍄", name: "Mushroom", color: "#ef4444" }, { emoji: "🔥", name: "Fire", color: "#f97316" }, { emoji: "💎", name: "Diamond", color: "#06b6d4" }, { emoji: "❤️", name: "Heart", color: "#ec4899" }];
  const [current, setCurrent] = useState(0);
  useEffect(() => { const i = setInterval(() => setCurrent(c => (c + 1) % items.length), 1500); return () => clearInterval(i); }, []);
  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center bg-slate-900 rounded-lg">
      <motion.div key={current} initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }} exit={{ scale: 0, rotate: 180 }} transition={{ type: "spring", bounce: 0.5 }} className="relative">
        <span className="text-7xl" style={{ filter: `drop-shadow(0 0 20px ${items[current].color})` }}>{items[current].emoji}</span>
      </motion.div>
      <motion.p key={current + "text"} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mt-3 text-sm font-bold" style={{ color: items[current].color }}>{items[current].name} Power!</motion.p>
    </div>
  );
}

// ===== SCI-FI EFFECTS =====
function HUDInterface() {
  const [stats, setStats] = useState({ speed: 0, altitude: 0, fuel: 100, shield: 100 });
  useEffect(() => {
    const i = setInterval(() => setStats(s => ({ speed: Math.floor(Math.random() * 400 + 200), altitude: Math.floor(Math.random() * 8000 + 3000), fuel: s.fuel <= 5 ? 100 : s.fuel - 0.3, shield: s.shield <= 10 ? 100 : s.shield - 0.5 })), 100);
    return () => clearInterval(i);
  }, []);
  return (
    <div className="relative w-full h-48 bg-black rounded-lg overflow-hidden font-mono text-cyan-400 border-2 border-cyan-500/40">
      <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "linear-gradient(#06b6d4 1px, transparent 1px), linear-gradient(90deg, #06b6d4 1px, transparent 1px)", backgroundSize: "30px 30px" }} />
      <div className="absolute top-3 left-4 text-sm space-y-1">
        <p>SPD: <span className="text-white font-bold">{stats.speed}</span> m/s</p>
        <p>ALT: <span className="text-white font-bold">{stats.altitude}</span> m</p>
        <p>SHIELD: <span className={`font-bold ${stats.shield < 30 ? "text-red-400" : "text-green-400"}`}>{stats.shield.toFixed(0)}%</span></p>
      </div>
      <div className="absolute top-3 right-4 text-sm text-right space-y-1">
        <p className={stats.fuel < 20 ? "text-red-400 animate-pulse" : ""}>FUEL: <span className="text-white font-bold">{stats.fuel.toFixed(1)}</span>%</p>
        {stats.fuel < 20 && <p className="text-red-500 text-xs">⚠ LOW FUEL WARNING</p>}
        <p className="text-green-400 text-xs">● SYSTEMS ONLINE</p>
      </div>
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.div className="w-24 h-24 border-2 border-cyan-400/70 rounded-full flex items-center justify-center" animate={{ scale: [1, 1.1, 1], opacity: [0.5, 1, 0.5] }} transition={{ duration: 1.5, repeat: Infinity }}>
          <div className="w-4 h-4 bg-cyan-400 rounded-full shadow-lg shadow-cyan-400/50" />
        </motion.div>
        <div className="absolute w-32 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />
        <div className="absolute h-32 w-0.5 bg-gradient-to-b from-transparent via-cyan-400 to-transparent" />
      </div>
      <p className="absolute bottom-3 left-1/2 -translate-x-1/2 text-xs text-cyan-500 bg-black/50 px-3 py-1 rounded">TARGETING SYSTEM ACTIVE</p>
    </div>
  );
}

function TargetLockOn() {
  const [locked, setLocked] = useState(false);
  const [targetPos, setTargetPos] = useState({ x: 50, y: 50 });
  useEffect(() => { const i = setInterval(() => { if (!locked) setTargetPos({ x: 20 + Math.random() * 60, y: 20 + Math.random() * 60 }); }, 500); return () => clearInterval(i); }, [locked]);
  return (
    <div className="relative w-full h-48 bg-slate-950 rounded-lg overflow-hidden cursor-crosshair border border-red-500/30 group" onClick={() => setLocked(!locked)}>
      <div className="absolute top-2 right-2 p-1 bg-white/10 rounded-full opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20">
        <MousePointerClick className="w-4 h-4 text-white/70" />
      </div>
      <motion.div className="absolute inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-red-500 to-transparent opacity-50" animate={{ top: ["0%", "100%"] }} transition={{ duration: 2, repeat: Infinity, ease: "linear" }} />
      <motion.div className="absolute inset-y-0 w-0.5 bg-gradient-to-b from-transparent via-red-500 to-transparent opacity-50" animate={{ left: ["0%", "100%"] }} transition={{ duration: 2.5, repeat: Infinity, ease: "linear" }} />
      <motion.div className="absolute" style={{ left: `${targetPos.x}%`, top: `${targetPos.y}%`, transform: "translate(-50%, -50%)" }} animate={locked ? { scale: [1, 0.85, 1] } : { scale: [1, 1.05, 1] }} transition={{ duration: 0.4, repeat: Infinity }}>
        <div className={`w-20 h-20 border-4 ${locked ? "border-red-500" : "border-yellow-500"} rounded-full flex items-center justify-center`} style={{ boxShadow: locked ? "0 0 20px #ef4444" : "0 0 15px #eab308" }}>
          <div className={`w-3 h-3 rounded-full ${locked ? "bg-red-500" : "bg-yellow-500"}`} />
        </div>
        <div className={`absolute top-1/2 left-0 w-full h-0.5 ${locked ? "bg-red-500" : "bg-yellow-500"}`} style={{ transform: "translateY(-50%)" }} />
        <div className={`absolute left-1/2 top-0 h-full w-0.5 ${locked ? "bg-red-500" : "bg-yellow-500"}`} style={{ transform: "translateX(-50%)" }} />
      </motion.div>
      <div className={`absolute bottom-3 left-3 px-3 py-1 rounded text-sm font-mono font-bold ${locked ? "bg-red-500/20 text-red-400 border border-red-500" : "bg-yellow-500/20 text-yellow-400 border border-yellow-500"}`}>
        {locked ? "🎯 TARGET LOCKED" : "⌖ ACQUIRING TARGET..."}
      </div>
      <p className="absolute top-3 right-3 text-xs text-slate-500 bg-black/50 px-2 py-1 rounded">Click to {locked ? "release" : "lock"}</p>
    </div>
  );
}

function WarpSpeed() {
  const [warping, setWarping] = useState(false);
  const stars = React.useMemo(() => [...Array(80)].map(() => ({ x: Math.random() * 100, y: Math.random() * 100, size: 1 + Math.random() * 2 })), []);
  return (
    <div className="relative w-full h-48 bg-black rounded-lg overflow-hidden cursor-pointer border border-cyan-500/20 group" onClick={() => setWarping(!warping)}>
      <div className="absolute top-2 right-2 p-1 bg-white/10 rounded-full opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20">
        <MousePointerClick className="w-4 h-4 text-white/70" />
      </div>
      {stars.map((star, i) => (
        <motion.div key={i} className="absolute bg-white rounded-full" style={{ width: star.size, height: star.size, left: `${star.x}%`, top: `${star.y}%` }} animate={warping ? { x: [0, (star.x - 50) * 15], scaleX: [1, 60], opacity: [1, 0] } : { opacity: [0.3, 1, 0.3], scale: [0.8, 1.3, 0.8] }} transition={{ duration: warping ? 0.8 : 1.5 + Math.random(), repeat: Infinity, delay: warping ? i * 0.01 : Math.random() }} />
      ))}
      {warping && <motion.div className="absolute inset-0 bg-gradient-radial from-blue-500/30 via-transparent to-transparent" animate={{ opacity: [0, 0.5, 0] }} transition={{ duration: 0.5, repeat: Infinity }} />}
      <div className={`absolute bottom-3 left-3 px-3 py-1.5 rounded-lg text-sm font-mono font-bold ${warping ? "bg-cyan-500/30 text-cyan-300 border border-cyan-400" : "bg-slate-800 text-cyan-400 border border-slate-600"}`}>
        {warping ? "⚡ WARP DRIVE ENGAGED" : "▶ CLICK TO ENGAGE WARP"}
      </div>
      <div className="absolute top-3 right-3 text-xs text-slate-500">{warping ? "SPEED: LUDICROUS" : "SPEED: NORMAL"}</div>
    </div>
  );
}

function LootDropper() {
  const items = ["🗡️", "🛡️", "💎", "📜", "🧪", "🔮", "🏹", "⚔️", "👑", "💰"];
  const rarities = [{ name: "Common", color: "#9ca3af" }, { name: "Rare", color: "#3b82f6" }, { name: "Epic", color: "#a855f7" }, { name: "Legendary", color: "#f59e0b" }];
  const [drops, setDrops] = useState([]);
  const [collected, setCollected] = useState(0);
  useEffect(() => {
    const i = setInterval(() => {
      const id = Date.now();
      const rarity = rarities[Math.floor(Math.random() * rarities.length)];
      setDrops(d => [...d, { id, item: items[Math.floor(Math.random() * items.length)], x: 10 + Math.random() * 80, rarity }]);
      setCollected(c => c + 1);
      setTimeout(() => setDrops(d => d.filter(drop => drop.id !== id)), 2000);
    }, 400);
    return () => clearInterval(i);
  }, []);
  return (
    <div className="relative w-full h-48 bg-gradient-to-b from-purple-950 to-slate-950 rounded-lg overflow-hidden border border-purple-500/30">
      {drops.map(d => (
        <motion.div key={d.id} className="absolute text-4xl z-10" style={{ left: `${d.x}%`, filter: `drop-shadow(0 0 12px ${d.rarity.color})` }} initial={{ top: -20, opacity: 0, scale: 0.5, rotate: -180 }} animate={{ top: 150, opacity: [0, 1, 1, 0.5], scale: [0.5, 1.3, 1], rotate: 360 }} transition={{ duration: 2, ease: "easeIn" }}>{d.item}</motion.div>
      ))}
      <div className="absolute bottom-3 left-3 bg-black/70 px-3 py-1.5 rounded-lg border border-purple-500/50">
        <p className="text-purple-300 text-sm font-bold">💎 Loot Collected: {collected}</p>
      </div>
      <div className="absolute top-3 right-3 text-xs text-purple-400 bg-black/50 px-2 py-1 rounded">LEGENDARY DROP ZONE</div>
    </div>
  );
}

function DamagePopups() {
  const [hits, setHits] = useState([]);
  useEffect(() => {
    const i = setInterval(() => {
      const id = Date.now();
      const damage = Math.floor(Math.random() * 999) + 1;
      const crit = Math.random() > 0.7;
      const heal = Math.random() > 0.85;
      setHits(h => [...h, { id, damage, crit, heal, x: 20 + Math.random() * 60 }]);
      setTimeout(() => setHits(h => h.filter(hit => hit.id !== id)), 1500);
    }, 300);
    return () => clearInterval(i);
  }, []);
  return (
    <div className="relative w-full h-48 bg-slate-950 rounded-lg overflow-hidden border border-red-500/20">
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-20 h-20 bg-gradient-to-b from-slate-700 to-slate-800 rounded-xl flex items-center justify-center text-4xl shadow-lg border-2 border-slate-600">👤</div>
      {hits.map(h => (
        <motion.div key={h.id} className={`absolute font-black z-20 ${h.heal ? "text-green-400" : h.crit ? "text-yellow-300" : "text-red-400"}`} style={{ left: `${h.x}%`, fontSize: h.crit ? "2rem" : "1.5rem", textShadow: h.crit ? "0 0 10px #fbbf24" : h.heal ? "0 0 10px #22c55e" : "0 0 8px #ef4444" }} initial={{ bottom: 80, opacity: 1, scale: h.crit ? 1.8 : 1.2 }} animate={{ bottom: 180, opacity: 0, scale: h.crit ? 2.2 : 1.5 }} transition={{ duration: 1.5, ease: "easeOut" }}>
          {h.crit && "💥"}{h.heal ? "+" : "-"}{h.damage}
        </motion.div>
      ))}
      <p className="absolute top-3 left-3 text-xs text-red-400 font-mono bg-black/50 px-2 py-1 rounded">COMBAT ZONE</p>
    </div>
  );
}

// ===== MODERN GAMING =====
function XPProgressBar() {
  const [xp, setXp] = useState(0);
  const [level, setLevel] = useState(1);
  useEffect(() => { const i = setInterval(() => setXp(x => { if (x >= 100) { setLevel(l => l + 1); return 0; } return x + 3; }), 150); return () => clearInterval(i); }, []);
  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center gap-4 bg-gradient-to-b from-violet-950 to-slate-950 rounded-lg">
      <motion.div key={level} initial={{ scale: 1.5 }} animate={{ scale: 1 }} className="flex items-center gap-2">
        <span className="text-3xl">👑</span>
        <span className="text-3xl font-black text-white">LVL {level}</span>
      </motion.div>
      <div className="w-56 h-5 bg-slate-800 rounded-full overflow-hidden border-2 border-violet-500/50">
        <motion.div className="h-full bg-gradient-to-r from-violet-500 to-cyan-400" style={{ boxShadow: "0 0 15px #8b5cf6" }} animate={{ width: `${xp}%` }} />
      </div>
      <p className="text-xs text-violet-300 font-mono">{xp}/100 XP to next level</p>
    </div>
  );
}

function ComboMeter() {
  const [combo, setCombo] = useState(0);
  const [maxCombo, setMaxCombo] = useState(0);
  useEffect(() => {
    const i = setInterval(() => setCombo(c => {
      if (c >= 99) { setMaxCombo(m => Math.max(m, c)); return 0; }
      return c + 1;
    }), 250);
    return () => clearInterval(i);
  }, []);
  const tier = combo >= 50 ? "🔥 INSANE!" : combo >= 30 ? "⚡ AMAZING!" : combo >= 15 ? "✨ GREAT!" : combo >= 5 ? "👊 NICE!" : "";
  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center bg-black rounded-lg relative overflow-hidden">
      {combo >= 20 && <div className="absolute inset-0 bg-gradient-to-t from-orange-500/20 to-transparent animate-pulse" />}
      <motion.div key={Math.floor(combo / 10)} initial={{ scale: 1.3, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center relative z-10">
        <p className="text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-orange-500 via-red-500 to-pink-500">{combo}</p>
        <p className="text-xl font-bold text-orange-400 -mt-2">COMBO!</p>
      </motion.div>
      {tier && <motion.p initial={{ scale: 0 }} animate={{ scale: [1, 1.1, 1] }} transition={{ repeat: Infinity, duration: 0.5 }} className="text-sm text-yellow-400 mt-2 relative z-10">{tier}</motion.p>}
      <p className="absolute bottom-2 right-2 text-xs text-slate-600">Max: {maxCombo}</p>
    </div>
  );
}

function AchievementPopup() {
  const achievements = [{ name: "First Blood!", icon: "🎯" }, { name: "Legendary!", icon: "🏆" }, { name: "Speed Demon!", icon: "⚡" }, { name: "Treasure Hunter!", icon: "💎" }];
  const [current, setCurrent] = useState(null);
  useEffect(() => {
    const i = setInterval(() => {
      setCurrent(achievements[Math.floor(Math.random() * achievements.length)]);
      setTimeout(() => setCurrent(null), 3500);
    }, 5000);
    return () => clearInterval(i);
  }, []);
  return (
    <div className="w-full h-full min-h-[300px] flex items-center justify-center bg-slate-900 rounded-lg overflow-hidden relative">
      <AnimatePresence>
        {current ? (
          <motion.div initial={{ x: 300, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -300, opacity: 0 }} className="flex items-center gap-4 bg-gradient-to-r from-yellow-500/20 to-amber-500/10 border-2 border-yellow-500/50 rounded-xl p-5 shadow-lg shadow-yellow-500/20">
            <span className="text-5xl">{current.icon}</span>
            <div>
              <p className="text-xs text-yellow-500 font-bold tracking-widest">🏆 ACHIEVEMENT UNLOCKED</p>
              <p className="text-xl text-white font-bold mt-1">{current.name}</p>
            </div>
          </motion.div>
        ) : (
          <p className="text-slate-600 text-sm">Waiting for achievement...</p>
        )}
      </AnimatePresence>
    </div>
  );
}

function BossHP() {
  const [hp, setHp] = useState(100);
  const [phase, setPhase] = useState(1);
  useEffect(() => {
    const i = setInterval(() => setHp(h => {
      if (h <= 0) { setPhase(p => p >= 3 ? 1 : p + 1); return 100; }
      return h - 2;
    }), 100);
    return () => clearInterval(i);
  }, []);
  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center gap-4 bg-black rounded-lg p-6 relative overflow-hidden">
      {hp < 30 && <motion.div className="absolute inset-0 bg-red-500/20" animate={{ opacity: [0.2, 0.4, 0.2] }} transition={{ duration: 0.3, repeat: Infinity }} />}
      <div className="flex items-center gap-3 relative z-10">
        <span className="text-3xl">💀</span>
        <span className="text-xl font-black text-red-500" style={{ textShadow: "0 0 10px #ef4444" }}>DARK OVERLORD</span>
        <span className="text-3xl">💀</span>
      </div>
      <p className="text-xs text-red-400 font-mono">PHASE {phase}/3</p>
      <div className="w-full max-w-xs h-6 bg-slate-900 rounded border-2 border-red-900 overflow-hidden relative z-10">
        <motion.div className="h-full bg-gradient-to-r from-red-600 to-red-400" animate={{ width: `${hp}%` }} transition={{ duration: 0.1 }} />
      </div>
      <p className="text-red-400 font-mono font-bold text-sm relative z-10">{hp.toFixed(0)}% HP</p>
    </div>
  );
}

function MiniRadar() {
  const [sweep, setSweep] = useState(0);
  const [blips, setBlips] = useState([]);
  useEffect(() => {
    const i = setInterval(() => setSweep(s => (s + 3) % 360), 30);
    const b = setInterval(() => {
      const angle = Math.random() * 360;
      const dist = 20 + Math.random() * 30;
      setBlips(bb => [...bb.slice(-4), { id: Date.now(), x: 50 + Math.cos(angle * Math.PI / 180) * dist, y: 50 + Math.sin(angle * Math.PI / 180) * dist }]);
    }, 2000);
    return () => { clearInterval(i); clearInterval(b); };
  }, []);
  return (
    <div className="w-full h-full min-h-[300px] flex items-center justify-center bg-slate-950 rounded-lg">
      <div className="relative w-36 h-36 rounded-full bg-slate-900 border-2 border-green-500/50 overflow-hidden">
        <motion.div className="absolute top-1/2 left-1/2 w-1/2 h-1 bg-gradient-to-r from-green-500 to-transparent origin-left" style={{ rotate: sweep }} />
        {[1, 2, 3].map(i => (<div key={i} className="absolute rounded-full border border-green-500/20" style={{ width: `${i * 33}%`, height: `${i * 33}%`, top: `${50 - i * 16.5}%`, left: `${50 - i * 16.5}%` }} />))}
        <div className="absolute top-1/2 left-1/2 w-3 h-3 bg-green-500 rounded-full -translate-x-1/2 -translate-y-1/2 shadow-lg shadow-green-500/50" />
        {blips.map(b => (<motion.div key={b.id} className="absolute w-2 h-2 bg-red-500 rounded-full" style={{ left: `${b.x}%`, top: `${b.y}%` }} animate={{ opacity: [1, 0.3, 1] }} transition={{ repeat: Infinity, duration: 1 }} />))}
      </div>
    </div>
  );
}

function AmmoDisplay() {
  const [ammo, setAmmo] = useState(30);
  const [reloading, setReloading] = useState(false);
  const [reloadProgress, setReloadProgress] = useState(0);
  useEffect(() => {
    const i = setInterval(() => {
      if (reloading) {
        setReloadProgress(p => { if (p >= 100) { setReloading(false); setAmmo(30); return 0; } return p + 10; });
      } else {
        setAmmo(a => { if (a <= 0) { setReloading(true); return 0; } return a - 1; });
      }
    }, 150);
    return () => clearInterval(i);
  }, [reloading]);
  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center bg-slate-950 rounded-lg gap-3">
      <div className="flex items-center gap-3">
        <span className="text-3xl">🎯</span>
        <span className={`text-5xl font-mono font-black ${ammo <= 5 && !reloading ? "text-red-500 animate-pulse" : "text-white"}`}>{ammo.toString().padStart(2, '0')}</span>
        <span className="text-xl text-slate-500 font-mono">/30</span>
      </div>
      {reloading && (
        <div className="w-40">
          <p className="text-center text-yellow-400 text-sm font-bold mb-1 animate-pulse">RELOADING...</p>
          <div className="h-2 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-yellow-500" style={{ width: `${reloadProgress}%` }} /></div>
        </div>
      )}
    </div>
  );
}

function StaminaWheel() {
  const [stamina, setStamina] = useState(100);
  const [sprinting, setSprinting] = useState(true);
  useEffect(() => {
    const i = setInterval(() => {
      if (sprinting) setStamina(s => { if (s <= 0) { setSprinting(false); return 0; } return s - 3; });
      else setStamina(s => { if (s >= 100) { setSprinting(true); return 100; } return s + 2; });
    }, 100);
    return () => clearInterval(i);
  }, [sprinting]);
  const circumference = 2 * Math.PI * 50;
  return (
    <div className="w-full h-full min-h-[300px] flex items-center justify-center bg-slate-900 rounded-lg">
      <div className="relative w-32 h-32">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
          <circle cx="60" cy="60" r="50" fill="none" stroke="#1e293b" strokeWidth="10" />
          <motion.circle cx="60" cy="60" r="50" fill="none" stroke={stamina > 30 ? "#22c55e" : "#ef4444"} strokeWidth="10" strokeLinecap="round" strokeDasharray={circumference} animate={{ strokeDashoffset: circumference - (stamina / 100) * circumference }} style={{ filter: `drop-shadow(0 0 8px ${stamina > 30 ? "#22c55e" : "#ef4444"})` }} />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={`text-2xl font-black ${stamina > 30 ? "text-green-400" : "text-red-400"}`}>{Math.round(stamina)}%</span>
          <span className="text-xs text-slate-500">{sprinting ? "SPRINTING" : "RECOVERING"}</span>
        </div>
      </div>
    </div>
  );
}

function KillFeedLog() {
  const names = ["Xx_Shadow_xX", "ProGamer99", "NoobDestroyer", "NinjaWarrior", "DragonSlayer"];
  const weapons = ["🔫", "🗡️", "💣", "🏹", "⚔️"];
  const [kills, setKills] = useState([]);
  useEffect(() => {
    const i = setInterval(() => {
      const id = Date.now();
      setKills(k => [...k.slice(-4), { id, killer: names[Math.floor(Math.random() * names.length)], victim: names[Math.floor(Math.random() * names.length)], weapon: weapons[Math.floor(Math.random() * weapons.length)] }]);
    }, 2500);
    return () => clearInterval(i);
  }, []);
  return (
    <div className="w-full h-full min-h-[300px] p-4 bg-black/90 rounded-lg overflow-hidden">
      <p className="text-[10px] text-slate-600 mb-2 font-mono">KILL FEED</p>
      <div className="space-y-1.5">
        {kills.map(k => (
          <motion.div key={k.id} initial={{ x: 100, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="text-xs flex items-center gap-1 bg-slate-900/50 px-2 py-1 rounded">
            <span className="text-red-400 font-bold truncate max-w-[80px]">{k.killer}</span>
            <span>{k.weapon}</span>
            <span className="text-blue-400 truncate max-w-[80px]">{k.victim}</span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function InventoryGrid() {
  const items = ["🗡️", "🛡️", "🧪", "📜", "💎", "🔮", "🍖", "🗝️", "🏹", null, null, null];
  const [selected, setSelected] = useState(0);
  return (
    <div className="w-full h-full min-h-[300px] flex items-center justify-center bg-slate-900 rounded-lg group relative cursor-pointer">
      <div className="absolute top-2 right-2 p-1 bg-white/10 rounded-full opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20">
        <MousePointerClick className="w-4 h-4 text-white/70" />
      </div>
      <div className="grid grid-cols-4 gap-2">
        {items.map((item, i) => (
          <motion.div key={i} whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => item && setSelected(i)} className={`w-12 h-12 rounded-lg border-2 flex items-center justify-center text-2xl cursor-pointer ${selected === i && item ? "border-violet-500 bg-violet-500/20 shadow-lg shadow-violet-500/30" : item ? "border-amber-500/50 bg-amber-500/10" : "border-slate-700 bg-slate-800"}`}>
            {item}
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function RespawnCountdown() {
  const [time, setTime] = useState(5);
  useEffect(() => { const i = setInterval(() => setTime(t => t <= 0 ? 5 : t - 1), 1000); return () => clearInterval(i); }, []);
  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center bg-gradient-to-b from-red-950 to-black rounded-lg relative overflow-hidden">
      <motion.div className="absolute inset-0 bg-red-500/10" animate={{ opacity: [0.1, 0.3, 0.1] }} transition={{ duration: 1, repeat: Infinity }} />
      <p className="text-red-500 text-lg font-bold mb-2 relative z-10">☠️ YOU DIED ☠️</p>
      <motion.p key={time} initial={{ scale: 2, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-7xl font-black text-white relative z-10">{time}</motion.p>
      <p className="text-slate-400 text-sm mt-2 relative z-10">Respawning...</p>
    </div>
  );
}

function TeamScoreboard() {
  const [blue, setBlue] = useState(0);
  const [red, setRed] = useState(0);
  useEffect(() => { const i = setInterval(() => { Math.random() > 0.5 ? setBlue(b => b + 1) : setRed(r => r + 1); }, 2000); return () => clearInterval(i); }, []);
  return (
    <div className="w-full h-full min-h-[300px] flex items-center justify-center gap-6 bg-slate-950 rounded-lg">
      <motion.div key={`b${blue}`} initial={{ scale: 1.2 }} animate={{ scale: 1 }} className="text-center">
        <div className="w-20 h-20 rounded-full bg-blue-500/20 border-4 border-blue-500 flex items-center justify-center shadow-lg shadow-blue-500/30">
          <span className="text-3xl font-black text-blue-400">{blue}</span>
        </div>
        <p className="text-blue-400 text-sm font-bold mt-2">BLUE</p>
      </motion.div>
      <div className="text-4xl font-black text-slate-600">VS</div>
      <motion.div key={`r${red}`} initial={{ scale: 1.2 }} animate={{ scale: 1 }} className="text-center">
        <div className="w-20 h-20 rounded-full bg-red-500/20 border-4 border-red-500 flex items-center justify-center shadow-lg shadow-red-500/30">
          <span className="text-3xl font-black text-red-400">{red}</span>
        </div>
        <p className="text-red-400 text-sm font-bold mt-2">RED</p>
      </motion.div>
    </div>
  );
}

function ClassSelector() {
  const classes = [{ emoji: "🧙", name: "Mage", color: "#8b5cf6" }, { emoji: "⚔️", name: "Warrior", color: "#ef4444" }, { emoji: "🏹", name: "Ranger", color: "#22c55e" }, { emoji: "🛡️", name: "Tank", color: "#3b82f6" }];
  const [selected, setSelected] = useState(0);
  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center bg-slate-900 rounded-lg cursor-pointer group relative">
      <div className="absolute top-2 right-2 p-1 bg-white/10 rounded-full opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20">
        <MousePointerClick className="w-4 h-4 text-white/70" />
      </div>
      <p className="text-slate-400 text-xs mb-4 tracking-widest">SELECT YOUR CLASS</p>
      <div className="flex gap-3">
        {classes.map((c, i) => (
          <motion.button key={i} onClick={() => setSelected(i)} whileHover={{ scale: 1.05, y: -2 }} whileTap={{ scale: 0.95 }} className={`w-16 h-16 rounded-xl text-3xl flex items-center justify-center ${selected === i ? "border-2 shadow-lg" : "border border-slate-700 bg-slate-800"}`} style={selected === i ? { borderColor: c.color, backgroundColor: `${c.color}20`, boxShadow: `0 0 20px ${c.color}40` } : {}}>
            {c.emoji}
          </motion.button>
        ))}
      </div>
      <p className="mt-3 text-sm font-bold" style={{ color: classes[selected].color }}>{classes[selected].name}</p>
    </div>
  );
}

function GameLoading() {
  const [progress, setProgress] = useState(0);
  const tips = ["Press SPACE to dodge attacks", "Collect gems for bonus points", "Watch your stamina bar"];
  const [tip, setTip] = useState(0);
  useEffect(() => {
    const i = setInterval(() => setProgress(p => p >= 100 ? 0 : p + 1), 50);
    const t = setInterval(() => setTip(tp => (tp + 1) % tips.length), 3000);
    return () => { clearInterval(i); clearInterval(t); };
  }, []);
  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center bg-black rounded-lg gap-4">
      <motion.p className="text-white font-bold tracking-widest" animate={{ opacity: [1, 0.5, 1] }} transition={{ duration: 1, repeat: Infinity }}>LOADING...</motion.p>
      <div className="w-56 h-3 bg-slate-800 rounded-full overflow-hidden">
        <motion.div className="h-full bg-gradient-to-r from-cyan-500 via-violet-500 to-cyan-500 bg-[length:200%_100%]" animate={{ width: `${progress}%`, backgroundPosition: ["0% 50%", "100% 50%"] }} transition={{ backgroundPosition: { duration: 2, repeat: Infinity } }} />
      </div>
      <p className="text-slate-500 text-xs font-mono">{progress}%</p>
      <motion.p key={tip} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-slate-600 text-xs">💡 {tips[tip]}</motion.p>
    </div>
  );
}

// React GameKit Components (150+ items now with new categories!)
const gameKitComponents = [
  { id: "gk1", title: "Sprite Animation", description: "Animated character sprite frames", component: GameKit.SpriteAnimation, category: "core", code: `const [frame, setFrame] = useState(0);\nuseEffect(() => {\n  const i = setInterval(() => setFrame(f => (f + 1) % 4), 150);\n  return () => clearInterval(i);\n}, []);`, prompt: "Create a sprite animation system with frame cycling for a 2D platformer character" },
  { id: "gk2", title: "Jump Physics", description: "Realistic jump mechanics", component: GameKit.JumpPhysics, category: "core", code: `const [jumping, setJumping] = useState(false);\nconst handleJump = () => {\n  if (!jumping) {\n    setJumping(true);\n    setTimeout(() => setJumping(false), 800);\n  }\n};`, prompt: "Implement jump physics with gravity and landing detection for a platformer game" },
  
  // VEHICLES (9 new components)
  { id: "gkv1", title: "Speed Lines", description: "Racing velocity blur", component: GameKit.SpeedLines, category: "vehicles", code: `const [speed, setSpeed] = useState(0);\n{[...Array(20)].map((_, i) => \n  <motion.div className="h-0.5 bg-cyan-400" \n    style={{ width: \`\${speed}%\` }} />\n)}`, prompt: "Create speed lines effect for racing games with velocity-based blur trails" },
  { id: "gkv2", title: "Drift Smoke", description: "Car drifting particles", component: GameKit.DriftSmoke, category: "vehicles", code: `{particles.map(p => \n  <motion.div initial={{ x: 20, scale: 0.5 }} \n    animate={{ x: -50, scale: 2, opacity: 0 }}>\n    💨\n  </motion.div>\n)}`, prompt: "Build drift smoke particle system for racing games with trailing smoke clouds" },
  { id: "gkv3", title: "Boost Flames", description: "Rocket boost fire", component: GameKit.BoostFlames, category: "vehicles", code: `{boost && \n  <motion.div animate={{ scale: [1, 2, 0], x: [-20, -80] }}>\n    🔥\n  </motion.div>\n}`, prompt: "Create boost flame animation for racing games with fire trail effect" },
  { id: "gkv4", title: "Tire Marks", description: "Skid mark trails", component: GameKit.TireMarks, category: "vehicles", code: `{marks.map((m, i) => \n  <div className="w-2 h-8 bg-slate-900" \n    style={{ left: \`\${10 + i * 5}%\` }} />\n)}`, prompt: "Implement tire mark trail system showing skid marks left by vehicles" },
  { id: "gkv5", title: "Helicopter Rotor", description: "Spinning rotor blades", component: GameKit.HelicopterRotor, category: "vehicles", code: `<motion.div className="w-32 h-2" \n  animate={{ rotate: speed }} \n  transition={{ duration: 0.05 }}\n/>`, prompt: "Create helicopter rotor animation with accelerating spin speed" },
  { id: "gkv6", title: "Plane Contrails", description: "Aircraft vapor trail", component: GameKit.PlaneContrails, category: "vehicles", code: `{trails.map(t => \n  <motion.div className="h-1 bg-white/60" \n    initial={{ opacity: 1 }} \n    animate={{ opacity: 0 }} />\n)}`, prompt: "Build airplane contrail system with fading vapor trails behind aircraft" },
  { id: "gkv7", title: "Speedometer Gauge", description: "Analog speed dial", component: GameKit.SpeedometerGauge, category: "vehicles", code: `<motion.div className="w-1 h-16 origin-bottom" \n  style={{ rotate: -90 + speed }}\n/>`, prompt: "Create analog speedometer gauge with rotating needle for vehicle HUD" },
  { id: "gkv8", title: "Fuel Gauge", description: "Gas tank indicator", component: GameKit.FuelGauge, category: "vehicles", code: `<motion.div \n  className={\`h-full \${fuel > 30 ? "bg-green-500" : "bg-red-500"}\`} \n  animate={{ width: \`\${fuel}%\` }}\n/>`, prompt: "Implement fuel gauge with warning colors for low fuel states" },
  { id: "gkv9", title: "Nitro Bar", description: "Boost energy meter", component: GameKit.NitroBar, category: "vehicles", code: `<motion.div className="bg-gradient-to-r from-orange-500 to-red-500" \n  animate={{ width: \`\${nitro}%\` }} \n  style={{ boxShadow: using ? "0 0 20px #f97316" : "none" }}\n/>`, prompt: "Build nitro boost meter with charge/discharge system and glow effect" },
  
  // WEAPONS (9 new components)
  { id: "gkw1", title: "Muzzle Flash", description: "Gun fire effect", component: GameKit.MuzzleFlash, category: "weapons", code: `{flash && \n  <motion.div initial={{ scale: 0 }} \n    animate={{ scale: 2, opacity: 0 }} \n    transition={{ duration: 0.15 }}>\n    💥\n  </motion.div>\n}`, prompt: "Create muzzle flash effect for firearms with brief explosion animation" },
  { id: "gkw2", title: "Bullet Tracer", description: "Projectile path lines", component: GameKit.BulletTracer, category: "weapons", code: `{bullets.map(b => \n  <motion.div className="h-0.5 bg-yellow-400" \n    initial={{ scaleX: 0 }} \n    animate={{ scaleX: 1, x: 300 }}\n    style={{ boxShadow: "0 0 8px #facc15" }} />\n)}`, prompt: "Build bullet tracer system showing projectile paths with glowing lines" },
  { id: "gkw3", title: "Impact Sparks", description: "Hit surface particles", component: GameKit.ImpactSparks, category: "weapons", code: `{impacts.map(imp => \n  <motion.div initial={{ scale: 0 }} \n    animate={{ scale: 2, opacity: 0 }}>\n    ✨\n  </motion.div>\n)}`, prompt: "Create impact spark particles that appear when bullets hit surfaces" },
  { id: "gkw4", title: "Laser Beam", description: "Continuous laser weapon", component: GameKit.LaserBeam, category: "weapons", code: `{firing && \n  <motion.div className="bg-gradient-to-r from-red-500 to-transparent" \n    style={{ boxShadow: "0 0 20px #ef4444" }}\n  />\n}`, prompt: "Implement laser beam weapon with pulsing energy beam effect" },
  { id: "gkw5", title: "Shotgun Spread", description: "Multiple pellet indicators", component: GameKit.ShotgunSpread, category: "weapons", code: `{pellets.map(p => \n  <motion.div \n    initial={{ scale: 0, rotate: p.angle }} \n    animate={{ scale: [1, 3], x: 100, opacity: 0 }}\n  />\n)}`, prompt: "Create shotgun spread pattern showing multiple projectiles dispersing" },
  { id: "gkw6", title: "Sniper Glint", description: "Scope reflection flash", component: GameKit.SniperGlint, category: "weapons", code: `{glint && \n  <motion.div className="bg-white rounded-full" \n    initial={{ scale: 0 }} \n    animate={{ scale: 3, opacity: 0 }}\n    style={{ boxShadow: "0 0 30px #fff" }} />\n}`, prompt: "Build sniper scope glint effect with bright flash for enemy awareness" },
  { id: "gkw7", title: "Minigun Spinup", description: "Rotating barrel acceleration", component: GameKit.MinigunSpinup, category: "weapons", code: `<motion.div animate={{ rotate: rpm * 10 }}>\n  ⚙️\n</motion.div>\n<p>RPM: {rpm * 100}</p>`, prompt: "Create minigun spinup mechanic with accelerating rotation speed" },
  { id: "gkw8", title: "Rocket Trail", description: "Missile smoke path", component: GameKit.RocketTrail, category: "weapons", code: `{rockets.map(r => \n  <motion.div animate={{ x: 300 }}>\n    🚀\n    <div className="bg-gradient-to-l from-orange-500" />\n  </motion.div>\n)}`, prompt: "Implement rocket trail effect with fire and smoke following missiles" },
  { id: "gkw9", title: "Energy Charge", description: "Weapon power-up animation", component: GameKit.EnergyCharge, category: "weapons", code: `<motion.div \n  animate={{ opacity: charge / 100 }} \n  style={{ background: \`radial-gradient(...)\` }}\n/>`, prompt: "Build energy charge weapon effect with radial glow intensity based on charge level" },
  
  // CHARACTERS/AVATARS (9 new)
  { id: "gkc1", title: "Idle Breathing", description: "Character idle animation", component: GameKit.IdleBreathing, category: "characters", code: `<motion.span \n  animate={{ scale: [1, 1.05, 1], y: [0, -2, 0] }} \n  transition={{ duration: 2, repeat: Infinity }}\n>🧍</motion.span>`, prompt: "Create idle breathing animation for characters with subtle bobbing motion" },
  { id: "gkc2", title: "Walking Cycle", description: "Side-view walk animation", component: GameKit.WalkingCycle, category: "characters", code: `const frames = ["🚶", "🚶‍♂️", "🚶", "🚶‍♀️"];\n<motion.span animate={{ x: [-40, 40] }}>\n  {frames[frame]}\n</motion.span>`, prompt: "Build walking cycle animation with sprite frames and horizontal movement" },
  { id: "gkc3", title: "Emote Wheel", description: "Radial emote selector", component: GameKit.EmoteWheel, category: "characters", code: `{emotes.map((e, i) => {\n  const angle = (i * 360) / emotes.length;\n  const x = 50 + 45 * Math.cos((angle * Math.PI) / 180);\n  return <button style={{ left: \`\${x}%\` }}>{e}</button>;\n})}`, prompt: "Create radial emote wheel selector with circular layout for player expressions" },
  { id: "gkc4", title: "Character Portrait", description: "Animated avatar frame", component: GameKit.CharacterPortrait, category: "characters", code: `<motion.div \n  className="rounded-full border-4" \n  animate={glow ? { boxShadow: "0 0 30px #facc15" } : {}}\n>🧙</motion.div>`, prompt: "Design character portrait frame with occasional glow effect for player avatars" },
  { id: "gkc5", title: "Costume Change", description: "Outfit swap animation", component: GameKit.CostumeChange, category: "characters", code: `<motion.div key={outfit} \n  initial={{ rotateY: -90, opacity: 0 }} \n  animate={{ rotateY: 0, opacity: 1 }}\n>{outfits[outfit]}</motion.div>`, prompt: "Implement costume change system with 3D rotation transition between outfits" },
  { id: "gkc6", title: "Shadow Effect", description: "Dynamic character shadow", component: GameKit.ShadowEffect, category: "characters", code: `<motion.div className="w-16 h-4 bg-black/40 rounded-full blur-sm" \n  animate={{ scale: [1, 1.2, 1] }}\n/>`, prompt: "Create dynamic character shadow that scales with jump height" },
  { id: "gkc7", title: "Footstep Dust", description: "Ground impact particles", component: GameKit.FootstepDust, category: "characters", code: `{steps.map(s => \n  <motion.span \n    initial={{ scale: 0.5, opacity: 1 }} \n    animate={{ scale: 2, opacity: 0, y: -20 }}\n  >💨</motion.span>\n)}`, prompt: "Build footstep dust particle system that spawns with each step" },
  { id: "gkc8", title: "Jumping Arc", description: "Jump trajectory trail", component: GameKit.JumpingArc, category: "characters", code: `<motion.span \n  animate={{ y: [40, -40, 40], x: [-40, 0, 40] }} \n  transition={{ duration: 2, repeat: Infinity }}\n>🤸</motion.span>`, prompt: "Create jumping arc animation showing parabolic trajectory motion" },
  { id: "gkc9", title: "Crouching Stealth", description: "Low profile visual", component: GameKit.CrouchingStealth, category: "characters", code: `<motion.span \n  animate={{ scaleY: crouched ? 0.6 : 1, y: crouched ? 20 : 0 }}\n>{crouched ? "🙇" : "🧍"}</motion.span>`, prompt: "Implement crouching mechanic with height reduction for stealth gameplay" },
  
  // ENVIRONMENT/NATURE (9 new)
  { id: "gke1", title: "Swaying Trees", description: "Wind-blown foliage", component: GameKit.SwayingTrees, category: "environment", code: `{[...Array(5)].map((_, i) => \n  <motion.span \n    animate={{ rotate: [-5, 5, -5] }} \n    transition={{ duration: 2 + i * 0.2, repeat: Infinity }}\n  >🌲</motion.span>\n)}`, prompt: "Create swaying tree animation with wind effect and staggered timing" },
  { id: "gke2", title: "Falling Leaves", description: "Seasonal particles", component: GameKit.FallingLeaves, category: "environment", code: `{leaves.map(l => \n  <motion.span \n    initial={{ top: -20, rotate: 0 }} \n    animate={{ top: 200, rotate: 360 }}\n  >🍂</motion.span>\n)}`, prompt: "Build falling leaves particle system with rotation and drift motion" },
  { id: "gke3", title: "Rain Effect", description: "Vertical water droplets", component: GameKit.RainEffect, category: "environment", code: `{drops.map(d => \n  <motion.div className="w-0.5 h-4 bg-blue-300/70" \n    animate={{ y: [-20, 200] }}\n  />\n)}`, prompt: "Create rain effect with vertical falling droplets at varying speeds" },
  { id: "gke4", title: "Snow Drift", description: "Blizzard particles", component: GameKit.SnowDrift, category: "environment", code: `{flakes.map(f => \n  <motion.span \n    animate={{ y: [-20, 200], x: [0, 10, -10, 0] }}\n  >❄️</motion.span>\n)}`, prompt: "Implement snow drift with falling snowflakes and horizontal wind motion" },
  { id: "gke5", title: "Fog Layer", description: "Ground mist overlay", component: GameKit.FogLayer, category: "environment", code: `<motion.div className="h-24 bg-gradient-to-t from-slate-300/60" \n  animate={{ opacity: [0.4, 0.7, 0.4], x: [-20, 20] }}\n/>`, prompt: "Create fog layer effect with drifting mist at ground level" },
  { id: "gke6", title: "Day/Night Cycle", description: "Sky color transition", component: GameKit.DayNightCycle, category: "environment", code: `const isDay = time < 180;\nconst bgColor = isDay ? "from-sky-400" : "from-slate-800";\n<div className={\`bg-gradient-to-b \${bgColor}\`}>`, prompt: "Build day/night cycle with smooth sky color transitions and sun/moon icons" },
  { id: "gke7", title: "Water Ripples", description: "Surface distortion", component: GameKit.WaterRipples, category: "environment", code: `{ripples.map(r => \n  <motion.div className="border-2 border-white/50 rounded-full" \n    initial={{ width: 0 }} \n    animate={{ width: 80, opacity: 0 }}\n  />\n)}`, prompt: "Create water ripple effect with expanding circles for splash impacts" },
  { id: "gke8", title: "Grass Rustle", description: "Ground vegetation motion", component: GameKit.GrassRustle, category: "environment", code: `{[...Array(12)].map((_, i) => \n  <motion.span \n    animate={{ rotate: [-10, 10, -10], y: [0, -5, 0] }}\n  >🌾</motion.span>\n)}`, prompt: "Build grass rustling animation with wind-blown swaying motion" },
  { id: "gke9", title: "Lightning Flash", description: "Thunder strike effect", component: GameKit.LightningFlash, category: "environment", code: `{flash && \n  <div className="bg-white">\n    <span className="text-6xl">⚡</span>\n  </div>\n}`, prompt: "Create lightning flash effect with screen brightening and thunder bolt" },
  
  // BUILDINGS/STRUCTURES (9 new)
  { id: "gkb1", title: "Construction Progress", description: "Building assembly", component: GameKit.ConstructionProgress, category: "buildings", code: `<motion.div animate={{ scale: prog / 100 }}>\n  🏗️\n</motion.div>\n<progress value={prog} max={100} />`, prompt: "Create building construction animation with progressive scaling and progress bar" },
  { id: "gkb2", title: "Damage Cracks", description: "Structure decay visual", component: GameKit.DamageCracks, category: "buildings", code: `{damage > 30 && \n  <div style={{ \n    background: "linear-gradient(45deg, transparent 40%, #ef4444 41%)" \n  }} />\n}`, prompt: "Build damage crack overlay system that appears as structures take damage" },
  { id: "gkb3", title: "Building On Fire", description: "Flame overlay effect", component: GameKit.BuildingOnFire, category: "buildings", code: `{[...Array(8)].map((_, i) => \n  <motion.div animate={{ y: [0, -40], opacity: [1, 0] }}>\n    🔥\n  </motion.div>\n)}`, prompt: "Create building fire effect with rising flames and flickering animation" },
  { id: "gkb4", title: "Defense Tower", description: "Rotating turret base", component: GameKit.DefenseTower, category: "buildings", code: `<motion.div className="w-12 h-2 origin-bottom" \n  style={{ rotate: angle }}\n/>`, prompt: "Build defense tower with rotating turret for tower defense games" },
  { id: "gkb5", title: "Door Opening", description: "Sliding/swinging door", component: GameKit.DoorOpening, category: "buildings", code: `<motion.div \n  animate={open ? { scaleX: [1, 0] } : {}}\n  transition={{ duration: 0.5 }}\n/>`, prompt: "Create door opening animation with scaling effect for entrances" },
  { id: "gkb6", title: "Window Light", description: "Interior glow effect", component: GameKit.WindowLight, category: "buildings", code: `<motion.div \n  className={\`\${lit ? "bg-yellow-300" : "bg-slate-900"}\`} \n  animate={lit ? { opacity: [0.8, 1, 0.8] } : {}}\n  style={{ boxShadow: lit ? "0 0 20px #fde047" : "none" }}\n/>`, prompt: "Build window lighting system with flickering glow for building interiors" },
  { id: "gkb7", title: "Rubble Collapse", description: "Destruction particles", component: GameKit.RubbleCollapse, category: "buildings", code: `{debris.map(d => \n  <motion.div \n    animate={{ y: 100, x: (Math.random() - 0.5) * 60, rotate: 360 }}\n  >🧱</motion.div>\n)}`, prompt: "Create building collapse with falling rubble debris particles" },
  { id: "gkb8", title: "Checkpoint Station", description: "Waypoint beacon", component: GameKit.CheckpointStation, category: "buildings", code: `<motion.div className="bg-cyan-500/20 border-2 border-cyan-400" \n  animate={{ opacity: [0.4, 0.8, 0.4] }}\n/>`, prompt: "Build checkpoint station with pulsing beacon light effect" },
  { id: "gkb9", title: "Teleporter Portal", description: "Warp gate animation", component: GameKit.TeleporterPortal, category: "buildings", code: `<motion.div \n  animate={{ rotate: 360, scale: [1, 1.1, 1] }} \n  transition={{ rotate: { duration: 3, repeat: Infinity } }}\n/>`, prompt: "Create teleporter portal with spinning vortex and scaling animation" },
  
  // EXPLOSIONS/EFFECTS (9 new)
  { id: "gkx1", title: "Nuclear Blast", description: "Mushroom cloud effect", component: GameKit.NuclearBlast, category: "explosions", code: `<motion.div className="bg-orange-500 rounded-full" \n  initial={{ scale: 0 }} \n  animate={{ scale: 20, opacity: 0 }}\n/>\n<motion.div className="rounded-t-full" \n  animate={{ height: 120 }}\n/>`, prompt: "Create nuclear explosion with expanding fireball and mushroom cloud" },
  { id: "gkx2", title: "Shockwave Ring", description: "Expanding impact circle", component: GameKit.ShockwaveRing, category: "explosions", code: `<motion.div className="border-4 border-cyan-400 rounded-full" \n  initial={{ scale: 0, opacity: 1 }} \n  animate={{ scale: 15, opacity: 0 }}\n/>`, prompt: "Build shockwave effect with expanding ring for explosion impacts" },
  { id: "gkx3", title: "Fire Explosion", description: "Burst with flames", component: GameKit.FireExplosion, category: "explosions", code: `{[...Array(12)].map((_, i) => \n  <motion.div animate={{ \n    x: Math.cos((i * 30 * Math.PI) / 180) * 60,\n    y: Math.sin((i * 30 * Math.PI) / 180) * 60\n  }}>🔥</motion.div>\n)}`, prompt: "Create fire explosion with radiating flame particles in all directions" },
  { id: "gkx4", title: "Smoke Plume", description: "Rising dark cloud", component: GameKit.SmokePlume, category: "explosions", code: `{smoke.map(s => \n  <motion.div \n    initial={{ y: 0, scale: 0.5 }} \n    animate={{ y: -120, scale: 2, opacity: 0 }}\n  >💨</motion.div>\n)}`, prompt: "Build rising smoke plume effect with expanding particles drifting upward" },
  { id: "gkx5", title: "Electric Discharge", description: "Lightning branching", component: GameKit.ElectricDischarge, category: "explosions", code: `{[...Array(8)].map((_, i) => \n  <motion.div \n    style={{ rotate: i * 45 }} \n    animate={{ scaleY: [0, 1, 0] }}\n  />\n)}`, prompt: "Create electric discharge with branching lightning bolts radiating outward" },
  { id: "gkx6", title: "Freeze Burst", description: "Ice shard explosion", component: GameKit.FreezeBurst, category: "explosions", code: `{[...Array(16)].map((_, i) => \n  <motion.div animate={{ \n    x: Math.cos((i * 22.5 * Math.PI) / 180) * 80\n  }}>❄️</motion.div>\n)}`, prompt: "Build freeze burst with ice shards shooting in all directions" },
  { id: "gkx7", title: "Acid Splash", description: "Green liquid spray", component: GameKit.AcidSplash, category: "explosions", code: `{[...Array(10)].map((_, i) => \n  <motion.div className="bg-green-500 rounded-full" \n    animate={{ x: (Math.random() - 0.5) * 100, y: -60 }}\n  />\n)}`, prompt: "Create acid splash effect with green particle spray" },
  { id: "gkx8", title: "Dust Cloud", description: "Impact debris", component: GameKit.DustCloud, category: "explosions", code: `<motion.div className="bg-amber-800/60" \n  initial={{ scale: 0, opacity: 1 }} \n  animate={{ scale: 3, opacity: 0 }}\n/>`, prompt: "Build dust cloud impact effect with expanding brown cloud" },
  { id: "gkx9", title: "Screen Shake", description: "Camera rumble effect", component: GameKit.ScreenShake, category: "explosions", code: `<motion.div \n  animate={shake ? { \n    x: [0, -5, 5, -3, 3, 0], \n    y: [0, 3, -3, 2, -2, 0] \n  } : {}}\n/>`, prompt: "Implement screen shake effect with randomized camera movement" },
  
  // COMBAT UI (9 new)
  { id: "gku1", title: "Block Indicator", description: "Incoming attack warning", component: GameKit.BlockIndicator, category: "combatui", code: `{incoming && \n  <motion.div className="border-4 border-red-500" \n    animate={{ opacity: [0.3, 1, 0.3] }}\n  />\n}`, prompt: "Create block indicator with pulsing border warning for incoming attacks" },
  { id: "gku2", title: "Counter Attack", description: "Perfect timing window", component: GameKit.CounterAttack, category: "combatui", code: `{counter && \n  <motion.p \n    initial={{ scale: 0, rotate: -180 }} \n    animate={{ scale: 1, rotate: 0 }}\n  >COUNTER!</motion.p>\n}`, prompt: "Build counter attack announcement with dramatic entrance animation" },
  { id: "gku3", title: "Finisher Prompt", description: "Execute command", component: GameKit.FinisherPrompt, category: "combatui", code: `{ready && \n  <motion.div className="bg-gradient-to-r from-red-600 to-orange-600">\n    FINISH HIM!\n  </motion.div>\n}`, prompt: "Create finisher prompt UI with bold text and border for execution moves" },
  { id: "gku4", title: "Weak Point", description: "Vulnerable area marker", component: GameKit.WeakPoint, category: "combatui", code: `{weak && \n  <motion.div className="border-4 border-yellow-400 rounded-full" \n    animate={{ scale: [1, 1.3, 1] }}\n  />\n}`, prompt: "Build weak point indicator showing vulnerable spots on enemies" },
  { id: "gku5", title: "Combo String", description: "Attack chain display", component: GameKit.ComboString, category: "combatui", code: `{combo.map((m, i) => \n  <motion.span key={i} \n    initial={{ scale: 0 }} \n    animate={{ scale: 1 }}\n  >{m}</motion.span>\n)}`, prompt: "Create combo string display showing sequence of attacks performed" },
  { id: "gku6", title: "Guard Break", description: "Defense shattered", component: GameKit.GuardBreak, category: "combatui", code: `{broken && \n  <motion.p initial={{ scale: 0 }} animate={{ scale: 1 }}>\n    GUARD BROKEN!\n  </motion.p>\n}`, prompt: "Build guard break announcement with explosion particles" },
  { id: "gku7", title: "Backstab Indicator", description: "Stealth kill prompt", component: GameKit.BackstabIndicator, category: "combatui", code: `{backstab && \n  <motion.p \n    initial={{ scale: 0, rotate: -20 }} \n    animate={{ scale: 1, rotate: 0 }}\n  >BACKSTAB!</motion.p>\n}`, prompt: "Create backstab indicator for successful stealth kills with dramatic reveal" },
  { id: "gku8", title: "Revenge Mode", description: "Power-up state", component: GameKit.RevengeMode, category: "combatui", code: `{revenge && \n  <motion.div className="bg-red-500/40 border-4 border-red-500" \n    animate={{ scale: [1, 1.1, 1] }}\n  />\n}`, prompt: "Build revenge mode visual with pulsing red border and angry emoji" },
  { id: "gku9", title: "Battle Stance", description: "Posture indicator", component: GameKit.BattleStance, category: "combatui", code: `const stances = [\n  { name: "Offensive", icon: "⚔️" },\n  { name: "Defensive", icon: "🛡️" }\n];`, prompt: "Create battle stance selector showing current combat posture" },
  
  // PROJECTILES/AMMUNITION (9 new)
  { id: "gkp1", title: "Arrow Flight", description: "Projectile arc", component: GameKit.ArrowFlight, category: "projectiles", code: `{arrows.map(a => \n  <motion.div \n    initial={{ rotate: 0 }} \n    animate={{ x: 280, rotate: -10 }}\n  >➤</motion.div>\n)}`, prompt: "Create arrow flight animation with tilted angle and smooth trajectory" },
  { id: "gkp2", title: "Grenade Arc Preview", description: "Throw trajectory", component: GameKit.GrenadeArcPreview, category: "projectiles", code: `<svg>\n  <motion.path \n    d="M 20 80 Q 50 20, 80 80" \n    stroke="#facc15" \n    strokeDasharray="5,5"\n  />\n</svg>`, prompt: "Build grenade arc preview showing throw trajectory with dashed line" },
  { id: "gkp3", title: "Boomerang Return", description: "Curved path weapon", component: GameKit.BoomerangReturn, category: "projectiles", code: `<motion.div \n  animate={{ \n    left: ["30%", "80%", "30%"], \n    rotate: [0, 720, 1440] \n  }}\n>🪃</motion.div>`, prompt: "Create boomerang return path with rotation and curved trajectory" },
  { id: "gkp4", title: "Sticky Bomb", description: "Attach and countdown", component: GameKit.StickyBomb, category: "projectiles", code: `{attached && \n  <motion.span animate={countdown < 2 ? { scale: [1, 1.2, 1] } : {}}>\n    💣 {countdown}\n  </motion.span>\n}`, prompt: "Build sticky bomb with attachment and countdown timer before explosion" },
  { id: "gkp5", title: "Homing Missile", description: "Tracking projectile", component: GameKit.HomingMissile, category: "projectiles", code: `<motion.div \n  animate={{ \n    left: \`\${missile.x + (target.x - missile.x) * 0.1}%\` \n  }}\n>🚀</motion.div>`, prompt: "Create homing missile that tracks and follows moving targets" },
  { id: "gkp6", title: "Ricochet Bullet", description: "Bounce trajectory", component: GameKit.RicochetBullet, category: "projectiles", code: `<motion.div \n  animate={{ \n    left: ["10%", "50%", "90%"], \n    top: ["50%", "20%", "50%"] \n  }}\n/>`, prompt: "Build ricochet bullet showing bouncing trajectory between points" },
  { id: "gkp7", title: "Chain Lightning", description: "Multi-target attack", component: GameKit.ChainLightning, category: "projectiles", code: `{zaps.map(z => \n  <motion.div className="bg-cyan-400" \n    style={{ rotate: (Math.random() - 0.5) * 40 }}\n  />\n)}`, prompt: "Create chain lightning jumping between multiple targets with electric arcs" },
  { id: "gkp8", title: "Piercing Shot", description: "Through-wall indicator", component: GameKit.PiercingShot, category: "projectiles", code: `<motion.div className="w-full h-0.5 bg-cyan-400" \n  initial={{ scaleX: 0 }} \n  animate={{ scaleX: 1 }}\n  style={{ boxShadow: "0 0 10px #22d3ee" }}\n/>`, prompt: "Build piercing shot visual showing bullet passing through obstacles" },
  { id: "gkp9", title: "Area Grenade Preview", description: "Blast radius display", component: GameKit.AreaGrenadePreview, category: "projectiles", code: `<motion.div className="border-2 border-red-500/50 rounded-full" \n  animate={{ scale: 0.5 + radius / 100 }}\n/>`, prompt: "Create area grenade preview showing blast radius before throwing" },
  
  // UI OVERLAYS (9 new)
  { id: "gko1", title: "Victory Screen", description: "Win celebration", component: GameKit.VictoryScreen, category: "overlays", code: `<motion.div \n  initial={{ scale: 0, rotate: -180 }} \n  animate={{ scale: 1, rotate: 0 }}\n>\n  🏆 VICTORY!\n</motion.div>`, prompt: "Create victory screen with trophy and celebratory animation" },
  { id: "gko2", title: "Defeat Banner", description: "Loss announcement", component: GameKit.DefeatBanner, category: "overlays", code: `<motion.p \n  initial={{ opacity: 0, y: -50 }} \n  animate={{ opacity: 1, y: 0 }}\n>DEFEAT</motion.p>`, prompt: "Build defeat banner with somber animation for game loss" },
  { id: "gko3", title: "Pause Menu", description: "Game suspended UI", component: GameKit.PauseMenuOverlay, category: "overlays", code: `{paused && \n  <motion.div className="bg-black/90">\n    <button>Resume</button>\n    <button>Quit</button>\n  </motion.div>\n}`, prompt: "Create pause menu overlay with resume and quit options" },
  { id: "gko4", title: "Options Slider", description: "Settings control", component: GameKit.OptionsSlider, category: "overlays", code: `<input \n  type="range" \n  min="0" \n  max="100" \n  className="accent-violet-500"\n/>`, prompt: "Build options slider for volume or settings adjustments" },
  { id: "gko5", title: "Keybind Display", description: "Control hints", component: GameKit.KeybindDisplay, category: "overlays", code: `{binds.map(b => \n  <div>\n    <span>{b.action}</span>\n    <span className="bg-slate-800">{b.key}</span>\n  </div>\n)}`, prompt: "Create keybind display showing action-key mappings for controls" },
  { id: "gko6", title: "Tutorial Arrow", description: "Pointing guide", component: GameKit.TutorialArrow, category: "overlays", code: `<motion.div \n  animate={{ x: [0, 10, 0] }} \n  transition={{ repeat: Infinity }}\n>👉</motion.div>`, prompt: "Build tutorial arrow that points to UI elements with bouncing animation" },
  { id: "gko7", title: "Notification Stack", description: "Alert queue", component: GameKit.NotificationStack, category: "overlays", code: `{notifs.map(n => \n  <motion.div \n    initial={{ x: 100 }} \n    animate={{ x: 0 }}\n  >{n.msg}</motion.div>\n)}`, prompt: "Create notification stack showing multiple alerts in queue" },
  { id: "gko8", title: "Currency Popup", description: "Reward earned", component: GameKit.CurrencyPopup, category: "overlays", code: `<motion.p \n  initial={{ y: 0, scale: 1 }} \n  animate={{ y: -40, scale: 1.5, opacity: 0 }}\n>+100 🪙</motion.p>`, prompt: "Build currency popup showing earned money floating upward" },
  { id: "gko9", title: "Mission Complete", description: "Objective cleared", component: GameKit.MissionComplete, category: "overlays", code: `<motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>\n  ✓ MISSION COMPLETE\n  <p>+500 XP | +250 Gold</p>\n</motion.div>`, prompt: "Create mission complete screen with checkmark and reward display" },
  { id: "gk3", title: "Collision Detection", description: "Object collision system", component: GameKit.CollisionDetection, category: "core", code: `const [pos, setPos] = useState(30);\nconst [hit, setHit] = useState(false);\n// Check collision bounds\nif (newPos >= 70 || newPos <= 10) {\n  setHit(true);\n  setTimeout(() => setHit(false), 100);\n}`, prompt: "Build a collision detection system with visual feedback when objects hit boundaries" },
  { id: "gk4", title: "Gravity System", description: "Realistic gravity physics", component: GameKit.GravitySystem, category: "core", code: `const [velocity, setVelocity] = useState(0);\nsetVelocity(v => v + 0.5); // Apply gravity\nsetY(yPos => {\n  const newY = yPos + velocity;\n  return newY >= 80 ? (setVelocity(-velocity * 0.7), 80) : newY;\n});`, prompt: "Create a gravity system with velocity and bounce physics for falling objects" },
  { id: "gk5", title: "Platformer Character", description: "Keyboard-controlled character", component: GameKit.PlatformerCharacter, category: "core", code: `useEffect(() => {\n  const handleKey = (e) => {\n    if (e.key === "ArrowLeft") setX(p => Math.max(5, p - 5));\n    if (e.key === "ArrowRight") setX(p => Math.min(95, p + 5));\n  };\n  window.addEventListener("keydown", handleKey);\n}, []);`, prompt: "Build a platformer character with left/right arrow key controls and sprite flipping" },
  { id: "gk6", title: "Item Spawner", description: "Random item generation", component: GameKit.ItemSpawner, category: "core", code: `const i = setInterval(() => {\n  const id = Date.now();\n  setItems(its => [...its, { id, x: Math.random() * 80 + 10, y: -10 }]);\n  setTimeout(() => setItems(its => its.filter(it => it.id !== id)), 2000);\n}, 800);`, prompt: "Create an item spawning system that generates random items at intervals with auto-cleanup" },
  { id: "gk7", title: "Parallax Background", description: "Multi-layer scrolling background", component: GameKit.ParallaxBackground, category: "gamekit", code: `const [scroll, setScroll] = useState(0);\n// Layer 1: Fast scroll\nbackgroundPositionX: -\${scroll}%\n// Layer 2: Slow scroll  \nbackgroundPositionX: -\${scroll * 0.5}%`, prompt: "Implement a parallax scrolling background with multiple layers moving at different speeds" },
  { id: "gk8", title: "Enemy AI Patrol", description: "NPC patrol movement", component: GameKit.EnemyAIPatrol, category: "gamekit", code: `useEffect(() => {\n  const i = setInterval(() => setX(p => {\n    if (p >= 85) setDir(-1);\n    if (p <= 10) setDir(1);\n    return p + dir * 1.5;\n  }), 30);\n}, [dir]);`, prompt: "Build an enemy AI patrol system with direction changes at boundaries" },
  { id: "gk9", title: "Projectile System", description: "Shooting mechanics", component: GameKit.ProjectileSystem, category: "gamekit", code: `const shoot = () => {\n  const id = Date.now();\n  setBullets(b => [...b, { id, x: 10 }]);\n  setTimeout(() => setBullets(b => b.filter(bu => bu.id !== id)), 1000);\n};`, prompt: "Create a projectile shooting system with bullet spawning and cleanup for a shooter game" },
  { id: "gk10", title: "Double Jump", description: "Double jump mechanic", component: GameKit.DoubleJump, category: "gamekit", code: `const handleJump = () => {\n  if (jumps < 2) {\n    setY(20);\n    setJumps(j => j + 1);\n    setTimeout(() => {\n      setY(80);\n      if (jumps === 1) setJumps(0);\n    }, 500);\n  }\n};`, prompt: "Implement double jump mechanics with jump counter reset on landing" },
  { id: "gk11", title: "Score Multiplier", description: "Combo score system", component: GameKit.ScoreMultiplier, category: "gamekit", code: `useEffect(() => {\n  const i = setInterval(() => {\n    setScore(s => s + 10 * mult);\n    setMult(m => m < 8 ? m + 0.5 : 1);\n  }, 500);\n}, [mult]);`, prompt: "Build a score multiplier system that increases with consecutive actions and resets periodically" },
  { id: "gk12", title: "Dash Attack", description: "Quick dash ability", component: GameKit.DashAttack, category: "gamekit", code: `const dash = () => {\n  setDashing(true);\n  setX(80); // Move to target\n  setTimeout(() => {\n    setDashing(false);\n    setX(20); // Return\n  }, 400);\n};`, prompt: "Create a dash attack ability with rapid movement and visual trail effect" },
  { id: "gk13", title: "Shield/Block System", description: "Defensive blocking", component: GameKit.ShieldBlock, category: "gamekit", code: `<div \n  onMouseDown={() => setBlocking(true)} \n  onMouseUp={() => setBlocking(false)}\n>\n  {blocking && <motion.div animate={{ scale: 1.05 }} />}\n</div>`, prompt: "Implement a shield blocking system activated by holding mouse button with visual feedback" },
  { id: "gk14", title: "Charge Attack", description: "Hold-to-charge mechanic", component: GameKit.ChargeAttack, category: "gamekit", code: `useEffect(() => {\n  if (charging && charge < 100) {\n    const i = setInterval(() => \n      setCharge(c => Math.min(100, c + 5)), 50);\n    return () => clearInterval(i);\n  }\n}, [charging, charge]);`, prompt: "Build a charge attack system where holding increases power with a progress bar indicator" },
  { id: "gk15", title: "Inventory Slot", description: "Item slot management", component: GameKit.InventorySlot, category: "gamekit", code: `const cycle = () => \n  setItem(items[(items.indexOf(item) + 1) % items.length]);`, prompt: "Create an inventory slot component that cycles through available items on click" },
  { id: "gk16", title: "Quest Marker", description: "Floating quest indicator", component: GameKit.QuestMarker, category: "gamekit", code: `<motion.div animate={{ y: [-10, 10, -10] }} transition={{ duration: 1.5, repeat: Infinity }}>\n  <span className="text-5xl">❗</span>\n</motion.div>`, prompt: "Design a floating quest marker with bobbing animation to indicate active objectives" },
  { id: "gk17", title: "Waypoint Navigation", description: "Path navigation system", component: GameKit.WaypointNavigation, category: "gamekit", code: `const points = [20, 40, 60, 80];\nuseEffect(() => {\n  const i = setInterval(() => \n    setCurrent(c => (c + 1) % points.length), 1500);\n}, []);`, prompt: "Build a waypoint navigation system that moves between predefined points automatically" },
  { id: "gk18", title: "Minimap", description: "Real-time minimap display", component: GameKit.Minimap, category: "gamekit", code: `useEffect(() => {\n  const i = setInterval(() => \n    setPlayerPos({\n      x: 20 + Math.random() * 60, \n      y: 20 + Math.random() * 60\n    }), 1000);\n}, []);`, prompt: "Create a minimap component with grid overlay and real-time player position tracking" },
  { id: "gk19", title: "Resource Counter", description: "Currency/resource display", component: GameKit.ResourceCounter, category: "gamekit", code: `useEffect(() => {\n  const i = setInterval(() => \n    setGold(g => g + Math.floor(Math.random() * 10)), 500);\n}, []);`, prompt: "Implement a resource counter with animated number changes for collecting currency" },
  { id: "gk20", title: "Skill Cooldown", description: "Ability cooldown timer", component: GameKit.SkillCooldown, category: "gamekit", code: `const use = () => { if (cd === 0) setCd(100); };\nuseEffect(() => {\n  if (cd > 0) {\n    const i = setInterval(() => \n      setCd(c => Math.max(0, c - 2)), 30);\n  }\n}, [cd]);`, prompt: "Build a skill cooldown system with circular progress indicator for game abilities" },
  { id: "gk21", title: "Damage Flash", description: "Hit reaction effect", component: GameKit.DamageFlash, category: "gamekit", code: `useEffect(() => {\n  const i = setInterval(() => {\n    setHit(true);\n    setTimeout(() => setHit(false), 100);\n  }, 2000);\n}, []);`, prompt: "Create a damage flash effect that briefly shows red overlay when taking damage" },
  { id: "gk22", title: "Combo Chain", description: "Combo counter system", component: GameKit.ComboChain, category: "gamekit", code: `const hit = () => setCombo(c => c + 1);\nuseEffect(() => {\n  if (combo > 0) {\n    const t = setTimeout(() => setCombo(0), 2000);\n    return () => clearTimeout(t);\n  }\n}, [combo]);`, prompt: "Implement a combo chain system that resets after inactivity with scaling text animation" },
  { id: "gk23", title: "Stealth Meter", description: "Visibility detection gauge", component: GameKit.StealthMeter, category: "gamekit", code: `useEffect(() => {\n  const i = setInterval(() => \n    setStealth(s => (s + 5) % 101), 200);\n}, []);`, prompt: "Build a stealth meter that shows player visibility with color-coded warning states" },
  { id: "gk24", title: "QTE Prompt", description: "Quick-time event button", component: GameKit.QTEPrompt, category: "gamekit", code: `useEffect(() => {\n  const i = setInterval(() => {\n    setActive(true);\n    setTimeout(() => setActive(false), 2000);\n  }, 4000);\n}, []);`, prompt: "Create a quick-time event (QTE) prompt that appears periodically with scaling animation" },
  { id: "gk25", title: "Level Up Burst", description: "Level up celebration", component: GameKit.LevelUpBurst, category: "gamekit", code: `<motion.div \n  className="absolute inset-0 bg-gradient-to-r from-yellow-500/50 via-transparent to-yellow-500/50" \n  initial={{ x: "-100%" }} \n  animate={{ x: "100%" }}\n/>`, prompt: "Design a level up burst effect with sweeping gradient and rotating text animation" },
  { id: "gk26", title: "Boss Intro", description: "Cinematic boss entrance", component: GameKit.BossIntro, category: "gamekit", code: `const seq = [0, 1000, 2000];\nseq.forEach((t, i) => \n  setTimeout(() => setPhase(i), t));`, prompt: "Create a boss introduction sequence with multi-phase reveal animation" },
  { id: "gk27", title: "Checkpoint Flag", description: "Save point indicator", component: GameKit.CheckpointFlag, category: "gamekit", code: `<motion.span \n  animate={saved ? { rotate: [0, 10, -10, 0] } : {}} \n  transition={{ duration: 0.3 }}\n>\n  🚩\n</motion.span>`, prompt: "Build a checkpoint flag with save confirmation and celebratory wiggle animation" },
  { id: "gk28", title: "Game Timer", description: "Countdown timer display", component: GameKit.GameTimer, category: "gamekit", code: `useEffect(() => {\n  if (time > 0) {\n    const i = setInterval(() => setTime(t => t - 1), 1000);\n    return () => clearInterval(i);\n  }\n}, [time]);`, prompt: "Implement a countdown timer with warning color changes for remaining time" },
  { id: "gk29", title: "Wave Counter", description: "Enemy wave announcer", component: GameKit.WaveCounter, category: "gamekit", code: `<motion.p \n  key={wave} \n  initial={{ scale: 2, opacity: 0 }} \n  animate={{ scale: 1, opacity: 1 }}\n>\n  WAVE {wave}\n</motion.p>`, prompt: "Create a wave counter announcement with dramatic scale-in animation between rounds" },
  { id: "gk30", title: "Mana Bar", description: "Magic resource bar", component: GameKit.ManaBar, category: "gamekit", code: `<motion.div \n  className="h-full bg-gradient-to-r from-blue-500 to-purple-500" \n  animate={{ width: \`\${mana}%\` }}\n  style={{ boxShadow: "0 0 10px #3b82f6" }}\n/>`, prompt: "Build a mana bar with gradient fill and glow effect for magical abilities" },
  { id: "gk31", title: "Critical Hit", description: "Critical damage popup", component: GameKit.CriticalHit, category: "gamekit", code: `{crit && \n  <motion.p \n    initial={{ scale: 0, rotate: -45 }} \n    animate={{ scale: 1, rotate: 0 }}\n  >\n    💥 CRIT!\n  </motion.p>\n}`, prompt: "Design a critical hit indicator with explosive entrance animation and bright colors" },
  { id: "gk32", title: "Dialogue Box", description: "Typewriter dialogue system", component: GameKit.DialogueBox, category: "gamekit", code: `let i = 0;\nconst interval = setInterval(() => {\n  if (i < msg.length) {\n    setText(msg.slice(0, i + 1));\n    i++;\n  }\n}, 100);`, prompt: "Create a dialogue box with typewriter text effect and blinking cursor for RPG games" },
  { id: "gk33", title: "Buff Icon", description: "Status buff indicators", component: GameKit.BuffIcon, category: "gamekit", code: `{buffs.map((b, i) => \n  <motion.div \n    initial={{ scale: 0 }} \n    animate={{ scale: 1, y: [0, -5, 0] }} \n    transition={{ delay: i * 0.2 }}\n  >\n    {b}\n  </motion.div>\n)}`, prompt: "Build a buff icon display with staggered entrance animations and floating effects" },
  { id: "gk34", title: "Debuff Timer", description: "Negative status countdown", component: GameKit.DebuffTimer, category: "gamekit", code: `useEffect(() => {\n  if (time > 0) {\n    const i = setInterval(() => setTime(t => t - 1), 1000);\n  }\n}, [time]);`, prompt: "Implement a debuff timer showing remaining duration of negative status effects" },
  { id: "gk35", title: "Rarity Glow", description: "Item rarity visual", component: GameKit.RarityGlow, category: "gamekit", code: `const rarities = [\n  { name: "Common", glow: "#9ca3af" },\n  { name: "Legendary", glow: "#f59e0b" }\n];\nstyle={{ boxShadow: \`0 0 20px \${rarity.glow}\` }}`, prompt: "Create item rarity indicators with color-coded glow effects (common to legendary)" },
  { id: "gk36", title: "Treasure Chest", description: "Interactive loot container", component: GameKit.TreasureChest, category: "gamekit", code: `<motion.span \n  animate={open ? { rotateY: 180 } : {}} \n  transition={{ duration: 0.5 }}\n>\n  {open ? "📬" : "📦"}\n</motion.span>`, prompt: "Build an interactive treasure chest that opens with 3D flip animation and reveals loot" },
  { id: "gk37", title: "Weapon Switch", description: "Weapon cycling system", component: GameKit.WeaponSwitch, category: "gamekit", code: `<motion.span \n  key={w} \n  initial={{ rotateY: -90, scale: 0 }} \n  animate={{ rotateY: 0, scale: 1 }}\n>\n  {weapons[w]}\n</motion.span>`, prompt: "Create a weapon switching system with 3D rotation animation between different weapons" },
  { id: "gk38", title: "Status Effect", description: "Environmental status display", component: GameKit.StatusEffect, category: "gamekit", code: `const effects = [\n  { icon: "🔥", name: "Burning" },\n  { icon: "⚡", name: "Shocked" }\n];\nanimate={{ scale: [1, 1.2, 1] }}`, prompt: "Build status effect indicators showing burning, frozen, or shocked states with pulsing icons" },
  { id: "gk39", title: "Energy Shield", description: "Protective barrier visual", component: GameKit.EnergyShield, category: "gamekit", code: `{active && \n  <motion.div \n    animate={{ scale: [1, 1.1, 1], opacity: [0.5, 1, 0.5] }} \n    transition={{ duration: 1.5, repeat: Infinity }}\n    style={{ boxShadow: "0 0 30px #22d3ee" }}\n  />\n}`, prompt: "Create an energy shield visual with pulsing border and cyan glow effect" },
  { id: "gk40", title: "Rage Meter", description: "Rage resource bar", component: GameKit.RageMeter, category: "gamekit", code: `<div className="w-48 h-4 bg-slate-800 rounded-full overflow-hidden">\n  <motion.div \n    className="h-full bg-gradient-to-r from-orange-500 to-red-600" \n    animate={{ width: \`\${rage}%\` }}\n  />\n</div>`, prompt: "Implement a rage meter bar with red-orange gradient that builds up during combat" },
  { id: "gk41", title: "Talent Tree", description: "Skill point allocation", component: GameKit.TalentTree, category: "gamekit", code: `const unlock = (i) => {\n  if (!unlocked.includes(i)) \n    setUnlocked([...unlocked, i]);\n};`, prompt: "Build a talent tree with unlockable nodes showing locked/unlocked states" },
  { id: "gk42", title: "Quest Log", description: "Active quest tracker", component: GameKit.QuestLog, category: "gamekit", code: `{quests.map((q, i) => \n  <p className={\`\${i === active ? "text-white" : "text-slate-600"}\`}>\n    {i === active ? "▶" : "○"} {q}\n  </p>\n)}`, prompt: "Create a quest log display showing active and inactive quests with indicators" },
  { id: "gk43", title: "Minimap Ping", description: "Map alert system", component: GameKit.MinimapPing, category: "gamekit", code: `<motion.div \n  initial={{ scale: 0 }} \n  animate={{ scale: [1, 2, 1], opacity: [1, 0, 1] }} \n  transition={{ duration: 1, repeat: Infinity }}\n/>`, prompt: "Implement minimap ping alerts with expanding ripple animation for team communication" },
  { id: "gk44", title: "Dodge Roll", description: "Evasive roll mechanic", component: GameKit.DodgeRoll, category: "gamekit", code: `<motion.span \n  animate={rolling ? { rotate: 360, x: [0, 100, 0] } : {}} \n  transition={{ duration: 0.6 }}\n>\n  {rolling ? "💨" : "🤸"}\n</motion.span>`, prompt: "Create a dodge roll ability with 360° rotation and horizontal movement animation" },
  { id: "gk45", title: "Parry Counter", description: "Perfect block mechanic", component: GameKit.ParryCounter, category: "gamekit", code: `{parry && \n  <motion.p \n    initial={{ scale: 0 }} \n    animate={{ scale: 1.5 }}\n  >\n    PARRY!\n  </motion.p>\n}`, prompt: "Build a parry counter system with dramatic text announcement for perfect blocks" },
  { id: "gk46", title: "Respawn Point", description: "Team respawn beacon", component: GameKit.RespawnPoint, category: "gamekit", code: `{active && \n  <motion.div \n    className="w-20 h-40 bg-cyan-500/20 border-2 border-cyan-400" \n    animate={{ opacity: [0.3, 0.7, 0.3] }}\n  />\n}`, prompt: "Design a respawn point beacon with pulsing vertical column of light effect" },
  { id: "gk47", title: "Pickup Item", description: "Collectable item animation", component: GameKit.PickupItem, category: "gamekit", code: `{!picked ? \n  <motion.span animate={{ y: [0, -10, 0] }} transition={{ duration: 1, repeat: Infinity }}\n    ⭐\n  </motion.span>\n  : <motion.p animate={{ y: -50, opacity: 0 }}>+1 Star!</motion.p>\n}`, prompt: "Create a pickup item with floating animation and collection feedback message" },
  { id: "gk48", title: "Zoom Scope", description: "Weapon scope zoom", component: GameKit.ZoomScope, category: "gamekit", code: `{zoomed && \n  <motion.div \n    className="absolute inset-0 border-4 border-white rounded-full" \n    initial={{ scale: 0 }} \n    animate={{ scale: 1 }}\n  />\n}`, prompt: "Implement a zoom scope effect with circular border and weapon icon transition" },
  { id: "gk49", title: "Grenade Timer", description: "Explosive countdown", component: GameKit.GrenadeTimer, category: "gamekit", code: `{time > 0 ? \n  <motion.div animate={time < 2 ? { scale: [1, 1.2, 1] } : {}}>\n    💣 {time}\n  </motion.div>\n  : <motion.p initial={{ scale: 0 }} animate={{ scale: 2, opacity: 0 }}>💥</motion.p>\n}`, prompt: "Create a grenade timer with countdown and explosion animation sequence" },
  { id: "gk50", title: "Team Indicator", description: "Team color identifier", component: GameKit.TeamIndicator, category: "gamekit", code: `const teams = [\n  { name: "BLUE", color: "#3b82f6" },\n  { name: "RED", color: "#ef4444" }\n];`, prompt: "Build a team indicator system showing player team affiliation with color coding" },
  { id: "gk51", title: "Kill Streak", description: "Consecutive kills counter", component: GameKit.KillStreak, category: "gamekit", code: `const msg = streak >= 10 ? "UNSTOPPABLE!" : \n  streak >= 7 ? "RAMPAGE!" : \n  streak >= 5 ? "KILLING SPREE!" : "";`, prompt: "Implement a kill streak counter with milestone announcements (Spree, Rampage, Unstoppable)" },
  { id: "gk52", title: "Leaderboard", description: "Player ranking display", component: GameKit.Leaderboard, category: "gamekit", code: `{players.map((p, i) => \n  <div className={\`\${i === 1 ? "text-cyan-400" : "text-slate-400"}\`}>\n    {i + 1}. {p.name} - {p.score}\n  </div>\n)}`, prompt: "Create a leaderboard UI highlighting current player position in player rankings" },
  { id: "gk53", title: "Map Marker", description: "Custom map pin", component: GameKit.MapMarker, category: "gamekit", code: `{pinned && \n  <motion.div \n    initial={{ scale: 0 }} \n    className="w-32 h-32 rounded-full border-2 border-red-500 opacity-30"\n  />\n}`, prompt: "Build a map marker system with ripple effect when pinning locations" },
  { id: "gk54", title: "Skill Slot", description: "Hotbar skill buttons", component: GameKit.SkillSlot, category: "gamekit", code: `{skills.map((s, i) => \n  <div \n    onClick={() => setActive(i)} \n    className={\`\${i === active ? "border-violet-500 bg-violet-500/20" : "border-slate-700"}\`}\n  >\n    {s}\n  </div>\n)}`, prompt: "Create skill slots showing available abilities with active state highlighting" },
  { id: "gk55", title: "Area Transition", description: "Zone change announcement", component: GameKit.AreaTransition, category: "gamekit", code: `<motion.p \n  key={zone} \n  initial={{ opacity: 0, scale: 2 }} \n  animate={{ opacity: 1, scale: 1 }}\n>\n  Entering {zone}...\n</motion.p>`, prompt: "Design area transition announcements for entering new game zones with fade-in text" },
  { id: "gk56", title: "Crafting Slot", description: "Item crafting interface", component: GameKit.CraftingSlot, category: "gamekit", code: `{materials.map((m, i) => \n  <div className="w-10 h-10 bg-slate-800 border border-amber-500">\n    {m}\n  </div>\n)}\n→\n<div onClick={() => setItem("🗡️")}>?</div>`, prompt: "Build a crafting interface showing material slots and result preview for item creation" },
  { id: "gk57", title: "Ping System", description: "Team communication pings", component: GameKit.PingSystem, category: "gamekit", code: `{pings.map(p => \n  <motion.div \n    initial={{ scale: 0 }} \n    animate={{ scale: [1, 2], opacity: [1, 0] }} \n    transition={{ duration: 1.5 }}\n  >\n    📍\n  </motion.div>\n)}`, prompt: "Create a ping system for team communication with expanding marker animations" },
  { id: "gk58", title: "Health Pickup", description: "Health restore item", component: GameKit.HealthPickup, category: "gamekit", code: `{visible ? \n  <motion.span animate={{ y: [0, -10, 0], rotate: [0, 10, -10, 0] }}>\n    💊\n  </motion.span>\n  : <motion.p>+50 HP</motion.p>\n}`, prompt: "Design health pickup items with floating animation and collection feedback" },
  { id: "gk59", title: "Ammo Pack", description: "Ammunition pickup", component: GameKit.AmmoPack, category: "gamekit", code: `{!collected ? \n  <motion.span animate={{ scale: [1, 1.1, 1] }}>📦</motion.span>\n  : <motion.p animate={{ y: -40, opacity: 0 }}>+30 Ammo</motion.p>\n}`, prompt: "Create ammo pack pickups with pulsing animation and collection message" },
  { id: "gk60", title: "Environment Hazard", description: "Danger zone warning", component: GameKit.EnvironmentHazard, category: "gamekit", code: `{danger && \n  <motion.div \n    className="absolute inset-0 bg-red-500/40" \n    animate={{ opacity: [0.2, 0.6, 0.2] }}\n  />\n}`, prompt: "Build environmental hazard warnings with pulsing red overlay for danger zones" },
  { id: "gk61", title: "Cover System", description: "Take cover mechanic", component: GameKit.CoverSystem, category: "gamekit", code: `<motion.span \n  animate={cover ? { x: 60 } : { x: 0 }}\n>\n  {cover ? "🙇" : "🏃"}\n</motion.span>`, prompt: "Implement a cover system where characters move behind obstacles when activated" },
  { id: "gk62", title: "Objective Marker", description: "Distance to objective", component: GameKit.ObjectiveMarker, category: "gamekit", code: `useEffect(() => {\n  const i = setInterval(() => \n    setDist(d => d > 0 ? d - 5 : 100), 200);\n}, []);`, prompt: "Create objective markers showing distance countdown as player approaches target" },
  { id: "gk63", title: "Interaction Prompt", description: "Context action button", component: GameKit.InteractionPrompt, category: "gamekit", code: `{show && \n  <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>\n    Press [E] to interact\n  </motion.div>\n}`, prompt: "Design interaction prompts that appear when near interactable objects" },
  { id: "gk64", title: "Vehicle HUD", description: "Vehicle speedometer", component: GameKit.VehicleHUD, category: "gamekit", code: `useEffect(() => {\n  const i = setInterval(() => \n    setSpeed(s => (s + 10) % 201), 100);\n}, []);`, prompt: "Build a vehicle HUD with speedometer and vehicle icon for racing/driving games" },
  { id: "gk65", title: "Turret Aim", description: "Rotating turret targeting", component: GameKit.TurretAim, category: "gamekit", code: `<motion.div \n  className="w-16 h-2 bg-red-500 origin-left" \n  style={{ rotate: angle }}\n/>`, prompt: "Create a turret aiming system with rotating barrel for tower defense games" },
  { id: "gk66", title: "Capture Point", description: "Territory control progress", component: GameKit.CapturePoint, category: "gamekit", code: `<div className="w-48 h-3 bg-slate-800 rounded-full overflow-hidden">\n  <motion.div \n    className="h-full bg-blue-500" \n    animate={{ width: \`\${progress}%\` }}\n  />\n</div>`, prompt: "Build a capture point system with progress bar for territory control objectives" },
  { id: "gk67", title: "Weapon Durability", description: "Equipment wear indicator", component: GameKit.WeaponDurability, category: "gamekit", code: `<motion.div \n  className={\`h-full \${dur > 50 ? "bg-green-500" : dur > 20 ? "bg-yellow-500" : "bg-red-500"}\`} \n  animate={{ width: \`\${dur}%\` }}\n/>`, prompt: "Implement weapon durability bars with color changes as equipment degrades" },
  { id: "gk68", title: "Armor Plate", description: "Armor segments display", component: GameKit.ArmorPlate, category: "gamekit", code: `{[...Array(3)].map((_, i) => \n  <motion.div \n    className={\`\${i < plates ? "bg-blue-500" : "bg-slate-700"}\`}\n    animate={i < plates ? { opacity: [0.7, 1, 0.7] } : {}}\n  />\n)}`, prompt: "Create armor plate indicators showing remaining armor segments with pulsing active plates" },
  { id: "gk69", title: "Gas Zone", description: "Battle royale gas damage", component: GameKit.GasZone, category: "gamekit", code: `<motion.div \n  className="absolute inset-0 bg-green-500/20" \n  animate={{ opacity: [0.1, 0.3, 0.1] }}\n/>\n<p>☠️ IN GAS ZONE</p>\n<p>-{damage} HP</p>`, prompt: "Build a gas zone warning system with pulsing green overlay and increasing damage counter" },
  { id: "gk70", title: "Revive Prompt", description: "Teammate revival system", component: GameKit.RevivePrompt, category: "core", code: `<div \n  onMouseDown={() => setReviving(true)} \n  onMouseUp={() => setReviving(false)}\n>\n  {reviving && <progress bar />}\n</div>`, prompt: "Create a teammate revival system with hold-to-revive progress bar mechanic" },
];

// All effects array
const effects = [
  { id: 1, title: "8-Bit Pixel Character", description: "Classic pixel art sprite", component: PixelArt8Bit, category: "retro" },
  { id: 2, title: "CRT Monitor", description: "Retro TV with scan lines", component: CRTMonitor, category: "retro" },
  { id: 3, title: "Arcade Score Counter", description: "Classic high score display", component: ArcadeScore, category: "retro" },
  { id: 4, title: "Coin Collector", description: "Floating coin animation", component: CoinCollector, category: "retro" },
  { id: 5, title: "Game Controller", description: "Interactive gamepad UI", component: GameControllerUI, category: "retro" },
  { id: 6, title: "Health Bar", description: "RPG health points bar", component: HealthBarRPG, category: "rpg" },
  { id: 7, title: "Power-Up Items", description: "Rotating power-ups", component: PowerUpItem, category: "retro" },
  { id: 8, title: "HUD Interface", description: "Heads-up display", component: HUDInterface, category: "scifi" },
  { id: 9, title: "Target Lock-On", description: "Targeting crosshair", component: TargetLockOn, category: "scifi" },
  { id: 10, title: "Warp Speed", description: "Hyperspace stars", component: WarpSpeed, category: "scifi" },
  { id: 11, title: "Loot Drop", description: "Falling item drops", component: LootDropper, category: "rpg" },
  { id: 12, title: "Damage Numbers", description: "Floating damage popups", component: DamagePopups, category: "rpg" },
  { id: 13, title: "XP Progress Bar", description: "Experience level up", component: XPProgressBar, category: "modern" },
  { id: 14, title: "Combo Counter", description: "Hit combo display", component: ComboMeter, category: "modern" },
  { id: 15, title: "Achievement Popup", description: "Trophy notifications", component: AchievementPopup, category: "modern" },
  { id: 16, title: "Boss Health Bar", description: "Epic boss HP display", component: BossHP, category: "rpg" },
  { id: 17, title: "Minimap Radar", description: "Scanning radar display", component: MiniRadar, category: "fps" },
  { id: 18, title: "Ammo Counter", description: "Bullet count display", component: AmmoDisplay, category: "fps" },
  { id: 19, title: "Stamina Wheel", description: "Circular stamina bar", component: StaminaWheel, category: "modern" },
  { id: 20, title: "Kill Feed", description: "Player elimination log", component: KillFeedLog, category: "fps" },
  { id: 21, title: "Inventory Grid", description: "Item slot grid", component: InventoryGrid, category: "rpg" },
  { id: 22, title: "Respawn Timer", description: "Death countdown", component: RespawnCountdown, category: "fps" },
  { id: 23, title: "Team Scoreboard", description: "VS team scores", component: TeamScoreboard, category: "fps" },
  { id: 24, title: "Class Selector", description: "Character class picker", component: ClassSelector, category: "rpg" },
  { id: 25, title: "Loading Screen", description: "Game loading bar", component: GameLoading, category: "retro" },
];

const categories = [
  { id: "all", label: "All Effects" },
  { id: "core", label: "React GameKit Core" },
  { id: "vehicles", label: "🚗 Vehicles" },
  { id: "weapons", label: "🔫 Weapons" },
  { id: "characters", label: "👥 Characters" },
  { id: "environment", label: "🌳 Environment" },
  { id: "buildings", label: "🏰 Buildings" },
  { id: "explosions", label: "💥 Explosions" },
  { id: "combatui", label: "⚔️ Combat UI" },
  { id: "projectiles", label: "🎯 Projectiles" },
  { id: "overlays", label: "📋 UI Overlays" },
  { id: "retro", label: "Retro / 8-Bit" },
  { id: "scifi", label: "Sci-Fi" },
  { id: "modern", label: "Modern" },
  { id: "fps", label: "FPS / Shooter" },
  { id: "rpg", label: "RPG" },
];

export default function GamingEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [showcaseMode, setShowcaseMode] = useState(false);

  const allEffects = [...gameKitComponents, ...effects];
  
  const filteredEffects = allEffects.filter(e => {
    const matchesSearch = e.title.toLowerCase().includes(searchQuery.toLowerCase()) || e.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === "all" || e.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={Gamepad2} title="Gaming Effects" description="250+ game components including React GameKit library with 9 new categories" gradient="#f59e0b, #ef4444" />
      <div className="max-w-7xl mx-auto px-4 pb-20">
        <div className="mb-6 flex flex-wrap gap-2">
          {categories.map(cat => (
            <button key={cat.id} onClick={() => setActiveCategory(cat.id)} className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${activeCategory === cat.id ? "bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-lg" : "bg-slate-800 text-slate-400 hover:bg-slate-700"}`}>
              {(cat.id === "core" || cat.id === "vehicles" || cat.id === "weapons" || cat.id === "characters" || cat.id === "environment" || cat.id === "buildings" || cat.id === "explosions" || cat.id === "combatui" || cat.id === "projectiles" || cat.id === "overlays") && <Zap className="w-3 h-3 inline mr-1" />}
              {cat.label}
            </button>
          ))}
        </div>
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between mb-6">
          <div className="w-full md:w-auto flex-1">
            <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filteredEffects.length} />
          </div>
          <button 
            onClick={() => setShowcaseMode(!showcaseMode)}
            className={`px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-all ${showcaseMode ? "bg-red-500 hover:bg-red-600 text-white shadow-lg shadow-red-500/20" : "bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg shadow-emerald-500/20"}`}
          >
            {showcaseMode ? <Zap className="w-5 h-5 fill-current animate-pulse" /> : <Gamepad2 className="w-5 h-5" />}
            {showcaseMode ? "Stop Showcase" : "Showcase Mode"}
          </button>
        </div>
        
        {/* React GameKit Featured Section */}
        {(activeCategory === "core" || activeCategory === "vehicles" || activeCategory === "weapons" || activeCategory === "characters" || activeCategory === "environment" || activeCategory === "buildings" || activeCategory === "explosions" || activeCategory === "combatui" || activeCategory === "projectiles" || activeCategory === "overlays") && (
          <div className="mb-8 p-6 rounded-2xl bg-gradient-to-br from-violet-900/30 to-orange-900/30 border border-violet-500/30">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-violet-500 rounded-lg">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">React GameKit Library - {categories.find(c => c.id === activeCategory)?.label}</h3>
                <p className="text-sm text-slate-400">150+ production-ready React components organized by category</p>
              </div>
            </div>
            <p className="text-xs text-slate-500">
              New categories: Vehicles, Weapons, Characters, Environment, Buildings, Explosions, Combat UI, Projectiles, and UI Overlays. Each with 9 specialized components ready to use.
            </p>
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEffects.map(effect => (
            <LazyRender key={effect.id} placeholderHeight="300px">
              <EffectErrorBoundary>
                <EffectCard 
                  title={effect.title} 
                  description={effect.description}
                  code={effect.code}
                  prompt={effect.prompt}
                  interactive={true}
                >
                  <effect.component showcase={showcaseMode} />
                </EffectCard>
              </EffectErrorBoundary>
            </LazyRender>
          ))}
        </div>
      </div>
    </div>
  );
}