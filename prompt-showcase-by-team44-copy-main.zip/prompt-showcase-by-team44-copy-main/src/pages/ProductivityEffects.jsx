import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckSquare, Clock, Calendar, Target, ListTodo, Timer, Zap, BarChart3, Flag, Plus, Trash2, GripVertical, Play, Pause, RotateCcw, ChevronRight, AlertCircle, Star, Archive, Filter, Search, Tag, Users, Repeat, Bell } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// Todo Item
function TodoItemEffect() {
  const [checked, setChecked] = useState(false);
  return (
    <EffectCard title="Todo Item" description="Checkable task row" whenToUse="Task lists, to-do apps, checklists.">
      <motion.div onClick={() => setChecked(!checked)} whileHover={{ x: 4 }} className={`flex items-center gap-3 p-3 bg-slate-800 rounded-lg cursor-pointer w-full ${checked ? "opacity-60" : ""}`}>
        <motion.div animate={checked ? { scale: [1, 1.2, 1] } : {}} className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${checked ? "bg-green-500 border-green-500" : "border-slate-500"}`}>
          {checked && <svg className="w-3 h-3 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M5 12l5 5 9-9"/></svg>}
        </motion.div>
        <span className={`flex-1 ${checked ? "line-through text-slate-500" : "text-white"}`}>Complete project documentation</span>
        <Flag className="w-4 h-4 text-amber-400" />
      </motion.div>
    </EffectCard>
  );
}

// Kanban Card
function KanbanCardEffect() {
  return (
    <EffectCard title="Kanban Card" description="Draggable task card" whenToUse="Project boards, task management, workflows.">
      <motion.div whileHover={{ y: -2 }} className="bg-slate-800 rounded-lg p-3 w-full cursor-grab active:cursor-grabbing">
        <div className="flex items-center gap-2 mb-2">
          <GripVertical className="w-4 h-4 text-slate-600" />
          <span className="px-2 py-0.5 bg-violet-500/20 text-violet-400 rounded text-xs">Feature</span>
        </div>
        <h4 className="text-white text-sm font-medium mb-2">Implement user authentication</h4>
        <div className="flex items-center justify-between">
          <div className="flex -space-x-2">
            <div className="w-6 h-6 rounded-full bg-violet-500 border-2 border-slate-800" />
            <div className="w-6 h-6 rounded-full bg-pink-500 border-2 border-slate-800" />
          </div>
          <div className="flex items-center gap-2 text-slate-500 text-xs">
            <span className="flex items-center gap-1"><CheckSquare className="w-3 h-3" /> 3/5</span>
            <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Dec 5</span>
          </div>
        </div>
      </motion.div>
    </EffectCard>
  );
}

// Pomodoro Timer
function PomodoroTimerEffect() {
  const [time, setTime] = useState(1500);
  const [running, setRunning] = useState(false);
  useEffect(() => {
    if (running && time > 0) {
      const interval = setInterval(() => setTime(t => t - 1), 1000);
      return () => clearInterval(interval);
    }
  }, [running, time]);
  const mins = Math.floor(time / 60);
  const secs = time % 60;
  const progress = ((1500 - time) / 1500) * 100;
  return (
    <EffectCard title="Pomodoro Timer" description="Focus timer with progress" whenToUse="Focus apps, time tracking, productivity.">
      <div className="text-center">
        <div className="relative w-32 h-32 mx-auto mb-4">
          <svg className="w-full h-full -rotate-90">
            <circle cx="64" cy="64" r="56" stroke="#334155" strokeWidth="8" fill="none" />
            <motion.circle cx="64" cy="64" r="56" stroke="#8b5cf6" strokeWidth="8" fill="none" strokeDasharray={352} animate={{ strokeDashoffset: 352 - (352 * progress / 100) }} />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-2xl font-bold text-white font-mono">{String(mins).padStart(2, "0")}:{String(secs).padStart(2, "0")}</span>
          </div>
        </div>
        <div className="flex gap-2 justify-center">
          <motion.button onClick={() => setRunning(!running)} whileTap={{ scale: 0.9 }} className="p-3 bg-violet-500 rounded-full text-white">
            {running ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
          </motion.button>
          <motion.button onClick={() => { setTime(1500); setRunning(false); }} whileTap={{ scale: 0.9 }} className="p-3 bg-slate-700 rounded-full text-white">
            <RotateCcw className="w-5 h-5" />
          </motion.button>
        </div>
      </div>
    </EffectCard>
  );
}

// Progress Tracker
function ProgressTrackerEffect() {
  return (
    <EffectCard title="Progress Tracker" description="Goal completion meter" whenToUse="Goals, habits, milestones.">
      <div className="w-full space-y-3">
        {[
          { label: "Daily Tasks", current: 7, total: 10, color: "violet" },
          { label: "Weekly Goal", current: 3, total: 5, color: "cyan" },
          { label: "Monthly Target", current: 15, total: 30, color: "pink" }
        ].map(g => (
          <div key={g.label}>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-slate-400">{g.label}</span>
              <span className="text-white">{g.current}/{g.total}</span>
            </div>
            <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
              <motion.div initial={{ width: 0 }} animate={{ width: `${(g.current / g.total) * 100}%` }} transition={{ duration: 1 }} className={`h-full bg-${g.color}-500 rounded-full`} />
            </div>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Priority Selector
function PrioritySelectorEffect() {
  const [priority, setPriority] = useState("medium");
  const levels = [
    { id: "low", label: "Low", color: "slate" },
    { id: "medium", label: "Medium", color: "amber" },
    { id: "high", label: "High", color: "orange" },
    { id: "urgent", label: "Urgent", color: "red" }
  ];
  return (
    <EffectCard title="Priority Selector" description="Task priority levels" whenToUse="Task creation, issue tracking.">
      <div className="flex gap-2">
        {levels.map(l => (
          <motion.button key={l.id} onClick={() => setPriority(l.id)} whileTap={{ scale: 0.95 }} className={`flex items-center gap-1 px-3 py-2 rounded-lg text-sm ${priority === l.id ? `bg-${l.color}-500 text-white` : "bg-slate-800 text-slate-400"}`}>
            <Flag className="w-4 h-4" /> {l.label}
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Due Date Picker
function DueDatePickerEffect() {
  const [date, setDate] = useState("today");
  const options = [
    { id: "today", label: "Today", icon: Zap },
    { id: "tomorrow", label: "Tomorrow", icon: Clock },
    { id: "week", label: "This Week", icon: Calendar },
    { id: "custom", label: "Custom", icon: Calendar }
  ];
  return (
    <EffectCard title="Due Date Picker" description="Quick date selection" whenToUse="Task scheduling, deadlines.">
      <div className="flex flex-wrap gap-2">
        {options.map(o => (
          <motion.button key={o.id} onClick={() => setDate(o.id)} whileHover={{ scale: 1.02 }} className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm ${date === o.id ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400"}`}>
            <o.icon className="w-4 h-4" /> {o.label}
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Streak Counter
function StreakCounterEffect() {
  return (
    <EffectCard title="Streak Counter" description="Consecutive days tracker" whenToUse="Habits, gamification, consistency.">
      <div className="text-center">
        <motion.div animate={{ scale: [1, 1.05, 1] }} transition={{ duration: 2, repeat: Infinity }} className="w-20 h-20 bg-gradient-to-br from-orange-500 to-amber-500 rounded-full mx-auto mb-3 flex items-center justify-center">
          <span className="text-3xl">🔥</span>
        </motion.div>
        <p className="text-white text-2xl font-bold">15 Day Streak!</p>
        <p className="text-slate-400 text-sm">Keep it up!</p>
        <div className="flex justify-center gap-1 mt-3">
          {[1, 2, 3, 4, 5, 6, 7].map(d => (
            <div key={d} className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${d <= 5 ? "bg-amber-500 text-white" : "bg-slate-700 text-slate-500"}`}>
              {d <= 5 ? "✓" : d}
            </div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Subtask List
function SubtaskListEffect() {
  const [tasks, setTasks] = useState([
    { text: "Research competitors", done: true },
    { text: "Create wireframes", done: true },
    { text: "Design mockups", done: false },
    { text: "Get feedback", done: false }
  ]);
  const toggle = (i) => setTasks(t => t.map((x, j) => j === i ? { ...x, done: !x.done } : x));
  return (
    <EffectCard title="Subtask List" description="Nested task items" whenToUse="Task breakdown, checklists.">
      <div className="space-y-2 w-full">
        {tasks.map((t, i) => (
          <motion.div key={i} onClick={() => toggle(i)} whileHover={{ x: 2 }} className="flex items-center gap-2 p-2 hover:bg-slate-800 rounded cursor-pointer">
            <div className={`w-4 h-4 rounded border ${t.done ? "bg-green-500 border-green-500" : "border-slate-500"} flex items-center justify-center`}>
              {t.done && <svg className="w-2.5 h-2.5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M5 12l5 5 9-9"/></svg>}
            </div>
            <span className={`text-sm ${t.done ? "line-through text-slate-500" : "text-white"}`}>{t.text}</span>
          </motion.div>
        ))}
        <button className="flex items-center gap-2 p-2 text-slate-500 hover:text-violet-400 text-sm"><Plus className="w-4 h-4" /> Add subtask</button>
      </div>
    </EffectCard>
  );
}

// Time Estimate
function TimeEstimateEffect() {
  const [hours, setHours] = useState(2);
  return (
    <EffectCard title="Time Estimate" description="Task duration input" whenToUse="Time tracking, estimation, planning.">
      <div className="flex items-center gap-3">
        <Timer className="w-5 h-5 text-violet-400" />
        <div className="flex items-center gap-2">
          {[0.5, 1, 2, 4, 8].map(h => (
            <motion.button key={h} onClick={() => setHours(h)} whileTap={{ scale: 0.9 }} className={`px-3 py-1.5 rounded-lg text-sm ${hours === h ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400"}`}>
              {h}h
            </motion.button>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Daily Planner Slot
function PlannerSlotEffect() {
  return (
    <EffectCard title="Daily Planner" description="Time-blocked schedule" whenToUse="Calendar, scheduling, planning.">
      <div className="space-y-2 w-full text-xs">
        {[
          { time: "9:00", task: "Team standup", color: "violet" },
          { time: "10:00", task: "", color: "" },
          { time: "11:00", task: "Design review", color: "cyan" },
          { time: "12:00", task: "Lunch break", color: "amber" }
        ].map((slot, i) => (
          <div key={i} className="flex gap-3">
            <span className="text-slate-500 w-12">{slot.time}</span>
            <div className={`flex-1 p-2 rounded-lg ${slot.task ? `bg-${slot.color}-500/20 border-l-2 border-${slot.color}-500` : "bg-slate-800/50 border border-dashed border-slate-700"}`}>
              {slot.task ? <span className={`text-${slot.color}-400`}>{slot.task}</span> : <span className="text-slate-600">Empty slot</span>}
            </div>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Quick Add Task
function QuickAddEffect() {
  return (
    <EffectCard title="Quick Add Task" description="Fast task creation" whenToUse="Task apps, inbox capture.">
      <div className="flex items-center gap-2 w-full">
        <div className="flex-1 flex items-center gap-2 px-4 py-3 bg-slate-800 rounded-lg">
          <Plus className="w-5 h-5 text-slate-400" />
          <input type="text" placeholder="Add a task..." className="flex-1 bg-transparent text-white outline-none" />
        </div>
        <button className="p-3 bg-violet-500 rounded-lg"><Plus className="w-5 h-5 text-white" /></button>
      </div>
    </EffectCard>
  );
}

// Project Progress
function ProjectProgressEffect() {
  return (
    <EffectCard title="Project Progress" description="Overall project status" whenToUse="Dashboards, project overview.">
      <div className="w-full bg-slate-800 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <h4 className="text-white font-medium">Website Redesign</h4>
          <span className="text-violet-400 text-sm font-medium">75%</span>
        </div>
        <div className="h-2 bg-slate-700 rounded-full overflow-hidden mb-3">
          <motion.div initial={{ width: 0 }} animate={{ width: "75%" }} transition={{ duration: 1 }} className="h-full bg-gradient-to-r from-violet-500 to-cyan-500 rounded-full" />
        </div>
        <div className="flex justify-between text-xs text-slate-500">
          <span>12 tasks completed</span>
          <span>4 remaining</span>
        </div>
      </div>
    </EffectCard>
  );
}

// Label/Tag Picker
function LabelPickerEffect() {
  const [selected, setSelected] = useState(["work"]);
  const labels = [
    { id: "work", label: "Work", color: "violet" },
    { id: "personal", label: "Personal", color: "cyan" },
    { id: "urgent", label: "Urgent", color: "red" },
    { id: "ideas", label: "Ideas", color: "amber" }
  ];
  const toggle = (id) => setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);
  return (
    <EffectCard title="Label Picker" description="Tag selection for tasks" whenToUse="Categorization, filtering, organization.">
      <div className="flex flex-wrap gap-2">
        {labels.map(l => (
          <motion.button key={l.id} onClick={() => toggle(l.id)} whileTap={{ scale: 0.95 }} className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-sm border ${selected.includes(l.id) ? `bg-${l.color}-500/20 border-${l.color}-500 text-${l.color}-400` : "border-slate-700 text-slate-400"}`}>
            <Tag className="w-3 h-3" /> {l.label}
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Assignee Selector
function AssigneeSelectorEffect() {
  const [assigned, setAssigned] = useState([0]);
  const users = ["Alice", "Bob", "Carol", "Dave"];
  return (
    <EffectCard title="Assignee Selector" description="Task assignment UI" whenToUse="Team tasks, collaboration.">
      <div className="flex items-center gap-2">
        <Users className="w-5 h-5 text-slate-400" />
        <div className="flex gap-1">
          {users.map((u, i) => (
            <motion.button key={u} onClick={() => setAssigned(a => a.includes(i) ? a.filter(x => x !== i) : [...a, i])} whileHover={{ scale: 1.1 }} className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium ${assigned.includes(i) ? "bg-violet-500 text-white ring-2 ring-violet-400" : "bg-slate-700 text-slate-400"}`}>
              {u[0]}
            </motion.button>
          ))}
          <button className="w-8 h-8 rounded-full bg-slate-800 border border-dashed border-slate-600 flex items-center justify-center text-slate-500">
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>
    </EffectCard>
  );
}

// Repeat/Recurring
function RecurringTaskEffect() {
  const [repeat, setRepeat] = useState("daily");
  return (
    <EffectCard title="Recurring Task" description="Repeat frequency selector" whenToUse="Habits, recurring tasks.">
      <div className="flex items-center gap-3">
        <Repeat className="w-5 h-5 text-slate-400" />
        <select value={repeat} onChange={e => setRepeat(e.target.value)} className="bg-slate-800 text-white px-3 py-2 rounded-lg text-sm border border-slate-700">
          <option value="none">No repeat</option>
          <option value="daily">Daily</option>
          <option value="weekdays">Weekdays</option>
          <option value="weekly">Weekly</option>
          <option value="monthly">Monthly</option>
        </select>
      </div>
    </EffectCard>
  );
}

// Focus Mode Toggle
function FocusModeEffect() {
  const [focused, setFocused] = useState(false);
  return (
    <EffectCard title="Focus Mode" description="Distraction-free toggle" whenToUse="Productivity apps, writing tools.">
      <motion.button onClick={() => setFocused(!focused)} whileTap={{ scale: 0.95 }} className={`flex items-center gap-3 px-6 py-3 rounded-xl ${focused ? "bg-violet-500" : "bg-slate-800"}`}>
        <motion.div animate={focused ? { scale: [1, 1.2, 1] } : {}} transition={{ duration: 1, repeat: focused ? Infinity : 0 }}>
          <Target className={`w-6 h-6 ${focused ? "text-white" : "text-slate-400"}`} />
        </motion.div>
        <div className="text-left">
          <p className={`font-medium ${focused ? "text-white" : "text-slate-300"}`}>{focused ? "Focus Mode On" : "Focus Mode Off"}</p>
          <p className={`text-xs ${focused ? "text-violet-200" : "text-slate-500"}`}>{focused ? "Notifications paused" : "Click to focus"}</p>
        </div>
      </motion.button>
    </EffectCard>
  );
}

// Task Filter Tabs
function TaskFilterEffect() {
  const [filter, setFilter] = useState("all");
  return (
    <EffectCard title="Task Filters" description="View filter tabs" whenToUse="Task lists, filtering views.">
      <div className="flex gap-1 bg-slate-800 p-1 rounded-lg">
        {[
          { id: "all", label: "All" },
          { id: "today", label: "Today" },
          { id: "upcoming", label: "Upcoming" },
          { id: "completed", label: "Completed" }
        ].map(f => (
          <motion.button key={f.id} onClick={() => setFilter(f.id)} whileTap={{ scale: 0.95 }} className={`flex-1 py-2 px-3 rounded-md text-sm ${filter === f.id ? "bg-violet-500 text-white" : "text-slate-400"}`}>
            {f.label}
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Reminder Bell
function ReminderBellEffect() {
  const [active, setActive] = useState(true);
  return (
    <EffectCard title="Reminder Toggle" description="Task notification setting" whenToUse="Reminders, notifications.">
      <motion.button onClick={() => setActive(!active)} whileTap={{ scale: 0.9 }} className={`flex items-center gap-3 px-4 py-2 rounded-lg ${active ? "bg-violet-500/20 text-violet-400" : "bg-slate-800 text-slate-500"}`}>
        <motion.div animate={active ? { rotate: [0, -10, 10, -10, 10, 0] } : {}} transition={{ duration: 0.5 }}>
          <Bell className="w-5 h-5" />
        </motion.div>
        <span>{active ? "Reminder set for 9:00 AM" : "No reminder"}</span>
      </motion.button>
    </EffectCard>
  );
}

// Eisenhower Matrix
function EisenhowerMatrixEffect() {
  return (
    <EffectCard title="Priority Matrix" description="Eisenhower decision grid" whenToUse="Task prioritization, planning.">
      <div className="grid grid-cols-2 gap-2 w-full text-xs">
        <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
          <p className="text-red-400 font-medium mb-1">Do First</p>
          <p className="text-slate-500">Urgent + Important</p>
        </div>
        <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg">
          <p className="text-amber-400 font-medium mb-1">Schedule</p>
          <p className="text-slate-500">Not Urgent + Important</p>
        </div>
        <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg">
          <p className="text-blue-400 font-medium mb-1">Delegate</p>
          <p className="text-slate-500">Urgent + Not Important</p>
        </div>
        <div className="p-3 bg-slate-500/10 border border-slate-500/30 rounded-lg">
          <p className="text-slate-400 font-medium mb-1">Eliminate</p>
          <p className="text-slate-500">Not Urgent + Not Important</p>
        </div>
      </div>
    </EffectCard>
  );
}

// Habit Tracker Grid
function HabitTrackerEffect() {
  const [checked, setChecked] = useState([true, true, false, true, true, true, false]);
  return (
    <EffectCard title="Habit Tracker" description="Weekly habit grid" whenToUse="Habit tracking, streaks.">
      <div className="w-full">
        <div className="flex items-center justify-between mb-3">
          <span className="text-white font-medium">Exercise</span>
          <span className="text-violet-400 text-sm">5/7 days</span>
        </div>
        <div className="flex gap-2">
          {["M", "T", "W", "T", "F", "S", "S"].map((day, i) => (
            <motion.button key={i} onClick={() => setChecked(c => c.map((v, j) => j === i ? !v : v))} whileTap={{ scale: 0.9 }} className={`flex-1 aspect-square rounded-lg flex flex-col items-center justify-center ${checked[i] ? "bg-green-500" : "bg-slate-800"}`}>
              <span className={`text-xs ${checked[i] ? "text-white" : "text-slate-500"}`}>{day}</span>
              {checked[i] && <span className="text-white text-lg">✓</span>}
            </motion.button>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Task Archive
function TaskArchiveEffect() {
  return (
    <EffectCard title="Task Archive" description="Completed tasks section" whenToUse="Task history, completed view.">
      <div className="space-y-2 w-full">
        <div className="flex items-center gap-2 text-slate-500 mb-2">
          <Archive className="w-4 h-4" />
          <span className="text-sm">Completed today (3)</span>
        </div>
        {["Review PRs", "Update docs", "Team sync"].map((task, i) => (
          <motion.div key={i} whileHover={{ x: 2 }} className="flex items-center gap-3 p-2 bg-slate-800/50 rounded-lg opacity-60">
            <div className="w-4 h-4 rounded-full bg-green-500 flex items-center justify-center">
              <svg className="w-2.5 h-2.5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M5 12l5 5 9-9"/></svg>
            </div>
            <span className="text-slate-500 line-through text-sm">{task}</span>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Note Input
function NoteInputEffect() {
  return (
    <EffectCard title="Note Input" description="Quick note capture" whenToUse="Note-taking, journaling.">
      <div className="w-full">
        <textarea placeholder="Capture your thoughts..." className="w-full h-24 p-3 bg-slate-800 rounded-lg text-white resize-none outline-none focus:ring-2 ring-violet-500 text-sm" />
        <div className="flex justify-between mt-2">
          <div className="flex gap-1">
            <button className="p-2 hover:bg-slate-700 rounded"><Tag className="w-4 h-4 text-slate-400" /></button>
            <button className="p-2 hover:bg-slate-700 rounded"><Clock className="w-4 h-4 text-slate-400" /></button>
          </div>
          <button className="px-4 py-1.5 bg-violet-500 rounded-lg text-white text-sm">Save</button>
        </div>
      </div>
    </EffectCard>
  );
}

// Timer Countdown
function TimerCountdownEffect() {
  const [seconds, setSeconds] = useState(300);
  const [running, setRunning] = useState(false);
  useEffect(() => {
    if (running && seconds > 0) {
      const interval = setInterval(() => setSeconds(s => s - 1), 1000);
      return () => clearInterval(interval);
    }
  }, [running, seconds]);
  return (
    <EffectCard title="Timer Countdown" description="Simple countdown timer" whenToUse="Time boxing, breaks, deadlines.">
      <div className="text-center">
        <div className="text-4xl font-mono font-bold text-white mb-4">
          {Math.floor(seconds / 60).toString().padStart(2, "0")}:{(seconds % 60).toString().padStart(2, "0")}
        </div>
        <div className="flex gap-2 justify-center">
          <button onClick={() => setRunning(!running)} className={`px-4 py-2 rounded-lg ${running ? "bg-red-500" : "bg-green-500"} text-white text-sm`}>
            {running ? "Pause" : "Start"}
          </button>
          <button onClick={() => { setSeconds(300); setRunning(false); }} className="px-4 py-2 bg-slate-700 rounded-lg text-white text-sm">Reset</button>
        </div>
      </div>
    </EffectCard>
  );
}

// Daily Review
function DailyReviewEffect() {
  return (
    <EffectCard title="Daily Review" description="End of day summary" whenToUse="Daily reflection, reviews.">
      <div className="w-full bg-slate-800 rounded-xl p-4 space-y-3">
        <h4 className="text-white font-medium flex items-center gap-2"><span className="text-amber-400">⭐</span> Daily Review</h4>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-slate-400">Tasks completed</span>
            <span className="text-green-400">8/10</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-slate-400">Focus time</span>
            <span className="text-violet-400">4h 32m</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-slate-400">Meetings</span>
            <span className="text-cyan-400">3</span>
          </div>
        </div>
        <div className="pt-2 border-t border-slate-700">
          <p className="text-slate-500 text-xs">Great day! 🎉 You're 20% more productive than yesterday.</p>
        </div>
      </div>
    </EffectCard>
  );
}

export default function ProductivityEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <TodoItemEffect />, name: "Todo Item" },
    { component: <KanbanCardEffect />, name: "Kanban Card" },
    { component: <PomodoroTimerEffect />, name: "Pomodoro Timer" },
    { component: <ProgressTrackerEffect />, name: "Progress Tracker" },
    { component: <PrioritySelectorEffect />, name: "Priority Selector" },
    { component: <DueDatePickerEffect />, name: "Due Date Picker" },
    { component: <StreakCounterEffect />, name: "Streak Counter" },
    { component: <SubtaskListEffect />, name: "Subtask List" },
    { component: <TimeEstimateEffect />, name: "Time Estimate" },
    { component: <PlannerSlotEffect />, name: "Daily Planner" },
    { component: <QuickAddEffect />, name: "Quick Add Task" },
    { component: <ProjectProgressEffect />, name: "Project Progress" },
    { component: <LabelPickerEffect />, name: "Label Picker" },
    { component: <AssigneeSelectorEffect />, name: "Assignee Selector" },
    { component: <RecurringTaskEffect />, name: "Recurring Task" },
    { component: <FocusModeEffect />, name: "Focus Mode" },
    { component: <TaskFilterEffect />, name: "Task Filters" },
    { component: <ReminderBellEffect />, name: "Reminder Toggle" },
    { component: <EisenhowerMatrixEffect />, name: "Priority Matrix" },
    { component: <HabitTrackerEffect />, name: "Habit Tracker" },
    { component: <TaskArchiveEffect />, name: "Task Archive" },
    { component: <NoteInputEffect />, name: "Note Input" },
    { component: <TimerCountdownEffect />, name: "Timer Countdown" },
    { component: <DailyReviewEffect />, name: "Daily Review" },
  ];

  const filtered = effects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={CheckSquare} title="Productivity & Tasks" description="25 components for task management, habits, and getting things done" gradient="#22c55e, #10b981" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((effect, i) => <motion.div key={effect.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>{effect.component}</motion.div>)}
        </div>
      </div>
    </div>
  );
}