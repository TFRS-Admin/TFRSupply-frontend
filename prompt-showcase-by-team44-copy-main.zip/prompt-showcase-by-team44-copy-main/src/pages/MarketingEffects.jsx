import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Megaphone, Star, Zap, Gift, Trophy, Timer, ArrowRight, Check, X, Mail, Users, TrendingUp, Sparkles, Crown, Rocket, Target, Award, Heart } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// Hero Banner
function HeroBannerEffect() {
  return (
    <EffectCard title="Hero Banner" description="Full-width promotional header" whenToUse="Landing pages, product launches, announcements.">
      <div className="w-full bg-gradient-to-r from-violet-600 to-cyan-600 rounded-xl p-6 text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "radial-gradient(circle at 2px 2px, white 1px, transparent 0)", backgroundSize: "20px 20px" }} />
        <h2 className="text-white text-xl font-bold mb-2 relative">Launch Your Business Today</h2>
        <p className="text-white/80 text-sm mb-4 relative">Get started with our premium features</p>
        <button className="px-6 py-2 bg-white text-violet-600 rounded-lg font-semibold text-sm relative">Get Started Free</button>
      </div>
    </EffectCard>
  );
}

// Testimonial Card
function TestimonialCardEffect() {
  return (
    <EffectCard title="Testimonial Card" description="Customer review display" whenToUse="Social proof, reviews, customer stories.">
      <div className="bg-slate-800 rounded-xl p-4">
        <div className="flex gap-1 mb-3">{[1,2,3,4,5].map(i => <Star key={i} className="w-4 h-4 text-amber-400 fill-amber-400" />)}</div>
        <p className="text-slate-300 text-sm italic mb-4">"This product completely transformed our workflow. Highly recommended!"</p>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-pink-500 to-violet-500" />
          <div>
            <p className="text-white text-sm font-medium">Sarah Johnson</p>
            <p className="text-slate-500 text-xs">CEO, TechCorp</p>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Pricing Card
function PricingCardEffect() {
  const [annual, setAnnual] = useState(true);
  return (
    <EffectCard title="Pricing Card" description="Subscription plan display" whenToUse="Pricing pages, plan comparison, upgrades.">
      <div className="bg-slate-800 rounded-xl p-4 border-2 border-violet-500">
        <span className="px-2 py-0.5 bg-violet-500 text-white text-xs rounded-full">Most Popular</span>
        <h3 className="text-white text-xl font-bold mt-2">Pro Plan</h3>
        <div className="my-3">
          <span className="text-3xl font-bold text-white">${annual ? "29" : "39"}</span>
          <span className="text-slate-400 text-sm">/month</span>
        </div>
        <ul className="space-y-2 mb-4">
          {["Unlimited projects", "Priority support", "Advanced analytics"].map(f => (
            <li key={f} className="flex items-center gap-2 text-sm text-slate-300">
              <Check className="w-4 h-4 text-green-400" /> {f}
            </li>
          ))}
        </ul>
        <button className="w-full py-2 bg-violet-500 rounded-lg text-white font-medium">Subscribe Now</button>
      </div>
    </EffectCard>
  );
}

// Countdown Timer
function CountdownTimerEffect() {
  const [time, setTime] = useState({ d: 2, h: 14, m: 32, s: 45 });
  useEffect(() => {
    const interval = setInterval(() => {
      setTime(t => {
        let { d, h, m, s } = t;
        s--; if (s < 0) { s = 59; m--; } if (m < 0) { m = 59; h--; } if (h < 0) { h = 23; d--; }
        return { d, h, m, s };
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);
  return (
    <EffectCard title="Countdown Timer" description="Urgency-driven timer" whenToUse="Flash sales, launches, limited offers.">
      <div className="text-center">
        <p className="text-amber-400 text-sm mb-2 flex items-center justify-center gap-1"><Timer className="w-4 h-4" /> Offer ends in</p>
        <div className="flex gap-2 justify-center">
          {Object.entries(time).map(([k, v]) => (
            <div key={k} className="bg-slate-800 rounded-lg p-3 min-w-[50px]">
              <motion.span key={v} initial={{ y: -10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="text-2xl font-bold text-white block">{String(v).padStart(2, "0")}</motion.span>
              <span className="text-xs text-slate-500 uppercase">{k === "d" ? "Days" : k === "h" ? "Hrs" : k === "m" ? "Min" : "Sec"}</span>
            </div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// CTA Button
function CTAButtonEffect() {
  return (
    <EffectCard title="CTA Button" description="Attention-grabbing call to action" whenToUse="Sign-ups, purchases, conversions.">
      <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="relative px-8 py-3 bg-gradient-to-r from-violet-500 to-pink-500 rounded-xl text-white font-bold overflow-hidden group">
        <span className="relative z-10 flex items-center gap-2">Start Free Trial <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" /></span>
        <motion.div className="absolute inset-0 bg-white/20" initial={{ x: "-100%" }} whileHover={{ x: "100%" }} transition={{ duration: 0.5 }} />
      </motion.button>
    </EffectCard>
  );
}

// Email Capture
function EmailCaptureEffect() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  return (
    <EffectCard title="Email Capture" description="Newsletter subscription form" whenToUse="Lead generation, newsletters, updates.">
      <div className="w-full">
        {!submitted ? (
          <div className="flex gap-2">
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Enter your email" className="flex-1 px-4 py-2 bg-slate-800 rounded-lg text-white text-sm border border-slate-700 focus:border-violet-500 outline-none" />
            <motion.button whileTap={{ scale: 0.95 }} onClick={() => setSubmitted(true)} className="px-4 py-2 bg-violet-500 rounded-lg text-white text-sm font-medium">Subscribe</motion.button>
          </div>
        ) : (
          <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center gap-2 text-green-400">
            <Check className="w-5 h-5" /> Thanks for subscribing!
          </motion.div>
        )}
      </div>
    </EffectCard>
  );
}

// Social Proof Counter
function SocialProofEffect() {
  return (
    <EffectCard title="Social Proof Counter" description="Trust-building numbers" whenToUse="Landing pages, about sections, credibility.">
      <div className="flex gap-6 justify-center">
        {[
          { value: "10K+", label: "Users", icon: Users },
          { value: "4.9", label: "Rating", icon: Star },
          { value: "99%", label: "Uptime", icon: TrendingUp }
        ].map(stat => (
          <div key={stat.label} className="text-center">
            <stat.icon className="w-5 h-5 text-violet-400 mx-auto mb-1" />
            <p className="text-2xl font-bold text-white">{stat.value}</p>
            <p className="text-xs text-slate-400">{stat.label}</p>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Feature Badge
function FeatureBadgeEffect() {
  return (
    <EffectCard title="Feature Badges" description="Highlight selling points" whenToUse="Product features, USPs, benefits.">
      <div className="flex flex-wrap gap-2 justify-center">
        {[
          { icon: Zap, label: "Lightning Fast", color: "amber" },
          { icon: Shield, label: "Secure", color: "green" },
          { icon: Sparkles, label: "AI Powered", color: "violet" }
        ].map(b => (
          <motion.div key={b.label} whileHover={{ y: -2 }} className={`flex items-center gap-2 px-3 py-2 bg-${b.color}-500/20 rounded-lg`}>
            <b.icon className={`w-4 h-4 text-${b.color}-400`} />
            <span className={`text-sm text-${b.color}-400`}>{b.label}</span>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

const Shield = ({ className }) => <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>;

// Popup Banner
function PopupBannerEffect() {
  const [show, setShow] = useState(false);
  return (
    <EffectCard title="Popup Banner" description="Promotional overlay" whenToUse="Special offers, announcements, lead capture.">
      <button onClick={() => setShow(true)} className="px-4 py-2 bg-violet-500 rounded-lg text-white text-sm">Show Popup</button>
      <AnimatePresence>
        {show && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={() => setShow(false)}>
            <motion.div initial={{ scale: 0.8 }} animate={{ scale: 1 }} exit={{ scale: 0.8 }} onClick={e => e.stopPropagation()} className="bg-gradient-to-br from-violet-600 to-pink-600 rounded-2xl p-6 max-w-sm text-center relative">
              <button onClick={() => setShow(false)} className="absolute top-2 right-2 p-1 bg-white/20 rounded-full"><X className="w-4 h-4 text-white" /></button>
              <Gift className="w-12 h-12 text-white mx-auto mb-3" />
              <h3 className="text-white text-xl font-bold mb-2">Special Offer!</h3>
              <p className="text-white/80 text-sm mb-4">Get 50% off your first month</p>
              <button className="w-full py-2 bg-white text-violet-600 rounded-lg font-semibold">Claim Now</button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </EffectCard>
  );
}

// Trust Logos
function TrustLogosEffect() {
  return (
    <EffectCard title="Trust Logos" description="Partner/client logos display" whenToUse="Social proof, partnerships, credibility.">
      <div className="text-center">
        <p className="text-slate-500 text-xs mb-3">Trusted by leading companies</p>
        <div className="flex gap-4 justify-center opacity-50">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="w-16 h-8 bg-slate-600 rounded flex items-center justify-center text-slate-400 text-xs">Logo</div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Announcement Bar
function AnnouncementBarEffect() {
  return (
    <EffectCard title="Announcement Bar" description="Top page notification strip" whenToUse="Promotions, updates, shipping info.">
      <div className="w-full bg-gradient-to-r from-amber-500 to-orange-500 py-2 px-4 flex items-center justify-center gap-2 rounded-lg">
        <Megaphone className="w-4 h-4 text-white" />
        <span className="text-white text-sm font-medium">🎉 New feature launch! Check out our latest update</span>
        <button className="text-white/80 hover:text-white text-sm underline">Learn more</button>
      </div>
    </EffectCard>
  );
}

// Comparison Table
function ComparisonTableEffect() {
  return (
    <EffectCard title="Comparison Table" description="Feature comparison grid" whenToUse="Pricing, product comparison, plans.">
      <div className="w-full text-xs overflow-hidden">
        <div className="grid grid-cols-4 gap-2 mb-2">
          <div></div>
          <div className="text-center text-slate-400">Free</div>
          <div className="text-center text-violet-400 font-medium">Pro</div>
          <div className="text-center text-slate-400">Team</div>
        </div>
        {["Storage", "Users", "Support"].map(f => (
          <div key={f} className="grid grid-cols-4 gap-2 py-2 border-t border-slate-800">
            <div className="text-slate-400">{f}</div>
            <div className="text-center text-slate-400">1GB</div>
            <div className="text-center text-white">10GB</div>
            <div className="text-center text-white">Unlimited</div>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Before/After Slider
function BeforeAfterEffect() {
  const [pos, setPos] = useState(50);
  return (
    <EffectCard title="Before/After Slider" description="Comparison visualization" whenToUse="Product demos, transformations, results.">
      <div className="relative w-full h-32 rounded-lg overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-slate-700 to-slate-600" />
        <div className="absolute inset-0 bg-gradient-to-r from-violet-500 to-cyan-500" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }} />
        <input type="range" min="0" max="100" value={pos} onChange={e => setPos(e.target.value)} className="absolute inset-0 w-full opacity-0 cursor-ew-resize" />
        <div className="absolute top-0 bottom-0 w-1 bg-white" style={{ left: `${pos}%` }}>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 bg-white rounded-full flex items-center justify-center">
            <span className="text-slate-900 text-xs">⇔</span>
          </div>
        </div>
        <span className="absolute left-2 top-2 text-white text-xs bg-black/50 px-2 py-0.5 rounded">Before</span>
        <span className="absolute right-2 top-2 text-white text-xs bg-black/50 px-2 py-0.5 rounded">After</span>
      </div>
    </EffectCard>
  );
}

// Gamification Badge
function GamificationBadgeEffect() {
  return (
    <EffectCard title="Gamification Badges" description="Achievement and reward icons" whenToUse="User achievements, rewards, loyalty programs.">
      <div className="flex gap-3 justify-center">
        {[
          { icon: Trophy, color: "amber", label: "Top User" },
          { icon: Crown, color: "violet", label: "Premium" },
          { icon: Award, color: "cyan", label: "Verified" }
        ].map(b => (
          <motion.div key={b.label} whileHover={{ scale: 1.1, rotate: 5 }} className="text-center">
            <div className={`w-14 h-14 rounded-full bg-${b.color}-500/20 flex items-center justify-center mb-1`}>
              <b.icon className={`w-7 h-7 text-${b.color}-400`} />
            </div>
            <span className="text-xs text-slate-400">{b.label}</span>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Exit Intent Popup (simulated)
function ExitIntentEffect() {
  const [show, setShow] = useState(false);
  return (
    <EffectCard title="Exit Intent" description="Leaving-page offer popup" whenToUse="Cart abandonment, exit offers, retention.">
      <button onClick={() => setShow(true)} className="px-4 py-2 bg-red-500 rounded-lg text-white text-sm">Simulate Exit</button>
      <AnimatePresence>
        {show && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={() => setShow(false)}>
            <motion.div initial={{ y: -50 }} animate={{ y: 0 }} exit={{ y: -50 }} onClick={e => e.stopPropagation()} className="bg-slate-800 rounded-2xl p-6 max-w-sm text-center border border-slate-700">
              <Heart className="w-10 h-10 text-red-400 mx-auto mb-3" />
              <h3 className="text-white text-lg font-bold mb-2">Wait! Don't leave yet</h3>
              <p className="text-slate-400 text-sm mb-4">Get 15% off if you complete your order now</p>
              <div className="flex gap-2">
                <button onClick={() => setShow(false)} className="flex-1 py-2 bg-slate-700 rounded-lg text-slate-300 text-sm">No thanks</button>
                <button className="flex-1 py-2 bg-violet-500 rounded-lg text-white text-sm font-medium">Get 15% Off</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </EffectCard>
  );
}

// Progress Steps
function ProgressStepsEffect() {
  const [step, setStep] = useState(2);
  return (
    <EffectCard title="Progress Steps" description="Multi-step process indicator" whenToUse="Onboarding, checkout, forms.">
      <div className="w-full px-4">
        <div className="flex items-center justify-between mb-2">
          {["Sign Up", "Details", "Confirm", "Done"].map((s, i) => (
            <React.Fragment key={s}>
              <motion.div animate={{ scale: i <= step ? 1 : 0.9 }} className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${i < step ? "bg-green-500 text-white" : i === step ? "bg-violet-500 text-white" : "bg-slate-700 text-slate-400"}`}>
                {i < step ? <Check className="w-4 h-4" /> : i + 1}
              </motion.div>
              {i < 3 && <div className={`flex-1 h-1 mx-2 rounded ${i < step ? "bg-green-500" : "bg-slate-700"}`} />}
            </React.Fragment>
          ))}
        </div>
        <button onClick={() => setStep((step + 1) % 4)} className="text-xs text-violet-400 hover:underline">Next Step</button>
      </div>
    </EffectCard>
  );
}

// Floating Action Bubble
function FloatingBubbleEffect() {
  return (
    <EffectCard title="Floating Bubble" description="Persistent action button" whenToUse="Chat support, quick actions, help.">
      <motion.button animate={{ y: [0, -5, 0] }} transition={{ duration: 2, repeat: Infinity }} className="w-14 h-14 bg-gradient-to-br from-violet-500 to-pink-500 rounded-full flex items-center justify-center shadow-lg shadow-violet-500/30">
        <Mail className="w-6 h-6 text-white" />
      </motion.button>
    </EffectCard>
  );
}

// Limited Stock Alert
function LimitedStockEffect() {
  return (
    <EffectCard title="Limited Stock Alert" description="Scarcity indicator" whenToUse="E-commerce, limited offers, FOMO.">
      <motion.div animate={{ scale: [1, 1.02, 1] }} transition={{ duration: 1, repeat: Infinity }} className="flex items-center gap-2 px-4 py-2 bg-red-500/20 border border-red-500/30 rounded-lg">
        <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
        <span className="text-red-400 text-sm font-medium">Only 3 left in stock!</span>
      </motion.div>
    </EffectCard>
  );
}

// Referral Banner
function ReferralBannerEffect() {
  return (
    <EffectCard title="Referral Banner" description="Invite friends promotion" whenToUse="Growth, referral programs, viral loops.">
      <div className="bg-gradient-to-r from-violet-500/20 to-pink-500/20 border border-violet-500/30 rounded-xl p-4 flex items-center gap-4">
        <div className="w-12 h-12 bg-violet-500/30 rounded-full flex items-center justify-center">
          <Gift className="w-6 h-6 text-violet-400" />
        </div>
        <div className="flex-1">
          <h4 className="text-white font-medium text-sm">Invite friends, get $10</h4>
          <p className="text-slate-400 text-xs">Share your link and earn rewards</p>
        </div>
        <button className="px-3 py-1.5 bg-violet-500 rounded-lg text-white text-xs">Invite</button>
      </div>
    </EffectCard>
  );
}

// Product Hunt Badge
function ProductHuntBadgeEffect() {
  return (
    <EffectCard title="Launch Badge" description="Product launch recognition" whenToUse="Product launches, awards, rankings.">
      <motion.div whileHover={{ rotate: 5 }} className="bg-slate-800 rounded-xl p-4 flex items-center gap-3 border border-slate-700">
        <div className="w-12 h-12 bg-orange-500 rounded-lg flex items-center justify-center">
          <Rocket className="w-6 h-6 text-white" />
        </div>
        <div>
          <p className="text-orange-400 text-xs font-medium">PRODUCT OF THE DAY</p>
          <p className="text-white font-bold">#1</p>
          <p className="text-slate-500 text-xs">December 2024</p>
        </div>
      </motion.div>
    </EffectCard>
  );
}

// Discount Code Copy
function DiscountCodeEffect() {
  const [copied, setCopied] = useState(false);
  return (
    <EffectCard title="Discount Code" description="Copyable promo code" whenToUse="Promotions, coupons, special offers.">
      <div className="flex items-center gap-2 bg-slate-800 rounded-lg p-2">
        <span className="flex-1 text-center font-mono text-lg text-white tracking-wider">SAVE20</span>
        <button onClick={() => { navigator.clipboard.writeText("SAVE20"); setCopied(true); setTimeout(() => setCopied(false), 1500); }} className={`px-3 py-1.5 rounded-lg text-sm ${copied ? "bg-green-500 text-white" : "bg-violet-500 text-white"}`}>
          {copied ? "Copied!" : "Copy"}
        </button>
      </div>
    </EffectCard>
  );
}

// Satisfaction Guarantee
function GuaranteeBadgeEffect() {
  return (
    <EffectCard title="Guarantee Badge" description="Trust-building guarantee" whenToUse="Checkout, product pages, trust signals.">
      <div className="flex items-center gap-4 justify-center">
        <motion.div whileHover={{ rotate: -5 }} className="text-center">
          <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-1">
            <Check className="w-8 h-8 text-green-400" />
          </div>
          <span className="text-xs text-slate-400">30-Day<br/>Money Back</span>
        </motion.div>
        <motion.div whileHover={{ rotate: 5 }} className="text-center">
          <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-1">
            <Target className="w-8 h-8 text-blue-400" />
          </div>
          <span className="text-xs text-slate-400">100%<br/>Satisfaction</span>
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Sticky Promo Bar
function StickyPromoEffect() {
  return (
    <EffectCard title="Sticky Promo Bar" description="Fixed bottom promotional bar" whenToUse="Sales, limited offers, cart reminders.">
      <div className="w-full bg-slate-800 border-t border-violet-500 py-3 px-4 flex items-center justify-between rounded-lg">
        <span className="text-white text-sm">🔥 Flash Sale: <span className="text-violet-400 font-bold">25% OFF</span> everything</span>
        <button className="px-3 py-1 bg-violet-500 rounded text-white text-xs font-medium">Shop Now</button>
      </div>
    </EffectCard>
  );
}

// Video Testimonial Placeholder
function VideoTestimonialEffect() {
  return (
    <EffectCard title="Video Testimonial" description="Customer video review" whenToUse="Social proof, case studies, reviews.">
      <div className="relative w-full h-32 bg-slate-800 rounded-xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-violet-500/20 to-pink-500/20" />
        <motion.div whileHover={{ scale: 1.1 }} className="absolute inset-0 flex items-center justify-center cursor-pointer">
          <div className="w-12 h-12 bg-white/90 rounded-full flex items-center justify-center">
            <div className="w-0 h-0 border-t-6 border-b-6 border-l-8 border-transparent border-l-violet-600 ml-1" />
          </div>
        </motion.div>
        <div className="absolute bottom-2 left-2 text-white text-xs">2:45</div>
      </div>
    </EffectCard>
  );
}

// Affiliate Link Card
function AffiliateLinkEffect() {
  const [copied, setCopied] = useState(false);
  return (
    <EffectCard title="Affiliate Link" description="Referral tracking link" whenToUse="Affiliate programs, partner marketing, tracking.">
      <div className="bg-slate-800 rounded-xl p-4 space-y-3">
        <p className="text-slate-400 text-xs">Your affiliate link:</p>
        <div className="flex gap-2">
          <div className="flex-1 bg-slate-900 rounded px-3 py-2 font-mono text-xs text-violet-400 truncate">app.com/ref/ABC123</div>
          <button onClick={() => { navigator.clipboard.writeText("app.com/ref/ABC123"); setCopied(true); setTimeout(() => setCopied(false), 1500); }} className={`px-3 py-2 rounded text-xs font-medium ${copied ? "bg-green-500 text-white" : "bg-violet-500 text-white"}`}>
            {copied ? "✓" : "Copy"}
          </button>
        </div>
        <div className="flex justify-between text-xs">
          <span className="text-slate-500">Clicks: <span className="text-white">247</span></span>
          <span className="text-slate-500">Revenue: <span className="text-green-400">$1,247</span></span>
        </div>
      </div>
    </EffectCard>
  );
}

// Crypto Wallet Connect
function CryptoWalletEffect() {
  const [connected, setConnected] = useState(false);
  return (
    <EffectCard title="Crypto Wallet Connect" description="Web3 wallet integration" whenToUse="NFT mints, crypto payments, DeFi apps.">
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => setConnected(!connected)}
        className={`w-full py-3 rounded-xl font-medium flex items-center justify-center gap-2 ${connected ? "bg-green-500/20 border-2 border-green-500 text-green-400" : "bg-gradient-to-r from-orange-500 to-amber-500 text-white"}`}
      >
        {connected ? (
          <>
            <Check className="w-5 h-5" />
            <span>Wallet Connected</span>
          </>
        ) : (
          <>
            <span>₿</span>
            <span>Connect Wallet</span>
          </>
        )}
      </motion.button>
    </EffectCard>
  );
}

// Token Price Ticker
function TokenPriceEffect() {
  const [price, setPrice] = useState(42567.89);
  useEffect(() => {
    const interval = setInterval(() => {
      setPrice(p => p + (Math.random() - 0.5) * 100);
    }, 2000);
    return () => clearInterval(interval);
  }, []);
  return (
    <EffectCard title="Crypto Price Ticker" description="Live token price display" whenToUse="Crypto marketing, trading apps, DeFi.">
      <div className="bg-slate-800 rounded-xl p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold">₿</div>
          <div>
            <p className="text-white font-medium text-sm">Bitcoin</p>
            <p className="text-slate-500 text-xs">BTC</p>
          </div>
        </div>
        <div className="text-right">
          <motion.p key={Math.floor(price)} initial={{ y: -10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="text-white font-bold">${price.toFixed(2)}</motion.p>
          <p className="text-green-400 text-xs">+2.4% 24h</p>
        </div>
      </div>
    </EffectCard>
  );
}

// NFT Mint Card
function NFTMintEffect() {
  return (
    <EffectCard title="NFT Mint Card" description="NFT collection minting UI" whenToUse="NFT launches, Web3 marketing, digital art.">
      <div className="bg-slate-800 rounded-xl overflow-hidden">
        <div className="w-full h-32 bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
          <span className="text-white text-4xl">🎨</span>
        </div>
        <div className="p-4">
          <h4 className="text-white font-bold text-sm mb-1">Cool Apes NFT</h4>
          <div className="flex justify-between text-xs mb-3">
            <span className="text-slate-400">Price: <span className="text-white">0.05 ETH</span></span>
            <span className="text-slate-400">Supply: <span className="text-violet-400">2,347/10,000</span></span>
          </div>
          <button className="w-full py-2 bg-gradient-to-r from-violet-500 to-pink-500 rounded-lg text-white text-sm font-medium">Mint Now</button>
        </div>
      </div>
    </EffectCard>
  );
}

// Influencer Collab Banner
function InfluencerCollabEffect() {
  return (
    <EffectCard title="Influencer Collab" description="Partnership announcement" whenToUse="Influencer marketing, partnerships, brand deals.">
      <div className="bg-gradient-to-r from-pink-500/20 to-purple-500/20 border border-pink-500/30 rounded-xl p-4 flex items-center gap-3">
        <div className="flex -space-x-2">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-pink-500 to-rose-500 border-2 border-slate-900" />
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-violet-500 border-2 border-slate-900" />
        </div>
        <div className="flex-1">
          <p className="text-white text-sm font-bold">Collab with @InfluencerName</p>
          <p className="text-slate-400 text-xs">Limited edition drop</p>
        </div>
        <Crown className="w-5 h-5 text-amber-400" />
      </div>
    </EffectCard>
  );
}

// Conversion Rate Widget
function ConversionRateEffect() {
  return (
    <EffectCard title="Conversion Rate" description="Live stats display" whenToUse="Dashboards, analytics, performance marketing.">
      <div className="bg-slate-800 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-slate-400 text-sm">Conversion Rate</span>
          <span className="text-green-400 text-xs flex items-center gap-1">
            <TrendingUp className="w-3 h-3" /> +12%
          </span>
        </div>
        <div className="flex items-end gap-1">
          <span className="text-3xl font-bold text-white">4.7</span>
          <span className="text-slate-500 text-lg mb-0.5">%</span>
        </div>
        <div className="w-full bg-slate-700 rounded-full h-2 mt-3 overflow-hidden">
          <motion.div initial={{ width: 0 }} animate={{ width: "47%" }} className="h-full bg-gradient-to-r from-violet-500 to-cyan-500" />
        </div>
      </div>
    </EffectCard>
  );
}

// Urgency Timer Banner
function UrgencyBannerEffect() {
  const [seconds, setSeconds] = useState(3599);
  useEffect(() => {
    const interval = setInterval(() => setSeconds(s => s > 0 ? s - 1 : 0), 1000);
    return () => clearInterval(interval);
  }, []);
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return (
    <EffectCard title="Urgency Timer" description="Time-sensitive offer banner" whenToUse="Flash sales, limited deals, urgency marketing.">
      <div className="bg-gradient-to-r from-red-500 to-orange-500 rounded-xl p-4 text-center">
        <p className="text-white text-xs font-bold mb-2">⚡ FLASH SALE ENDS IN</p>
        <div className="flex gap-2 justify-center">
          {[{ v: h, l: "H" }, { v: m, l: "M" }, { v: s, l: "S" }].map((t, i) => (
            <div key={i} className="bg-black/30 rounded px-2 py-1 min-w-[40px]">
              <span className="text-white text-lg font-mono font-bold">{String(t.v).padStart(2, "0")}</span>
              <span className="text-white/60 text-xs block">{t.l}</span>
            </div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Waitlist Counter
function WaitlistEffect() {
  return (
    <EffectCard title="Waitlist Counter" description="Pre-launch signup tracker" whenToUse="Product launches, waitlists, early access.">
      <div className="bg-slate-800 rounded-xl p-4 text-center">
        <Users className="w-8 h-8 text-violet-400 mx-auto mb-2" />
        <p className="text-2xl font-bold text-white mb-1">12,847</p>
        <p className="text-slate-400 text-xs mb-3">people on the waitlist</p>
        <button className="w-full py-2 bg-violet-500 rounded-lg text-white text-sm font-medium">Join Waitlist</button>
      </div>
    </EffectCard>
  );
}

// Live Sales Notification
function LiveSalesEffect() {
  return (
    <EffectCard title="Live Sales Popup" description="Real-time purchase notifications" whenToUse="E-commerce, FOMO, social proof.">
      <motion.div initial={{ x: -300 }} animate={{ x: 0 }} className="bg-slate-800 border border-slate-700 rounded-xl p-3 flex items-center gap-3 shadow-lg">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-400 to-emerald-500" />
        <div className="flex-1">
          <p className="text-white text-sm font-medium">John just purchased</p>
          <p className="text-slate-400 text-xs">Pro Plan - 2 min ago</p>
        </div>
        <Check className="w-4 h-4 text-green-400" />
      </motion.div>
    </EffectCard>
  );
}

// Milestone Banner
function MilestoneBannerEffect() {
  return (
    <EffectCard title="Milestone Banner" description="Achievement celebration" whenToUse="Growth milestones, anniversaries, achievements.">
      <div className="bg-gradient-to-r from-violet-600 to-fuchsia-600 rounded-xl p-4 text-center relative overflow-hidden">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 20, repeat: Infinity, ease: "linear" }} className="absolute top-2 right-2 text-2xl">✨</motion.div>
        <Trophy className="w-10 h-10 text-amber-300 mx-auto mb-2" />
        <p className="text-white text-lg font-bold">100K Users Milestone!</p>
        <p className="text-white/80 text-xs">Thank you for your support 🎉</p>
      </div>
    </EffectCard>
  );
}

// A/B Test Variant Switcher
function ABTestVariantEffect() {
  const [variant, setVariant] = useState("A");
  return (
    <EffectCard title="A/B Test Variants" description="Marketing test variations" whenToUse="A/B testing, conversion optimization, experiments.">
      <div className="space-y-3">
        <div className="flex gap-2">
          <button onClick={() => setVariant("A")} className={`flex-1 py-2 rounded-lg text-sm ${variant === "A" ? "bg-violet-500 text-white" : "bg-slate-700 text-slate-400"}`}>Variant A</button>
          <button onClick={() => setVariant("B")} className={`flex-1 py-2 rounded-lg text-sm ${variant === "B" ? "bg-cyan-500 text-white" : "bg-slate-700 text-slate-400"}`}>Variant B</button>
        </div>
        <motion.div key={variant} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-slate-800 rounded-lg p-3 text-center">
          {variant === "A" ? (
            <button className="px-6 py-2 bg-violet-500 rounded text-white text-sm">Buy Now</button>
          ) : (
            <button className="px-6 py-2 bg-gradient-to-r from-green-500 to-emerald-500 rounded text-white text-sm">Get Started Free</button>
          )}
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Loyalty Points Display
function LoyaltyPointsEffect() {
  return (
    <EffectCard title="Loyalty Points" description="Rewards program display" whenToUse="Customer retention, gamification, rewards.">
      <div className="bg-gradient-to-br from-amber-500/20 to-orange-500/20 border border-amber-500/30 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
            <span className="text-white text-sm font-medium">Your Points</span>
          </div>
          <Crown className="w-5 h-5 text-amber-400" />
        </div>
        <p className="text-3xl font-bold text-white mb-1">2,847</p>
        <p className="text-slate-400 text-xs">153 points until next reward</p>
        <div className="w-full bg-slate-700 rounded-full h-2 mt-2 overflow-hidden">
          <div className="h-full bg-gradient-to-r from-amber-400 to-orange-400 w-[85%]" />
        </div>
      </div>
    </EffectCard>
  );
}

// Bundle Deal Card
function BundleDealEffect() {
  return (
    <EffectCard title="Bundle Deal" description="Multi-product package offer" whenToUse="Upsells, product bundles, package deals.">
      <div className="bg-slate-800 rounded-xl p-4 border-2 border-green-500/50">
        <span className="px-2 py-0.5 bg-green-500 text-white text-xs rounded-full">Save 40%</span>
        <h4 className="text-white font-bold mt-2 mb-1">Ultimate Bundle</h4>
        <div className="flex items-center gap-2 mb-3">
          <span className="text-2xl font-bold text-white">$99</span>
          <span className="text-slate-500 text-sm line-through">$165</span>
        </div>
        <div className="space-y-1 mb-3">
          {["Product A", "Product B", "Product C"].map(p => (
            <div key={p} className="flex items-center gap-2 text-xs text-slate-300">
              <Check className="w-3 h-3 text-green-400" /> {p}
            </div>
          ))}
        </div>
        <button className="w-full py-2 bg-green-500 rounded-lg text-white text-sm font-medium">Get Bundle</button>
      </div>
    </EffectCard>
  );
}

// Free Shipping Banner
function FreeShippingEffect() {
  return (
    <EffectCard title="Free Shipping Banner" description="Promotional shipping offer" whenToUse="E-commerce, cart, checkout pages.">
      <motion.div animate={{ scale: [1, 1.02, 1] }} transition={{ duration: 2, repeat: Infinity }} className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl p-3 flex items-center justify-center gap-2">
        <Zap className="w-5 h-5 text-white" />
        <span className="text-white text-sm font-bold">FREE SHIPPING on orders over $50</span>
      </motion.div>
    </EffectCard>
  );
}

// Member Exclusive Badge
function MemberExclusiveEffect() {
  return (
    <EffectCard title="Member Exclusive" description="VIP/member-only tag" whenToUse="Membership sites, premium content, exclusivity.">
      <div className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-500 to-pink-500 px-4 py-2 rounded-full">
        <Crown className="w-4 h-4 text-amber-300" />
        <span className="text-white text-sm font-bold">MEMBERS ONLY</span>
        <Sparkles className="w-4 h-4 text-amber-300" />
      </div>
    </EffectCard>
  );
}

// Money Back Guarantee
function MoneyBackEffect() {
  return (
    <EffectCard title="Money Back Seal" description="Risk-free guarantee badge" whenToUse="Trust building, checkout, product pages.">
      <motion.div whileHover={{ rotate: [0, -5, 5, 0] }} className="w-24 h-24 mx-auto bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center border-4 border-white shadow-xl relative">
        <div className="text-center">
          <p className="text-white text-xs font-bold leading-tight">30 DAY</p>
          <p className="text-white text-lg font-black leading-none">100%</p>
          <p className="text-white text-xs font-bold leading-tight">GUARANTEE</p>
        </div>
      </motion.div>
    </EffectCard>
  );
}

// Sticky Cart Reminder
function StickyCartEffect() {
  return (
    <EffectCard title="Sticky Cart Reminder" description="Persistent cart notification" whenToUse="E-commerce, cart abandonment, conversions.">
      <div className="bg-slate-800 border-t-2 border-violet-500 rounded-xl p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-violet-500/20 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold">3</span>
          </div>
          <div>
            <p className="text-white text-sm font-medium">Items in cart</p>
            <p className="text-slate-400 text-xs">Total: $247.00</p>
          </div>
        </div>
        <button className="px-4 py-2 bg-violet-500 rounded-lg text-white text-xs font-medium">Checkout</button>
      </div>
    </EffectCard>
  );
}

// Reward Unlock Animation
function RewardUnlockEffect() {
  const [unlocked, setUnlocked] = useState(false);
  return (
    <EffectCard title="Reward Unlock" description="Achievement unlock animation" whenToUse="Gamification, rewards, engagement.">
      <button onClick={() => setUnlocked(!unlocked)} className="px-4 py-2 bg-violet-500 rounded-lg text-white text-sm">Toggle Unlock</button>
      <AnimatePresence>
        {unlocked && (
          <motion.div initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }} exit={{ scale: 0, rotate: 180 }} className="mt-3 bg-gradient-to-br from-amber-500 to-orange-500 rounded-xl p-4 text-center">
            <motion.div animate={{ rotate: 360 }} transition={{ duration: 2, repeat: Infinity, ease: "linear" }}>
              <Trophy className="w-10 h-10 text-white mx-auto mb-2" />
            </motion.div>
            <p className="text-white font-bold text-sm">Achievement Unlocked!</p>
            <p className="text-white/80 text-xs">You earned 500 bonus points</p>
          </motion.div>
        )}
      </AnimatePresence>
    </EffectCard>
  );
}

// Seasonal Sale Banner
function SeasonalSaleEffect() {
  return (
    <EffectCard title="Seasonal Sale" description="Holiday/seasonal promotion" whenToUse="Holiday sales, seasonal campaigns, events.">
      <div className="bg-gradient-to-r from-red-600 to-green-600 rounded-xl p-4 text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <motion.div animate={{ y: [0, -100] }} transition={{ duration: 10, repeat: Infinity, ease: "linear" }} className="text-6xl">
            ❄️🎄⭐🎁❄️🎄⭐🎁
          </motion.div>
        </div>
        <h3 className="text-white text-lg font-bold mb-1 relative">Winter Sale</h3>
        <p className="text-white/90 text-sm mb-2 relative">Up to 70% off everything!</p>
        <button className="px-6 py-2 bg-white text-red-600 rounded-lg font-bold text-sm relative">Shop Now</button>
      </div>
    </EffectCard>
  );
}

// Smart Recommendation
function SmartRecommendationEffect() {
  return (
    <EffectCard title="AI Recommendation" description="Personalized product suggestion" whenToUse="Upselling, cross-selling, personalization.">
      <div className="bg-slate-800 rounded-xl p-4 border border-violet-500/30">
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="w-4 h-4 text-violet-400" />
          <span className="text-violet-400 text-xs font-medium">Recommended for you</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-16 h-16 bg-gradient-to-br from-violet-500 to-pink-500 rounded-lg" />
          <div className="flex-1">
            <p className="text-white text-sm font-medium">Premium Wireless Headphones</p>
            <p className="text-slate-400 text-xs mb-1">Based on your browsing</p>
            <span className="text-violet-400 text-sm font-bold">$129.99</span>
          </div>
        </div>
        <button className="w-full mt-3 py-2 bg-violet-500 rounded-lg text-white text-xs font-medium">View Product</button>
      </div>
    </EffectCard>
  );
}

export default function MarketingEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <HeroBannerEffect />, name: "Hero Banner" },
    { component: <TestimonialCardEffect />, name: "Testimonial Card" },
    { component: <PricingCardEffect />, name: "Pricing Card" },
    { component: <CountdownTimerEffect />, name: "Countdown Timer" },
    { component: <CTAButtonEffect />, name: "CTA Button" },
    { component: <EmailCaptureEffect />, name: "Email Capture" },
    { component: <SocialProofEffect />, name: "Social Proof" },
    { component: <FeatureBadgeEffect />, name: "Feature Badges" },
    { component: <PopupBannerEffect />, name: "Popup Banner" },
    { component: <TrustLogosEffect />, name: "Trust Logos" },
    { component: <AnnouncementBarEffect />, name: "Announcement Bar" },
    { component: <ComparisonTableEffect />, name: "Comparison Table" },
    { component: <BeforeAfterEffect />, name: "Before/After Slider" },
    { component: <GamificationBadgeEffect />, name: "Gamification Badges" },
    { component: <ExitIntentEffect />, name: "Exit Intent" },
    { component: <ProgressStepsEffect />, name: "Progress Steps" },
    { component: <FloatingBubbleEffect />, name: "Floating Bubble" },
    { component: <LimitedStockEffect />, name: "Limited Stock" },
    { component: <ReferralBannerEffect />, name: "Referral Banner" },
    { component: <ProductHuntBadgeEffect />, name: "Launch Badge" },
    { component: <DiscountCodeEffect />, name: "Discount Code" },
    { component: <GuaranteeBadgeEffect />, name: "Guarantee Badge" },
    { component: <StickyPromoEffect />, name: "Sticky Promo Bar" },
    { component: <VideoTestimonialEffect />, name: "Video Testimonial" },
    { component: <AffiliateLinkEffect />, name: "Affiliate Link" },
    { component: <CryptoWalletEffect />, name: "Crypto Wallet Connect" },
    { component: <TokenPriceEffect />, name: "Token Price Ticker" },
    { component: <NFTMintEffect />, name: "NFT Mint Card" },
    { component: <InfluencerCollabEffect />, name: "Influencer Collab" },
    { component: <ConversionRateEffect />, name: "Conversion Rate" },
    { component: <UrgencyBannerEffect />, name: "Urgency Timer" },
    { component: <WaitlistEffect />, name: "Waitlist Counter" },
    { component: <LiveSalesEffect />, name: "Live Sales Popup" },
    { component: <MilestoneBannerEffect />, name: "Milestone Banner" },
    { component: <ABTestVariantEffect />, name: "A/B Test Variants" },
    { component: <LoyaltyPointsEffect />, name: "Loyalty Points" },
    { component: <BundleDealEffect />, name: "Bundle Deal" },
    { component: <FreeShippingEffect />, name: "Free Shipping Banner" },
    { component: <MemberExclusiveEffect />, name: "Member Exclusive" },
    { component: <MoneyBackEffect />, name: "Money Back Seal" },
    { component: <StickyCartEffect />, name: "Sticky Cart Reminder" },
    { component: <RewardUnlockEffect />, name: "Reward Unlock" },
    { component: <SeasonalSaleEffect />, name: "Seasonal Sale" },
    { component: <SmartRecommendationEffect />, name: "AI Recommendation" },
  ];

  const filtered = effects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={Megaphone} title="Marketing Components" description="40 conversion-focused components for landing pages, promotions, and growth" gradient="#f43f5e, #f97316" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((effect, i) => <motion.div key={effect.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>{effect.component}</motion.div>)}
        </div>
      </div>
    </div>
  );
}