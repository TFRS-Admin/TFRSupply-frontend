import React, { useState } from "react";
import { motion } from "framer-motion";
import { Layers } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilterEnhanced from "@/components/effects/SearchFilterEnhanced";
import { useQuery } from "@tanstack/react-query";

// ===== DIVIDER EFFECTS =====

function WaveDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-violet-600 to-slate-900 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-16" preserveAspectRatio="none">
          <path d="M0,60 C300,120 600,0 900,60 C1050,90 1150,30 1200,60 L1200,120 L0,120 Z" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function AnimatedWaveDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-cyan-600 to-slate-900 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-20" preserveAspectRatio="none">
          <motion.path
            d="M0,60 C300,120 600,0 900,60 C1050,90 1150,30 1200,60 L1200,120 L0,120 Z"
            fill="rgb(15 23 42)"
            animate={{
              d: [
                "M0,60 C300,120 600,0 900,60 C1050,90 1150,30 1200,60 L1200,120 L0,120 Z",
                "M0,80 C300,20 600,100 900,40 C1050,70 1150,50 1200,80 L1200,120 L0,120 Z",
                "M0,60 C300,120 600,0 900,60 C1050,90 1150,30 1200,60 L1200,120 L0,120 Z",
              ],
            }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          />
        </svg>
      </div>
    </div>
  );
}

function DiagonalDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-r from-pink-600 to-rose-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-16" preserveAspectRatio="none">
          <polygon points="0,120 1200,0 1200,120" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function ReverseDiagonalDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-r from-amber-500 to-orange-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-16" preserveAspectRatio="none">
          <polygon points="0,0 1200,120 0,120" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function ArrowDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-emerald-600 to-teal-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-16" preserveAspectRatio="none">
          <polygon points="0,120 600,20 1200,120" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function InvertedArrowDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-blue-600 to-indigo-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-16" preserveAspectRatio="none">
          <polygon points="0,0 600,120 1200,0 1200,120 0,120" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function TriangleDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-purple-600 to-violet-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0 flex justify-center">
        <svg viewBox="0 0 100 50" className="w-24 h-10" preserveAspectRatio="none">
          <polygon points="50,0 100,50 0,50" fill="rgb(15 23 42)" />
        </svg>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-2 bg-slate-900" />
    </div>
  );
}

function CurvedDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-fuchsia-600 to-pink-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-20" preserveAspectRatio="none">
          <ellipse cx="600" cy="120" rx="700" ry="80" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function InvertedCurveDivider() {
  return (
    <div className="relative h-40 w-full bg-slate-900 rounded-xl overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-teal-500 to-cyan-600">
        <svg viewBox="0 0 1200 120" className="absolute bottom-0 w-full h-12" preserveAspectRatio="none">
          <ellipse cx="600" cy="0" rx="700" ry="60" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function ZigzagDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-red-600 to-orange-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 60" className="w-full h-8" preserveAspectRatio="none">
          <polygon points="0,60 50,0 100,60 150,0 200,60 250,0 300,60 350,0 400,60 450,0 500,60 550,0 600,60 650,0 700,60 750,0 800,60 850,0 900,60 950,0 1000,60 1050,0 1100,60 1150,0 1200,60 1200,60 0,60" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function DoubleWaveDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-indigo-600 to-blue-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-20" preserveAspectRatio="none">
          <path d="M0,40 C200,80 400,0 600,40 C800,80 1000,0 1200,40 L1200,120 L0,120 Z" fill="rgba(15,23,42,0.5)" />
          <path d="M0,60 C200,100 400,20 600,60 C800,100 1000,20 1200,60 L1200,120 L0,120 Z" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function TripleWaveDivider() {
  return (
    <div className="relative h-44 w-full bg-gradient-to-b from-violet-600 via-purple-600 to-fuchsia-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-24" preserveAspectRatio="none">
          <path d="M0,20 C300,80 600,-20 900,40 C1050,60 1150,20 1200,30 L1200,120 L0,120 Z" fill="rgba(15,23,42,0.3)" />
          <path d="M0,40 C300,100 600,0 900,60 C1050,80 1150,40 1200,50 L1200,120 L0,120 Z" fill="rgba(15,23,42,0.6)" />
          <path d="M0,60 C300,120 600,20 900,80 C1050,100 1150,60 1200,70 L1200,120 L0,120 Z" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function CloudDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-sky-400 to-blue-500 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-16" preserveAspectRatio="none">
          <path d="M0,120 C100,80 150,100 200,90 C250,80 300,60 400,80 C500,100 550,70 650,90 C750,110 800,70 900,80 C1000,90 1100,60 1200,80 L1200,120 Z" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function MountainDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-slate-600 to-slate-700 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-20" preserveAspectRatio="none">
          <polygon points="0,120 200,40 400,80 600,20 800,60 1000,30 1200,70 1200,120" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function RippleDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-cyan-500 to-teal-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-16" preserveAspectRatio="none">
          <motion.path
            d="M0,60 Q150,20 300,60 T600,60 T900,60 T1200,60 L1200,120 L0,120 Z"
            fill="rgb(15 23 42)"
            animate={{
              d: [
                "M0,60 Q150,20 300,60 T600,60 T900,60 T1200,60 L1200,120 L0,120 Z",
                "M0,60 Q150,100 300,60 T600,60 T900,60 T1200,60 L1200,120 L0,120 Z",
                "M0,60 Q150,20 300,60 T600,60 T900,60 T1200,60 L1200,120 L0,120 Z",
              ],
            }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          />
        </svg>
      </div>
    </div>
  );
}

function DrippingDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-green-500 to-emerald-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-20" preserveAspectRatio="none">
          <path d="M0,0 L0,60 Q50,120 100,60 L100,0 Q150,60 200,0 L200,60 Q250,120 300,60 L300,0 Q350,60 400,0 L400,60 Q450,120 500,60 L500,0 Q550,60 600,0 L600,60 Q650,120 700,60 L700,0 Q750,60 800,0 L800,60 Q850,120 900,60 L900,0 Q950,60 1000,0 L1000,60 Q1050,120 1100,60 L1100,0 Q1150,60 1200,0 L1200,120 L0,120 Z" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function BookDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-amber-600 to-orange-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 60" className="w-full h-12" preserveAspectRatio="none">
          <path d="M0,0 L600,60 L1200,0 L1200,60 L0,60 Z" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function SplitDivider() {
  return (
    <div className="relative h-40 w-full bg-slate-900 rounded-xl overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-r from-rose-500 to-pink-600" />
      <div className="absolute top-1/2 left-0 right-0 flex">
        <div className="w-1/2 h-8 bg-gradient-to-r from-rose-500 to-pink-600" style={{ clipPath: "polygon(0 0, 100% 0, 100% 100%)" }} />
        <div className="w-1/2 h-8 bg-gradient-to-r from-pink-600 to-rose-500" style={{ clipPath: "polygon(0 0, 100% 0, 0 100%)" }} />
      </div>
    </div>
  );
}

function GradientFadeDivider() {
  return (
    <div className="relative h-40 rounded-xl overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-purple-600 via-purple-600/50 to-slate-900" />
    </div>
  );
}

function ScallopDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-lime-500 to-green-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 60" className="w-full h-10" preserveAspectRatio="none">
          {[...Array(12)].map((_, i) => (
            <circle key={i} cx={50 + i * 100} cy="60" r="50" fill="rgb(15 23 42)" />
          ))}
        </svg>
      </div>
    </div>
  );
}

function HexagonDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-yellow-500 to-amber-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0 flex justify-center gap-0">
        {[...Array(8)].map((_, i) => (
          <div key={i} className="w-16 h-8 bg-slate-900" style={{ clipPath: "polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)" }} />
        ))}
      </div>
    </div>
  );
}

function SlantedStripeDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-red-500 to-rose-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0 h-12" style={{ background: "repeating-linear-gradient(-45deg, transparent, transparent 10px, rgb(15 23 42) 10px, rgb(15 23 42) 20px)" }} />
      <div className="absolute bottom-0 left-0 right-0 h-4 bg-slate-900" />
    </div>
  );
}

function TornPaperDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-stone-500 to-stone-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 60" className="w-full h-12" preserveAspectRatio="none">
          <path d="M0,20 L30,25 L60,15 L90,30 L120,10 L150,25 L180,20 L210,35 L240,15 L270,30 L300,20 L330,25 L360,10 L390,30 L420,20 L450,35 L480,15 L510,25 L540,20 L570,30 L600,15 L630,25 L660,20 L690,35 L720,10 L750,30 L780,20 L810,25 L840,15 L870,30 L900,20 L930,35 L960,15 L990,25 L1020,20 L1050,30 L1080,10 L1110,25 L1140,20 L1170,35 L1200,15 L1200,60 L0,60 Z" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function ParticleGlowDivider() {
  return (
    <div className="relative h-40 w-full bg-slate-900 rounded-xl overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-violet-600 to-transparent" />
      <div className="absolute top-20 left-0 right-0 flex justify-around">
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            className="w-2 h-2 rounded-full bg-violet-400"
            animate={{ y: [0, -10, 0], opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.1 }}
          />
        ))}
      </div>
    </div>
  );
}

function LiquidDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-blue-500 to-cyan-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-20" preserveAspectRatio="none">
          <motion.path
            fill="rgb(15 23 42)"
            animate={{
              d: [
                "M0,64L48,58.7C96,53,192,43,288,58.7C384,75,480,117,576,117.3C672,117,768,75,864,64C960,53,1056,75,1152,74.7C1248,75,1344,53,1392,42.7L1440,32L1440,120L1392,120C1344,120,1248,120,1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120L0,120Z",
                "M0,32L48,42.7C96,53,192,75,288,74.7C384,75,480,53,576,64C672,75,768,117,864,117.3C960,117,1056,75,1152,58.7C1248,43,1344,53,1392,58.7L1440,64L1440,120L1392,120C1344,120,1248,120,1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120L0,120Z",
                "M0,64L48,58.7C96,53,192,43,288,58.7C384,75,480,117,576,117.3C672,117,768,75,864,64C960,53,1056,75,1152,74.7C1248,75,1344,53,1392,42.7L1440,32L1440,120L1392,120C1344,120,1248,120,1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120L0,120Z",
              ],
            }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
          />
        </svg>
      </div>
    </div>
  );
}

// NEW DIVIDERS (14 additional)

function CirclePatternDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-indigo-500 to-purple-700 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0 flex">
        {[...Array(10)].map((_, i) => (
          <div key={i} className="w-24 h-12 bg-slate-900 rounded-t-full" />
        ))}
      </div>
    </div>
  );
}

function StepsDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-r from-teal-500 to-emerald-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-16" preserveAspectRatio="none">
          <path d="M0,120 L0,80 L200,80 L200,60 L400,60 L400,40 L600,40 L600,20 L800,20 L800,40 L1000,40 L1000,60 L1200,60 L1200,120 Z" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function SpiralDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-pink-500 to-rose-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-20" preserveAspectRatio="none">
          <motion.path
            d="M0,60 Q100,20 200,60 Q300,100 400,60 Q500,20 600,60 Q700,100 800,60 Q900,20 1000,60 Q1100,100 1200,60 L1200,120 L0,120 Z"
            fill="rgb(15 23 42)"
            animate={{ d: ["M0,60 Q100,20 200,60 Q300,100 400,60 Q500,20 600,60 Q700,100 800,60 Q900,20 1000,60 Q1100,100 1200,60 L1200,120 L0,120 Z", "M0,60 Q100,100 200,60 Q300,20 400,60 Q500,100 600,60 Q700,20 800,60 Q900,100 1000,60 Q1100,20 1200,60 L1200,120 L0,120 Z"] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          />
        </svg>
      </div>
    </div>
  );
}

function DiamondDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-cyan-400 to-blue-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0 flex justify-center gap-1">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="w-12 h-12 bg-slate-900 rotate-45 -mb-6" />
        ))}
      </div>
    </div>
  );
}

function WaveLineDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-orange-500 to-red-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 20" className="w-full h-5" preserveAspectRatio="none">
          <path d="M0,10 Q150,0 300,10 T600,10 T900,10 T1200,10" stroke="rgb(15 23 42)" strokeWidth="6" fill="none" />
        </svg>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-2 bg-slate-900" />
    </div>
  );
}

function PeaksDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-violet-500 to-purple-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-20" preserveAspectRatio="none">
          <path d="M0,120 L100,40 L200,120 L300,30 L400,120 L500,50 L600,120 L700,35 L800,120 L900,45 L1000,120 L1100,40 L1200,120 Z" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function LayeredCurveDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-green-500 to-teal-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-24" preserveAspectRatio="none">
          <path d="M0,80 Q300,40 600,80 T1200,80 L1200,120 L0,120 Z" fill="rgba(15,23,42,0.3)" />
          <path d="M0,90 Q300,50 600,90 T1200,90 L1200,120 L0,120 Z" fill="rgba(15,23,42,0.6)" />
          <path d="M0,100 Q300,60 600,100 T1200,100 L1200,120 L0,120 Z" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function BricksDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-red-600 to-orange-700 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0 h-16 grid grid-cols-6 gap-1 p-1 bg-slate-900">
        {[...Array(12)].map((_, i) => (
          <div key={i} className="bg-slate-700 rounded" style={{ gridColumn: i % 2 === 0 ? 'span 2' : 'span 1' }} />
        ))}
      </div>
    </div>
  );
}

function FanDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-amber-500 to-yellow-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0 flex justify-center">
        {[...Array(7)].map((_, i) => (
          <div key={i} className="w-20 h-24 bg-slate-900 origin-bottom" style={{ transform: `rotate(${-30 + i * 10}deg)`, clipPath: "polygon(40% 0%, 60% 0%, 100% 100%, 0% 100%)" }} />
        ))}
      </div>
    </div>
  );
}

function SawtoothDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-blue-600 to-indigo-700 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 60" className="w-full h-10" preserveAspectRatio="none">
          <polygon points="0,60 60,0 120,60 180,0 240,60 300,0 360,60 420,0 480,60 540,0 600,60 660,0 720,60 780,0 840,60 900,0 960,60 1020,0 1080,60 1140,0 1200,60" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function GridFadeDivider() {
  return (
    <div className="relative h-40 w-full bg-slate-900 rounded-xl overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-fuchsia-600 to-transparent" style={{ maskImage: "repeating-linear-gradient(0deg, black 0px, black 8px, transparent 8px, transparent 16px), repeating-linear-gradient(90deg, black 0px, black 8px, transparent 8px, transparent 16px)", maskComposite: "intersect" }} />
    </div>
  );
}

function CrescentDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-slate-600 to-slate-800 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0 flex justify-around">
        {[...Array(8)].map((_, i) => (
          <svg key={i} viewBox="0 0 50 50" className="w-12 h-12">
            <circle cx="25" cy="50" r="25" fill="rgb(15 23 42)" />
          </svg>
        ))}
      </div>
    </div>
  );
}

function SliceDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-b from-lime-600 to-green-700 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-20" preserveAspectRatio="none">
          <path d="M0,60 L150,120 L300,60 L450,120 L600,60 L750,120 L900,60 L1050,120 L1200,60 L1200,120 L0,120 Z" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

function AsymmetricDivider() {
  return (
    <div className="relative h-40 w-full bg-gradient-to-r from-emerald-500 to-cyan-600 rounded-xl overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-20" preserveAspectRatio="none">
          <path d="M0,120 L0,40 Q300,0 600,60 Q900,120 1200,40 L1200,120 Z" fill="rgb(15 23 42)" />
        </svg>
      </div>
    </div>
  );
}

// All effects with EffectCard integration
const effects = [
  { component: WaveDivider, name: "Wave Divider", category: "wave", description: "Classic smooth wave transition", code: `<svg viewBox="0 0 1200 120" preserveAspectRatio="none">
  <path d="M0,60 C300,120 600,0 900,60 C1050,90 1150,30 1200,60 L1200,120 L0,120 Z" fill="#0f172a" />
</svg>`, prompt: "Create a smooth SVG wave divider with bezier curves for seamless section transitions." },
  { component: AnimatedWaveDivider, name: "Animated Wave", category: "wave", description: "Flowing animated wave", code: `<motion.path
  d="M0,60 C300,120 600,0 900,60..."
  animate={{ d: [...] }}
  transition={{ duration: 4, repeat: Infinity }}
/>`, prompt: "Create an animated SVG wave using Framer Motion with smooth transitions between multiple path states." },
  { component: DoubleWaveDivider, name: "Double Wave", category: "wave", description: "Layered dual waves", code: `<svg viewBox="0 0 1200 120">
  <path d="M0,40 C200,80..." fill="rgba(15,23,42,0.5)" />
  <path d="M0,60 C200,100..." fill="rgb(15 23 42)" />
</svg>`, prompt: "Create a double-layered wave divider with semi-transparent top layer for depth." },
  { component: TripleWaveDivider, name: "Triple Wave", category: "wave", description: "Three-layer wave stack", code: `// Three overlapping wave paths with different opacities`, prompt: "Create a triple-layered wave divider with varying opacity levels for a cascading effect." },
  { component: LiquidDivider, name: "Liquid Wave", category: "wave", description: "Fluid liquid motion", code: `<motion.path animate={{ d: [path1, path2, path3] }} transition={{ duration: 5 }} />`, prompt: "Create a liquid-like animated wave divider with organic flowing motion using Framer Motion." },
  { component: RippleDivider, name: "Ripple Wave", category: "wave", description: "Gentle rippling effect", code: `<motion.path d="M0,60 Q150,20 300,60..." animate={{ d: [...] }} />`, prompt: "Create a rippling wave divider with smooth quadratic bezier curves and gentle animation." },
  { component: DiagonalDivider, name: "Diagonal", category: "angle", description: "Simple diagonal slice", code: `<polygon points="0,120 1200,0 1200,120" fill="#0f172a" />`, prompt: "Create a simple diagonal SVG divider using a polygon shape." },
  { component: ReverseDiagonalDivider, name: "Reverse Diagonal", category: "angle", description: "Opposite diagonal cut", code: `<polygon points="0,0 1200,120 0,120" fill="#0f172a" />`, prompt: "Create a reverse diagonal divider slicing from opposite direction." },
  { component: ArrowDivider, name: "Arrow Point", category: "angle", description: "Downward arrow shape", code: `<polygon points="0,120 600,20 1200,120" fill="#0f172a" />`, prompt: "Create an arrow-shaped SVG divider pointing downward." },
  { component: InvertedArrowDivider, name: "Inverted Arrow", category: "angle", description: "Upward arrow peak", code: `<polygon points="0,0 600,120 1200,0 1200,120 0,120" fill="#0f172a" />`, prompt: "Create an inverted arrow divider with upward peak for section separation." },
  { component: BookDivider, name: "Book Fold", category: "angle", description: "Open book effect", code: `<path d="M0,0 L600,60 L1200,0 L1200,60 L0,60 Z" fill="#0f172a" />`, prompt: "Create a book-fold divider with center valley for page-like transition." },
  { component: SplitDivider, name: "Split Angle", category: "angle", description: "Center split design", code: `// Split gradient with angled dividers meeting at center`, prompt: "Create a split divider with two gradients meeting at center with angled edges." },
  { component: CurvedDivider, name: "Curved", category: "curved", description: "Smooth ellipse curve", code: `<ellipse cx="600" cy="120" rx="700" ry="80" fill="#0f172a" />`, prompt: "Create a smooth curved divider using an SVG ellipse shape." },
  { component: InvertedCurveDivider, name: "Inverted Curve", category: "curved", description: "Upward curve arc", code: `<ellipse cx="600" cy="0" rx="700" ry="60" fill="#0f172a" />`, prompt: "Create an inverted curved divider arcing upward for unique section breaks." },
  { component: CloudDivider, name: "Cloud", category: "curved", description: "Fluffy cloud shapes", code: `<path d="M0,120 C100,80 150,100 200,90..." fill="#0f172a" />`, prompt: "Create a cloud-shaped divider with organic bumpy curves for soft transitions." },
  { component: ScallopDivider, name: "Scallop", category: "curved", description: "Overlapping circles", code: `{[...Array(12)].map((_, i) => <circle cx={50 + i * 100} cy="60" r="50" />)}`, prompt: "Create a scalloped edge divider using overlapping SVG circles." },
  { component: TriangleDivider, name: "Triangle", category: "geometric", description: "Single triangle point", code: `<polygon points="50,0 100,50 0,50" fill="#0f172a" />`, prompt: "Create a centered triangle divider pointing downward." },
  { component: ZigzagDivider, name: "Zigzag", category: "geometric", description: "Sharp zigzag pattern", code: `<polygon points="0,60 50,0 100,60 150,0..." fill="#0f172a" />`, prompt: "Create a zigzag divider with sharp angular pattern for energetic transitions." },
  { component: MountainDivider, name: "Mountain", category: "geometric", description: "Mountain range silhouette", code: `<polygon points="0,120 200,40 400,80 600,20..." fill="#0f172a" />`, prompt: "Create a mountain range divider with varying peak heights." },
  { component: HexagonDivider, name: "Hexagon", category: "geometric", description: "Hexagonal pattern edge", code: `// Hexagons with clip-path polygon`, prompt: "Create a hexagonal edge divider using CSS clip-path for geometric design." },
  { component: DrippingDivider, name: "Dripping", category: "creative", description: "Drip effect design", code: `<path d="M0,0 L0,60 Q50,120 100,60..." fill="#0f172a" />`, prompt: "Create a dripping divider with liquid droplet shapes for creative transitions." },
  { component: TornPaperDivider, name: "Torn Paper", category: "creative", description: "Jagged torn edge", code: `<path d="M0,20 L30,25 L60,15 L90,30..." fill="#0f172a" />`, prompt: "Create a torn paper edge divider with irregular jagged path for organic feel." },
  { component: SlantedStripeDivider, name: "Slanted Stripes", category: "creative", description: "Diagonal stripe pattern", code: `background: repeating-linear-gradient(-45deg, transparent, transparent 10px, #0f172a 10px, #0f172a 20px)`, prompt: "Create a slanted stripe divider using CSS repeating gradient." },
  { component: ParticleGlowDivider, name: "Particle Glow", category: "creative", description: "Floating glowing particles", code: `{[...Array(12)].map((_, i) => <motion.div animate={{ y: [0, -10, 0] }} />)}`, prompt: "Create an animated particle glow divider with floating orbs using Framer Motion." },
  { component: GradientFadeDivider, name: "Gradient Fade", category: "fade", description: "Smooth gradient transition", code: `<div className="bg-gradient-to-b from-purple-600 via-purple-600/50 to-slate-900" />`, prompt: "Create a gradient fade divider transitioning smoothly between sections." },
  { component: CirclePatternDivider, name: "Circle Pattern", category: "geometric", description: "Repeating rounded circles", code: `{[...Array(10)].map((_, i) => <div className="rounded-t-full" />)}`, prompt: "Create a divider with repeating rounded circle pattern along bottom edge." },
  { component: StepsDivider, name: "Steps", category: "geometric", description: "Staircase step pattern", code: `<path d="M0,120 L0,80 L200,80 L200,60 L400,60..." fill="#0f172a" />`, prompt: "Create a stepped divider with staircase pattern for progressive transition." },
  { component: SpiralDivider, name: "Spiral", category: "wave", description: "Spiraling wave motion", code: `<motion.path d="M0,60 Q100,20 200,60..." animate={{ d: [...] }} />`, prompt: "Create an animated spiral wave divider with alternating curves." },
  { component: DiamondDivider, name: "Diamond", category: "geometric", description: "Rotated diamond shapes", code: `{[...Array(6)].map((_, i) => <div className="rotate-45" />)}`, prompt: "Create a diamond-shaped divider using rotated squares." },
  { component: WaveLineDivider, name: "Wave Line", category: "wave", description: "Single wavy line", code: `<path d="M0,10 Q150,0 300,10 T600,10..." stroke="#0f172a" />`, prompt: "Create a simple wavy line divider using SVG stroke path." },
  { component: PeaksDivider, name: "Peaks", category: "geometric", description: "Sharp mountain peaks", code: `<path d="M0,120 L100,40 L200,120 L300,30..." fill="#0f172a" />`, prompt: "Create a sharp peaks divider with varying heights for dramatic effect." },
  { component: LayeredCurveDivider, name: "Layered Curve", category: "curved", description: "Multi-layer curves", code: `// Three overlapping curved paths with opacity`, prompt: "Create a layered curved divider with multiple overlapping bezier curves." },
  { component: BricksDivider, name: "Bricks", category: "creative", description: "Brick wall pattern", code: `// Grid with alternating brick widths`, prompt: "Create a brick wall divider pattern using CSS grid." },
  { component: FanDivider, name: "Fan", category: "creative", description: "Radiating fan pattern", code: `{[...Array(7)].map((_, i) => <div style={{ transform: 'rotate(...)' }} />)}`, prompt: "Create a fan-shaped divider with radiating elements." },
  { component: SawtoothDivider, name: "Sawtooth", category: "geometric", description: "Sharp sawtooth edge", code: `<polygon points="0,60 60,0 120,60 180,0..." fill="#0f172a" />`, prompt: "Create a sawtooth divider with evenly spaced sharp triangles." },
  { component: GridFadeDivider, name: "Grid Fade", category: "fade", description: "Fading grid pattern", code: `// Gradient with repeating-linear-gradient mask`, prompt: "Create a fading grid divider using CSS gradient mask." },
  { component: CrescentDivider, name: "Crescent", category: "curved", description: "Crescent moon shapes", code: `{[...Array(8)].map((_, i) => <circle cx="25" cy="50" r="25" />)}`, prompt: "Create a crescent divider using overlapping circles." },
  { component: SliceDivider, name: "Slice", category: "angle", description: "Diagonal slice pattern", code: `<path d="M0,60 L150,120 L300,60 L450,120..." fill="#0f172a" />`, prompt: "Create a sliced divider with alternating diagonal cuts." },
  { component: AsymmetricDivider, name: "Asymmetric", category: "curved", description: "Unbalanced organic curve", code: `<path d="M0,120 L0,40 Q300,0 600,60 Q900,120 1200,40..." fill="#0f172a" />`, prompt: "Create an asymmetric curved divider with organic flowing shape." },
];

const categories = [
  { id: "all", label: "All", count: effects.length },
  { id: "wave", label: "Waves", count: effects.filter(e => e.category === "wave").length },
  { id: "angle", label: "Angles", count: effects.filter(e => e.category === "angle").length },
  { id: "curved", label: "Curved", count: effects.filter(e => e.category === "curved").length },
  { id: "geometric", label: "Geometric", count: effects.filter(e => e.category === "geometric").length },
  { id: "creative", label: "Creative", count: effects.filter(e => e.category === "creative").length },
  { id: "fade", label: "Fade", count: effects.filter(e => e.category === "fade").length },
];

export default function DividerEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const filtered = effects.filter(e => {
    const matchesSearch = e.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === "all" || e.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={Layers} title="Divider Effects" description={`${effects.length} section dividers and transition effects for seamless page flow`} gradient="#8b5cf6, #06b6d4" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="mb-6 flex flex-wrap gap-2">
          <style>{`
            .tag-btn-active {
              background: rgba(0, 0, 0, 0.3);
              position: relative;
              z-index: 1;
            }
            .tag-btn-active::before {
              content: "";
              position: absolute;
              inset: 0;
              border-radius: 0.75rem; 
              padding: 2px; 
              background: linear-gradient(135deg, #06b6d4, #10b981, #a855f7); 
              -webkit-mask: 
                 linear-gradient(#fff 0 0) content-box, 
                 linear-gradient(#fff 0 0);
              -webkit-mask-composite: xor;
              mask-composite: exclude;
              pointer-events: none;
            }
            .tag-btn-text-glitch:hover {
              animation: tag-glitch 0.3s ease-in-out infinite;
            }
            @keyframes tag-glitch {
              0%, 100% { text-shadow: none; transform: translate(0); }
              20% { text-shadow: -1px 0 #a855f7, 1px 0 #06b6d4; transform: translate(-1px, 0); }
              40% { text-shadow: 1px 0 #a855f7, -1px 0 #06b6d4; transform: translate(1px, 0); }
              60% { text-shadow: -1px 0 #06b6d4, 1px 0 #a855f7; transform: translate(-1px, 0); }
              80% { text-shadow: 1px 0 #06b6d4, -1px 0 #a855f7; transform: translate(1px, 0); }
            }
          `}</style>
          {categories.map(cat => (
            <button 
              key={cat.id} 
              onClick={() => setActiveCategory(cat.id)} 
              className={`relative px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                activeCategory === cat.id 
                  ? "tag-btn-active text-white" 
                  : "bg-black/30 text-slate-400 hover:text-white border border-transparent hover:border-slate-700"
              }`}
            >
              <span className={activeCategory === cat.id ? "tag-btn-text-glitch" : ""}>
                {cat.label} ({cat.count})
              </span>
            </button>
          ))}
        </div>
        <SearchFilterEnhanced 
          searchQuery={searchQuery} 
          setSearchQuery={setSearchQuery} 
          activeCategory={activeCategory} 
          setActiveCategory={setActiveCategory} 
          resultCount={filtered.length}
          suggestions={effects.map(e => ({ name: e.name, page: "DividerEffects", category: e.category }))} 
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((effect, i) => (
            <EffectCard key={i} title={effect.name} description={effect.description} code={effect.code} prompt={effect.prompt}>
              <effect.component />
            </EffectCard>
          ))}
        </div>
      </div>
    </div>
  );
}