import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Mail, MessageCircle, Phone, Video, Bell, Send, Inbox, Archive, Trash2, Star, Paperclip, Reply, Forward, MoreHorizontal, Search, Filter, Users, AtSign, Hash, Smile, Mic, Image, Check, CheckCheck, Clock, AlertCircle, Volume2, VolumeX, PhoneOff, UserPlus } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// Email List Item
function EmailListItemEffect() {
  const [starred, setStarred] = useState(false);
  const [selected, setSelected] = useState(false);
  return (
    <EffectCard title="Email List Item" description="Inbox message row" whenToUse="Email clients, notification lists, inboxes.">
      <motion.div onClick={() => setSelected(!selected)} whileHover={{ x: 4 }} className={`flex items-start gap-3 p-3 rounded-lg cursor-pointer ${selected ? "bg-violet-500/10" : "bg-slate-800"}`}>
        <input type="checkbox" checked={selected} onChange={() => {}} className="mt-1 rounded" />
        <button onClick={e => { e.stopPropagation(); setStarred(!starred); }} className="mt-1"><Star className={`w-4 h-4 ${starred ? "text-amber-400 fill-amber-400" : "text-slate-500"}`} /></button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-1">
            <span className="text-white font-medium text-sm truncate">John Doe</span>
            <span className="text-slate-500 text-xs">2:34 PM</span>
          </div>
          <p className="text-slate-300 text-sm font-medium truncate">Meeting Tomorrow</p>
          <p className="text-slate-500 text-xs truncate">Hi, just wanted to confirm our meeting...</p>
        </div>
        <Paperclip className="w-4 h-4 text-slate-500" />
      </motion.div>
    </EffectCard>
  );
}

// Email Compose
function EmailComposeEffect() {
  return (
    <EffectCard title="Email Compose" description="New message form" whenToUse="Email clients, contact forms, messaging.">
      <div className="w-full bg-slate-800 rounded-lg overflow-hidden">
        <div className="flex items-center justify-between p-2 border-b border-slate-700">
          <span className="text-white text-sm font-medium">New Message</span>
          <button className="text-slate-400 hover:text-white">×</button>
        </div>
        <div className="p-3 space-y-2">
          <input type="text" placeholder="To:" className="w-full bg-transparent text-white text-sm p-1 border-b border-slate-700 focus:border-violet-500 outline-none" />
          <input type="text" placeholder="Subject:" className="w-full bg-transparent text-white text-sm p-1 border-b border-slate-700 focus:border-violet-500 outline-none" />
          <textarea placeholder="Write your message..." className="w-full bg-transparent text-white text-sm p-1 h-16 resize-none outline-none" />
        </div>
        <div className="flex items-center justify-between p-2 bg-slate-800/50">
          <div className="flex gap-2">
            <button className="p-2 hover:bg-slate-700 rounded"><Paperclip className="w-4 h-4 text-slate-400" /></button>
            <button className="p-2 hover:bg-slate-700 rounded"><Image className="w-4 h-4 text-slate-400" /></button>
          </div>
          <button className="px-4 py-1.5 bg-violet-500 rounded text-white text-sm flex items-center gap-2"><Send className="w-4 h-4" /> Send</button>
        </div>
      </div>
    </EffectCard>
  );
}

// Chat Bubble
function ChatBubbleEffect() {
  return (
    <EffectCard title="Chat Bubbles" description="Message conversation style" whenToUse="Chat apps, messaging, support.">
      <div className="space-y-3 w-full">
        <div className="flex gap-2">
          <div className="w-8 h-8 rounded-full bg-slate-600 flex-shrink-0" />
          <div className="bg-slate-800 rounded-2xl rounded-bl-sm px-4 py-2 max-w-[70%]">
            <p className="text-white text-sm">Hey! How's it going?</p>
            <span className="text-slate-500 text-xs">10:32 AM</span>
          </div>
        </div>
        <div className="flex gap-2 justify-end">
          <div className="bg-violet-500 rounded-2xl rounded-br-sm px-4 py-2 max-w-[70%]">
            <p className="text-white text-sm">Great! Just finished the project 🎉</p>
            <div className="flex items-center justify-end gap-1 mt-1">
              <span className="text-violet-200 text-xs">10:33 AM</span>
              <CheckCheck className="w-4 h-4 text-violet-200" />
            </div>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Typing Indicator
function TypingIndicatorEffect() {
  return (
    <EffectCard title="Typing Indicator" description="User is typing animation" whenToUse="Chat apps, real-time messaging.">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-full bg-violet-500" />
        <div className="bg-slate-800 rounded-2xl px-4 py-3 flex items-center gap-1">
          <motion.div animate={{ y: [0, -4, 0] }} transition={{ duration: 0.6, repeat: Infinity, delay: 0 }} className="w-2 h-2 bg-slate-400 rounded-full" />
          <motion.div animate={{ y: [0, -4, 0] }} transition={{ duration: 0.6, repeat: Infinity, delay: 0.2 }} className="w-2 h-2 bg-slate-400 rounded-full" />
          <motion.div animate={{ y: [0, -4, 0] }} transition={{ duration: 0.6, repeat: Infinity, delay: 0.4 }} className="w-2 h-2 bg-slate-400 rounded-full" />
        </div>
      </div>
    </EffectCard>
  );
}

// Notification Badge
function NotificationBadgeEffect() {
  const [count, setCount] = useState(5);
  return (
    <EffectCard title="Notification Badge" description="Unread count indicator" whenToUse="Notifications, inboxes, alerts.">
      <div className="flex gap-4">
        <button className="relative p-3 bg-slate-800 rounded-lg">
          <Bell className="w-6 h-6 text-white" />
          <motion.span key={count} initial={{ scale: 0 }} animate={{ scale: 1 }} className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-white text-xs flex items-center justify-center">{count}</motion.span>
        </button>
        <button onClick={() => setCount(c => c + 1)} className="px-3 py-2 bg-slate-800 rounded-lg text-slate-400 text-sm">Add +1</button>
        <button onClick={() => setCount(0)} className="px-3 py-2 bg-slate-800 rounded-lg text-slate-400 text-sm">Clear</button>
      </div>
    </EffectCard>
  );
}

// Message Reactions
function MessageReactionsEffect() {
  const [reactions, setReactions] = useState({ "👍": 3, "❤️": 2, "😂": 1 });
  return (
    <EffectCard title="Message Reactions" description="Emoji reactions on messages" whenToUse="Chat apps, social messaging, comments.">
      <div className="bg-slate-800 rounded-2xl p-3">
        <p className="text-white text-sm mb-2">This is a great idea!</p>
        <div className="flex gap-1 flex-wrap">
          {Object.entries(reactions).map(([emoji, count]) => (
            <motion.button key={emoji} onClick={() => setReactions(r => ({ ...r, [emoji]: r[emoji] + 1 }))} whileHover={{ scale: 1.1 }} className="flex items-center gap-1 px-2 py-1 bg-slate-700 hover:bg-violet-500/20 rounded-full">
              <span>{emoji}</span>
              <span className="text-white text-xs">{count}</span>
            </motion.button>
          ))}
          <button className="w-7 h-7 bg-slate-700 hover:bg-slate-600 rounded-full flex items-center justify-center">
            <Smile className="w-4 h-4 text-slate-400" />
          </button>
        </div>
      </div>
    </EffectCard>
  );
}

// Voice Message
function VoiceMessageEffect() {
  const [playing, setPlaying] = useState(false);
  return (
    <EffectCard title="Voice Message" description="Audio message player" whenToUse="Messaging apps, voice notes.">
      <div className="flex items-center gap-3 bg-slate-800 rounded-2xl p-3 w-full">
        <button onClick={() => setPlaying(!playing)} className="w-10 h-10 bg-violet-500 rounded-full flex items-center justify-center flex-shrink-0">
          {playing ? <span className="w-3 h-3 bg-white rounded-sm" /> : <div className="w-0 h-0 border-t-4 border-b-4 border-l-6 border-transparent border-l-white ml-1" style={{ borderTopWidth: 6, borderBottomWidth: 6, borderLeftWidth: 10 }} />}
        </button>
        <div className="flex-1">
          <div className="flex gap-0.5 h-8 items-center">
            {[...Array(20)].map((_, i) => (
              <motion.div key={i} animate={playing ? { height: [8, 20 + Math.random() * 12, 8] } : {}} transition={{ duration: 0.3, repeat: playing ? Infinity : 0, delay: i * 0.05 }} className="w-1 bg-violet-400 rounded-full" style={{ height: 8 + Math.random() * 16 }} />
            ))}
          </div>
        </div>
        <span className="text-slate-400 text-xs">0:42</span>
      </div>
    </EffectCard>
  );
}

// Video Call UI
function VideoCallUIEffect() {
  const [muted, setMuted] = useState(false);
  const [videoOff, setVideoOff] = useState(false);
  return (
    <EffectCard title="Video Call UI" description="Video conference controls" whenToUse="Video calls, meetings, conferencing.">
      <div className="w-full space-y-3">
        <div className="relative h-32 bg-slate-800 rounded-xl overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-violet-500/20 to-cyan-500/20 flex items-center justify-center">
            {videoOff ? <Video className="w-12 h-12 text-slate-600" /> : <div className="w-16 h-16 rounded-full bg-violet-500" />}
          </div>
          <div className="absolute bottom-2 right-2 w-16 h-12 bg-slate-900 rounded-lg" />
        </div>
        <div className="flex justify-center gap-3">
          <motion.button onClick={() => setMuted(!muted)} whileTap={{ scale: 0.9 }} className={`p-3 rounded-full ${muted ? "bg-red-500" : "bg-slate-700"}`}>
            {muted ? <VolumeX className="w-5 h-5 text-white" /> : <Mic className="w-5 h-5 text-white" />}
          </motion.button>
          <motion.button onClick={() => setVideoOff(!videoOff)} whileTap={{ scale: 0.9 }} className={`p-3 rounded-full ${videoOff ? "bg-red-500" : "bg-slate-700"}`}>
            <Video className="w-5 h-5 text-white" />
          </motion.button>
          <motion.button whileTap={{ scale: 0.9 }} className="p-3 rounded-full bg-red-500">
            <PhoneOff className="w-5 h-5 text-white" />
          </motion.button>
        </div>
      </div>
    </EffectCard>
  );
}

// Chat Input
function ChatInputEffect() {
  return (
    <EffectCard title="Chat Input" description="Message composer with actions" whenToUse="Chat apps, messaging, comments.">
      <div className="flex items-center gap-2 bg-slate-800 rounded-full p-2 w-full">
        <button className="p-2 hover:bg-slate-700 rounded-full"><Smile className="w-5 h-5 text-slate-400" /></button>
        <button className="p-2 hover:bg-slate-700 rounded-full"><Paperclip className="w-5 h-5 text-slate-400" /></button>
        <input type="text" placeholder="Type a message..." className="flex-1 bg-transparent text-white text-sm outline-none" />
        <button className="p-2 hover:bg-slate-700 rounded-full"><Mic className="w-5 h-5 text-slate-400" /></button>
        <button className="w-10 h-10 bg-violet-500 rounded-full flex items-center justify-center"><Send className="w-5 h-5 text-white" /></button>
      </div>
    </EffectCard>
  );
}

// Contact List
function ContactListEffect() {
  return (
    <EffectCard title="Contact List" description="People/contacts list" whenToUse="Contacts, team members, chat lists.">
      <div className="space-y-2 w-full">
        {["Alice Smith", "Bob Johnson", "Carol White"].map((name, i) => (
          <motion.div key={name} whileHover={{ x: 4 }} className="flex items-center gap-3 p-2 hover:bg-slate-800 rounded-lg cursor-pointer">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-pink-500" />
              <span className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-slate-900 ${i === 0 ? "bg-green-500" : i === 1 ? "bg-amber-500" : "bg-slate-500"}`} />
            </div>
            <div className="flex-1">
              <p className="text-white text-sm">{name}</p>
              <p className="text-slate-500 text-xs">{i === 0 ? "Online" : i === 1 ? "Away" : "Offline"}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Read Receipt
function ReadReceiptEffect() {
  return (
    <EffectCard title="Read Receipts" description="Message delivery status" whenToUse="Messaging apps, chat, email.">
      <div className="space-y-3">
        {[
          { status: "Sending", icon: Clock, color: "slate" },
          { status: "Sent", icon: Check, color: "slate" },
          { status: "Delivered", icon: CheckCheck, color: "slate" },
          { status: "Read", icon: CheckCheck, color: "blue" }
        ].map(s => (
          <div key={s.status} className="flex items-center justify-between p-2 bg-slate-800 rounded-lg">
            <span className="text-white text-sm">{s.status}</span>
            <s.icon className={`w-5 h-5 text-${s.color}-400`} />
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Channel/Group Header
function ChannelHeaderEffect() {
  return (
    <EffectCard title="Channel Header" description="Group/channel info bar" whenToUse="Team chat, Slack-style apps, forums.">
      <div className="flex items-center justify-between p-3 bg-slate-800 rounded-lg w-full">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-violet-500/20 rounded-lg flex items-center justify-center"><Hash className="w-5 h-5 text-violet-400" /></div>
          <div>
            <h4 className="text-white font-medium text-sm">general</h4>
            <p className="text-slate-500 text-xs">42 members</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button className="p-2 hover:bg-slate-700 rounded"><Users className="w-4 h-4 text-slate-400" /></button>
          <button className="p-2 hover:bg-slate-700 rounded"><Bell className="w-4 h-4 text-slate-400" /></button>
        </div>
      </div>
    </EffectCard>
  );
}

// Mention Input
function MentionInputEffect() {
  const [showMentions, setShowMentions] = useState(false);
  return (
    <EffectCard title="Mention Input" description="@mention autocomplete" whenToUse="Team chat, comments, social apps.">
      <div className="relative w-full">
        <input type="text" placeholder="Type @ to mention..." onFocus={() => setShowMentions(true)} onBlur={() => setTimeout(() => setShowMentions(false), 100)} className="w-full px-4 py-2 bg-slate-800 rounded-lg text-white text-sm outline-none focus:ring-2 ring-violet-500" />
        <AnimatePresence>
          {showMentions && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="absolute top-full left-0 right-0 mt-1 bg-slate-800 rounded-lg shadow-xl border border-slate-700 p-1">
              {["@john", "@alice", "@bob"].map(m => (
                <button key={m} className="w-full flex items-center gap-2 p-2 hover:bg-slate-700 rounded text-left">
                  <div className="w-6 h-6 rounded-full bg-violet-500" />
                  <span className="text-white text-sm">{m}</span>
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Notification Toast
function NotificationToastEffect() {
  const [show, setShow] = useState(false);
  return (
    <EffectCard title="Notification Toast" description="Pop-up message alert" whenToUse="System notifications, alerts, updates.">
      <button onClick={() => { setShow(true); setTimeout(() => setShow(false), 2000); }} className="px-4 py-2 bg-violet-500 rounded-lg text-white text-sm">Show Notification</button>
      <AnimatePresence>
        {show && (
          <motion.div initial={{ opacity: 0, y: 20, x: "-50%" }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }} className="fixed bottom-20 left-1/2 flex items-center gap-3 px-4 py-3 bg-slate-800 rounded-lg shadow-xl border border-slate-700">
            <div className="w-10 h-10 rounded-full bg-violet-500" />
            <div>
              <p className="text-white text-sm font-medium">New message from Alice</p>
              <p className="text-slate-400 text-xs">Hey, are you free to chat?</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </EffectCard>
  );
}

// Email Folder
function EmailFolderEffect() {
  const [active, setActive] = useState(0);
  const folders = [
    { icon: Inbox, label: "Inbox", count: 12 },
    { icon: Star, label: "Starred", count: 3 },
    { icon: Send, label: "Sent", count: 0 },
    { icon: Archive, label: "Archive", count: 0 },
    { icon: Trash2, label: "Trash", count: 2 }
  ];
  return (
    <EffectCard title="Email Folders" description="Mailbox navigation" whenToUse="Email clients, file managers, organization.">
      <div className="space-y-1 w-full">
        {folders.map((f, i) => (
          <motion.button key={f.label} onClick={() => setActive(i)} whileHover={{ x: 4 }} className={`w-full flex items-center justify-between p-2 rounded-lg ${active === i ? "bg-violet-500/20 text-violet-400" : "text-slate-400 hover:bg-slate-800"}`}>
            <span className="flex items-center gap-2"><f.icon className="w-4 h-4" /> {f.label}</span>
            {f.count > 0 && <span className="text-xs">{f.count}</span>}
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Email Actions
function EmailActionsEffect() {
  return (
    <EffectCard title="Email Actions" description="Message action buttons" whenToUse="Email clients, message details.">
      <div className="flex gap-2">
        <button className="flex items-center gap-1 px-3 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-400 text-sm"><Reply className="w-4 h-4" /> Reply</button>
        <button className="flex items-center gap-1 px-3 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-400 text-sm"><Forward className="w-4 h-4" /> Forward</button>
        <button className="flex items-center gap-1 px-3 py-2 bg-slate-800 hover:bg-red-500/20 rounded-lg text-slate-400 hover:text-red-400 text-sm"><Trash2 className="w-4 h-4" /></button>
        <button className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-400"><MoreHorizontal className="w-4 h-4" /></button>
      </div>
    </EffectCard>
  );
}

// Incoming Call
function IncomingCallEffect() {
  const [show, setShow] = useState(false);
  return (
    <EffectCard title="Incoming Call" description="Call notification UI" whenToUse="Voice/video calls, notifications.">
      <button onClick={() => setShow(true)} className="px-4 py-2 bg-green-500 rounded-lg text-white text-sm">Simulate Call</button>
      <AnimatePresence>
        {show && (
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} className="fixed inset-0 bg-slate-900/90 flex items-center justify-center z-50">
            <div className="text-center">
              <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ duration: 1, repeat: Infinity }} className="w-24 h-24 rounded-full bg-violet-500 mx-auto mb-4" />
              <h3 className="text-white text-xl font-medium mb-1">Alice Smith</h3>
              <p className="text-slate-400 mb-8">Incoming video call...</p>
              <div className="flex gap-4 justify-center">
                <motion.button onClick={() => setShow(false)} whileTap={{ scale: 0.9 }} className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center">
                  <PhoneOff className="w-6 h-6 text-white" />
                </motion.button>
                <motion.button onClick={() => setShow(false)} whileTap={{ scale: 0.9 }} className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center">
                  <Phone className="w-6 h-6 text-white" />
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </EffectCard>
  );
}

// Thread Reply
function ThreadReplyEffect() {
  return (
    <EffectCard title="Thread Reply" description="Conversation threading" whenToUse="Email threads, nested comments.">
      <div className="space-y-2 w-full">
        <div className="p-3 bg-slate-800 rounded-lg">
          <p className="text-white text-sm">Original message here</p>
        </div>
        <div className="ml-6 border-l-2 border-slate-700 pl-3 space-y-2">
          <div className="p-2 bg-slate-800/50 rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-5 h-5 rounded-full bg-violet-500" />
              <span className="text-white text-xs">Alice</span>
              <span className="text-slate-500 text-xs">2h ago</span>
            </div>
            <p className="text-slate-300 text-xs">This is a reply in the thread</p>
          </div>
          <div className="p-2 bg-slate-800/50 rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-5 h-5 rounded-full bg-pink-500" />
              <span className="text-white text-xs">Bob</span>
              <span className="text-slate-500 text-xs">1h ago</span>
            </div>
            <p className="text-slate-300 text-xs">Another reply here</p>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Group Avatar
function GroupAvatarEffect() {
  return (
    <EffectCard title="Group Avatars" description="Multiple user avatars" whenToUse="Group chats, team displays, participants.">
      <div className="flex items-center">
        <div className="flex -space-x-3">
          {["violet", "pink", "cyan", "amber"].map((c, i) => (
            <motion.div key={c} whileHover={{ y: -4, zIndex: 10 }} className={`w-10 h-10 rounded-full bg-${c}-500 border-2 border-slate-900`} />
          ))}
        </div>
        <span className="ml-3 text-slate-400 text-sm">+8 others</span>
      </div>
    </EffectCard>
  );
}

// Quick Reply
function QuickReplyEffect() {
  const replies = ["Thanks!", "Got it 👍", "On it!", "Let me check"];
  return (
    <EffectCard title="Quick Replies" description="Preset response buttons" whenToUse="Chat apps, customer support, bots.">
      <div className="flex flex-wrap gap-2">
        {replies.map(r => (
          <motion.button key={r} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="px-3 py-1.5 bg-slate-800 hover:bg-violet-500/20 rounded-full text-sm text-slate-300 hover:text-violet-400">{r}</motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Message Search
function MessageSearchEffect() {
  return (
    <EffectCard title="Message Search" description="Search within messages" whenToUse="Chat apps, email, archives.">
      <div className="w-full">
        <div className="flex items-center gap-2 px-3 py-2 bg-slate-800 rounded-lg mb-3">
          <Search className="w-4 h-4 text-slate-400" />
          <input type="text" placeholder="Search messages..." className="flex-1 bg-transparent text-white text-sm outline-none" />
          <button className="p-1 hover:bg-slate-700 rounded"><Filter className="w-4 h-4 text-slate-400" /></button>
        </div>
        <div className="space-y-2 text-xs">
          {[1, 2].map(i => (
            <div key={i} className="p-2 bg-slate-800/50 rounded-lg">
              <span className="text-slate-500">3 days ago in #general</span>
              <p className="text-white">Found <span className="bg-amber-500/30 text-amber-400 px-1 rounded">search term</span> here</p>
            </div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Status Update
function StatusUpdateEffect() {
  const statuses = [
    { emoji: "🟢", label: "Available" },
    { emoji: "🌙", label: "Away" },
    { emoji: "🔴", label: "Do Not Disturb" },
    { emoji: "📅", label: "In a Meeting" }
  ];
  const [current, setCurrent] = useState(0);
  return (
    <EffectCard title="Status Selector" description="Presence/availability status" whenToUse="Team chat, collaboration tools.">
      <div className="space-y-2">
        {statuses.map((s, i) => (
          <motion.button key={s.label} onClick={() => setCurrent(i)} whileHover={{ x: 4 }} className={`w-full flex items-center gap-2 p-2 rounded-lg ${current === i ? "bg-violet-500/20" : "bg-slate-800"}`}>
            <span>{s.emoji}</span>
            <span className={current === i ? "text-violet-400" : "text-slate-300"}>{s.label}</span>
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Pinned Message
function PinnedMessageEffect() {
  return (
    <EffectCard title="Pinned Message" description="Important message highlight" whenToUse="Chat channels, important info.">
      <div className="w-full bg-amber-500/10 border border-amber-500/30 rounded-lg p-3">
        <div className="flex items-center gap-2 mb-2">
          <svg className="w-4 h-4 text-amber-400" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.4 7.4H22l-6 4.6 2.3 7-6.3-4.6L5.7 21 8 14l-6-4.6h7.6z"/></svg>
          <span className="text-amber-400 text-xs font-medium">Pinned by Admin</span>
        </div>
        <p className="text-white text-sm">Team meeting moved to 3pm tomorrow. Please update your calendars.</p>
      </div>
    </EffectCard>
  );
}

// File Attachment
function FileAttachmentEffect() {
  return (
    <EffectCard title="File Attachment" description="Shared file preview" whenToUse="File sharing, attachments.">
      <motion.div whileHover={{ scale: 1.02 }} className="flex items-center gap-3 p-3 bg-slate-800 rounded-lg w-full cursor-pointer">
        <div className="w-12 h-12 bg-violet-500/20 rounded-lg flex items-center justify-center">
          <Paperclip className="w-6 h-6 text-violet-400" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-white text-sm truncate">project_proposal.pdf</p>
          <p className="text-slate-500 text-xs">2.4 MB • PDF Document</p>
        </div>
        <button className="p-2 hover:bg-slate-700 rounded-lg">
          <Download className="w-4 h-4 text-slate-400" />
        </button>
      </motion.div>
    </EffectCard>
  );
}

const Download = ({ className }) => <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>;

// Scheduled Message
function ScheduledMessageEffect() {
  return (
    <EffectCard title="Scheduled Message" description="Delayed send indicator" whenToUse="Email scheduling, timed posts.">
      <div className="flex items-center gap-3 p-3 bg-slate-800 rounded-lg w-full">
        <div className="w-10 h-10 bg-blue-500/20 rounded-full flex items-center justify-center">
          <Clock className="w-5 h-5 text-blue-400" />
        </div>
        <div className="flex-1">
          <p className="text-white text-sm">Meeting reminder</p>
          <p className="text-blue-400 text-xs flex items-center gap-1">
            <Clock className="w-3 h-3" /> Scheduled for Dec 5, 9:00 AM
          </p>
        </div>
        <button className="text-slate-400 hover:text-red-400 text-xs">Cancel</button>
      </div>
    </EffectCard>
  );
}

export default function CommunicationEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <EmailListItemEffect />, name: "Email List Item" },
    { component: <EmailComposeEffect />, name: "Email Compose" },
    { component: <ChatBubbleEffect />, name: "Chat Bubbles" },
    { component: <TypingIndicatorEffect />, name: "Typing Indicator" },
    { component: <NotificationBadgeEffect />, name: "Notification Badge" },
    { component: <MessageReactionsEffect />, name: "Message Reactions" },
    { component: <VoiceMessageEffect />, name: "Voice Message" },
    { component: <VideoCallUIEffect />, name: "Video Call UI" },
    { component: <ChatInputEffect />, name: "Chat Input" },
    { component: <ContactListEffect />, name: "Contact List" },
    { component: <ReadReceiptEffect />, name: "Read Receipts" },
    { component: <ChannelHeaderEffect />, name: "Channel Header" },
    { component: <MentionInputEffect />, name: "Mention Input" },
    { component: <NotificationToastEffect />, name: "Notification Toast" },
    { component: <EmailFolderEffect />, name: "Email Folders" },
    { component: <EmailActionsEffect />, name: "Email Actions" },
    { component: <IncomingCallEffect />, name: "Incoming Call" },
    { component: <ThreadReplyEffect />, name: "Thread Reply" },
    { component: <GroupAvatarEffect />, name: "Group Avatars" },
    { component: <QuickReplyEffect />, name: "Quick Replies" },
    { component: <MessageSearchEffect />, name: "Message Search" },
    { component: <StatusUpdateEffect />, name: "Status Selector" },
    { component: <PinnedMessageEffect />, name: "Pinned Message" },
    { component: <FileAttachmentEffect />, name: "File Attachment" },
    { component: <ScheduledMessageEffect />, name: "Scheduled Message" },
  ];

  const filtered = effects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={Mail} title="Communication & Messaging" description="25 components for email, chat, video calls, and team collaboration" gradient="#6366f1, #8b5cf6" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((effect, i) => <motion.div key={effect.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>{effect.component}</motion.div>)}
        </div>
      </div>
    </div>
  );
}