import React, { useState } from "react";
import { motion } from "framer-motion";
import { Gamepad2, Wrench, Users, Sparkles } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// ============================================
// 8-BIT PIXEL ART CHARACTERS (30)
// ============================================
const pixelCharacters = [
  { name: "Knight", frames: 4, color: "#6366f1" },
  { name: "Mage", frames: 4, color: "#8b5cf6" },
  { name: "Archer", frames: 4, color: "#22c55e" },
  { name: "Rogue", frames: 4, color: "#1e293b" },
  { name: "Warrior", frames: 4, color: "#ef4444" },
  { name: "Healer", frames: 4, color: "#fbbf24" },
  { name: "Paladin", frames: 4, color: "#f59e0b" },
  { name: "Necro", frames: 4, color: "#7c3aed" },
  { name: "Bard", frames: 4, color: "#ec4899" },
  { name: "Monk", frames: 4, color: "#f97316" },
  { name: "Ranger", frames: 4, color: "#10b981" },
  { name: "Berserker", frames: 4, color: "#dc2626" },
  { name: "Ninja", frames: 4, color: "#334155" },
  { name: "Samurai", frames: 4, color: "#0ea5e9" },
  { name: "Viking", frames: 4, color: "#78716c" },
  { name: "Pirate", frames: 4, color: "#a16207" },
  { name: "Wizard", frames: 4, color: "#4f46e5" },
  { name: "Druid", frames: 4, color: "#16a34a" },
  { name: "Assassin", frames: 4, color: "#1f2937" },
  { name: "Cleric", frames: 4, color: "#fcd34d" },
  { name: "Barbarian", frames: 4, color: "#b91c1c" },
  { name: "Thief", frames: 4, color: "#475569" },
  { name: "Hunter", frames: 4, color: "#65a30d" },
  { name: "Witch", frames: 4, color: "#9333ea" },
  { name: "Shaman", frames: 4, color: "#0d9488" },
  { name: "Guard", frames: 4, color: "#64748b" },
  { name: "King", frames: 4, color: "#eab308" },
  { name: "Queen", frames: 4, color: "#db2777" },
  { name: "Peasant", frames: 4, color: "#92400e" },
  { name: "Merchant", frames: 4, color: "#ca8a04" },
];

function PixelCharacterSprite({ char, index }) {
  const [frame, setFrame] = useState(0);
  
  React.useEffect(() => {
    const interval = setInterval(() => {
      setFrame(f => (f + 1) % 4);
    }, 200);
    return () => clearInterval(interval);
  }, []);

  // Simple 8x8 pixel character
  const pixels = [
    [0,0,1,1,1,1,0,0],
    [0,1,2,2,2,2,1,0],
    [0,1,2,3,3,2,1,0],
    [0,0,1,2,2,1,0,0],
    [0,1,1,1,1,1,1,0],
    [0,0,1,1,1,1,0,0],
    [0,1,0,1,1,0,1,0],
    [1,0,0,0,0,0,0,1],
  ];

  // Animate walk by shifting leg pixels
  const walkPixels = [...pixels];
  if (frame === 1 || frame === 3) {
    walkPixels[6] = [0,0,1,1,1,1,0,0];
    walkPixels[7] = [0,1,0,0,0,0,1,0];
  }

  return (
    <motion.div 
      whileHover={{ scale: 1.2 }}
      className="flex flex-col items-center gap-1"
    >
      <div className="grid gap-0" style={{ gridTemplateColumns: 'repeat(8, 1fr)' }}>
        {walkPixels.flat().map((p, i) => (
          <div 
            key={i} 
            className="w-2 h-2"
            style={{ 
              backgroundColor: p === 0 ? 'transparent' : 
                              p === 1 ? char.color : 
                              p === 2 ? '#fff' : '#1e293b' 
            }}
          />
        ))}
      </div>
      <p className="text-[9px] text-slate-400 truncate w-14 text-center">{char.name}</p>
    </motion.div>
  );
}

function PixelCharactersGallery() {
  return (
    <EffectCard 
      title="8-Bit Character Sprites (30)" 
      description="16x16 pixel walk cycle animations"
      code={`// 8-Bit Pixel Character with Walk Animation
const pixels = [
  [0,0,1,1,1,1,0,0],
  [0,1,2,2,2,2,1,0],
  [0,1,2,3,3,2,1,0],
  // ... more rows
];

// Colors: 0=transparent, 1=primary, 2=skin, 3=details`}
      prompt="Create an 8-bit pixel art character sprite sheet with 4-frame walk cycle, 16x16 pixels, retro NES game style. Include idle, walk left, walk right frames. Use limited color palette."
    >
      <div className="w-full max-h-64 overflow-auto bg-slate-950 rounded-lg p-3">
        <div className="grid grid-cols-6 sm:grid-cols-10 gap-2">
          {pixelCharacters.map((char, i) => (
            <PixelCharacterSprite key={i} char={char} index={i} />
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// ============================================
// 2D FLAT VECTOR CHARACTERS (30)
// ============================================
const vectorCharacters = [
  { name: "Hero", gradient: "from-blue-400 to-indigo-600", emoji: "🦸" },
  { name: "Villain", gradient: "from-purple-500 to-fuchsia-700", emoji: "🦹" },
  { name: "Princess", gradient: "from-pink-400 to-rose-500", emoji: "👸" },
  { name: "Prince", gradient: "from-blue-500 to-cyan-600", emoji: "🤴" },
  { name: "Wizard", gradient: "from-violet-500 to-purple-700", emoji: "🧙" },
  { name: "Knight", gradient: "from-slate-400 to-slate-600", emoji: "🛡️" },
  { name: "Archer", gradient: "from-green-500 to-emerald-700", emoji: "🏹" },
  { name: "Ninja", gradient: "from-slate-700 to-slate-900", emoji: "🥷" },
  { name: "Robot", gradient: "from-slate-400 to-zinc-600", emoji: "🤖" },
  { name: "Alien", gradient: "from-green-400 to-emerald-600", emoji: "👽" },
  { name: "Zombie", gradient: "from-green-600 to-lime-800", emoji: "🧟" },
  { name: "Ghost", gradient: "from-slate-200 to-slate-400", emoji: "👻" },
  { name: "Vampire", gradient: "from-red-600 to-rose-800", emoji: "🧛" },
  { name: "Werewolf", gradient: "from-amber-600 to-orange-800", emoji: "🐺" },
  { name: "Dragon", gradient: "from-red-500 to-orange-600", emoji: "🐉" },
  { name: "Fairy", gradient: "from-pink-300 to-fuchsia-500", emoji: "🧚" },
  { name: "Elf", gradient: "from-emerald-400 to-teal-600", emoji: "🧝" },
  { name: "Dwarf", gradient: "from-amber-500 to-orange-700", emoji: "🧔" },
  { name: "Goblin", gradient: "from-green-500 to-lime-700", emoji: "👺" },
  { name: "Orc", gradient: "from-green-600 to-emerald-800", emoji: "👹" },
  { name: "Pirate", gradient: "from-amber-600 to-orange-800", emoji: "🏴‍☠️" },
  { name: "Cowboy", gradient: "from-amber-500 to-yellow-700", emoji: "🤠" },
  { name: "Astronaut", gradient: "from-slate-300 to-slate-500", emoji: "👨‍🚀" },
  { name: "Scientist", gradient: "from-cyan-400 to-blue-600", emoji: "🧑‍🔬" },
  { name: "Chef", gradient: "from-slate-200 to-slate-400", emoji: "👨‍🍳" },
  { name: "Farmer", gradient: "from-green-500 to-lime-700", emoji: "👨‍🌾" },
  { name: "Firefighter", gradient: "from-red-500 to-orange-600", emoji: "👨‍🚒" },
  { name: "Police", gradient: "from-blue-500 to-indigo-700", emoji: "👮" },
  { name: "Doctor", gradient: "from-cyan-300 to-blue-500", emoji: "👨‍⚕️" },
  { name: "Teacher", gradient: "from-amber-400 to-orange-600", emoji: "👨‍🏫" },
];

function VectorCharacter({ char }) {
  const [frame, setFrame] = useState(0);
  
  React.useEffect(() => {
    const interval = setInterval(() => {
      setFrame(f => (f + 1) % 4);
    }, 250);
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div 
      whileHover={{ scale: 1.1 }}
      className="flex flex-col items-center gap-1"
    >
      <motion.div 
        animate={{ y: frame === 1 || frame === 3 ? -2 : 0 }}
        className={`w-12 h-12 rounded-xl bg-gradient-to-br ${char.gradient} flex items-center justify-center shadow-lg`}
      >
        <span className="text-2xl">{char.emoji}</span>
      </motion.div>
      <p className="text-[9px] text-slate-400 truncate w-12 text-center">{char.name}</p>
    </motion.div>
  );
}

function VectorCharactersGallery() {
  return (
    <EffectCard 
      title="2D Vector Characters (30)" 
      description="Flat style side-scroller animation frames"
      code={`// Flat Vector Character Component
<motion.div 
  animate={{ y: frame === 1 || frame === 3 ? -2 : 0 }}
  className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-400 to-indigo-600"
>
  <span className="text-2xl">🦸</span>
</motion.div>`}
      prompt="Create a 2D game character sprite sheet in flat vector style for side-scroller. Include 4 animation frames: idle, run frame 1, run frame 2, jump. Use glossy gradients and rounded shapes like Clash Royale style."
    >
      <div className="w-full max-h-64 overflow-auto bg-slate-950 rounded-lg p-3">
        <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
          {vectorCharacters.map((char, i) => (
            <VectorCharacter key={i} char={char} />
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// ============================================
// TOOLS SECTION
// ============================================
const tools = [
  { name: "Aseprite", desc: "Best pixel art editor", type: "Pixel Art", url: "https://aseprite.org", emoji: "🎨" },
  { name: "Spine 2D", desc: "2D animation tool", type: "Animation", url: "https://esotericsoftware.com", emoji: "🦴" },
  { name: "Piskel", desc: "Free online pixel editor", type: "Pixel Art", url: "https://piskelapp.com", emoji: "🖼️" },
  { name: "GraphicsGale", desc: "Sprite animation", type: "Pixel Art", url: "", emoji: "✨" },
  { name: "Pyxel Edit", desc: "Tileset editor", type: "Pixel Art", url: "", emoji: "🧩" },
  { name: "DragonBones", desc: "Free 2D animation", type: "Animation", url: "", emoji: "🐲" },
  { name: "Midjourney", desc: "AI image generation", type: "AI Generator", url: "", emoji: "🤖" },
  { name: "DALL-E", desc: "OpenAI image gen", type: "AI Generator", url: "", emoji: "🎯" },
  { name: "Stable Diffusion", desc: "Open source AI", type: "AI Generator", url: "", emoji: "🌊" },
];

function ToolsSection() {
  return (
    <EffectCard title="🛠️ Sprite Creation Tools" description="Best tools for pixel art & animation">
      <div className="grid grid-cols-3 gap-2 p-3">
        {tools.map((tool, i) => (
          <motion.div 
            key={i}
            whileHover={{ scale: 1.05 }}
            className="p-2 rounded-lg bg-slate-800/50 border border-slate-700 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <span className="text-xl">{tool.emoji}</span>
              <div>
                <p className="text-xs font-medium text-white">{tool.name}</p>
                <p className="text-[10px] text-slate-500">{tool.type}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// ============================================
// 100 FLAT VECTOR GAME UI ICONS
// ============================================
const gameUIIcons = [
  { name: "Fire", emoji: "🔥", gradient: "from-orange-500 to-red-600" },
  { name: "Water", emoji: "💧", gradient: "from-cyan-400 to-blue-600" },
  { name: "Coin", emoji: "🪙", gradient: "from-yellow-400 to-amber-600" },
  { name: "Gem", emoji: "💎", gradient: "from-cyan-300 to-blue-500" },
  { name: "Sword", emoji: "🗡️", gradient: "from-slate-300 to-slate-500" },
  { name: "Shield", emoji: "🛡️", gradient: "from-blue-400 to-indigo-600" },
  { name: "Potion", emoji: "🧪", gradient: "from-purple-400 to-fuchsia-600" },
  { name: "Key", emoji: "🗝️", gradient: "from-yellow-500 to-amber-700" },
  { name: "Heart", emoji: "❤️", gradient: "from-red-400 to-rose-600" },
  { name: "Star", emoji: "⭐", gradient: "from-yellow-300 to-orange-500" },
  { name: "Lightning", emoji: "⚡", gradient: "from-yellow-400 to-amber-500" },
  { name: "Bomb", emoji: "💣", gradient: "from-slate-600 to-slate-800" },
  { name: "Crystal", emoji: "🔮", gradient: "from-violet-400 to-purple-700" },
  { name: "Crown", emoji: "👑", gradient: "from-yellow-400 to-amber-600" },
  { name: "Mushroom", emoji: "🍄", gradient: "from-red-400 to-rose-600" },
  { name: "Cherry", emoji: "🍒", gradient: "from-red-500 to-rose-700" },
  { name: "Apple", emoji: "🍎", gradient: "from-red-400 to-red-600" },
  { name: "Banana", emoji: "🍌", gradient: "from-yellow-300 to-yellow-500" },
  { name: "Grapes", emoji: "🍇", gradient: "from-purple-400 to-violet-600" },
  { name: "Orange", emoji: "🍊", gradient: "from-orange-400 to-orange-600" },
  { name: "Axe", emoji: "🪓", gradient: "from-amber-600 to-orange-800" },
  { name: "Bow", emoji: "🏹", gradient: "from-amber-500 to-orange-700" },
  { name: "Hammer", emoji: "🔨", gradient: "from-slate-400 to-slate-600" },
  { name: "Pickaxe", emoji: "⛏️", gradient: "from-stone-400 to-stone-600" },
  { name: "Wand", emoji: "🪄", gradient: "from-violet-400 to-purple-600" },
  { name: "Trident", emoji: "🔱", gradient: "from-cyan-400 to-teal-600" },
  { name: "Tree", emoji: "🌲", gradient: "from-green-500 to-emerald-700" },
  { name: "Flower", emoji: "🌸", gradient: "from-pink-400 to-rose-500" },
  { name: "Sun", emoji: "☀️", gradient: "from-yellow-400 to-orange-500" },
  { name: "Moon", emoji: "🌙", gradient: "from-slate-300 to-indigo-400" },
  { name: "Cloud", emoji: "☁️", gradient: "from-slate-200 to-slate-400" },
  { name: "Rainbow", emoji: "🌈", gradient: "from-red-400 to-blue-400" },
  { name: "Leaf", emoji: "🍃", gradient: "from-green-400 to-emerald-600" },
  { name: "Rock", emoji: "🪨", gradient: "from-stone-400 to-stone-600" },
  { name: "Mountain", emoji: "⛰️", gradient: "from-stone-500 to-stone-700" },
  { name: "Wave", emoji: "🌊", gradient: "from-blue-400 to-cyan-600" },
  { name: "Castle", emoji: "🏰", gradient: "from-stone-400 to-stone-600" },
  { name: "House", emoji: "🏠", gradient: "from-amber-500 to-orange-600" },
  { name: "Tower", emoji: "🗼", gradient: "from-slate-400 to-slate-600" },
  { name: "Bridge", emoji: "🌉", gradient: "from-amber-600 to-amber-800" },
  { name: "Door", emoji: "🚪", gradient: "from-amber-700 to-amber-900" },
  { name: "Chest", emoji: "📦", gradient: "from-amber-500 to-amber-700" },
  { name: "Barrel", emoji: "🛢️", gradient: "from-amber-600 to-amber-800" },
  { name: "Tent", emoji: "⛺", gradient: "from-orange-500 to-red-600" },
  { name: "Fence", emoji: "🧱", gradient: "from-amber-600 to-amber-800" },
  { name: "Flag", emoji: "🚩", gradient: "from-red-500 to-rose-700" },
  { name: "Knight", emoji: "⚔️", gradient: "from-slate-400 to-slate-600" },
  { name: "Wizard", emoji: "🧙", gradient: "from-violet-500 to-purple-700" },
  { name: "Dragon", emoji: "🐉", gradient: "from-green-500 to-emerald-700" },
  { name: "Ghost", emoji: "👻", gradient: "from-slate-200 to-slate-400" },
  { name: "Skull", emoji: "💀", gradient: "from-slate-200 to-slate-400" },
  { name: "Monster", emoji: "👾", gradient: "from-purple-500 to-fuchsia-700" },
  { name: "Robot", emoji: "🤖", gradient: "from-slate-400 to-slate-600" },
  { name: "Alien", emoji: "👽", gradient: "from-green-400 to-emerald-600" },
  { name: "Ninja", emoji: "🥷", gradient: "from-slate-700 to-slate-900" },
  { name: "Princess", emoji: "👸", gradient: "from-pink-400 to-rose-500" },
  { name: "Sparkles", emoji: "✨", gradient: "from-yellow-300 to-amber-500" },
  { name: "Magic", emoji: "🪄", gradient: "from-violet-400 to-purple-600" },
  { name: "Portal", emoji: "🌀", gradient: "from-purple-500 to-fuchsia-700" },
  { name: "Scroll", emoji: "📜", gradient: "from-amber-200 to-amber-400" },
  { name: "Book", emoji: "📕", gradient: "from-red-600 to-rose-800" },
  { name: "Compass", emoji: "🧭", gradient: "from-amber-400 to-orange-600" },
  { name: "Map", emoji: "🗺️", gradient: "from-amber-300 to-amber-500" },
  { name: "Hourglass", emoji: "⏳", gradient: "from-amber-400 to-amber-600" },
  { name: "Bell", emoji: "🔔", gradient: "from-yellow-400 to-amber-600" },
  { name: "Lantern", emoji: "🏮", gradient: "from-red-500 to-orange-600" },
  { name: "Rocket", emoji: "🚀", gradient: "from-red-500 to-orange-600" },
  { name: "Ship", emoji: "🚢", gradient: "from-slate-500 to-slate-700" },
  { name: "Boat", emoji: "⛵", gradient: "from-slate-300 to-blue-400" },
  { name: "Plane", emoji: "✈️", gradient: "from-slate-300 to-slate-500" },
  { name: "Horse", emoji: "🐴", gradient: "from-amber-600 to-amber-800" },
  { name: "Cart", emoji: "🛒", gradient: "from-slate-400 to-slate-600" },
  { name: "Balloon", emoji: "🎈", gradient: "from-red-400 to-rose-600" },
  { name: "Meat", emoji: "🍖", gradient: "from-amber-600 to-orange-700" },
  { name: "Bread", emoji: "🍞", gradient: "from-amber-400 to-amber-600" },
  { name: "Cheese", emoji: "🧀", gradient: "from-yellow-400 to-amber-500" },
  { name: "Fish", emoji: "🐟", gradient: "from-blue-400 to-cyan-500" },
  { name: "Egg", emoji: "🥚", gradient: "from-amber-100 to-amber-300" },
  { name: "Cake", emoji: "🎂", gradient: "from-pink-400 to-rose-500" },
  { name: "Cookie", emoji: "🍪", gradient: "from-amber-500 to-amber-700" },
  { name: "Candy", emoji: "🍬", gradient: "from-pink-400 to-fuchsia-500" },
  { name: "Ice Cream", emoji: "🍦", gradient: "from-pink-300 to-rose-400" },
  { name: "Pizza", emoji: "🍕", gradient: "from-amber-400 to-orange-500" },
  { name: "Helmet", emoji: "⛑️", gradient: "from-slate-400 to-slate-600" },
  { name: "Boots", emoji: "🥾", gradient: "from-amber-600 to-amber-800" },
  { name: "Gloves", emoji: "🧤", gradient: "from-slate-300 to-slate-500" },
  { name: "Cape", emoji: "🦸", gradient: "from-red-500 to-rose-700" },
  { name: "Ring", emoji: "💍", gradient: "from-yellow-400 to-amber-600" },
  { name: "Amulet", emoji: "📿", gradient: "from-emerald-400 to-teal-600" },
  { name: "Trophy", emoji: "🏆", gradient: "from-yellow-400 to-amber-600" },
  { name: "Medal", emoji: "🏅", gradient: "from-yellow-500 to-orange-600" },
  { name: "Dice", emoji: "🎲", gradient: "from-slate-200 to-slate-400" },
  { name: "Cards", emoji: "🃏", gradient: "from-red-500 to-rose-600" },
  { name: "Target", emoji: "🎯", gradient: "from-red-500 to-rose-600" },
  { name: "Feather", emoji: "🪶", gradient: "from-amber-400 to-orange-500" },
  { name: "Bone", emoji: "🦴", gradient: "from-slate-200 to-slate-400" },
  { name: "Eye", emoji: "👁️", gradient: "from-blue-400 to-indigo-500" },
  { name: "Hand", emoji: "✋", gradient: "from-amber-300 to-orange-400" },
  { name: "Footprint", emoji: "👣", gradient: "from-amber-500 to-orange-600" },
];

function GameUIIcon({ item }) {
  return (
    <motion.div whileHover={{ scale: 1.15 }} className="relative group cursor-pointer">
      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${item.gradient} flex items-center justify-center shadow-lg`}>
        <span className="text-2xl">{item.emoji}</span>
      </div>
      <p className="text-[8px] text-slate-500 text-center mt-0.5 truncate w-12">{item.name}</p>
    </motion.div>
  );
}

function GameUIIconsGallery() {
  return (
    <EffectCard title="Flat Vector UI Icons (100)" description="Glossy mobile game style - Clash Royale / Candy Crush">
      <div className="w-full max-h-80 overflow-auto bg-slate-950 rounded-lg p-3">
        <div className="grid grid-cols-8 sm:grid-cols-10 gap-2">
          {gameUIIcons.map((item, i) => <GameUIIcon key={i} item={item} />)}
        </div>
      </div>
    </EffectCard>
  );
}

// ============================================
// 100 FLAT VECTOR ANIMATIONS/OBJECTS
// ============================================
const vectorAnimations = [
  // Animals (20)
  { name: "Cat", emoji: "🐱", gradient: "from-orange-400 to-amber-600", anim: "bounce" },
  { name: "Dog", emoji: "🐕", gradient: "from-amber-500 to-orange-700", anim: "bounce" },
  { name: "Bird", emoji: "🐦", gradient: "from-blue-400 to-cyan-600", anim: "fly" },
  { name: "Fish", emoji: "🐠", gradient: "from-cyan-400 to-blue-600", anim: "swim" },
  { name: "Rabbit", emoji: "🐰", gradient: "from-pink-300 to-rose-400", anim: "bounce" },
  { name: "Bear", emoji: "🐻", gradient: "from-amber-600 to-orange-800", anim: "bounce" },
  { name: "Fox", emoji: "🦊", gradient: "from-orange-500 to-red-600", anim: "bounce" },
  { name: "Wolf", emoji: "🐺", gradient: "from-slate-500 to-slate-700", anim: "bounce" },
  { name: "Lion", emoji: "🦁", gradient: "from-amber-500 to-orange-600", anim: "bounce" },
  { name: "Tiger", emoji: "🐯", gradient: "from-orange-500 to-amber-700", anim: "bounce" },
  { name: "Elephant", emoji: "🐘", gradient: "from-slate-400 to-slate-600", anim: "bounce" },
  { name: "Monkey", emoji: "🐵", gradient: "from-amber-500 to-orange-700", anim: "bounce" },
  { name: "Penguin", emoji: "🐧", gradient: "from-slate-700 to-slate-900", anim: "bounce" },
  { name: "Owl", emoji: "🦉", gradient: "from-amber-600 to-orange-800", anim: "fly" },
  { name: "Eagle", emoji: "🦅", gradient: "from-amber-700 to-stone-700", anim: "fly" },
  { name: "Butterfly", emoji: "🦋", gradient: "from-blue-400 to-purple-500", anim: "fly" },
  { name: "Bee", emoji: "🐝", gradient: "from-yellow-400 to-amber-500", anim: "fly" },
  { name: "Snake", emoji: "🐍", gradient: "from-green-500 to-emerald-700", anim: "wiggle" },
  { name: "Frog", emoji: "🐸", gradient: "from-green-400 to-emerald-600", anim: "bounce" },
  { name: "Turtle", emoji: "🐢", gradient: "from-green-500 to-teal-700", anim: "wiggle" },
  // Houses & Buildings (20)
  { name: "Cottage", emoji: "🏡", gradient: "from-amber-500 to-orange-700", anim: "none" },
  { name: "Castle", emoji: "🏰", gradient: "from-stone-400 to-slate-600", anim: "none" },
  { name: "Tower", emoji: "🗼", gradient: "from-slate-300 to-slate-500", anim: "none" },
  { name: "Temple", emoji: "⛩️", gradient: "from-red-500 to-rose-700", anim: "none" },
  { name: "Church", emoji: "⛪", gradient: "from-slate-200 to-slate-400", anim: "none" },
  { name: "Factory", emoji: "🏭", gradient: "from-slate-500 to-slate-700", anim: "smoke" },
  { name: "Hospital", emoji: "🏥", gradient: "from-slate-200 to-blue-300", anim: "none" },
  { name: "School", emoji: "🏫", gradient: "from-amber-400 to-orange-600", anim: "none" },
  { name: "Bank", emoji: "🏦", gradient: "from-slate-300 to-slate-500", anim: "none" },
  { name: "Hotel", emoji: "🏨", gradient: "from-blue-400 to-indigo-600", anim: "none" },
  { name: "Shop", emoji: "🏪", gradient: "from-amber-400 to-orange-500", anim: "none" },
  { name: "Windmill", emoji: "🏞️", gradient: "from-amber-500 to-orange-600", anim: "spin" },
  { name: "Lighthouse", emoji: "🗼", gradient: "from-slate-200 to-slate-400", anim: "pulse" },
  { name: "Barn", emoji: "🏚️", gradient: "from-red-600 to-rose-800", anim: "none" },
  { name: "Treehouse", emoji: "🌳", gradient: "from-green-500 to-amber-600", anim: "none" },
  { name: "Igloo", emoji: "🏠", gradient: "from-cyan-200 to-blue-300", anim: "none" },
  { name: "Pyramid", emoji: "🔺", gradient: "from-amber-400 to-yellow-600", anim: "none" },
  { name: "Tent", emoji: "⛺", gradient: "from-orange-400 to-red-500", anim: "none" },
  { name: "Well", emoji: "🪣", gradient: "from-stone-500 to-slate-600", anim: "none" },
  { name: "Fountain", emoji: "⛲", gradient: "from-cyan-400 to-blue-500", anim: "splash" },
  // Effects & Magic (20)
  { name: "Fire Burst", emoji: "🔥", gradient: "from-orange-500 to-red-600", anim: "pulse" },
  { name: "Ice Shard", emoji: "❄️", gradient: "from-cyan-300 to-blue-500", anim: "pulse" },
  { name: "Lightning", emoji: "⚡", gradient: "from-yellow-400 to-amber-500", anim: "flash" },
  { name: "Tornado", emoji: "🌪️", gradient: "from-slate-400 to-slate-600", anim: "spin" },
  { name: "Explosion", emoji: "💥", gradient: "from-orange-500 to-red-600", anim: "pulse" },
  { name: "Smoke", emoji: "💨", gradient: "from-slate-300 to-slate-500", anim: "float" },
  { name: "Sparkle", emoji: "✨", gradient: "from-yellow-300 to-amber-500", anim: "flash" },
  { name: "Rainbow", emoji: "🌈", gradient: "from-red-400 to-violet-500", anim: "none" },
  { name: "Meteor", emoji: "☄️", gradient: "from-orange-500 to-red-700", anim: "fall" },
  { name: "Comet", emoji: "💫", gradient: "from-cyan-400 to-blue-600", anim: "fly" },
  { name: "Portal", emoji: "🌀", gradient: "from-purple-500 to-fuchsia-700", anim: "spin" },
  { name: "Shield", emoji: "🛡️", gradient: "from-blue-400 to-indigo-600", anim: "pulse" },
  { name: "Heal", emoji: "💚", gradient: "from-green-400 to-emerald-600", anim: "pulse" },
  { name: "Poison", emoji: "☠️", gradient: "from-purple-500 to-fuchsia-700", anim: "bubble" },
  { name: "Sleep", emoji: "💤", gradient: "from-indigo-400 to-violet-600", anim: "float" },
  { name: "Stun", emoji: "💫", gradient: "from-yellow-400 to-amber-500", anim: "spin" },
  { name: "Buff", emoji: "⬆️", gradient: "from-green-400 to-emerald-600", anim: "float" },
  { name: "Debuff", emoji: "⬇️", gradient: "from-red-500 to-rose-700", anim: "fall" },
  { name: "Aura", emoji: "🔵", gradient: "from-blue-400 to-indigo-600", anim: "pulse" },
  { name: "Beam", emoji: "🔷", gradient: "from-cyan-400 to-blue-600", anim: "flash" },
  // Objects & Items (20)
  { name: "Chest", emoji: "📦", gradient: "from-amber-500 to-orange-700", anim: "bounce" },
  { name: "Barrel", emoji: "🛢️", gradient: "from-amber-600 to-orange-800", anim: "none" },
  { name: "Crate", emoji: "📦", gradient: "from-amber-400 to-amber-600", anim: "none" },
  { name: "Sign", emoji: "🪧", gradient: "from-amber-500 to-orange-600", anim: "none" },
  { name: "Lamp", emoji: "🪔", gradient: "from-yellow-400 to-amber-600", anim: "pulse" },
  { name: "Candle", emoji: "🕯️", gradient: "from-amber-300 to-orange-500", anim: "pulse" },
  { name: "Torch", emoji: "🔦", gradient: "from-orange-500 to-red-600", anim: "pulse" },
  { name: "Campfire", emoji: "🔥", gradient: "from-orange-500 to-red-600", anim: "pulse" },
  { name: "Cauldron", emoji: "🫕", gradient: "from-slate-600 to-slate-800", anim: "bubble" },
  { name: "Mirror", emoji: "🪞", gradient: "from-cyan-200 to-blue-300", anim: "flash" },
  { name: "Clock", emoji: "🕐", gradient: "from-amber-400 to-orange-600", anim: "spin" },
  { name: "Compass", emoji: "🧭", gradient: "from-amber-400 to-orange-600", anim: "spin" },
  { name: "Telescope", emoji: "🔭", gradient: "from-slate-400 to-slate-600", anim: "none" },
  { name: "Anchor", emoji: "⚓", gradient: "from-slate-500 to-slate-700", anim: "none" },
  { name: "Wheel", emoji: "☸️", gradient: "from-amber-600 to-orange-800", anim: "spin" },
  { name: "Bell", emoji: "🔔", gradient: "from-yellow-400 to-amber-600", anim: "bounce" },
  { name: "Horn", emoji: "📯", gradient: "from-amber-500 to-orange-700", anim: "none" },
  { name: "Drum", emoji: "🥁", gradient: "from-red-500 to-rose-700", anim: "bounce" },
  { name: "Harp", emoji: "🎵", gradient: "from-amber-400 to-orange-600", anim: "none" },
  { name: "Crown", emoji: "👑", gradient: "from-yellow-400 to-amber-600", anim: "bounce" },
  // Characters (20)
  { name: "Hero", emoji: "🦸", gradient: "from-blue-500 to-indigo-700", anim: "bounce" },
  { name: "Villain", emoji: "🦹", gradient: "from-purple-600 to-fuchsia-800", anim: "bounce" },
  { name: "Wizard", emoji: "🧙", gradient: "from-violet-500 to-purple-700", anim: "float" },
  { name: "Warrior", emoji: "⚔️", gradient: "from-slate-500 to-slate-700", anim: "bounce" },
  { name: "Archer", emoji: "🏹", gradient: "from-green-500 to-emerald-700", anim: "bounce" },
  { name: "Mage", emoji: "🔮", gradient: "from-purple-400 to-violet-600", anim: "float" },
  { name: "Healer", emoji: "💚", gradient: "from-green-400 to-emerald-600", anim: "pulse" },
  { name: "Tank", emoji: "🛡️", gradient: "from-slate-400 to-slate-600", anim: "bounce" },
  { name: "Rogue", emoji: "🗡️", gradient: "from-slate-600 to-slate-800", anim: "bounce" },
  { name: "Ranger", emoji: "🌲", gradient: "from-green-500 to-teal-700", anim: "bounce" },
  { name: "Paladin", emoji: "✨", gradient: "from-yellow-400 to-amber-600", anim: "pulse" },
  { name: "Necro", emoji: "💀", gradient: "from-purple-600 to-violet-800", anim: "float" },
  { name: "Bard", emoji: "🎵", gradient: "from-pink-400 to-rose-600", anim: "bounce" },
  { name: "Monk", emoji: "🧘", gradient: "from-orange-400 to-amber-600", anim: "float" },
  { name: "Druid", emoji: "🌿", gradient: "from-green-400 to-emerald-600", anim: "float" },
  { name: "Shaman", emoji: "🪄", gradient: "from-teal-400 to-cyan-600", anim: "float" },
  { name: "Assassin", emoji: "🥷", gradient: "from-slate-700 to-slate-900", anim: "bounce" },
  { name: "Berserker", emoji: "💢", gradient: "from-red-500 to-rose-700", anim: "bounce" },
  { name: "Cleric", emoji: "⛪", gradient: "from-amber-300 to-yellow-500", anim: "pulse" },
  { name: "Summoner", emoji: "🌀", gradient: "from-purple-500 to-fuchsia-700", anim: "spin" },
];

function AnimatedVectorItem({ item }) {
  const getAnimation = () => {
    switch(item.anim) {
      case "bounce": return { y: [0, -4, 0] };
      case "fly": return { y: [0, -6, 0], x: [0, 2, 0] };
      case "swim": return { x: [0, 4, 0], rotate: [0, 5, 0, -5, 0] };
      case "spin": return { rotate: 360 };
      case "pulse": return { scale: [1, 1.1, 1] };
      case "float": return { y: [0, -3, 0] };
      case "flash": return { opacity: [1, 0.5, 1] };
      case "wiggle": return { rotate: [0, 5, -5, 0] };
      case "bubble": return { scale: [1, 1.05, 1], y: [0, -2, 0] };
      case "smoke": return { opacity: [0.8, 1, 0.8], y: [0, -2, 0] };
      case "splash": return { scale: [1, 1.1, 1] };
      case "fall": return { y: [0, 4, 0] };
      default: return {};
    }
  };

  return (
    <motion.div 
      whileHover={{ scale: 1.15 }}
      className="flex flex-col items-center gap-0.5 cursor-pointer"
    >
      <motion.div 
        animate={getAnimation()}
        transition={{ duration: item.anim === "spin" ? 3 : 1, repeat: Infinity, ease: "easeInOut" }}
        className={`w-11 h-11 rounded-xl bg-gradient-to-br ${item.gradient} flex items-center justify-center shadow-md`}
      >
        <span className="text-xl">{item.emoji}</span>
      </motion.div>
      <p className="text-[7px] text-slate-500 truncate w-11 text-center">{item.name}</p>
    </motion.div>
  );
}

function VectorAnimationsGallery() {
  return (
    <EffectCard title="Vector Animations & Objects (100)" description="Animated characters, animals, buildings, effects">
      <div className="w-full max-h-80 overflow-auto bg-slate-950 rounded-lg p-3">
        <div className="grid grid-cols-8 sm:grid-cols-10 gap-2">
          {vectorAnimations.map((item, i) => <AnimatedVectorItem key={i} item={item} />)}
        </div>
      </div>
    </EffectCard>
  );
}

// ============================================
// MAIN PAGE
// ============================================
const allEffects = [
  { component: <PixelCharactersGallery />, name: "8-Bit Pixel Characters (30)", category: "pixel" },
  { component: <VectorCharactersGallery />, name: "2D Vector Characters (30)", category: "vector" },
  { component: <ToolsSection />, name: "Sprite Creation Tools", category: "tools" },
  { component: <GameUIIconsGallery />, name: "Flat Vector UI Icons (100)", category: "icons" },
  { component: <VectorAnimationsGallery />, name: "Vector Animations (100)", category: "animations" },
];

const categories = [
  { id: "all", label: "All" },
  { id: "pixel", label: "8-Bit Pixel" },
  { id: "vector", label: "2D Vector" },
  { id: "icons", label: "UI Icons" },
  { id: "animations", label: "Animations" },
  { id: "tools", label: "Tools" },
];

export default function PixelAssets() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const filtered = allEffects.filter(e => {
    const matchesSearch = e.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === "all" || e.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen">
      <CategoryHeader 
        icon={Gamepad2} 
        title="Game Art Assets" 
        description="260+ sprites, icons, and animations in pixel art & flat vector styles" 
        gradient="#10b981, #06b6d4" 
      />
      <div className="max-w-7xl mx-auto px-4 pb-20">
        <div className="mb-6 flex flex-wrap gap-2">
          {categories.map(cat => (
            <button 
              key={cat.id} 
              onClick={() => setActiveCategory(cat.id)} 
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${activeCategory === cat.id ? "bg-gradient-to-r from-green-500 to-cyan-500 text-white shadow-lg" : "bg-slate-800 text-slate-400 hover:bg-slate-700"}`}
            >
              {cat.label}
            </button>
          ))}
        </div>
        
        <SearchFilter 
          searchQuery={searchQuery} 
          setSearchQuery={setSearchQuery} 
          activeCategory={activeCategory} 
          setActiveCategory={setActiveCategory} 
          resultCount={filtered.length} 
        />
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filtered.map((effect, i) => <div key={i}>{effect.component}</div>)}
        </div>
      </div>
    </div>
  );
}