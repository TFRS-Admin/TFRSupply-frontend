import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Palette, Copy, Check, Info, Lightbulb, Pipette, RefreshCw, Star, Eye } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import CategoryHeader from "@/components/effects/CategoryHeader";

// Color Theory Palettes
const colorTheories = [
  {
    name: "60-30-10 Rule",
    description: "The classic interior design rule: 60% dominant, 30% secondary, 10% accent",
    example: { dominant: "#1e293b", secondary: "#8b5cf6", accent: "#06b6d4" },
    usage: "Dashboard backgrounds, enterprise apps, professional interfaces"
  },
  {
    name: "Analogous",
    description: "Colors adjacent on the color wheel for harmonious, cohesive designs",
    example: { primary: "#8b5cf6", secondary: "#a855f7", tertiary: "#d946ef" },
    usage: "Brand consistency, gradient backgrounds, unified themes"
  },
  {
    name: "Complementary",
    description: "Opposite colors on the wheel for high contrast and visual impact",
    example: { primary: "#8b5cf6", complement: "#b4f60c" },
    usage: "CTAs, buttons, important alerts, attention-grabbing elements"
  },
  {
    name: "Triadic",
    description: "Three evenly spaced colors for vibrant, balanced palettes",
    example: { primary: "#8b5cf6", secondary: "#f6c60c", tertiary: "#0cf6a8" },
    usage: "Playful apps, creative portfolios, children's products"
  },
  {
    name: "Split-Complementary",
    description: "A color plus two adjacent to its complement for softer contrast",
    example: { primary: "#8b5cf6", split1: "#a8f60c", split2: "#f6e00c" },
    usage: "More nuanced designs that need contrast without harshness"
  },
  {
    name: "Monochromatic",
    description: "Single hue with varying saturation and lightness",
    example: { dark: "#4c1d95", mid: "#7c3aed", light: "#c4b5fd" },
    usage: "Elegant designs, minimalist interfaces, professional apps"
  }
];

// Pre-made color schemes
const colorSchemes = [
  { name: "Cyberpunk Neon", colors: ["#0f0f23", "#8b5cf6", "#06b6d4", "#f472b6", "#22d3ee"], tags: ["dark", "vibrant"] },
  { name: "Forest Dawn", colors: ["#1a2e1a", "#22c55e", "#86efac", "#fbbf24", "#f8fafc"], tags: ["nature", "calm"] },
  { name: "Ocean Depths", colors: ["#0c1929", "#0284c7", "#38bdf8", "#06b6d4", "#f0f9ff"], tags: ["blue", "professional"] },
  { name: "Sunset Glow", colors: ["#1f1523", "#f97316", "#fb923c", "#fbbf24", "#fef3c7"], tags: ["warm", "energetic"] },
  { name: "Midnight Purple", colors: ["#0f0a1e", "#7c3aed", "#a78bfa", "#c4b5fd", "#f5f3ff"], tags: ["dark", "elegant"] },
  { name: "Coral Reef", colors: ["#1e1b4b", "#f43f5e", "#fb7185", "#fda4af", "#fff1f2"], tags: ["pink", "playful"] },
  { name: "Emerald Night", colors: ["#022c22", "#10b981", "#34d399", "#6ee7b7", "#d1fae5"], tags: ["green", "calm"] },
  { name: "Fire & Ice", colors: ["#18181b", "#ef4444", "#3b82f6", "#f97316", "#60a5fa"], tags: ["contrast", "bold"] },
  { name: "Grayscale Pro", colors: ["#09090b", "#27272a", "#52525b", "#a1a1aa", "#f4f4f5"], tags: ["minimal", "professional"] },
  { name: "Cotton Candy", colors: ["#fdf2f8", "#f9a8d4", "#a78bfa", "#67e8f9", "#fef08a"], tags: ["light", "playful"] },
  { name: "Terminal Green", colors: ["#0a0a0a", "#22c55e", "#4ade80", "#166534", "#052e16"], tags: ["retro", "tech"] },
  { name: "Autumn Leaves", colors: ["#1c1917", "#c2410c", "#ea580c", "#fbbf24", "#fef3c7"], tags: ["warm", "cozy"] },
];

// Tailwind color palette (named colors)
const tailwindColors = {
  slate: ["slate-50", "slate-100", "slate-200", "slate-300", "slate-400", "slate-500", "slate-600", "slate-700", "slate-800", "slate-900", "slate-950"],
  violet: ["violet-50", "violet-100", "violet-200", "violet-300", "violet-400", "violet-500", "violet-600", "violet-700", "violet-800", "violet-900", "violet-950"],
  purple: ["purple-50", "purple-100", "purple-200", "purple-300", "purple-400", "purple-500", "purple-600", "purple-700", "purple-800", "purple-900", "purple-950"],
  blue: ["blue-50", "blue-100", "blue-200", "blue-300", "blue-400", "blue-500", "blue-600", "blue-700", "blue-800", "blue-900", "blue-950"],
  cyan: ["cyan-50", "cyan-100", "cyan-200", "cyan-300", "cyan-400", "cyan-500", "cyan-600", "cyan-700", "cyan-800", "cyan-900", "cyan-950"],
  teal: ["teal-50", "teal-100", "teal-200", "teal-300", "teal-400", "teal-500", "teal-600", "teal-700", "teal-800", "teal-900", "teal-950"],
  green: ["green-50", "green-100", "green-200", "green-300", "green-400", "green-500", "green-600", "green-700", "green-800", "green-900", "green-950"],
  amber: ["amber-50", "amber-100", "amber-200", "amber-300", "amber-400", "amber-500", "amber-600", "amber-700", "amber-800", "amber-900", "amber-950"],
  orange: ["orange-50", "orange-100", "orange-200", "orange-300", "orange-400", "orange-500", "orange-600", "orange-700", "orange-800", "orange-900", "orange-950"],
  red: ["red-50", "red-100", "red-200", "red-300", "red-400", "red-500", "red-600", "red-700", "red-800", "red-900", "red-950"],
  pink: ["pink-50", "pink-100", "pink-200", "pink-300", "pink-400", "pink-500", "pink-600", "pink-700", "pink-800", "pink-900", "pink-950"],
  rose: ["rose-50", "rose-100", "rose-200", "rose-300", "rose-400", "rose-500", "rose-600", "rose-700", "rose-800", "rose-900", "rose-950"],
};

const tailwindColorValues = {
  "slate-50": "#f8fafc", "slate-100": "#f1f5f9", "slate-200": "#e2e8f0", "slate-300": "#cbd5e1", "slate-400": "#94a3b8", "slate-500": "#64748b", "slate-600": "#475569", "slate-700": "#334155", "slate-800": "#1e293b", "slate-900": "#0f172a", "slate-950": "#020617",
  "violet-50": "#f5f3ff", "violet-100": "#ede9fe", "violet-200": "#ddd6fe", "violet-300": "#c4b5fd", "violet-400": "#a78bfa", "violet-500": "#8b5cf6", "violet-600": "#7c3aed", "violet-700": "#6d28d9", "violet-800": "#5b21b6", "violet-900": "#4c1d95", "violet-950": "#2e1065",
  "purple-50": "#faf5ff", "purple-100": "#f3e8ff", "purple-200": "#e9d5ff", "purple-300": "#d8b4fe", "purple-400": "#c084fc", "purple-500": "#a855f7", "purple-600": "#9333ea", "purple-700": "#7e22ce", "purple-800": "#6b21a8", "purple-900": "#581c87", "purple-950": "#3b0764",
  "blue-50": "#eff6ff", "blue-100": "#dbeafe", "blue-200": "#bfdbfe", "blue-300": "#93c5fd", "blue-400": "#60a5fa", "blue-500": "#3b82f6", "blue-600": "#2563eb", "blue-700": "#1d4ed8", "blue-800": "#1e40af", "blue-900": "#1e3a8a", "blue-950": "#172554",
  "cyan-50": "#ecfeff", "cyan-100": "#cffafe", "cyan-200": "#a5f3fc", "cyan-300": "#67e8f9", "cyan-400": "#22d3ee", "cyan-500": "#06b6d4", "cyan-600": "#0891b2", "cyan-700": "#0e7490", "cyan-800": "#155e75", "cyan-900": "#164e63", "cyan-950": "#083344",
  "teal-50": "#f0fdfa", "teal-100": "#ccfbf1", "teal-200": "#99f6e4", "teal-300": "#5eead4", "teal-400": "#2dd4bf", "teal-500": "#14b8a6", "teal-600": "#0d9488", "teal-700": "#0f766e", "teal-800": "#115e59", "teal-900": "#134e4a", "teal-950": "#042f2e",
  "green-50": "#f0fdf4", "green-100": "#dcfce7", "green-200": "#bbf7d0", "green-300": "#86efac", "green-400": "#4ade80", "green-500": "#22c55e", "green-600": "#16a34a", "green-700": "#15803d", "green-800": "#166534", "green-900": "#14532d", "green-950": "#052e16",
  "amber-50": "#fffbeb", "amber-100": "#fef3c7", "amber-200": "#fde68a", "amber-300": "#fcd34d", "amber-400": "#fbbf24", "amber-500": "#f59e0b", "amber-600": "#d97706", "amber-700": "#b45309", "amber-800": "#92400e", "amber-900": "#78350f", "amber-950": "#451a03",
  "orange-50": "#fff7ed", "orange-100": "#ffedd5", "orange-200": "#fed7aa", "orange-300": "#fdba74", "orange-400": "#fb923c", "orange-500": "#f97316", "orange-600": "#ea580c", "orange-700": "#c2410c", "orange-800": "#9a3412", "orange-900": "#7c2d12", "orange-950": "#431407",
  "red-50": "#fef2f2", "red-100": "#fee2e2", "red-200": "#fecaca", "red-300": "#fca5a5", "red-400": "#f87171", "red-500": "#ef4444", "red-600": "#dc2626", "red-700": "#b91c1c", "red-800": "#991b1b", "red-900": "#7f1d1d", "red-950": "#450a0a",
  "pink-50": "#fdf2f8", "pink-100": "#fce7f3", "pink-200": "#fbcfe8", "pink-300": "#f9a8d4", "pink-400": "#f472b6", "pink-500": "#ec4899", "pink-600": "#db2777", "pink-700": "#be185d", "pink-800": "#9d174d", "pink-900": "#831843", "pink-950": "#500724",
  "rose-50": "#fff1f2", "rose-100": "#ffe4e6", "rose-200": "#fecdd3", "rose-300": "#fda4af", "rose-400": "#fb7185", "rose-500": "#f43f5e", "rose-600": "#e11d48", "rose-700": "#be123c", "rose-800": "#9f1239", "rose-900": "#881337", "rose-950": "#4c0519",
};

// Color wheel component
function ColorWheel({ onColorSelect }) {
  const [rotation, setRotation] = useState(0);
  
  const generateHSLColor = (angle) => {
    const hue = (angle + rotation) % 360;
    return `hsl(${hue}, 70%, 50%)`;
  };

  return (
    <div className="relative w-48 h-48 mx-auto">
      <motion.div
        className="w-full h-full rounded-full"
        style={{
          background: `conic-gradient(
            hsl(0, 70%, 50%),
            hsl(60, 70%, 50%),
            hsl(120, 70%, 50%),
            hsl(180, 70%, 50%),
            hsl(240, 70%, 50%),
            hsl(300, 70%, 50%),
            hsl(360, 70%, 50%)
          )`,
          transform: `rotate(${rotation}deg)`
        }}
        drag
        dragConstraints={{ top: 0, left: 0, right: 0, bottom: 0 }}
        onDrag={(e, info) => setRotation(r => r + info.delta.x)}
      />
      <div className="absolute inset-8 rounded-full bg-slate-900 flex items-center justify-center">
        <button 
          onClick={() => setRotation(r => r + 30)}
          className="p-2 rounded-full hover:bg-slate-800"
        >
          <RefreshCw className="w-5 h-5 text-slate-400" />
        </button>
      </div>
      {[0, 60, 120, 180, 240, 300].map((angle) => (
        <button
          key={angle}
          onClick={() => onColorSelect(generateHSLColor(angle))}
          className="absolute w-4 h-4 rounded-full border-2 border-white shadow-lg transform -translate-x-1/2 -translate-y-1/2 hover:scale-150 transition-transform"
          style={{
            backgroundColor: generateHSLColor(angle),
            top: `${50 - 40 * Math.cos((angle + rotation) * Math.PI / 180)}%`,
            left: `${50 + 40 * Math.sin((angle + rotation) * Math.PI / 180)}%`
          }}
        />
      ))}
    </div>
  );
}

// Color picker with hex input
function ColorPicker({ color, onChange, label }) {
  const [copied, setCopied] = useState(false);

  const copyColor = async () => {
    await navigator.clipboard.writeText(color);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="space-y-2">
      {label && <span className="text-xs text-slate-400">{label}</span>}
      <div className="flex gap-2 items-center">
        <div 
          className="w-10 h-10 rounded-lg border border-slate-600 cursor-pointer relative overflow-hidden"
          style={{ backgroundColor: color }}
        >
          <input
            type="color"
            value={color}
            onChange={(e) => onChange(e.target.value)}
            className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
          />
        </div>
        <Input
          value={color}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 bg-slate-800 border-slate-700 text-white font-mono text-sm"
        />
        <button
          onClick={copyColor}
          className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
        >
          {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
}

// Color scheme card
function SchemeCard({ scheme }) {
  const [copiedIdx, setCopiedIdx] = useState(null);

  const copyColor = async (color, idx) => {
    await navigator.clipboard.writeText(color);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 1500);
  };

  const copyAll = async () => {
    await navigator.clipboard.writeText(scheme.colors.join(", "));
    setCopiedIdx("all");
    setTimeout(() => setCopiedIdx(null), 1500);
  };

  return (
    <Card className="bg-slate-900/50 border-slate-800 overflow-hidden group hover:border-violet-500/50 transition-colors">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-white text-base">{scheme.name}</CardTitle>
          <button
            onClick={copyAll}
            className="text-xs px-2 py-1 rounded bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          >
            {copiedIdx === "all" ? "Copied!" : "Copy All"}
          </button>
        </div>
        <div className="flex gap-1 mt-1">
          {scheme.tags.map(tag => (
            <span key={tag} className="px-2 py-0.5 text-xs rounded bg-slate-800 text-slate-500">{tag}</span>
          ))}
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex rounded-lg overflow-hidden h-16">
          {scheme.colors.map((color, idx) => (
            <button
              key={idx}
              onClick={() => copyColor(color, idx)}
              className="flex-1 relative group/color transition-transform hover:scale-y-110 origin-bottom"
              style={{ backgroundColor: color }}
            >
              <span className="absolute inset-0 flex items-center justify-center opacity-0 group-hover/color:opacity-100 transition-opacity text-xs font-mono text-white bg-black/50">
                {copiedIdx === idx ? <Check className="w-3 h-3" /> : color}
              </span>
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// Color theory card
function TheoryCard({ theory }) {
  const [copied, setCopied] = useState(false);
  const colors = Object.values(theory.example);

  const copyColors = async () => {
    await navigator.clipboard.writeText(colors.join(", "));
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <Card className="bg-slate-900/50 border-slate-800">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-white text-lg">{theory.name}</CardTitle>
            <p className="text-sm text-slate-400 mt-1">{theory.description}</p>
          </div>
          <button onClick={copyColors} className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700">
            {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4 text-slate-400" />}
          </button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          {colors.map((color, i) => (
            <div key={i} className="flex-1 text-center">
              <div className="h-12 rounded-lg mb-2" style={{ backgroundColor: color }} />
              <span className="text-xs font-mono text-slate-400">{color}</span>
            </div>
          ))}
        </div>
        <div className="flex items-start gap-2 p-3 rounded-lg bg-slate-800/50">
          <Lightbulb className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
          <span className="text-xs text-slate-400">{theory.usage}</span>
        </div>
      </CardContent>
    </Card>
  );
}

// Tailwind color chip
function TailwindColorChip({ name, hex }) {
  const [copied, setCopied] = useState(false);
  const isLight = name.includes("50") || name.includes("100") || name.includes("200");
  
  const copy = async () => {
    await navigator.clipboard.writeText(name);
    setCopied(true);
    setTimeout(() => setCopied(false), 1000);
  };

  return (
    <motion.button
      onClick={copy}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="flex flex-col items-center p-2 rounded-lg hover:ring-2 ring-white/20 transition-all"
      style={{ backgroundColor: hex }}
    >
      <span className={`text-xs font-mono ${isLight ? "text-slate-700" : "text-white"}`}>
        {copied ? "✓" : name}
      </span>
      <span className={`text-[10px] font-mono ${isLight ? "text-slate-500" : "text-white/60"}`}>{hex}</span>
    </motion.button>
  );
}

// Contrast checker
function ContrastChecker() {
  const [bg, setBg] = useState("#1e293b");
  const [fg, setFg] = useState("#ffffff");

  const getLuminance = (hex) => {
    const rgb = hex.match(/\w\w/g).map(x => parseInt(x, 16) / 255);
    const [r, g, b] = rgb.map(c => c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4));
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  };

  const getContrastRatio = () => {
    const l1 = getLuminance(bg);
    const l2 = getLuminance(fg);
    const lighter = Math.max(l1, l2);
    const darker = Math.min(l1, l2);
    return ((lighter + 0.05) / (darker + 0.05)).toFixed(2);
  };

  const ratio = getContrastRatio();
  const wcagAA = ratio >= 4.5;
  const wcagAAA = ratio >= 7;

  return (
    <Card className="bg-slate-900/50 border-slate-800">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Pipette className="w-5 h-5" /> Contrast Checker
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <ColorPicker color={bg} onChange={setBg} label="Background" />
          <ColorPicker color={fg} onChange={setFg} label="Foreground" />
        </div>
        <div className="p-6 rounded-xl text-center" style={{ backgroundColor: bg, color: fg }}>
          <p className="text-2xl font-bold mb-1">Sample Text</p>
          <p className="text-sm">The quick brown fox jumps</p>
        </div>
        <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800">
          <div>
            <p className="text-3xl font-bold text-white">{ratio}:1</p>
            <p className="text-sm text-slate-400">Contrast Ratio</p>
          </div>
          <div className="flex gap-2">
            <span className={`px-3 py-1 rounded-full text-sm ${wcagAA ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}>
              AA {wcagAA ? "✓" : "✗"}
            </span>
            <span className={`px-3 py-1 rounded-full text-sm ${wcagAAA ? "bg-green-500/20 text-green-400" : "bg-amber-500/20 text-amber-400"}`}>
              AAA {wcagAAA ? "✓" : "✗"}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function ColorSchemes() {
  const [selectedColor, setSelectedColor] = useState("#8b5cf6");

  return (
    <div className="min-h-screen">
      <CategoryHeader 
        icon={Palette} 
        title="Color Schemes" 
        description="Master color theory, explore harmonious palettes, and check accessibility" 
        gradient="#8b5cf6, #06b6d4" 
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
        {/* Accessibility & Contrast - Moved to Top */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
            <Pipette className="w-6 h-6 text-cyan-400" /> Accessibility & Contrast
          </h2>
          <div className="grid lg:grid-cols-2 gap-6">
            <ContrastChecker />
            
            {/* Color Wheel - Condensed */}
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Palette className="w-5 h-5 text-violet-400" /> Interactive Color Wheel
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <ColorWheel onColorSelect={setSelectedColor} />
                <ColorPicker color={selectedColor} onChange={setSelectedColor} label="Selected Color" />
                <p className="text-xs text-slate-400">
                  Drag the wheel or click markers to select colors. Find complementary and analogous colors.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Pro Tips */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
            <Lightbulb className="w-6 h-6 text-amber-400" /> Pro Tips
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { tip: "Start with your brand's primary color, then build outward using color theory", icon: "🎨" },
              { tip: "Use high contrast for text - minimum 4.5:1 ratio for accessibility", icon: "👁️" },
              { tip: "Limit your palette to 3-5 colors max for cohesive designs", icon: "🎯" },
              { tip: "Test colors in both light and dark modes before committing", icon: "🌗" },
              { tip: "Use color to create hierarchy - brighter colors draw more attention", icon: "📊" },
              { tip: "Consider color blindness - don't rely on color alone for information", icon: "🔴" }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="p-4 rounded-xl bg-slate-900/50 border border-slate-800"
              >
                <span className="text-2xl mb-2 block">{item.icon}</span>
                <p className="text-sm text-slate-300">{item.tip}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Color Theory */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
            <Info className="w-6 h-6 text-cyan-400" /> Color Theory Rules
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {colorTheories.map(theory => (
              <TheoryCard key={theory.name} theory={theory} />
            ))}
          </div>
        </section>

        {/* Pre-made Schemes */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-6">Ready-to-Use Palettes</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {colorSchemes.map(scheme => (
              <SchemeCard key={scheme.name} scheme={scheme} />
            ))}
          </div>
        </section>

        {/* Gradients Mastery */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
            <Palette className="w-6 h-6 text-pink-400" /> Gradient Theory & Usage
          </h2>
          
          <div className="grid lg:grid-cols-2 gap-6 mb-6">
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">🌈 What Are Gradients?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-slate-300 text-sm">
                <p>Gradients are smooth transitions between two or more colors. They add depth, dimension, and visual interest to flat designs.</p>
                <div className="space-y-2">
                  <p className="font-semibold text-white">Common Types:</p>
                  <ul className="space-y-1 text-xs">
                    <li>• <strong className="text-violet-400">Linear</strong> - Color flows in a straight line (top to bottom, left to right)</li>
                    <li>• <strong className="text-cyan-400">Radial</strong> - Color radiates from a center point outward</li>
                    <li>• <strong className="text-pink-400">Conic</strong> - Color rotates around a center (like a pie chart)</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">✨ When to Use Gradients</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-slate-300 text-sm">
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-lg">✓</span>
                  <div><strong>Backgrounds:</strong> Subtle gradients add depth without distraction</div>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-lg">✓</span>
                  <div><strong>Buttons & CTAs:</strong> Eye-catching hover effects and premium feel</div>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 text-lg">✓</span>
                  <div><strong>Text:</strong> Gradient text creates modern, vibrant headlines</div>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-red-400 text-lg">✗</span>
                  <div><strong>Avoid:</strong> Overusing gradients everywhere (causes visual fatigue)</div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Gradient Examples */}
          <div className="grid md:grid-cols-3 gap-4">
            {[
              { name: "Violet Dream", gradient: "from-violet-500 via-purple-500 to-pink-500", usage: "Hero sections, CTAs" },
              { name: "Ocean Breeze", gradient: "from-blue-500 via-cyan-500 to-teal-500", usage: "Trust, professionalism" },
              { name: "Sunset Fire", gradient: "from-orange-500 via-red-500 to-pink-600", usage: "Energy, passion" },
              { name: "Forest Mist", gradient: "from-emerald-500 via-teal-500 to-cyan-500", usage: "Nature, growth" },
              { name: "Royal Purple", gradient: "from-indigo-600 via-purple-600 to-pink-600", usage: "Luxury, premium" },
              { name: "Neon Night", gradient: "from-fuchsia-500 via-violet-500 to-cyan-500", usage: "Tech, gaming" },
              { name: "Warm Sunset", gradient: "from-amber-400 via-orange-500 to-red-500", usage: "Warmth, comfort" },
              { name: "Arctic Cool", gradient: "from-slate-500 via-blue-400 to-cyan-300", usage: "Modern, clean" },
              { name: "Candy Pop", gradient: "from-pink-400 via-fuchsia-400 to-purple-400", usage: "Playful, fun" }
            ].map((grad, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="p-4 rounded-xl bg-slate-900/50 border border-slate-800"
              >
                <div className={`h-24 rounded-lg mb-3 bg-gradient-to-r ${grad.gradient}`} />
                <h4 className="text-white font-medium text-sm mb-1">{grad.name}</h4>
                <p className="text-xs text-slate-400 mb-2">{grad.usage}</p>
                <code className="text-[10px] text-violet-400 bg-slate-800 px-2 py-1 rounded block truncate">{grad.gradient}</code>
              </motion.div>
            ))}
          </div>
        </section>

        {/* UX/UI Color Psychology */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
            <Info className="w-6 h-6 text-amber-400" /> Color Psychology in UX/UI
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { color: "Blue", hex: "#3b82f6", meaning: "Trust, security, professionalism", use: "Banks, healthcare, corporate" },
              { color: "Green", hex: "#22c55e", meaning: "Growth, success, eco-friendly", use: "Finance, sustainability, health" },
              { color: "Red", hex: "#ef4444", meaning: "Urgency, passion, alerts", use: "Sales, errors, food delivery" },
              { color: "Yellow", hex: "#fbbf24", meaning: "Optimism, clarity, warnings", use: "Caution messages, highlights" },
              { color: "Purple", hex: "#8b5cf6", meaning: "Luxury, creativity, wisdom", use: "Premium products, creative tools" },
              { color: "Orange", hex: "#f97316", meaning: "Energy, fun, affordability", use: "E-commerce, entertainment" },
              { color: "Pink", hex: "#ec4899", meaning: "Romance, playfulness, youth", use: "Fashion, beauty, social apps" },
              { color: "Black/Gray", hex: "#18181b", meaning: "Sophistication, minimalism", use: "Luxury brands, tech products" }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 text-center"
              >
                <div className="w-12 h-12 rounded-full mx-auto mb-3 border-4 border-white/10" style={{ backgroundColor: item.hex }} />
                <h4 className="text-white font-bold mb-1">{item.color}</h4>
                <p className="text-xs text-slate-400 mb-2">{item.meaning}</p>
                <p className="text-[10px] text-slate-500 italic">Use for: {item.use}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Branding & Theming */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
            <Star className="w-6 h-6 text-violet-400" /> Branding & Theme Strategy
          </h2>
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white text-base">🎯 Define Your Brand</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-slate-300">
                <p><strong className="text-violet-400">Primary Color:</strong> Your brand's main identity (logo, CTAs)</p>
                <p><strong className="text-cyan-400">Secondary Color:</strong> Supporting elements, accents</p>
                <p><strong className="text-pink-400">Accent Color:</strong> Highlights, important actions</p>
                <div className="pt-3 border-t border-slate-700 text-xs text-slate-400">
                  Consistency across all touchpoints builds brand recognition.
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white text-base">🌗 Dark vs Light Themes</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-slate-300">
                <div><strong className="text-violet-400">Dark Mode:</strong> Reduces eye strain, saves battery (OLED), modern aesthetic</div>
                <div><strong className="text-amber-400">Light Mode:</strong> Better readability in bright environments, traditional feel</div>
                <div className="pt-3 border-t border-slate-700 text-xs text-slate-400">
                  <strong>Pro tip:</strong> Always offer both! Users have strong preferences.
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white text-base">🎨 Color Terminology</CardTitle>
              </CardHeader>
              <CardContent className="space-y-1 text-xs text-slate-300">
                <div><strong className="text-violet-400">Hue:</strong> The pure color (red, blue, green)</div>
                <div><strong className="text-cyan-400">Saturation:</strong> Intensity/purity (vibrant vs muted)</div>
                <div><strong className="text-pink-400">Lightness:</strong> How light or dark (tints/shades)</div>
                <div><strong className="text-amber-400">Opacity:</strong> Transparency level (alpha channel)</div>
                <div><strong className="text-emerald-400">Tint:</strong> Color + white (lighter)</div>
                <div><strong className="text-orange-400">Shade:</strong> Color + black (darker)</div>
                <div><strong className="text-rose-400">Tone:</strong> Color + gray (muted)</div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Accessibility Best Practices */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
            <Eye className="w-6 h-6 text-green-400" /> Accessibility & WCAG Standards
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">📏 Contrast Ratios Explained</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm text-slate-300">
                <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/30">
                  <p className="font-bold text-green-400">WCAG AA (Minimum)</p>
                  <p className="text-xs text-slate-400 mt-1">4.5:1 for normal text • 3:1 for large text (18px+)</p>
                </div>
                <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/30">
                  <p className="font-bold text-blue-400">WCAG AAA (Enhanced)</p>
                  <p className="text-xs text-slate-400 mt-1">7:1 for normal text • 4.5:1 for large text</p>
                </div>
                <p className="text-xs text-slate-400 pt-2 border-t border-slate-700">
                  <strong>Why it matters:</strong> 1 in 12 men and 1 in 200 women have color vision deficiency. Good contrast ensures everyone can use your app.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">🎨 Don't Rely on Color Alone</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm text-slate-300">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-red-500 rounded flex items-center justify-center text-white font-bold">!</div>
                  <span>Use icons + color for errors</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-green-500 rounded flex items-center justify-center text-white">✓</div>
                  <span>Use checkmarks + color for success</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-blue-500 rounded flex items-center justify-center text-white">i</div>
                  <span>Use symbols + color for info</span>
                </div>
                <p className="text-xs text-slate-400 pt-2 border-t border-slate-700">
                  Users with color blindness need more than just color to understand your UI. Always combine color with shapes, icons, or labels.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Tailwind Named Colors */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-2">Tailwind CSS Named Colors</h2>
          <p className="text-slate-400 mb-6">Copy class names like <code className="px-2 py-0.5 bg-slate-800 rounded text-violet-400">bg-violet-500</code> or <code className="px-2 py-0.5 bg-slate-800 rounded text-cyan-400">text-cyan-300</code></p>
          <div className="space-y-6">
            {Object.entries(tailwindColors).map(([colorName, shades]) => (
              <div key={colorName} className="bg-slate-900/50 border border-slate-800 rounded-xl p-4">
                <h3 className="text-white font-medium mb-3 capitalize">{colorName}</h3>
                <div className="flex flex-wrap gap-2">
                  {shades.map((shade) => {
                    const hex = tailwindColorValues[shade];
                    return (
                      <TailwindColorChip key={shade} name={shade} hex={hex} />
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Beginner Color Rules */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
            <Lightbulb className="w-6 h-6 text-yellow-400" /> Golden Rules for Beginners
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { rule: "Start with 2-3 colors max, expand later", icon: "🎨", why: "Too many colors = visual chaos. Master simplicity first." },
              { rule: "Use shades of the same color for depth", icon: "📊", why: "E.g., slate-700 for bg, slate-600 for cards, slate-500 for borders." },
              { rule: "Reserve bright colors for important actions", icon: "🚨", why: "If everything is bright, nothing stands out. Use sparingly." },
              { rule: "Test on real devices, not just your monitor", icon: "📱", why: "Colors look different on phones, tablets, and laptops." },
              { rule: "Check color meaning in target cultures", icon: "🌍", why: "White = purity in West, mourning in East. Research your audience." },
              { rule: "Use neutral grays for 70% of your UI", icon: "⚖️", why: "Grays let colorful elements shine without overwhelming users." },
              { rule: "Add subtle transparency for layering", icon: "🪟", why: "bg-slate-900/80 creates depth without hard edges." },
              { rule: "Avoid pure black (#000) - use dark grays", icon: "🌑", why: "Pure black is harsh. Use #0f172a (slate-900) instead." },
              { rule: "Gradients should have similar lightness", icon: "🌈", why: "from-blue-500 to-red-500 works. from-blue-200 to-red-900 fights." }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="p-4 rounded-xl bg-gradient-to-br from-slate-900/50 to-slate-800/50 border border-slate-800"
              >
                <div className="text-3xl mb-2">{item.icon}</div>
                <p className="text-white font-medium mb-2 text-sm">{item.rule}</p>
                <p className="text-xs text-slate-400 italic">{item.why}</p>
              </motion.div>
            ))}
          </div>
        </section>

      </div>
    </div>
  );
}