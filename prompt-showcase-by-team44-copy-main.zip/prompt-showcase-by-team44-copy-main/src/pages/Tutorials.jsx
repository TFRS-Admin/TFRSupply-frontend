import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BookOpen, ChevronRight, Check, Copy, Wand2, Play, Zap, Palette, Code, Heart, Search, MousePointerClick } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import CategoryHeader from "@/components/effects/CategoryHeader";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useQuery } from "@tanstack/react-query";

const tutorials = [
  {
    id: "favorites-guide",
    title: "❤️ Saving Your Favorites",
    difficulty: "Beginner",
    duration: "2 min",
    icon: Heart,
    steps: [
      {
        title: "Find an Effect",
        content: "Browse through our collection of visual effects, buttons, and animations to find something you like.",
        interactive: { type: "link", label: "Go to Explore", page: "Explore" },
        preview: () => (
          <div className="p-6 flex justify-center items-center bg-slate-900 rounded-xl border border-slate-800">
            <Link to={createPageUrl("Explore")}>
              <Button variant="outline" className="gap-2">
                <Search className="w-4 h-4" /> Explore Collection
              </Button>
            </Link>
          </div>
        )
      },
      {
        title: "Click the Heart",
        content: "Tap the heart icon on any effect card to save it. It works even if you're not logged in (using local storage)!",
        preview: function LikePreview() {
          const [liked, setLiked] = useState(false);
          return (
            <div className="p-6 flex justify-center items-center bg-slate-900 rounded-xl border border-slate-800">
              <motion.button
                whileTap={{ scale: 0.8 }}
                onClick={() => setLiked(!liked)}
                className={`p-3 rounded-full transition-colors ${liked ? "bg-red-500/20 text-red-500" : "bg-slate-800 text-slate-400 hover:text-white"}`}
              >
                <Heart className={`w-6 h-6 ${liked ? "fill-current" : ""}`} />
              </motion.button>
            </div>
          );
        }
      },
      {
        title: "View Your Collection",
        content: "Access your saved items anytime from the 'Favorites' page in the navigation menu.",
        interactive: { type: "link", label: "Go to Favorites", page: "Favorites" },
        preview: () => (
          <div className="p-6 rounded-xl bg-gradient-to-r from-pink-500/10 to-rose-500/10 border border-pink-500/20">
            <Link to={createPageUrl("Favorites")}>
              <Button className="w-full bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600">
                <Heart className="w-4 h-4 mr-2 fill-white" /> View My Favorites
              </Button>
            </Link>
          </div>
        )
      }
    ]
  },
  {
    id: "button-gallery",
    title: "👆 Using the Button Gallery",
    difficulty: "Beginner",
    duration: "3 min",
    icon: MousePointerClick,
    steps: [
      {
        title: "Explore Styles",
        content: "Check out the Button Showcase to see dozens of interactive button styles, from neon glows to retro glitches.",
        interactive: { type: "link", label: "Go to Buttons", page: "ButtonShowcase" },
        preview: () => (
          <div className="flex flex-wrap gap-2 justify-center p-4">
            <Button className="bg-cyan-500 hover:bg-cyan-600">Neon</Button>
            <Button className="bg-purple-500 hover:bg-purple-600">Retro</Button>
            <Button variant="outline" className="border-pink-500 text-pink-500 hover:bg-pink-500/10">Outline</Button>
          </div>
        )
      },
      {
        title: "Test Interactions",
        content: "Hover and click buttons to see their animations. Good UI gives feedback when you interact with it.",
        preview: () => (
          <div className="flex justify-center p-6">
            <motion.button
              whileHover={{ scale: 1.1, rotate: -2 }}
              whileTap={{ scale: 0.95 }}
              className="px-6 py-3 bg-indigo-500 text-white rounded-xl font-bold shadow-lg shadow-indigo-500/30"
            >
              Hover Me!
            </motion.button>
          </div>
        )
      },
      {
        title: "Grab the Code",
        content: "Found a button you like? Use the 'Copy Code' button to get the React + Tailwind snippet instantly.",
        preview: () => (
          <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 font-mono text-xs text-slate-400">
            &lt;Button className="hover:scale-110"&gt;Click&lt;/Button&gt;
          </div>
        )
      }
    ]
  },
  {
    id: "design-terms",
    title: "📚 Learning Design Terms",
    difficulty: "Intermediate",
    duration: "5 min",
    icon: BookOpen,
    steps: [
      {
        title: "Visit the Guide",
        content: "Confused by 'Padding' vs 'Margin'? Our Design Terminology guide explains it all visually.",
        interactive: { type: "link", label: "Go to Terminology", page: "DesignTerminology" },
        preview: () => (
          <div className="p-6 rounded-xl bg-slate-800/50 border border-slate-700 text-center">
            <BookOpen className="w-8 h-8 text-violet-400 mx-auto mb-2" />
            <p className="text-white font-semibold">Design Dictionary</p>
          </div>
        )
      },
      {
        title: "Hover to Learn",
        content: "Hover over any term card to see a live demonstration of the concept. It's better than reading a definition!",
        preview: () => (
          <div className="flex justify-center gap-4 p-4">
            <div className="p-2 bg-blue-500/20 border border-blue-500 rounded text-blue-300 text-xs">Padding</div>
            <div className="p-2 border-2 border-dashed border-green-500 rounded text-green-500 text-xs m-2">Margin</div>
          </div>
        )
      }
    ]
  },
  {
    id: "copy-paste",
    title: "📋 The Copy-Paste Workflow",
    difficulty: "Beginner",
    duration: "2 min",
    icon: Copy,
    steps: [
      {
        title: "Code or Prompt?",
        content: "Use 'Copy Code' if you're a developer. Use 'Copy Prompt' if you want to ask AI (like me!) to generate it for you.",
        preview: () => (
          <div className="flex gap-2 justify-center">
            <Button size="sm" variant="outline" className="gap-2"><Code className="w-3 h-3" /> Code</Button>
            <Button size="sm" variant="outline" className="gap-2"><Wand2 className="w-3 h-3" /> AI Prompt</Button>
          </div>
        )
      },
      {
        title: "Customize with AI",
        content: "Paste the prompt into your AI chat and add instructions like '...but make it green' to customize it effortlessly.",
        preview: () => (
          <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-xs text-slate-400">
            "Create a neon button... <span className="text-green-400">but make it green and rounded</span>"
          </div>
        )
      }
    ]
  }
];

function TutorialStep({ step, index, isActive, params, setParams }) {
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedPrompt, setCopiedPrompt] = useState(false);

  const copyCode = async () => {
    if (step.code) {
      await navigator.clipboard.writeText(step.code);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const copyPrompt = async () => {
    const prompt = `Create this effect: ${step.title}. ${step.content}`;
    await navigator.clipboard.writeText(prompt);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.1 }}
      className={`p-5 rounded-xl border-2 transition-all ${
        isActive ? "border-violet-500 bg-violet-500/10" : "border-slate-800 bg-slate-900/50"
      }`}
    >
      <div className="flex items-start gap-4">
        <motion.div
          animate={isActive ? { scale: [1, 1.1, 1] } : {}}
          transition={{ duration: 0.5 }}
          className={`w-10 h-10 rounded-full flex items-center justify-center text-base font-bold flex-shrink-0 ${
            isActive ? "bg-gradient-to-br from-violet-500 to-cyan-500 text-white" : "bg-slate-800 text-slate-400"
          }`}
        >
          {index + 1}
        </motion.div>

        <div className="flex-1 min-w-0">
          <h4 className="font-semibold text-white mb-2 text-lg">{step.title}</h4>
          <p className="text-slate-400 text-sm mb-4 leading-relaxed">{step.content}</p>

          {step.code && (
            <div className="mb-4">
              <pre className="p-4 rounded-lg bg-slate-950 border border-slate-800 text-xs overflow-x-auto">
                <code className="text-cyan-400">{step.code}</code>
              </pre>
              <div className="flex gap-2 mt-3">
                <motion.button
                  onClick={copyCode}
                  whileTap={{ scale: 0.95 }}
                  className="px-4 py-2 rounded-lg border-2 border-cyan-500 text-sm font-medium text-cyan-400 hover:bg-cyan-500 hover:text-white transition-colors flex items-center gap-2"
                >
                  {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copiedCode ? "Copied!" : "Copy Code"}
                </motion.button>
                <motion.button
                  onClick={copyPrompt}
                  whileTap={{ scale: 0.95 }}
                  className="px-4 py-2 rounded-lg border-2 border-purple-500 text-sm font-medium text-purple-400 hover:bg-purple-500 hover:text-white transition-colors flex items-center gap-2"
                >
                  {copiedPrompt ? <Check className="w-4 h-4" /> : <Wand2 className="w-4 h-4" />}
                  {copiedPrompt ? "Copied!" : "AI Prompt"}
                </motion.button>
              </div>
            </div>
          )}

          {step.interactive && isActive && (
            <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700 mb-4">
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm text-slate-300 font-medium">{step.interactive.label}</p>
                <span className="text-white font-mono text-sm">
                  {typeof (params[step.interactive.type] ?? step.interactive.default) === 'number'
                    ? (params[step.interactive.type] ?? step.interactive.default).toFixed(1)
                    : params[step.interactive.type] ?? step.interactive.default}
                </span>
              </div>
              {step.interactive.type !== "link" && (
                <Slider
                  value={[params[step.interactive.type] ?? step.interactive.default]}
                  onValueChange={([v]) => setParams({ ...params, [step.interactive.type]: v })}
                  min={step.interactive.min}
                  max={step.interactive.max}
                  step={step.interactive.type === "speed" ? 0.1 : step.interactive.type === "opacity" ? 0.01 : 1}
                  className="mb-2"
                />
              )}
            </div>
          )}

          {step.preview && isActive && (
            <div className="rounded-xl overflow-hidden border-2 border-slate-700 bg-slate-950">
              <step.preview params={params} />
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

function TutorialCard({ tutorial }) {
  const [isOpen, setIsOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [params, setParams] = useState({});

  return (
    <Card className="bg-slate-900/50 border-slate-800 overflow-hidden hover:border-violet-500/50 transition-colors">
      <CardHeader className="cursor-pointer" onClick={() => setIsOpen(!isOpen)}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <motion.div
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.5 }}
              className="w-12 h-12 flex items-center justify-center rounded-xl bg-slate-900 border-2 border-violet-500"
            >
              <tutorial.icon className="w-6 h-6 text-white" />
            </motion.div>
            <div>
              <CardTitle className="text-xl text-white mb-1">{tutorial.title}</CardTitle>
              <div className="flex gap-2">
                <span className="px-3 py-1 rounded-full bg-violet-500/20 text-violet-300 text-xs font-medium">
                  {tutorial.difficulty}
                </span>
                <span className="px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 text-xs font-medium">
                  {tutorial.duration}
                </span>
                <span className="px-3 py-1 rounded-full bg-slate-800 text-slate-400 text-xs font-medium">
                  {tutorial.steps.length} steps
                </span>
              </div>
            </div>
          </div>
          <motion.div animate={{ rotate: isOpen ? 90 : 0 }}>
            <ChevronRight className="w-6 h-6 text-slate-400" />
          </motion.div>
        </div>
      </CardHeader>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
          >
            <CardContent className="space-y-6 pt-0">
              {/* Progress Bar */}
              <div className="flex items-center gap-2">
                {tutorial.steps.map((_, i) => (
                  <div
                    key={i}
                    className={`h-2 flex-1 rounded-full transition-all ${
                      i <= currentStep ? "bg-gradient-to-r from-violet-500 to-cyan-500" : "bg-slate-700"
                    }`}
                  />
                ))}
              </div>

              {/* Steps */}
              <div className="space-y-4">
                {tutorial.steps.map((step, i) => (
                  <div key={i} onClick={() => setCurrentStep(i)} className="cursor-pointer">
                    <TutorialStep
                      step={step}
                      index={i}
                      isActive={i === currentStep}
                      params={params}
                      setParams={setParams}
                    />
                  </div>
                ))}
              </div>

              {/* Navigation */}
              <div className="flex justify-between pt-6 border-t border-slate-800">
                <Button
                  variant="outline"
                  onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                  disabled={currentStep === 0}
                  className="border-slate-700"
                >
                  Previous Step
                </Button>
                {currentStep < tutorial.steps.length - 1 ? (
                  <Button
                    onClick={() => setCurrentStep(currentStep + 1)}
                    className="bg-gradient-to-r from-violet-500 to-cyan-500 hover:from-violet-600 hover:to-cyan-600"
                  >
                    Next Step <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                ) : (
                  <Button className="bg-green-500 hover:bg-green-600">
                    <Check className="w-4 h-4 mr-2" /> Tutorial Complete!
                  </Button>
                )}
              </div>
            </CardContent>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}

export default function Tutorials() {
  return (
    <div className="min-h-screen">
      <CategoryHeader
        icon={BookOpen}
        title="Interactive Tutorials"
        description="Step-by-step guides with live demos and hands-on practice"
        gradient="#8b5cf6, #06b6d4"
      />
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* Intro */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12 p-6 rounded-2xl bg-gradient-to-r from-violet-500/10 to-cyan-500/10 border border-violet-500/30"
        >
          <h2 className="text-2xl font-bold text-white mb-3">🎓 Learn by Doing</h2>
          <p className="text-slate-300 mb-4">
            Each tutorial includes interactive examples, adjustable parameters, and copy-ready code snippets. 
            Click any tutorial to expand and start learning!
          </p>
          <div className="flex gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-violet-500" />
              <span className="text-slate-400">Interactive demos</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-cyan-500" />
              <span className="text-slate-400">Real-time adjustments</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-pink-500" />
              <span className="text-slate-400">Copy code & AI prompts</span>
            </div>
          </div>
        </motion.div>

        {/* Tutorials */}
        <div className="space-y-6">
          {tutorials.map((tutorial, index) => (
            <motion.div
              key={tutorial.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <TutorialCard tutorial={tutorial} />
            </motion.div>
          ))}
        </div>

        {/* More Coming Soon */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-12 p-8 rounded-2xl bg-slate-900/50 border border-slate-800 text-center"
        >
          <Zap className="w-12 h-12 mx-auto mb-4 text-violet-400" />
          <h3 className="text-xl font-bold text-white mb-2">More Tutorials Coming Soon!</h3>
          <p className="text-slate-400">
            We're constantly adding new interactive guides. Check back for tutorials on advanced animations, 
            custom effects, and real-world use cases.
          </p>
        </motion.div>
      </div>
    </div>
  );
}