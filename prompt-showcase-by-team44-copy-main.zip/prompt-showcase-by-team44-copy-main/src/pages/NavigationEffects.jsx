import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Navigation, Menu, X, ChevronDown, ArrowUp, ChevronRight, Home, Settings, User, Mail, Bell, Search, ShoppingCart, Heart, Star, Plus, Minus, LogOut, MoreHorizontal, Grid, List, Filter, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// ===== TOP NAV EFFECTS =====
function ShrinkingHeader() {
  const [scrollY, setScrollY] = useState(0);
  const headerHeight = Math.max(50, 80 - scrollY * 0.4);
  return (
    <EffectCard title="Shrinking Header" description="Compresses on scroll">
      <div onScroll={(e) => setScrollY(e.target.scrollTop)} className="relative h-[220px] overflow-auto rounded-xl bg-slate-950">
        <div className="sticky top-0 z-10 bg-slate-800/95 backdrop-blur border-b border-slate-700 flex items-center justify-between px-4 transition-all" style={{ height: headerHeight }}>
          <div className="flex items-center gap-2"><div className="w-6 h-6 rounded bg-gradient-to-br from-violet-500 to-cyan-500" /><span className="text-white font-bold text-sm">Brand</span></div>
          <div className="flex gap-3 text-xs text-slate-400">{["Home", "About", "Contact"].map(t => <span key={t}>{t}</span>)}</div>
        </div>
        <div className="p-3 space-y-2">{[...Array(8)].map((_, i) => <div key={i} className="p-3 rounded bg-slate-800/50 text-slate-500 text-xs">Content {i + 1}</div>)}</div>
      </div>
    </EffectCard>
  );
}

function TransparentHeader() {
  const [scrollY, setScrollY] = useState(0);
  return (
    <EffectCard title="Transparent to Solid" description="Background appears on scroll">
      <div onScroll={(e) => setScrollY(e.target.scrollTop)} className="relative h-[220px] overflow-auto rounded-xl">
        <div className="absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-violet-600 to-cyan-600" />
        <div className="sticky top-0 z-10 px-4 py-3 flex items-center justify-between transition-all" style={{ backgroundColor: `rgba(30, 41, 59, ${Math.min(scrollY / 60, 0.95)})`, backdropFilter: scrollY > 0 ? "blur(8px)" : "none" }}>
          <span className="text-white font-bold">Logo</span>
          <div className="flex gap-2 text-xs text-white/80">{["Home", "Shop", "Blog"].map(t => <span key={t}>{t}</span>)}</div>
        </div>
        <div className="p-3 pt-28 space-y-2">{[...Array(6)].map((_, i) => <div key={i} className="p-3 rounded bg-slate-800/50 text-slate-500 text-xs">Section {i + 1}</div>)}</div>
      </div>
    </EffectCard>
  );
}

function HideOnScrollHeader() {
  const [lastY, setLastY] = useState(0);
  const [show, setShow] = useState(true);
  const handleScroll = (e) => { const y = e.target.scrollTop; setShow(y < lastY || y < 30); setLastY(y); };
  return (
    <EffectCard title="Hide on Scroll" description="Disappears when scrolling down">
      <div onScroll={handleScroll} className="relative h-[220px] overflow-auto rounded-xl bg-slate-950">
        <motion.div animate={{ y: show ? 0 : -60 }} className="sticky top-0 z-10 bg-slate-800 border-b border-slate-700 px-4 py-3 flex items-center justify-between">
          <span className="text-white font-bold">Header</span>
          <span className="text-xs text-slate-400">Scroll to hide ↓</span>
        </motion.div>
        <div className="p-3 space-y-2">{[...Array(8)].map((_, i) => <div key={i} className="p-3 rounded bg-slate-800/50 text-slate-500 text-xs">Content {i + 1}</div>)}</div>
      </div>
    </EffectCard>
  );
}

function MegaMenuHeader() {
  const [open, setOpen] = useState(false);
  return (
    <EffectCard title="Mega Menu" description="Expandable dropdown menu">
      <div className="h-[220px] bg-slate-950 rounded-xl relative">
        <div className="bg-slate-800 border-b border-slate-700 px-4 py-3 flex items-center justify-between">
          <span className="text-white font-bold">Store</span>
          <button onClick={() => setOpen(!open)} className="flex items-center gap-1 text-sm text-slate-300 hover:text-white">Products <ChevronDown className={`w-4 h-4 transition ${open ? "rotate-180" : ""}`} /></button>
        </div>
        <AnimatePresence>
          {open && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="absolute left-0 right-0 top-12 bg-slate-800 border border-slate-700 rounded-b-xl p-4 grid grid-cols-3 gap-4 z-20">
              {["Electronics", "Clothing", "Home"].map(cat => (
                <div key={cat}><p className="text-violet-400 text-xs font-bold mb-2">{cat}</p>{["Item 1", "Item 2", "Item 3"].map(i => <p key={i} className="text-slate-400 text-xs hover:text-white cursor-pointer">{i}</p>)}</div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

function SearchExpandHeader() {
  const [expanded, setExpanded] = useState(false);
  return (
    <EffectCard title="Expanding Search" description="Search bar expands on click">
      <div className="h-[120px] bg-slate-950 rounded-xl">
        <div className="bg-slate-800 border-b border-slate-700 px-4 py-3 flex items-center justify-between">
          <span className="text-white font-bold">Site</span>
          <motion.div animate={{ width: expanded ? 200 : 40 }} className="bg-slate-700 rounded-full flex items-center overflow-hidden">
            <button onClick={() => setExpanded(!expanded)} className="p-2"><Search className="w-4 h-4 text-slate-400" /></button>
            {expanded && <input autoFocus placeholder="Search..." className="bg-transparent text-white text-sm outline-none flex-1 pr-3" onBlur={() => setExpanded(false)} />}
          </motion.div>
        </div>
      </div>
    </EffectCard>
  );
}

function CenteredLogoNav() {
  return (
    <EffectCard title="Centered Logo Nav" description="Logo in the middle">
      <div className="h-[100px] bg-slate-950 rounded-xl">
        <div className="bg-slate-800 border-b border-slate-700 px-4 py-3 flex items-center justify-between">
          <div className="flex gap-3 text-xs text-slate-400">{["Home", "About"].map(t => <span key={t} className="hover:text-white cursor-pointer">{t}</span>)}</div>
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center text-white font-bold">B</div>
          <div className="flex gap-3 text-xs text-slate-400">{["Shop", "Contact"].map(t => <span key={t} className="hover:text-white cursor-pointer">{t}</span>)}</div>
        </div>
      </div>
    </EffectCard>
  );
}

function SplitHeader() {
  return (
    <EffectCard title="Split Header" description="Two-tier navigation">
      <div className="bg-slate-950 rounded-xl overflow-hidden">
        <div className="bg-violet-600 px-4 py-1 flex items-center justify-between text-xs text-white/80">
          <span>Free shipping over $50</span>
          <div className="flex gap-3">{["Help", "Track Order"].map(t => <span key={t} className="hover:text-white cursor-pointer">{t}</span>)}</div>
        </div>
        <div className="bg-slate-800 px-4 py-3 flex items-center justify-between">
          <span className="text-white font-bold">Store</span>
          <div className="flex gap-4 text-sm text-slate-300">{["Shop", "Sale", "New"].map(t => <span key={t} className="hover:text-white cursor-pointer">{t}</span>)}</div>
          <div className="flex gap-2"><Search className="w-4 h-4 text-slate-400" /><ShoppingCart className="w-4 h-4 text-slate-400" /></div>
        </div>
      </div>
    </EffectCard>
  );
}

function FloatingHeader() {
  return (
    <EffectCard title="Floating Header" description="Detached from edges">
      <div className="h-[120px] bg-slate-950 rounded-xl p-4">
        <div className="bg-slate-800/90 backdrop-blur border border-slate-700 rounded-2xl px-4 py-3 flex items-center justify-between shadow-xl">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-violet-500" />
          <div className="flex gap-4 text-xs text-slate-300">{["Home", "Features", "Pricing"].map(t => <span key={t} className="hover:text-white cursor-pointer">{t}</span>)}</div>
          <button className="px-3 py-1 bg-violet-500 rounded-lg text-xs text-white">Sign Up</button>
        </div>
      </div>
    </EffectCard>
  );
}

function AnimatedUnderlineNav() {
  const [active, setActive] = useState(0);
  const items = ["Home", "About", "Services", "Contact"];
  return (
    <EffectCard title="Animated Underline" description="Sliding indicator">
      <div className="h-[100px] bg-slate-950 rounded-xl">
        <div className="bg-slate-800 border-b border-slate-700 px-4 py-3">
          <div className="flex gap-6 relative">
            {items.map((item, i) => (
              <button key={item} onClick={() => setActive(i)} className={`text-sm pb-2 ${active === i ? "text-violet-400" : "text-slate-400"}`}>{item}</button>
            ))}
            <motion.div className="absolute bottom-0 h-0.5 bg-violet-500" animate={{ left: active * 80, width: 50 }} transition={{ type: "spring", bounce: 0.2 }} />
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

function GlassHeader() {
  return (
    <EffectCard title="Glass Header" description="Frosted glass effect">
      <div className="h-[120px] rounded-xl relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-violet-600 via-pink-500 to-cyan-500" />
        <div className="relative p-4">
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl px-4 py-3 flex items-center justify-between">
            <span className="text-white font-bold">Glass</span>
            <div className="flex gap-4 text-sm text-white/80">{["Home", "About", "Contact"].map(t => <span key={t} className="hover:text-white cursor-pointer">{t}</span>)}</div>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// ===== BOTTOM NAV EFFECTS =====
function MobileBottomNav() {
  const [active, setActive] = useState(0);
  const items = [{ icon: Home, label: "Home" }, { icon: Search, label: "Search" }, { icon: Heart, label: "Saved" }, { icon: User, label: "Profile" }];
  return (
    <EffectCard title="Mobile Bottom Nav" description="iOS/Android style">
      <div className="h-[180px] bg-slate-950 rounded-xl flex flex-col">
        <div className="flex-1 flex items-center justify-center text-slate-500 text-sm">{items[active].label} Screen</div>
        <div className="bg-slate-800 border-t border-slate-700 px-2 py-2 flex justify-around">
          {items.map((item, i) => (
            <button key={i} onClick={() => setActive(i)} className={`flex flex-col items-center gap-1 p-2 rounded-lg ${active === i ? "text-violet-400" : "text-slate-500"}`}>
              <item.icon className="w-5 h-5" /><span className="text-[10px]">{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

function FloatingBottomNav() {
  const [active, setActive] = useState(0);
  const items = [{ icon: Home }, { icon: Search }, { icon: Plus }, { icon: Bell }, { icon: User }];
  return (
    <EffectCard title="Floating Bottom Nav" description="Pill-shaped floating bar">
      <div className="h-[180px] bg-slate-950 rounded-xl relative">
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-slate-800 border border-slate-700 rounded-full px-4 py-2 flex gap-4 shadow-xl">
          {items.map((item, i) => (
            <motion.button key={i} onClick={() => setActive(i)} whileTap={{ scale: 0.9 }} className={`p-2 rounded-full ${active === i ? "bg-violet-500 text-white" : "text-slate-400"}`}>
              <item.icon className="w-5 h-5" />
            </motion.button>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

function DockBottomNav() {
  const [active, setActive] = useState(2);
  const items = [Home, Search, Plus, Bell, User];
  return (
    <EffectCard title="Dock Style Nav" description="macOS dock inspired">
      <div className="h-[180px] bg-slate-950 rounded-xl relative">
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-slate-800/80 backdrop-blur border border-slate-700 rounded-2xl px-3 py-2 flex gap-2">
          {items.map((Icon, i) => (
            <motion.button key={i} onClick={() => setActive(i)} whileHover={{ scale: 1.2, y: -5 }} className={`p-2.5 rounded-xl ${active === i ? "bg-violet-500" : "bg-slate-700"}`}>
              <Icon className={`w-5 h-5 ${active === i ? "text-white" : "text-slate-400"}`} />
            </motion.button>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

function CurvedBottomNav() {
  const [active, setActive] = useState(0);
  const items = [Home, Search, Bell, User];
  return (
    <EffectCard title="Curved Bottom Nav" description="Center FAB cutout">
      <div className="h-[180px] bg-slate-950 rounded-xl relative overflow-hidden">
        <div className="flex-1 flex items-center justify-center h-[120px]">
          <p className="text-slate-600 text-sm">Content Area</p>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-slate-800 border-t border-slate-700">
          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }} className="absolute -top-7 left-1/2 -translate-x-1/2 w-14 h-14 rounded-full bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center shadow-xl shadow-violet-500/30 cursor-pointer z-10">
            <Plus className="w-7 h-7 text-white" />
          </motion.div>
          <div className="flex justify-around items-center h-full px-6">
            {items.slice(0, 2).map((Icon, i) => (
              <button key={i} onClick={() => setActive(i)} className={`p-2 rounded-lg transition-colors ${active === i ? "text-violet-400 bg-violet-500/10" : "text-slate-500 hover:text-slate-300"}`}>
                <Icon className="w-6 h-6" />
              </button>
            ))}
            <div className="w-14" />
            {items.slice(2).map((Icon, i) => (
              <button key={i + 2} onClick={() => setActive(i + 2)} className={`p-2 rounded-lg transition-colors ${active === i + 2 ? "text-violet-400 bg-violet-500/10" : "text-slate-500 hover:text-slate-300"}`}>
                <Icon className="w-6 h-6" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

function LabeledBottomNav() {
  const [active, setActive] = useState(0);
  const items = [{ icon: Home, label: "Home" }, { icon: Grid, label: "Browse" }, { icon: Heart, label: "Wishlist" }, { icon: User, label: "Account" }];
  return (
    <EffectCard title="Labeled Bottom Nav" description="With text labels">
      <div className="h-[180px] bg-slate-950 rounded-xl flex flex-col">
        <div className="flex-1" />
        <div className="bg-slate-800 border-t border-slate-700 py-2 flex justify-around">
          {items.map((item, i) => (
            <button key={i} onClick={() => setActive(i)} className="flex flex-col items-center gap-0.5">
              <div className={`p-1.5 rounded-lg ${active === i ? "bg-violet-500/20" : ""}`}>
                <item.icon className={`w-5 h-5 ${active === i ? "text-violet-400" : "text-slate-500"}`} />
              </div>
              <span className={`text-[10px] ${active === i ? "text-violet-400" : "text-slate-500"}`}>{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// ===== ALTERNATIVE NAV EFFECTS =====
function SideDrawer() {
  const [open, setOpen] = useState(false);
  return (
    <EffectCard title="Side Drawer" description="Slide-in menu" controls={<Button onClick={() => setOpen(!open)} variant="outline" size="sm">{open ? "Close" : "Open"}</Button>}>
      <div className="h-[200px] bg-slate-950 rounded-xl relative overflow-hidden">
        <motion.div animate={{ x: open ? 160 : 0, opacity: open ? 0.5 : 1 }} className="h-full p-4">
          <button onClick={() => setOpen(true)} className="p-2 rounded hover:bg-slate-800"><Menu className="w-5 h-5 text-white" /></button>
        </motion.div>
        <AnimatePresence>
          {open && (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(false)} className="absolute inset-0 bg-black/50" />
              <motion.div initial={{ x: "-100%" }} animate={{ x: 0 }} exit={{ x: "-100%" }} className="absolute left-0 top-0 bottom-0 w-40 bg-slate-800 border-r border-slate-700 p-4">
                <button onClick={() => setOpen(false)} className="mb-4"><X className="w-4 h-4 text-slate-400" /></button>
                {["Dashboard", "Settings", "Profile", "Logout"].map(item => <p key={item} className="text-slate-300 text-sm py-2 hover:text-white cursor-pointer">{item}</p>)}
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

function SlideOverPanel() {
  const [open, setOpen] = useState(false);
  return (
    <EffectCard title="Slide-Over Panel" description="Right side panel" controls={<Button onClick={() => setOpen(!open)} variant="outline" size="sm">{open ? "Close" : "Open"}</Button>}>
      <div className="h-[200px] bg-slate-950 rounded-xl relative overflow-hidden">
        <div className="p-4"><button onClick={() => setOpen(true)} className="px-3 py-1 bg-violet-500 rounded text-white text-sm">Open Panel</button></div>
        <AnimatePresence>
          {open && (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(false)} className="absolute inset-0 bg-black/50" />
              <motion.div initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} className="absolute right-0 top-0 bottom-0 w-48 bg-slate-800 border-l border-slate-700 p-4">
                <div className="flex justify-between items-center mb-4"><span className="text-white font-bold">Details</span><button onClick={() => setOpen(false)}><X className="w-4 h-4 text-slate-400" /></button></div>
                <p className="text-slate-400 text-xs">Panel content here...</p>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

function ModalPopup() {
  const [open, setOpen] = useState(false);
  return (
    <EffectCard title="Modal Popup" description="Centered overlay" controls={<Button onClick={() => setOpen(!open)} variant="outline" size="sm">{open ? "Close" : "Open"}</Button>}>
      <div className="h-[200px] bg-slate-950 rounded-xl relative overflow-hidden flex items-center justify-center">
        <button onClick={() => setOpen(true)} className="px-4 py-2 bg-violet-500 rounded-lg text-white text-sm">Show Modal</button>
        <AnimatePresence>
          {open && (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(false)} className="absolute inset-0 bg-black/70" />
              <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} className="absolute bg-slate-800 border border-slate-700 rounded-xl p-6 shadow-2xl">
                <h3 className="text-white font-bold mb-2">Modal Title</h3>
                <p className="text-slate-400 text-sm mb-4">This is modal content.</p>
                <button onClick={() => setOpen(false)} className="px-3 py-1 bg-violet-500 rounded text-white text-sm">Close</button>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

function BottomSheet() {
  const [open, setOpen] = useState(false);
  return (
    <EffectCard title="Bottom Sheet" description="Slides up from bottom" controls={<Button onClick={() => setOpen(!open)} variant="outline" size="sm">{open ? "Close" : "Open"}</Button>}>
      <div className="h-[220px] bg-slate-950 rounded-xl relative overflow-hidden">
        <div className="p-4"><button onClick={() => setOpen(true)} className="px-3 py-1 bg-cyan-500 rounded text-white text-sm">Show Sheet</button></div>
        <AnimatePresence>
          {open && (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(false)} className="absolute inset-0 bg-black/50" />
              <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} className="absolute bottom-0 left-0 right-0 bg-slate-800 border-t border-slate-700 rounded-t-2xl p-4">
                <div className="w-12 h-1 bg-slate-600 rounded-full mx-auto mb-4" />
                <h3 className="text-white font-bold mb-2">Bottom Sheet</h3>
                <p className="text-slate-400 text-xs">Swipe down or tap outside to close</p>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

function CommandPalette() {
  const [open, setOpen] = useState(false);
  return (
    <EffectCard title="Command Palette" description="Spotlight-style search" controls={<Button onClick={() => setOpen(!open)} variant="outline" size="sm">⌘K</Button>}>
      <div className="h-[220px] bg-slate-950 rounded-xl relative overflow-hidden flex items-center justify-center">
        <p className="text-slate-500 text-sm">Press ⌘K or click button</p>
        <AnimatePresence>
          {open && (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(false)} className="absolute inset-0 bg-black/70" />
              <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="absolute top-8 left-4 right-4 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl overflow-hidden">
                <div className="flex items-center gap-2 p-3 border-b border-slate-700"><Search className="w-4 h-4 text-slate-400" /><input autoFocus placeholder="Type a command..." className="bg-transparent text-white text-sm outline-none flex-1" /></div>
                <div className="p-2">{["Go to Dashboard", "Open Settings", "Search Files"].map(cmd => <div key={cmd} className="px-3 py-2 text-sm text-slate-300 hover:bg-slate-700 rounded cursor-pointer">{cmd}</div>)}</div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

function TabBar() {
  const [active, setActive] = useState(0);
  const tabs = ["Overview", "Analytics", "Reports", "Settings"];
  return (
    <EffectCard title="Animated Tab Bar" description="Sliding pill indicator">
      <div className="p-4 bg-slate-950 rounded-xl">
        <div className="relative flex bg-slate-800 rounded-xl p-1">
          <motion.div layoutId="tabPill" className="absolute inset-y-1 rounded-lg bg-violet-500" style={{ width: `${100 / tabs.length}%`, left: `${(100 / tabs.length) * active}%` }} transition={{ type: "spring", bounce: 0.2 }} />
          {tabs.map((tab, i) => <button key={tab} onClick={() => setActive(i)} className={`relative z-10 flex-1 py-2 text-xs font-medium ${active === i ? "text-white" : "text-slate-400"}`}>{tab}</button>)}
        </div>
      </div>
    </EffectCard>
  );
}

function AccordionNav() {
  const [open, setOpen] = useState(null);
  const sections = [{ title: "Products", items: ["Electronics", "Clothing", "Home"] }, { title: "Services", items: ["Consulting", "Support", "Training"] }];
  return (
    <EffectCard title="Accordion Navigation" description="Expandable sections">
      <div className="p-4 bg-slate-950 rounded-xl space-y-2">
        {sections.map((section, i) => (
          <div key={i} className="bg-slate-800 rounded-lg overflow-hidden">
            <button onClick={() => setOpen(open === i ? null : i)} className="w-full flex items-center justify-between p-3 text-sm text-white">
              {section.title}<ChevronDown className={`w-4 h-4 transition ${open === i ? "rotate-180" : ""}`} />
            </button>
            <AnimatePresence>
              {open === i && (
                <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }} className="overflow-hidden">
                  <div className="p-3 pt-0 space-y-1">{section.items.map(item => <p key={item} className="text-slate-400 text-xs hover:text-white cursor-pointer">{item}</p>)}</div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

function BreadcrumbNav() {
  const [path, setPath] = useState(["Home"]);
  const allPaths = ["Home", "Shop", "Electronics", "Phones"];
  return (
    <EffectCard title="Breadcrumb" description="Path navigation" controls={<Button onClick={() => path.length < allPaths.length && setPath(allPaths.slice(0, path.length + 1))} variant="outline" size="sm" disabled={path.length >= allPaths.length}>Go Deeper</Button>}>
      <div className="p-4 bg-slate-950 rounded-xl">
        <div className="flex items-center gap-1 flex-wrap">
          {path.map((p, i) => (
            <div key={p} className="flex items-center gap-1">
              {i > 0 && <ChevronRight className="w-3 h-3 text-slate-600" />}
              <button onClick={() => setPath(allPaths.slice(0, i + 1))} className={`text-sm ${i === path.length - 1 ? "text-violet-400" : "text-slate-400 hover:text-white"}`}>{p}</button>
            </div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

function StepperNav() {
  const [step, setStep] = useState(0);
  const steps = ["Cart", "Shipping", "Payment", "Confirm"];
  return (
    <EffectCard title="Stepper Navigation" description="Multi-step progress" controls={<div className="flex gap-2"><Button onClick={() => setStep(Math.max(0, step - 1))} variant="outline" size="sm" disabled={step === 0}>Back</Button><Button onClick={() => setStep(Math.min(3, step + 1))} size="sm" disabled={step === 3}>Next</Button></div>}>
      <div className="p-4 bg-slate-950 rounded-xl">
        <div className="flex items-center justify-between">
          {steps.map((s, i) => (
            <div key={i} className="flex items-center">
              <motion.div animate={{ scale: i === step ? 1.1 : 1, backgroundColor: i <= step ? "#8b5cf6" : "#334155" }} className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold">{i + 1}</motion.div>
              {i < steps.length - 1 && <div className="w-8 h-0.5 mx-1"><motion.div animate={{ width: i < step ? "100%" : "0%" }} className="h-full bg-violet-500" /></div>}
            </div>
          ))}
        </div>
        <p className="text-center text-white text-sm mt-3">{steps[step]}</p>
      </div>
    </EffectCard>
  );
}

function ContextMenu() {
  const [pos, setPos] = useState(null);
  return (
    <EffectCard title="Context Menu" description="Right-click menu">
      <div className="h-[180px] bg-slate-950 rounded-xl relative flex items-center justify-center" onContextMenu={(e) => { e.preventDefault(); setPos({ x: e.nativeEvent.offsetX, y: e.nativeEvent.offsetY }); }} onClick={() => setPos(null)}>
        <p className="text-slate-500 text-sm">Right-click anywhere</p>
        <AnimatePresence>
          {pos && (
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} className="absolute bg-slate-800 border border-slate-700 rounded-lg py-1 shadow-xl z-10" style={{ left: pos.x, top: pos.y }}>
              {["Edit", "Copy", "Delete", "Share"].map(item => <button key={item} className="block w-full text-left px-4 py-1.5 text-sm text-slate-300 hover:bg-slate-700">{item}</button>)}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

function DropdownMenu() {
  const [open, setOpen] = useState(false);
  return (
    <EffectCard title="Dropdown Menu" description="Animated dropdown">
      <div className="p-4 bg-slate-950 rounded-xl flex justify-center">
        <div className="relative">
          <Button onClick={() => setOpen(!open)} variant="outline">Options <ChevronDown className={`w-4 h-4 ml-2 transition ${open ? "rotate-180" : ""}`} /></Button>
          <AnimatePresence>
            {open && (
              <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="absolute top-full left-0 mt-2 w-40 bg-slate-800 border border-slate-700 rounded-lg py-1 shadow-xl">
                {["Profile", "Settings", "Help", "Logout"].map((item, i) => (
                  <motion.button key={item} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }} onClick={() => setOpen(false)} className="block w-full text-left px-4 py-2 text-sm text-slate-300 hover:bg-slate-700">{item}</motion.button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </EffectCard>
  );
}

function CollapsibleSidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const items = [{ icon: Home, label: "Home" }, { icon: User, label: "Profile" }, { icon: Settings, label: "Settings" }];
  return (
    <EffectCard title="Collapsible Sidebar" description="Expandable side nav">
      <div className="h-[180px] bg-slate-950 rounded-xl flex overflow-hidden">
        <motion.div animate={{ width: collapsed ? 50 : 140 }} className="bg-slate-800 border-r border-slate-700 p-2 flex flex-col">
          <button onClick={() => setCollapsed(!collapsed)} className="p-2 rounded hover:bg-slate-700 mb-2"><Menu className="w-4 h-4 text-slate-400" /></button>
          {items.map((item, i) => (
            <button key={i} className="flex items-center gap-2 p-2 rounded hover:bg-slate-700 text-slate-400">
              <item.icon className="w-4 h-4 flex-shrink-0" />
              <AnimatePresence>{!collapsed && <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-xs whitespace-nowrap">{item.label}</motion.span>}</AnimatePresence>
            </button>
          ))}
        </motion.div>
        <div className="flex-1 p-4 text-slate-500 text-sm">Main content</div>
      </div>
    </EffectCard>
  );
}

const effects = [
  // Top Nav
  { component: <ShrinkingHeader />, name: "Shrinking Header", category: "top" },
  { component: <TransparentHeader />, name: "Transparent Header", category: "top" },
  { component: <HideOnScrollHeader />, name: "Hide on Scroll", category: "top" },
  { component: <MegaMenuHeader />, name: "Mega Menu", category: "top" },
  { component: <SearchExpandHeader />, name: "Expanding Search", category: "top" },
  { component: <CenteredLogoNav />, name: "Centered Logo", category: "top" },
  { component: <SplitHeader />, name: "Split Header", category: "top" },
  { component: <FloatingHeader />, name: "Floating Header", category: "top" },
  { component: <AnimatedUnderlineNav />, name: "Animated Underline", category: "top" },
  { component: <GlassHeader />, name: "Glass Header", category: "top" },
  // Bottom Nav
  { component: <MobileBottomNav />, name: "Mobile Bottom Nav", category: "bottom" },
  { component: <FloatingBottomNav />, name: "Floating Bottom", category: "bottom" },
  { component: <DockBottomNav />, name: "Dock Style", category: "bottom" },
  { component: <CurvedBottomNav />, name: "Curved with FAB", category: "bottom" },
  { component: <LabeledBottomNav />, name: "Labeled Bottom", category: "bottom" },
  // Alternative
  { component: <SideDrawer />, name: "Side Drawer", category: "alt" },
  { component: <SlideOverPanel />, name: "Slide-Over Panel", category: "alt" },
  { component: <ModalPopup />, name: "Modal Popup", category: "alt" },
  { component: <BottomSheet />, name: "Bottom Sheet", category: "alt" },
  { component: <CommandPalette />, name: "Command Palette", category: "alt" },
  { component: <TabBar />, name: "Tab Bar", category: "alt" },
  { component: <AccordionNav />, name: "Accordion Nav", category: "alt" },
  { component: <BreadcrumbNav />, name: "Breadcrumb", category: "alt" },
  { component: <StepperNav />, name: "Stepper", category: "alt" },
  { component: <ContextMenu />, name: "Context Menu", category: "alt" },
  { component: <DropdownMenu />, name: "Dropdown Menu", category: "alt" },
  { component: <CollapsibleSidebar />, name: "Collapsible Sidebar", category: "alt" },
];

const categories = [
  { id: "all", label: "All" },
  { id: "top", label: "Top Nav (15)" },
  { id: "bottom", label: "Bottom Nav (5)" },
  { id: "alt", label: "Alternative (12)" },
];

export default function NavigationEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const filtered = effects.filter(e => {
    const matchesSearch = e.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === "all" || e.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={Navigation} title="Navigation Effects" description="50+ top nav, bottom nav, and alternative navigation patterns" gradient="#f59e0b" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="mb-6 flex flex-wrap gap-2">
          {categories.map(cat => (
            <button key={cat.id} onClick={() => setActiveCategory(cat.id)} className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${activeCategory === cat.id ? "bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg" : "bg-slate-800 text-slate-400 hover:bg-slate-700"}`}>{cat.label}</button>
          ))}
        </div>
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">{filtered.map((effect, i) => <div key={i}>{effect.component}</div>)}</div>
      </div>
    </div>
  );
}