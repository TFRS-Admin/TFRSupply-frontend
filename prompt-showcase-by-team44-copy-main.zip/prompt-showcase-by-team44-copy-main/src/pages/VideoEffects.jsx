import React, { useState } from "react";
import { motion } from "framer-motion";
import { Video, Play, Pause, Volume2, VolumeX, Maximize, Film } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import { useQuery } from "@tanstack/react-query";

const videoEffects = [
  {
    id: 1,
    title: "Video Player - Dark Theme",
    description: "Sleek dark video player with custom controls",
    category: "player",
    code: `<div className="relative bg-black rounded-xl overflow-hidden">
  <video className="w-full h-64 object-cover">
    <source src="video.mp4" type="video/mp4" />
  </video>
  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
    <div className="flex items-center gap-3">
      <button className="p-2 rounded-full bg-white/20 hover:bg-white/30">
        <Play className="w-5 h-5 text-white" />
      </button>
      <div className="flex-1 h-1 bg-white/20 rounded">
        <div className="h-full w-1/3 bg-violet-500 rounded"></div>
      </div>
      <Volume2 className="w-5 h-5 text-white" />
    </div>
  </div>
</div>`,
    component: function VideoPlayer() {
      const [isPlaying, setIsPlaying] = useState(false);
      return (
        <div className="relative bg-black rounded-xl overflow-hidden h-64">
          <div className="absolute inset-0 bg-gradient-to-br from-violet-600/20 to-cyan-600/20" />
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
            <div className="flex items-center gap-3">
              <button onClick={() => setIsPlaying(!isPlaying)} className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition">
                {isPlaying ? <Pause className="w-5 h-5 text-white" /> : <Play className="w-5 h-5 text-white" />}
              </button>
              <div className="flex-1 h-1 bg-white/20 rounded">
                <motion.div animate={{ width: isPlaying ? "100%" : "0%" }} transition={{ duration: 10 }} className="h-full bg-violet-500 rounded" />
              </div>
              <Volume2 className="w-5 h-5 text-white cursor-pointer" />
            </div>
          </div>
        </div>
      );
    }
  },
  {
    id: 2,
    title: "Video Thumbnail Grid",
    description: "YouTube-style video grid with hover effects",
    category: "grid",
    code: `<div className="grid grid-cols-3 gap-4">
  {videos.map(v => (
    <div key={v.id} className="group cursor-pointer">
      <div className="relative rounded-lg overflow-hidden">
        <img src={v.thumb} className="w-full h-40 object-cover group-hover:scale-110 transition" />
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center">
          <Play className="w-12 h-12 text-white" />
        </div>
      </div>
    </div>
  ))}
</div>`,
    component: () => (
      <div className="grid grid-cols-3 gap-4">
        {[1,2,3].map(i => (
          <motion.div key={i} whileHover={{ scale: 1.05 }} className="group cursor-pointer">
            <div className="relative rounded-lg overflow-hidden h-28">
              <div className={`w-full h-full bg-gradient-to-br ${i === 1 ? 'from-violet-500 to-purple-600' : i === 2 ? 'from-cyan-500 to-blue-600' : 'from-pink-500 to-rose-600'}`} />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center">
                <Play className="w-8 h-8 text-white" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    )
  },
  {
    id: 3,
    title: "Floating Video Player",
    description: "Picture-in-picture style floating video",
    category: "player",
    code: `<div className="fixed bottom-4 right-4 w-80 bg-black rounded-xl shadow-2xl">
  <video className="w-full rounded-t-xl" />
  <div className="p-2 flex items-center justify-between">
    <button className="p-2"><Play /></button>
    <button className="p-2"><X /></button>
  </div>
</div>`,
    component: () => (
      <div className="relative w-full bg-slate-900 rounded-xl shadow-2xl border border-slate-700">
        <div className="w-full h-40 bg-gradient-to-br from-indigo-600 to-purple-700 rounded-t-xl" />
        <div className="p-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button className="p-2 rounded-full hover:bg-slate-800"><Play className="w-4 h-4 text-white" /></button>
            <span className="text-xs text-slate-400">Floating Mode</span>
          </div>
          <Maximize className="w-4 h-4 text-slate-400 cursor-pointer" />
        </div>
      </div>
    )
  },
  {
    id: 4,
    title: "Video Progress Ring",
    description: "Circular progress indicator for videos",
    category: "controls",
    code: `<svg className="w-20 h-20">
  <circle cx="40" cy="40" r="36" stroke="#333" strokeWidth="4" fill="none" />
  <circle cx="40" cy="40" r="36" stroke="#8b5cf6" strokeWidth="4" fill="none" 
    strokeDasharray="226" strokeDashoffset={226 - (226 * progress)} />
</svg>`,
    component: function ProgressRing() {
      const [progress, setProgress] = useState(0.3);
      return (
        <div className="flex items-center justify-center">
          <svg className="w-24 h-24 -rotate-90">
            <circle cx="48" cy="48" r="40" stroke="#334155" strokeWidth="6" fill="none" />
            <circle cx="48" cy="48" r="40" stroke="#8b5cf6" strokeWidth="6" fill="none" 
              strokeDasharray="251" strokeDashoffset={251 - (251 * progress)} className="transition-all" />
          </svg>
        </div>
      );
    }
  },
  {
    id: 5,
    title: "Video Card with Stats",
    description: "Video card showing views and duration",
    category: "card",
    code: `<div className="bg-slate-900 rounded-xl overflow-hidden">
  <img src={thumb} className="w-full h-48 object-cover" />
  <div className="p-4">
    <h3 className="text-white font-bold">Video Title</h3>
    <div className="flex gap-4 text-sm text-slate-400 mt-2">
      <span>👁️ 1.2M views</span>
      <span>⏱️ 12:34</span>
    </div>
  </div>
</div>`,
    component: () => (
      <div className="bg-slate-900 rounded-xl overflow-hidden border border-slate-800 max-w-xs">
        <div className="relative h-40 bg-gradient-to-br from-blue-600 to-purple-700">
          <div className="absolute bottom-2 right-2 bg-black/80 px-2 py-1 rounded text-xs text-white">12:34</div>
        </div>
        <div className="p-4">
          <h3 className="text-white font-bold mb-2">Amazing Tutorial</h3>
          <div className="flex gap-4 text-sm text-slate-400">
            <span>👁️ 1.2M</span>
            <span>⏱️ 12:34</span>
          </div>
        </div>
      </div>
    )
  },
  {
    id: 6,
    title: "Video Timeline Scrubber",
    description: "Interactive timeline with thumbnails on hover",
    category: "controls",
    code: `<div className="relative w-full h-2 bg-slate-800 rounded cursor-pointer">
  <div className="h-full bg-violet-500 rounded" style={{width: '40%'}} />
  <div className="absolute -top-16 left-1/2 -translate-x-1/2 opacity-0 hover:opacity-100">
    <img src={thumbnail} className="w-32 h-20 rounded" />
  </div>
</div>`,
    component: function TimelineScrubber() {
      const [progress, setProgress] = useState(40);
      return (
        <div className="relative w-full h-2 bg-slate-800 rounded cursor-pointer group">
          <div className="h-full bg-violet-500 rounded" style={{width: `${progress}%`}} />
          <div className="absolute -top-20 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition">
            <div className="w-28 h-16 bg-gradient-to-br from-violet-600 to-cyan-600 rounded border-2 border-white shadow-xl" />
          </div>
        </div>
      );
    }
  },
  {
    id: 7,
    title: "Video Quality Selector",
    description: "Dropdown for video quality selection",
    category: "controls",
    code: `<select className="bg-slate-800 text-white rounded px-3 py-2">
  <option>Auto</option>
  <option>1080p</option>
  <option>720p</option>
  <option>480p</option>
  <option>360p</option>
</select>`,
    component: () => (
      <select className="bg-slate-800 text-white rounded-lg px-4 py-2 border border-slate-700 hover:border-violet-500 transition">
        <option>Auto (1080p)</option>
        <option>1080p HD</option>
        <option>720p HD</option>
        <option>480p</option>
        <option>360p</option>
      </select>
    )
  },
  {
    id: 8,
    title: "Video Playlist Sidebar",
    description: "Vertical playlist with auto-play queue",
    category: "playlist",
    code: `<div className="bg-slate-900 rounded-xl p-4 w-80">
  <h3 className="text-white font-bold mb-4">Up Next</h3>
  {videos.map(v => (
    <div key={v.id} className="flex gap-3 mb-3 cursor-pointer hover:bg-slate-800 p-2 rounded">
      <img src={v.thumb} className="w-24 h-16 rounded" />
      <div>
        <p className="text-white text-sm">{v.title}</p>
        <p className="text-slate-400 text-xs">{v.duration}</p>
      </div>
    </div>
  ))}
</div>`,
    component: () => (
      <div className="bg-slate-900 rounded-xl p-4 border border-slate-800">
        <h3 className="text-white font-bold mb-4 flex items-center gap-2"><Film className="w-5 h-5" /> Up Next</h3>
        {[1,2,3].map(i => (
          <div key={i} className="flex gap-3 mb-3 cursor-pointer hover:bg-slate-800 p-2 rounded transition">
            <div className={`w-24 h-16 rounded bg-gradient-to-br ${i === 1 ? 'from-pink-500 to-rose-600' : i === 2 ? 'from-cyan-500 to-blue-600' : 'from-amber-500 to-orange-600'}`} />
            <div>
              <p className="text-white text-sm">Video Title {i}</p>
              <p className="text-slate-400 text-xs">8:42</p>
            </div>
          </div>
        ))}
      </div>
    )
  },
  {
    id: 9,
    title: "Video Loading Skeleton",
    description: "Animated loading placeholder for videos",
    category: "loading",
    code: `<div className="animate-pulse">
  <div className="bg-slate-800 h-48 w-full rounded-xl mb-3"></div>
  <div className="bg-slate-800 h-4 w-3/4 rounded mb-2"></div>
  <div className="bg-slate-800 h-4 w-1/2 rounded"></div>
</div>`,
    component: () => (
      <div className="animate-pulse space-y-3">
        <div className="bg-slate-800 h-40 w-full rounded-xl"></div>
        <div className="bg-slate-800 h-4 w-3/4 rounded"></div>
        <div className="bg-slate-800 h-4 w-1/2 rounded"></div>
      </div>
    )
  },
  {
    id: 10,
    title: "Video Speed Control",
    description: "Playback speed adjustment buttons",
    category: "controls",
    code: `<div className="flex gap-2">
  {[0.5, 0.75, 1, 1.25, 1.5, 2].map(speed => (
    <button className="px-3 py-1 bg-slate-800 rounded hover:bg-violet-600">
      {speed}x
    </button>
  ))}
</div>`,
    component: function SpeedControl() {
      const [speed, setSpeed] = useState(1);
      return (
        <div className="flex gap-2 flex-wrap">
          {[0.5, 0.75, 1, 1.25, 1.5, 2].map(s => (
            <button key={s} onClick={() => setSpeed(s)} className={`px-3 py-1 rounded transition ${speed === s ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}>
              {s}x
            </button>
          ))}
        </div>
      );
    }
  },
  {
    id: 11,
    title: "Video Chapters Timeline",
    description: "Timeline with chapter markers",
    category: "controls",
    code: `<div className="relative w-full h-3 bg-slate-800 rounded">
  {chapters.map(c => (
    <div key={c.id} className="absolute top-0 h-full bg-violet-500/50 border-l-2 border-white" 
      style={{left: \`\${c.time}%\`, width: \`\${c.duration}%\`}} />
  ))}
</div>`,
    component: () => (
      <div className="relative w-full h-4 bg-slate-800 rounded overflow-hidden">
        <div className="absolute top-0 left-0 h-full w-1/4 bg-violet-500/30 border-l-2 border-violet-400" />
        <div className="absolute top-0 left-1/4 h-full w-1/4 bg-cyan-500/30 border-l-2 border-cyan-400" />
        <div className="absolute top-0 left-1/2 h-full w-1/4 bg-pink-500/30 border-l-2 border-pink-400" />
        <div className="absolute top-0 left-3/4 h-full w-1/4 bg-amber-500/30 border-l-2 border-amber-400" />
      </div>
    )
  },
  {
    id: 12,
    title: "Video Theater Mode",
    description: "Expand video to theater/fullscreen mode",
    category: "player",
    code: `<button onClick={toggleTheater} className="p-2 rounded hover:bg-white/20">
  <Maximize className="w-5 h-5 text-white" />
</button>`,
    component: function TheaterMode() {
      const [isTheater, setIsTheater] = useState(false);
      return (
        <div className={`bg-black rounded-xl transition-all ${isTheater ? 'p-8' : 'p-4'}`}>
          <div className={`bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg transition-all ${isTheater ? 'h-64' : 'h-32'}`}>
            <div className="flex justify-end p-2">
              <button onClick={() => setIsTheater(!isTheater)} className="p-2 rounded-lg bg-white/20 hover:bg-white/30 transition">
                <Maximize className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>
        </div>
      );
    }
  },
  {
    id: 13,
    title: "Video Subtitle Toggle",
    description: "Enable/disable subtitle display",
    category: "controls",
    code: `<button className="flex items-center gap-2 px-3 py-2 bg-slate-800 rounded">
  <Type className="w-4 h-4" />
  <span>CC</span>
</button>`,
    component: function SubtitleToggle() {
      const [ccOn, setCcOn] = useState(false);
      return (
        <button onClick={() => setCcOn(!ccOn)} className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${ccOn ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}>
          <span className="font-mono font-bold">CC</span>
          {ccOn && <span className="text-xs">ON</span>}
        </button>
      );
    }
  },
  {
    id: 14,
    title: "Video Reactions Bar",
    description: "Like/dislike reactions below video",
    category: "engagement",
    code: `<div className="flex gap-3">
  <button className="flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-full">
    <ThumbsUp /> <span>1.2K</span>
  </button>
  <button className="flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-full">
    <ThumbsDown /> <span>12</span>
  </button>
</div>`,
    component: function ReactionsBar() {
      const [liked, setLiked] = useState(false);
      return (
        <div className="flex gap-3">
          <button onClick={() => setLiked(!liked)} className={`flex items-center gap-2 px-4 py-2 rounded-full transition ${liked ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}>
            👍 <span>1.2K</span>
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-full text-slate-300 hover:bg-slate-700 transition">
            👎 <span>12</span>
          </button>
        </div>
      );
    }
  },
  {
    id: 15,
    title: "Video Share Button",
    description: "Share video with social links",
    category: "engagement",
    code: `<button className="flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-full">
  <Share2 className="w-4 h-4" />
  <span>Share</span>
</button>`,
    component: () => (
      <button className="flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-full text-white hover:bg-violet-600 transition">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" /></svg>
        <span>Share</span>
      </button>
    )
  },
  {
    id: 16,
    title: "Video Comment Section",
    description: "Comments with replies",
    category: "engagement",
    code: `<div className="space-y-4">
  {comments.map(c => (
    <div key={c.id} className="flex gap-3">
      <img src={c.avatar} className="w-10 h-10 rounded-full" />
      <div>
        <p className="text-white font-semibold">{c.author}</p>
        <p className="text-slate-400 text-sm">{c.text}</p>
      </div>
    </div>
  ))}
</div>`,
    component: () => (
      <div className="space-y-4 max-w-md">
        {[1,2].map(i => (
          <div key={i} className="flex gap-3">
            <div className={`w-10 h-10 rounded-full ${i === 1 ? 'bg-violet-500' : 'bg-cyan-500'}`} />
            <div className="flex-1">
              <p className="text-white font-semibold text-sm">User {i}</p>
              <p className="text-slate-400 text-xs">Great video! Thanks for sharing.</p>
              <div className="flex gap-3 mt-1 text-xs text-slate-500">
                <button className="hover:text-white">👍 24</button>
                <button className="hover:text-white">Reply</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    )
  },
  {
    id: 17,
    title: "Video Auto-Play Next",
    description: "Countdown timer for next video",
    category: "playlist",
    code: `<div className="bg-slate-900 p-4 rounded-xl">
  <p className="text-white">Next video in {countdown}s</p>
  <button onClick={cancelAutoplay}>Cancel</button>
</div>`,
    component: function AutoPlayNext() {
      const [countdown, setCountdown] = useState(5);
      return (
        <div className="bg-slate-900 p-4 rounded-xl border border-slate-700 text-center">
          <p className="text-white mb-2">Next video in <span className="text-violet-400 font-bold text-xl">{countdown}s</span></p>
          <button className="px-4 py-1 bg-slate-800 hover:bg-red-600 rounded-lg text-white text-sm transition">Cancel</button>
        </div>
      );
    }
  },
  {
    id: 18,
    title: "Video Buffering Indicator",
    description: "Loading spinner during buffering",
    category: "loading",
    code: `<div className="absolute inset-0 flex items-center justify-center bg-black/50">
  <Loader2 className="w-12 h-12 text-white animate-spin" />
</div>`,
    component: () => (
      <div className="relative h-48 bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl flex items-center justify-center">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }}>
          <div className="w-12 h-12 border-4 border-violet-500 border-t-transparent rounded-full" />
        </motion.div>
      </div>
    )
  },
  {
    id: 19,
    title: "Video Captions Overlay",
    description: "Subtitle text overlay on video",
    category: "controls",
    code: `<div className="absolute bottom-20 left-1/2 -translate-x-1/2">
  <div className="bg-black/80 px-4 py-2 rounded">
    <p className="text-white text-center">{currentCaption}</p>
  </div>
</div>`,
    component: () => (
      <div className="relative h-48 bg-gradient-to-br from-blue-900 to-purple-900 rounded-xl flex items-end justify-center pb-12">
        <div className="bg-black/90 px-6 py-2 rounded-lg">
          <p className="text-white text-center text-sm">This is a subtitle example</p>
        </div>
      </div>
    )
  },
  {
    id: 20,
    title: "Video Timestamp Links",
    description: "Clickable timestamps in description",
    category: "navigation",
    code: `<div className="space-y-2">
  {timestamps.map(t => (
    <button key={t.time} className="text-violet-400 hover:underline">
      {t.time} - {t.label}
    </button>
  ))}
</div>`,
    component: () => (
      <div className="space-y-2 text-sm">
        {["0:00", "2:15", "5:30", "8:45"].map((time, i) => (
          <button key={time} className="block text-violet-400 hover:text-violet-300 transition">
            {time} - Chapter {i + 1}
          </button>
        ))}
      </div>
    )
  },
  {
    id: 21,
    title: "Video Watch Later Button",
    description: "Save to watch later playlist",
    category: "engagement",
    code: `<button className="p-2 rounded hover:bg-slate-800">
  <Clock className="w-5 h-5" />
</button>`,
    component: function WatchLater() {
      const [saved, setSaved] = useState(false);
      return (
        <button onClick={() => setSaved(!saved)} className={`p-3 rounded-lg transition ${saved ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}>
          🕒 {saved ? "Saved" : "Watch Later"}
        </button>
      );
    }
  },
  {
    id: 22,
    title: "Video Download Button",
    description: "Download video for offline viewing",
    category: "engagement",
    code: `<button className="flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-full">
  <Download className="w-4 h-4" />
  <span>Download</span>
</button>`,
    component: () => (
      <button className="flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-full text-white hover:bg-green-600 transition">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
        <span>Download</span>
      </button>
    )
  },
  {
    id: 23,
    title: "Video Live Badge",
    description: "Live streaming indicator",
    category: "badge",
    code: `<span className="px-3 py-1 bg-red-600 text-white rounded-full font-bold animate-pulse">
  🔴 LIVE
</span>`,
    component: () => (
      <span className="inline-flex items-center gap-2 px-3 py-1 bg-red-600 text-white rounded-full font-bold text-sm animate-pulse">
        🔴 LIVE
      </span>
    )
  },
  {
    id: 24,
    title: "Video Viewer Count",
    description: "Live viewer counter",
    category: "badge",
    code: `<div className="flex items-center gap-2 px-3 py-1 bg-slate-800 rounded-full">
  <Eye className="w-4 h-4" />
  <span className="font-mono">1,234</span>
</div>`,
    component: () => (
      <div className="flex items-center gap-2 px-3 py-1 bg-slate-800 rounded-full text-white">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
        <span className="font-mono">1,234</span>
      </div>
    )
  },
  {
    id: 25,
    title: "Video Miniplayer",
    description: "Small player in corner while scrolling",
    category: "player",
    code: `<div className="fixed bottom-4 right-4 w-64 bg-black rounded-lg shadow-2xl">
  <video className="w-full rounded-t-lg" />
  <div className="p-2 flex justify-between">
    <Play className="w-4 h-4" />
    <X className="w-4 h-4" />
  </div>
</div>`,
    component: () => (
      <div className="relative w-full bg-slate-900 rounded-lg shadow-xl border border-slate-700 overflow-hidden">
        <div className="w-full h-32 bg-gradient-to-br from-teal-600 to-green-700" />
        <div className="p-2 flex justify-between items-center bg-slate-800">
          <Play className="w-4 h-4 text-white cursor-pointer" />
          <span className="text-xs text-slate-400">Miniplayer</span>
          <button className="text-slate-400 hover:text-white">✕</button>
        </div>
      </div>
    )
  },
  {
    id: 26,
    title: "Video Scrub Preview",
    description: "Thumbnail preview on timeline hover",
    category: "controls",
    code: `<div className="relative w-full">
  <div className="h-2 bg-slate-800 rounded" onMouseMove={showPreview}>
    <div className="h-full bg-violet-500 rounded" style={{width: '30%'}} />
  </div>
  {preview && (
    <img src={previewThumb} className="absolute -top-20 w-32 h-20 rounded shadow-xl" />
  )}
</div>`,
    component: function ScrubPreview() {
      const [showPreview, setShowPreview] = useState(false);
      return (
        <div className="relative w-full" onMouseEnter={() => setShowPreview(true)} onMouseLeave={() => setShowPreview(false)}>
          <div className="h-2 bg-slate-800 rounded cursor-pointer">
            <div className="h-full bg-violet-500 rounded" style={{width: '35%'}} />
          </div>
          {showPreview && (
            <div className="absolute -top-20 left-1/3 -translate-x-1/2 w-28 h-16 bg-gradient-to-br from-violet-600 to-pink-600 rounded shadow-2xl border-2 border-white" />
          )}
        </div>
      );
    }
  },
  {
    id: 27,
    title: "Video Loop Toggle",
    description: "Enable repeat/loop playback",
    category: "controls",
    code: `<button className="p-2 rounded hover:bg-slate-800">
  <Repeat className="w-5 h-5" />
</button>`,
    component: function LoopToggle() {
      const [loop, setLoop] = useState(false);
      return (
        <button onClick={() => setLoop(!loop)} className={`p-3 rounded-lg transition ${loop ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}>
          🔁 {loop ? "Loop ON" : "Loop OFF"}
        </button>
      );
    }
  },
  {
    id: 28,
    title: "Video Analytics Card",
    description: "View statistics and analytics",
    category: "engagement",
    code: `<div className="bg-slate-900 rounded-xl p-4">
  <h3 className="text-white font-bold mb-3">Analytics</h3>
  <div className="grid grid-cols-2 gap-4">
    <div>
      <p className="text-slate-400 text-sm">Views</p>
      <p className="text-white text-2xl font-bold">1.2M</p>
    </div>
    <div>
      <p className="text-slate-400 text-sm">Watch Time</p>
      <p className="text-white text-2xl font-bold">45m</p>
    </div>
  </div>
</div>`,
    component: () => (
      <div className="bg-slate-900 rounded-xl p-4 border border-slate-800">
        <h3 className="text-white font-bold mb-3">📊 Analytics</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-slate-400 text-xs">Views</p>
            <p className="text-white text-xl font-bold">1.2M</p>
          </div>
          <div>
            <p className="text-slate-400 text-xs">Likes</p>
            <p className="text-white text-xl font-bold">42K</p>
          </div>
        </div>
      </div>
    )
  },
  {
    id: 29,
    title: "Video End Screen",
    description: "Related videos at video end",
    category: "engagement",
    code: `<div className="absolute inset-0 bg-black/80 flex items-center justify-center">
  <div className="grid grid-cols-2 gap-4">
    {suggestions.map(v => (
      <div key={v.id} className="w-48 cursor-pointer">
        <img src={v.thumb} className="w-full h-28 rounded" />
        <p className="text-white text-sm mt-2">{v.title}</p>
      </div>
    ))}
  </div>
</div>`,
    component: () => (
      <div className="relative h-64 bg-black rounded-xl flex items-center justify-center p-6">
        <div className="grid grid-cols-2 gap-3">
          {[1,2].map(i => (
            <div key={i} className="cursor-pointer group">
              <div className={`w-32 h-20 rounded bg-gradient-to-br ${i === 1 ? 'from-red-500 to-pink-600' : 'from-blue-500 to-cyan-600'} group-hover:scale-105 transition`} />
              <p className="text-white text-xs mt-1">Next Video {i}</p>
            </div>
          ))}
        </div>
      </div>
    )
  },
  {
    id: 30,
    title: "Video Fullscreen Button",
    description: "Toggle fullscreen mode",
    category: "controls",
    code: `<button onClick={toggleFullscreen} className="p-2 rounded hover:bg-white/20">
  <Maximize2 className="w-5 h-5 text-white" />
</button>`,
    component: () => (
      <button className="p-3 rounded-lg bg-slate-800 hover:bg-violet-600 text-white transition">
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" /></svg>
      </button>
    )
  },
  {
    id: 31,
    title: "Video Thumbnail Carousel",
    description: "Horizontal scrolling video thumbnails",
    category: "grid",
    code: `<div className="flex gap-4 overflow-x-auto pb-4">
  {videos.map(v => (
    <div key={v.id} className="flex-shrink-0 w-64">
      <img src={v.thumb} className="w-full h-36 rounded-lg" />
      <p className="text-white mt-2">{v.title}</p>
    </div>
  ))}
</div>`,
    component: () => (
      <div className="flex gap-4 overflow-x-auto pb-4">
        {[1,2,3,4].map(i => (
          <div key={i} className="flex-shrink-0 w-48">
            <div className={`w-full h-28 rounded-lg bg-gradient-to-br ${i % 2 === 0 ? 'from-orange-500 to-red-600' : 'from-green-500 to-teal-600'}`} />
            <p className="text-white text-sm mt-2">Video {i}</p>
          </div>
        ))}
      </div>
    )
  },
  {
    id: 32,
    title: "Video Category Badge",
    description: "Category tag on video thumbnail",
    category: "badge",
    code: `<span className="absolute top-2 left-2 px-2 py-1 bg-violet-600 rounded text-xs text-white font-semibold">
  Tutorial
</span>`,
    component: () => (
      <div className="relative w-48 h-28 bg-gradient-to-br from-indigo-600 to-purple-700 rounded-lg">
        <span className="absolute top-2 left-2 px-2 py-1 bg-violet-600 rounded text-xs text-white font-semibold">
          Tutorial
        </span>
      </div>
    )
  },
  {
    id: 33,
    title: "Video Mute Button",
    description: "Toggle audio on/off",
    category: "controls",
    code: `<button onClick={toggleMute}>
  {muted ? <VolumeX /> : <Volume2 />}
</button>`,
    component: function MuteButton() {
      const [muted, setMuted] = useState(false);
      return (
        <button onClick={() => setMuted(!muted)} className="p-3 rounded-lg bg-slate-800 hover:bg-violet-600 transition text-white">
          {muted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
        </button>
      );
    }
  },
  {
    id: 34,
    title: "Video Volume Slider",
    description: "Vertical volume control",
    category: "controls",
    code: `<input type="range" min="0" max="100" value={volume} 
  onChange={e => setVolume(e.target.value)} 
  className="transform -rotate-90" />`,
    component: function VolumeSlider() {
      const [volume, setVolume] = useState(75);
      return (
        <div className="flex flex-col items-center gap-2 p-4 bg-slate-900 rounded-xl">
          <Volume2 className="w-5 h-5 text-white" />
          <input type="range" min="0" max="100" value={volume} 
            onChange={e => setVolume(e.target.value)} 
            className="h-24 accent-violet-500 transform -rotate-90 origin-center" />
          <span className="text-white text-sm">{volume}%</span>
        </div>
      );
    }
  },
  {
    id: 35,
    title: "Video Playlist Counter",
    description: "Show current position in playlist",
    category: "playlist",
    code: `<div className="flex items-center gap-2 px-3 py-1 bg-slate-800 rounded-full">
  <List className="w-4 h-4" />
  <span>3 / 12</span>
</div>`,
    component: () => (
      <div className="flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-full text-white">
        <span className="text-xl">📋</span>
        <span className="font-mono">3 / 12</span>
      </div>
    )
  },
  {
    id: 36,
    title: "Video Hover Card",
    description: "Preview card on thumbnail hover",
    category: "card",
    code: `<div className="group relative">
  <img src={thumb} className="rounded-lg" />
  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100">
    <div className="p-4 text-white">
      <h4>{title}</h4>
      <p>{description}</p>
    </div>
  </div>
</div>`,
    component: () => (
      <div className="group relative w-48 h-28 rounded-lg overflow-hidden">
        <div className="w-full h-full bg-gradient-to-br from-yellow-500 to-orange-600" />
        <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition flex items-center justify-center p-3">
          <div className="text-white text-center">
            <h4 className="font-bold text-sm mb-1">Video Title</h4>
            <p className="text-xs text-slate-300">Quick description here</p>
          </div>
        </div>
      </div>
    )
  },
  {
    id: 37,
    title: "Video Watch Progress",
    description: "Red progress bar showing watched portion",
    category: "controls",
    code: `<div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-700">
  <div className="h-full bg-red-600" style={{width: '45%'}} />
</div>`,
    component: () => (
      <div className="relative w-full">
        <div className="w-full h-32 bg-gradient-to-br from-purple-600 to-blue-700 rounded-lg" />
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-700 rounded-b-lg">
          <div className="h-full bg-red-600 rounded-bl-lg" style={{width: '45%'}} />
        </div>
      </div>
    )
  },
  {
    id: 38,
    title: "Video Aspect Ratio Toggle",
    description: "Switch between 16:9, 4:3, 1:1",
    category: "controls",
    code: `<div className="flex gap-2">
  {['16:9', '4:3', '1:1'].map(ratio => (
    <button key={ratio} className="px-3 py-1 bg-slate-800 rounded">
      {ratio}
    </button>
  ))}
</div>`,
    component: function AspectRatioToggle() {
      const [ratio, setRatio] = useState('16:9');
      return (
        <div className="flex gap-2">
          {['16:9', '4:3', '1:1'].map(r => (
            <button key={r} onClick={() => setRatio(r)} className={`px-3 py-1 rounded text-xs transition ${ratio === r ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}>
              {r}
            </button>
          ))}
        </div>
      );
    }
  },
  {
    id: 39,
    title: "Video Thumbnail Grid - Large",
    description: "Large thumbnail grid for video library",
    category: "grid",
    code: `<div className="grid grid-cols-4 gap-6">
  {videos.map(v => (
    <div key={v.id} className="group">
      <img src={v.thumb} className="w-full h-48 rounded-xl" />
      <h3 className="text-white mt-2">{v.title}</h3>
      <p className="text-slate-400 text-sm">{v.views} views</p>
    </div>
  ))}
</div>`,
    component: () => (
      <div className="grid grid-cols-3 gap-4">
        {[1,2,3,4,5,6].map(i => (
          <div key={i} className="group">
            <div className={`w-full h-24 rounded-lg bg-gradient-to-br ${i % 3 === 0 ? 'from-red-500 to-pink-600' : i % 3 === 1 ? 'from-blue-500 to-cyan-600' : 'from-green-500 to-teal-600'} group-hover:scale-105 transition`} />
            <h3 className="text-white text-xs mt-1">Video {i}</h3>
          </div>
        ))}
      </div>
    )
  },
  {
    id: 40,
    title: "Video Series Badge",
    description: "Episode number indicator",
    category: "badge",
    code: `<span className="absolute top-2 right-2 px-2 py-1 bg-black/80 rounded text-white text-xs font-mono">
  EP. 5
</span>`,
    component: () => (
      <div className="relative w-48 h-28 bg-gradient-to-br from-teal-600 to-green-700 rounded-lg">
        <span className="absolute top-2 right-2 px-2 py-1 bg-black/80 rounded text-white text-xs font-mono">
          EP. 5
        </span>
      </div>
    )
  },
  {
    id: 41,
    title: "Video Playlist Shuffle",
    description: "Random playback order toggle",
    category: "playlist",
    code: `<button className="p-2 rounded hover:bg-slate-800">
  <Shuffle className="w-5 h-5" />
</button>`,
    component: function ShuffleToggle() {
      const [shuffle, setShuffle] = useState(false);
      return (
        <button onClick={() => setShuffle(!shuffle)} className={`p-3 rounded-lg transition ${shuffle ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}>
          🔀 {shuffle ? "Shuffle ON" : "Shuffle"}
        </button>
      );
    }
  },
  {
    id: 42,
    title: "Video Channel Avatar",
    description: "Creator profile picture and name",
    category: "engagement",
    code: `<div className="flex items-center gap-3">
  <img src={avatar} className="w-10 h-10 rounded-full" />
  <div>
    <p className="text-white font-semibold">{channelName}</p>
    <p className="text-slate-400 text-sm">{subscribers}</p>
  </div>
</div>`,
    component: () => (
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-pink-500" />
        <div>
          <p className="text-white font-semibold text-sm">Creator Name</p>
          <p className="text-slate-400 text-xs">100K subscribers</p>
        </div>
      </div>
    )
  },
  {
    id: 43,
    title: "Video Subscribe Button",
    description: "Channel subscription toggle",
    category: "engagement",
    code: `<button className="px-6 py-2 bg-red-600 hover:bg-red-700 rounded-full text-white font-semibold">
  Subscribe
</button>`,
    component: function SubscribeButton() {
      const [subscribed, setSubscribed] = useState(false);
      return (
        <button onClick={() => setSubscribed(!subscribed)} className={`px-6 py-2 rounded-full font-semibold transition ${subscribed ? 'bg-slate-800 text-white' : 'bg-red-600 hover:bg-red-700 text-white'}`}>
          {subscribed ? "Subscribed" : "Subscribe"}
        </button>
      );
    }
  },
  {
    id: 44,
    title: "Video Report Button",
    description: "Flag inappropriate content",
    category: "engagement",
    code: `<button className="flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-lg hover:bg-red-600">
  <Flag className="w-4 h-4" />
  <span>Report</span>
</button>`,
    component: () => (
      <button className="flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-lg hover:bg-red-600 text-white transition text-sm">
        🚩 <span>Report</span>
      </button>
    )
  },
  {
    id: 45,
    title: "Video Related Videos Sidebar",
    description: "Suggested videos in sidebar",
    category: "playlist",
    code: `<div className="space-y-3">
  {related.map(v => (
    <div key={v.id} className="flex gap-3 cursor-pointer hover:bg-slate-800 p-2 rounded">
      <img src={v.thumb} className="w-32 h-20 rounded" />
      <div>
        <p className="text-white text-sm">{v.title}</p>
        <p className="text-slate-400 text-xs">{v.views}</p>
      </div>
    </div>
  ))}
</div>`,
    component: () => (
      <div className="space-y-3">
        {[1,2,3].map(i => (
          <div key={i} className="flex gap-3 cursor-pointer hover:bg-slate-800 p-2 rounded transition">
            <div className={`w-28 h-16 rounded bg-gradient-to-br ${i === 1 ? 'from-amber-500 to-orange-600' : i === 2 ? 'from-emerald-500 to-teal-600' : 'from-rose-500 to-pink-600'}`} />
            <div className="flex-1">
              <p className="text-white text-xs">Related Video {i}</p>
              <p className="text-slate-400 text-xs">50K views</p>
            </div>
          </div>
        ))}
      </div>
    )
  },
  {
    id: 46,
    title: "Video Duration Badge",
    description: "Time length indicator on thumbnail",
    category: "badge",
    code: `<span className="absolute bottom-2 right-2 px-2 py-1 bg-black/90 rounded text-white text-xs font-mono">
  12:34
</span>`,
    component: () => (
      <div className="relative w-48 h-28 bg-gradient-to-br from-cyan-600 to-blue-700 rounded-lg">
        <span className="absolute bottom-2 right-2 px-2 py-1 bg-black/90 rounded text-white text-xs font-mono">
          12:34
        </span>
      </div>
    )
  },
  {
    id: 47,
    title: "Video 4K Badge",
    description: "High quality indicator",
    category: "badge",
    code: `<span className="absolute top-2 left-2 px-2 py-1 bg-gradient-to-r from-violet-600 to-pink-600 rounded text-white text-xs font-bold">
  4K
</span>`,
    component: () => (
      <div className="relative w-48 h-28 bg-gradient-to-br from-slate-800 to-slate-900 rounded-lg">
        <span className="absolute top-2 left-2 px-2 py-1 bg-gradient-to-r from-violet-600 to-pink-600 rounded text-white text-xs font-bold">
          4K HD
        </span>
      </div>
    )
  },
  {
    id: 48,
    title: "Video Error State",
    description: "Error message with retry",
    category: "loading",
    code: `<div className="flex flex-col items-center justify-center p-8">
  <AlertCircle className="w-12 h-12 text-red-500 mb-3" />
  <p className="text-white mb-4">Failed to load video</p>
  <button className="px-4 py-2 bg-violet-600 rounded-lg">Retry</button>
</div>`,
    component: () => (
      <div className="flex flex-col items-center justify-center p-8 bg-slate-900 rounded-xl border border-red-500/30">
        <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center mb-3">
          <span className="text-2xl">⚠️</span>
        </div>
        <p className="text-white mb-4 text-sm">Failed to load video</p>
        <button className="px-4 py-2 bg-violet-600 hover:bg-violet-700 rounded-lg text-white text-sm transition">Retry</button>
      </div>
    )
  },
  {
    id: 49,
    title: "Video Embed Code",
    description: "Share embed iframe code",
    category: "engagement",
    code: `<div className="bg-slate-900 p-4 rounded-lg">
  <code className="text-green-400 text-xs">
    &lt;iframe src="video.mp4"&gt;&lt;/iframe&gt;
  </code>
  <button className="mt-2 px-3 py-1 bg-violet-600 rounded">Copy</button>
</div>`,
    component: function EmbedCode() {
      const [copied, setCopied] = useState(false);
      return (
        <div className="bg-slate-900 p-4 rounded-lg border border-slate-700">
          <code className="text-green-400 text-xs block mb-2">
            &lt;iframe src="video"&gt;&lt;/iframe&gt;
          </code>
          <button onClick={() => setCopied(true)} className="px-3 py-1 bg-violet-600 hover:bg-violet-700 rounded text-white text-xs transition">
            {copied ? "Copied!" : "Copy Code"}
          </button>
        </div>
      );
    }
  },
  {
    id: 50,
    title: "Video Autoplay Warning",
    description: "Notification for autoplay blocked",
    category: "notification",
    code: `<div className="bg-yellow-500/20 border border-yellow-500 rounded-lg p-3">
  <p className="text-yellow-500 text-sm">Autoplay was blocked. Click to play.</p>
</div>`,
    component: () => (
      <div className="bg-yellow-500/20 border border-yellow-500 rounded-lg p-3 flex items-center gap-2">
        <span className="text-xl">⚠️</span>
        <p className="text-yellow-400 text-sm">Autoplay blocked. Click play to start.</p>
      </div>
    )
  }
];

export default function VideoEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const categories = [
    { id: "all", label: "All" },
    { id: "player", label: "Players" },
    { id: "controls", label: "Controls" },
    { id: "grid", label: "Grids" },
    { id: "card", label: "Cards" },
    { id: "playlist", label: "Playlists" },
    { id: "engagement", label: "Engagement" },
    { id: "badge", label: "Badges" },
    { id: "loading", label: "Loading" },
    { id: "navigation", label: "Navigation" },
    { id: "notification", label: "Notifications" }
  ];

  const filteredEffects = videoEffects.filter(effect => {
    const matchesSearch = effect.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      effect.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === "all" || effect.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-slate-950">
      <CategoryHeader
        icon={Video}
        title="Video Effects"
        description="50 video player components, controls, thumbnails, and engagement features"
        gradient="rgb(139, 92, 246), rgb(6, 182, 212)"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* Search and Filter */}
        <div className="mb-8 space-y-4">
          <input
            type="text"
            placeholder="Search video effects..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder:text-slate-500"
          />
          
          <div className="flex gap-2 flex-wrap">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2 rounded-lg text-sm transition ${
                  activeCategory === cat.id
                    ? "bg-violet-600 text-white"
                    : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Effects Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {filteredEffects.map(effect => {
            const PreviewComponent = effect.component;
            return (
              <EffectCard
                key={effect.id}
                title={effect.title}
                description={effect.description}
                code={effect.code}
              >
                <PreviewComponent />
              </EffectCard>
            );
          })}
        </div>
      </div>
    </div>
  );
}