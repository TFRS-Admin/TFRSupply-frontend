import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import {
  Eye, Volume2, Layers, Navigation, MousePointerClick,
  Menu, MessageCircle, Bot, Users, LayoutDashboard, Megaphone,
  Palette, FileText, Mail, Heart, CheckSquare, ShoppingBag, ShoppingCart,
  Gamepad2, Sparkles, Loader2, Video, ArrowRight } from
"lucide-react";

const categories = [
{
  title: "UI Components",
  items: [
  { name: "Visual", page: "VisualEffects", icon: Eye, desc: "VHS, glitch, particles & more" },
  { name: "Audio", page: "AudioEffects", icon: Volume2, desc: "Music & visualizers" },
  { name: "Transitions", page: "Transitions", icon: Layers, desc: "Page fades & animations" },
  { name: "Buttons", page: "ButtonEffects", icon: MousePointerClick, desc: "Ripples & hover effects" },
  { name: "Colors", page: "ColorSchemes", icon: Eye, desc: "Color palettes" },
  { name: "Icons", page: "IconEffects", icon: Sparkles, desc: "Icon animations" },
  { name: "Menus", page: "MenuEffects", icon: Menu, desc: "Dropdowns & mega menus" },
  { name: "Navigation", page: "NavigationEffects", icon: Navigation, desc: "Headers & scroll reveals" },
  { name: "Spinners", page: "LoadingSpinners", icon: Loader2, desc: "Loading animations" },
  { name: "Dividers", page: "DividerEffects", icon: Layers, desc: "Section dividers" }]

},
{
  title: "Interactive",
  items: [
  { name: "Chat", page: "ChatEffects", icon: MessageCircle, desc: "Chat bubbles & messaging" },
  { name: "AI Agents", page: "AIAgentEffects", icon: Bot, desc: "AI interfaces" },
  { name: "Characters", page: "CharacterEffects", icon: Users, desc: "Animated mascots" }]

},
{
  title: "Business",
  items: [
  { name: "Admin", page: "AdminLayouts", icon: LayoutDashboard, desc: "Tables & dashboards" },
  { name: "Marketing", page: "MarketingEffects", icon: Megaphone, desc: "CTAs & testimonials" },
  { name: "E-commerce", page: "EcommerceEffects", icon: ShoppingBag, desc: "Products & ratings" },
  { name: "Cart", page: "CartCheckout", icon: ShoppingCart, desc: "Shopping cart UI" }]

},
{
  title: "Content & Media",
  items: [
    { name: "Text", page: "TextEffects", icon: Sparkles, desc: "50+ animated typography" },
    { name: "Creative", page: "CreativeEffects", icon: Palette, desc: "Design tools" },
    { name: "Content", page: "ContentEffects", icon: FileText, desc: "Blog & publishing" },
    { name: "Social", page: "SocialEffects", icon: Heart, desc: "Posts & feeds" },
    { name: "Comms", page: "CommunicationEffects", icon: Mail, desc: "Email & notifications" },
    { name: "Video", page: "VideoEffects", icon: Video, desc: "Video players & effects" },
    { name: "YouTube", page: "VideoPlayerCustomization", icon: Video, desc: "Custom overlays & players" },
    { name: "Donations", page: "DonationComponents", icon: Heart, desc: "Payment gateways" }]

},
{
  title: "Specialty",
  items: [
  { name: "Productivity", page: "ProductivityEffects", icon: CheckSquare, desc: "Tasks & timers" },
  { name: "Abstract", page: "AbstractAnimations", icon: Sparkles, desc: "Mesmerizing visuals" },
  { name: "Gaming", page: "GamingEffects", icon: Gamepad2, desc: "Retro & game UI" },
  { name: "Pixel Assets", page: "PixelAssets", icon: Layers, desc: "Sprites & icons" },
  { name: "Premium", page: "PremiumEffects", icon: Heart, desc: "Premium store" }]

}];


export default function Explore() {
  const [hoveredCard, setHoveredCard] = useState(null);

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12">

          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="text-white">Explore </span>
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-violet-400 to-cyan-400">
              All Effects
            </span>
          </h1>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">Browse through our complete collection of 400+ UI effects, organized by category

          </p>
        </motion.div>

        {/* Categories Grid */}
        <div className="space-y-12">
          {categories.map((category, categoryIndex) =>
          <motion.div
            key={category.title}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: categoryIndex * 0.1 }}>

              {/* Category Title */}
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
                <div className="w-1 h-8 bg-gradient-to-b from-violet-500 to-cyan-500 rounded-full" />
                {category.title}
                <span className="text-sm text-slate-500 font-normal">
                  ({category.items.length} {category.items.length === 1 ? 'page' : 'pages'})
                </span>
              </h2>

              {/* Items Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {category.items.map((item, itemIndex) =>
              <Link
                key={item.page}
                to={createPageUrl(item.page)}
                onMouseEnter={() => setHoveredCard(`${categoryIndex}-${itemIndex}`)}
                onMouseLeave={() => setHoveredCard(null)}>

                    <motion.div
                  whileHover={{ y: -4 }}
                  className="relative group h-full">

                      {/* Glow effect */}
                      <motion.div
                    animate={{
                      opacity: hoveredCard === `${categoryIndex}-${itemIndex}` ? 0.3 : 0
                    }}
                    className="absolute -inset-2 bg-gradient-to-r from-violet-500 to-cyan-500 rounded-2xl blur-xl" />


                      {/* Card */}
                      <div className="relative p-6 rounded-xl bg-slate-900/80 border border-slate-800 group-hover:border-slate-700 transition-all h-full">
                        <div className="flex items-start gap-4">
                          {/* Icon */}
                          <motion.div
                        animate={{
                          rotate: hoveredCard === `${categoryIndex}-${itemIndex}` ? 360 : 0
                        }}
                        transition={{ duration: 0.6 }}
                        className="flex-shrink-0 p-3 rounded-lg bg-gradient-to-br from-violet-500/20 to-cyan-500/20 border border-violet-500/30">

                            <item.icon className="w-5 h-5 text-violet-400" />
                          </motion.div>

                          {/* Content */}
                          <div className="flex-1 min-w-0">
                            <h3 className="font-semibold text-white mb-1 group-hover:text-violet-400 transition-colors">
                              {item.name}
                            </h3>
                            <p className="text-sm text-slate-400 line-clamp-2">
                              {item.desc}
                            </p>
                          </div>

                          {/* Arrow */}
                          <motion.div
                        animate={{
                          x: hoveredCard === `${categoryIndex}-${itemIndex}` ? 4 : 0
                        }}>

                            <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-violet-400" />
                          </motion.div>
                        </div>
                      </div>
                    </motion.div>
                  </Link>
              )}
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>);

}