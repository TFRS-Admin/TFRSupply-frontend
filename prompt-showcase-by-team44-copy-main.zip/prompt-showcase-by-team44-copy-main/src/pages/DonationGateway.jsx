import React, { useState } from "react";
import { motion } from "framer-motion";
import { ExternalLink, Heart, Sparkles, Zap, Copy, Check } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

export default function DonationGateway() {
  const [copied, setCopied] = useState(null);

  const { data: settings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || {};
    },
    initialData: {}
  });

  const donations = settings?.donation_settings || {};

  const copyToClipboard = (text, key) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  };

  const donationOptions = [
    { 
      key: "kofi_username", 
      label: "Ko-fi", 
      icon: "☕", 
      color: "from-amber-500 to-orange-500",
      bg: "bg-gradient-to-br from-amber-400 to-orange-500",
      url: donations.kofi_username ? `https://ko-fi.com/${donations.kofi_username}` : null,
      display: donations.kofi_username,
      desc: "No fees • Perfect for Canadians"
    },
    { 
      key: "buymeacoffee_username", 
      label: "Buy Me a Coffee", 
      icon: "🍵", 
      color: "from-yellow-500 to-amber-600",
      bg: "bg-gradient-to-br from-yellow-400 to-amber-500",
      url: donations.buymeacoffee_username ? `https://buymeacoffee.com/${donations.buymeacoffee_username}` : null,
      display: donations.buymeacoffee_username,
      desc: "5% fee • Super popular"
    },
    { 
      key: "paypal_me", 
      label: "PayPal", 
      icon: "💳", 
      color: "from-blue-500 to-indigo-600",
      bg: "bg-gradient-to-br from-blue-400 to-indigo-500",
      url: donations.paypal_me ? `https://${donations.paypal_me}` : donations.paypal_email ? `https://paypal.me/${donations.paypal_email}` : null,
      display: donations.paypal_me || donations.paypal_email,
      desc: "Most trusted worldwide"
    },
    { 
      key: "patreon_url", 
      label: "Patreon", 
      icon: "🎨", 
      color: "from-red-500 to-pink-600",
      bg: "bg-gradient-to-br from-red-400 to-pink-500",
      url: donations.patreon_url,
      display: donations.patreon_url,
      desc: "Monthly subscriptions"
    },
    { 
      key: "stripe_link", 
      label: "Stripe", 
      icon: "💎", 
      color: "from-violet-500 to-purple-600",
      bg: "bg-gradient-to-br from-violet-400 to-purple-500",
      url: donations.stripe_link,
      display: donations.stripe_link,
      desc: "Credit & debit cards"
    },
    { 
      key: "gofundme_url", 
      label: "GoFundMe", 
      icon: "💚", 
      color: "from-green-500 to-emerald-600",
      bg: "bg-gradient-to-br from-green-400 to-emerald-500",
      url: donations.gofundme_url,
      display: donations.gofundme_url,
      desc: "One-time fundraising"
    },
    { 
      key: "bitcoin_address", 
      label: "Bitcoin", 
      icon: "₿", 
      color: "from-orange-500 to-yellow-500",
      bg: "bg-gradient-to-br from-orange-400 to-yellow-500",
      url: null,
      display: donations.bitcoin_address,
      desc: "Crypto • No middleman"
    },
    { 
      key: "ethereum_address", 
      label: "Ethereum", 
      icon: "Ξ", 
      color: "from-slate-500 to-slate-700",
      bg: "bg-gradient-to-br from-slate-400 to-slate-600",
      url: null,
      display: donations.ethereum_address,
      desc: "ETH & ERC-20 tokens"
    },
    { 
      key: "solana_address", 
      label: "Solana", 
      icon: "◎", 
      color: "from-purple-500 to-indigo-600",
      bg: "bg-gradient-to-br from-purple-400 to-indigo-500",
      url: null,
      display: donations.solana_address,
      desc: "Fast & low fees"
    },
    { 
      key: "etransfer_email", 
      label: "Interac e-Transfer", 
      icon: "🇨🇦", 
      color: "from-red-600 to-red-700",
      bg: "bg-gradient-to-br from-red-500 to-red-600",
      url: null,
      display: donations.etransfer_email,
      desc: "Canada only • Instant"
    },
    { 
      key: "venmo_username", 
      label: "Venmo", 
      icon: "💙", 
      color: "from-blue-400 to-blue-600",
      bg: "bg-gradient-to-br from-blue-300 to-blue-500",
      url: donations.venmo_username ? `https://venmo.com/${donations.venmo_username}` : null,
      display: donations.venmo_username,
      desc: "US only • Mobile friendly"
    },
    { 
      key: "cashapp_tag", 
      label: "Cash App", 
      icon: "💵", 
      color: "from-green-500 to-green-700",
      bg: "bg-gradient-to-br from-green-400 to-green-600",
      url: donations.cashapp_tag ? `https://cash.app/${donations.cashapp_tag}` : null,
      display: donations.cashapp_tag,
      desc: "US & UK • Instant"
    },
  ].filter(d => d.display);

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Feastables-inspired vibrant background */}
      <div className="absolute inset-0 bg-gradient-to-br from-cyan-400 via-blue-500 to-fuchsia-600">
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 60px, rgba(255,255,255,0.05) 60px, rgba(255,255,255,0.05) 120px)`
        }} />
      </div>

      {/* Floating candy-like shapes */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute"
            style={{
              left: `${5 + i * 8}%`,
              top: `${10 + (i % 4) * 25}%`,
              width: `${30 + Math.random() * 40}px`,
              height: `${30 + Math.random() * 40}px`
            }}
            animate={{
              y: [0, -40, 0],
              rotate: [0, 360],
              scale: [1, 1.3, 1]
            }}
            transition={{
              duration: 5 + i,
              repeat: Infinity,
              delay: i * 0.4
            }}
          >
            <div className={`w-full h-full rounded-full ${i % 4 === 0 ? 'bg-pink-300/20' : i % 4 === 1 ? 'bg-yellow-300/20' : i % 4 === 2 ? 'bg-cyan-300/20' : 'bg-white/20'} blur-sm`} />
          </motion.div>
        ))}
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <motion.div
            animate={{ scale: [1, 1.05, 1], rotate: [0, 2, -2, 0] }}
            transition={{ duration: 3, repeat: Infinity }}
            className="inline-block px-8 py-4 bg-white/20 backdrop-blur-md rounded-full border-6 border-white mb-8 shadow-2xl"
          >
            <p className="text-lg font-black text-white uppercase tracking-widest flex items-center gap-3">
              <Heart className="w-6 h-6 text-pink-200" />
              Support the Mission
              <Sparkles className="w-6 h-6 text-yellow-200" />
            </p>
          </motion.div>

          <h1 className="text-6xl md:text-7xl font-black text-white mb-6 leading-tight" style={{
            textShadow: "5px 5px 0 rgba(0,0,0,0.3), 10px 10px 0 rgba(255,255,255,0.1)"
          }}>
            FUEL THE<br />
            <span className="text-yellow-300">FREE</span> REVOLUTION
          </h1>

          <p className="text-2xl md:text-3xl font-bold text-white/90 max-w-3xl mx-auto mb-4">
            300+ Effects • Zero Ads • Always Free
          </p>

          <p className="text-xl text-white/80 max-w-2xl mx-auto italic">
            Your donation keeps the code flowing and the features growing! 🚀
          </p>
        </motion.div>

        {/* Donation Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {donationOptions.map((option, i) => (
            <motion.div
              key={option.key}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
              whileHover={{ y: -8, scale: 1.02 }}
              className="relative group"
            >
              <div className="relative rounded-2xl overflow-hidden border-4 border-white shadow-[0_8px_30px_rgba(0,0,0,0.3)] bg-white p-6">
                {/* Background gradient */}
                <div className={`absolute inset-0 ${option.bg} opacity-90`} />
                
                {/* Content */}
                <div className="relative z-10">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-5xl">{option.icon}</span>
                    <motion.div
                      animate={{ rotate: [0, 10, -10, 0] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="w-12 h-12 bg-white rounded-full flex items-center justify-center font-black text-xl border-2 border-black/10 shadow-lg"
                    >
                      ⭐
                    </motion.div>
                  </div>

                  <h3 className="text-2xl font-black text-white mb-2" style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.3)" }}>
                    {option.label}
                  </h3>

                  <p className="text-sm text-white/80 mb-4 font-semibold">
                    {option.desc}
                  </p>

                  {option.url ? (
                    <a
                      href={option.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block w-full px-6 py-3 bg-white text-black font-black rounded-xl shadow-lg hover:scale-105 transition-transform text-center flex items-center justify-center gap-2"
                    >
                      DONATE NOW
                      <ExternalLink className="w-5 h-5" />
                    </a>
                  ) : (
                    <div className="space-y-2">
                      <div className="px-3 py-2 bg-black/20 rounded-lg font-mono text-xs text-white break-all backdrop-blur-sm border border-white/20">
                        {option.display}
                      </div>
                      <button
                        onClick={() => copyToClipboard(option.display, option.key)}
                        className="w-full px-4 py-2 bg-white text-black font-bold rounded-lg hover:scale-105 transition-transform flex items-center justify-center gap-2"
                      >
                        {copied === option.key ? (
                          <>
                            <Check className="w-4 h-4" />
                            COPIED!
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4" />
                            COPY ADDRESS
                          </>
                        )}
                      </button>
                    </div>
                  )}
                </div>

                {/* Decorative corner */}
                <div className="absolute top-0 right-0 w-16 h-16 bg-white/20 transform rotate-45 translate-x-8 -translate-y-8" />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="text-center"
        >
          <div className="inline-block px-8 py-6 bg-white/95 backdrop-blur-md rounded-3xl border-4 border-pink-400 shadow-2xl">
            <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-600 to-fuchsia-600 mb-2">
              Every Contribution Matters! 💙
            </p>
            <p className="text-slate-700 font-semibold">
              From $1 to $1000 • All donations fuel the mission 🚀
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}