import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, useMotionValue, useSpring } from "framer-motion";
import {
  Eye, Volume2, Layers, Navigation, MousePointerClick,
  ArrowRight, Sparkles, Zap, Star, MessageCircle, Bot, Search, Loader2,
  LayoutDashboard, Megaphone, Palette, FileText, Mail, Heart, CheckSquare, ShoppingCart, ShoppingBag, Menu, Users, Gamepad2, Type, Video } from
"lucide-react";
import { Button } from "@/components/ui/button";
import TypewriterHero from "@/components/effects/TypewriterHero";
import SearchFilterEnhanced from "@/components/effects/SearchFilterEnhanced";
// GlitchButton removed (unused)
import AdBannerManager from "@/components/ads/AdBannerManager";
// BuyMeCoffeeCTA removed (unused)
import RetroTVShowcase from "@/components/video/RetroTVShowcase";
import ThemedVideoShowcase from "@/components/video/ThemedVideoShowcase";
import BlockbusterShowcase from "@/components/video/BlockbusterShowcase";
import TemplateShowcase from "@/components/marketing/TemplateShowcase";
import DonationBanner from "@/components/marketing/DonationBanner";
import CinematicVideoModal from "@/components/video/CinematicVideoModal";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

const categories = [
{
  name: "Text Effects",
  page: "TextEffects",
  icon: Type,
  description: "50+ animated text & interactive typography",
  gradient: "from-violet-500 to-fuchsia-600",
  borderColor: "border-violet-500",
  category: "creative",
  count: 50
},
{
  name: "Visual Effects",
  page: "VisualEffects",
  icon: Eye,
  description: "VHS, glitch, particles, neon glow & more",
  gradient: "from-violet-500 to-purple-600",
  borderColor: "border-violet-500",
  category: "visual",
  count: 50
},
{
  name: "Audio Effects",
  page: "AudioEffects",
  icon: Volume2,
  description: "Background music, visualizers, sounds",
  gradient: "from-cyan-500 to-blue-600",
  borderColor: "border-cyan-500",
  category: "audio",
  count: 20
},
{
  name: "Transitions",
  page: "Transitions",
  icon: Layers,
  description: "Page fades, staggered lists, counters",
  gradient: "from-teal-500 to-emerald-600",
  borderColor: "border-teal-500",
  category: "transition",
  count: 25
},
{
  name: "Navigation",
  page: "NavigationEffects",
  icon: Navigation,
  description: "Headers, drawers, scroll reveals",
  gradient: "from-amber-500 to-orange-600",
  borderColor: "border-amber-500",
  category: "navigation",
  count: 20
},
{
  name: "Buttons",
  page: "ButtonEffects",
  icon: MousePointerClick,
  description: "Ripples, fills, loading states",
  gradient: "from-emerald-500 to-teal-600",
  borderColor: "border-emerald-500",
  category: "button",
  count: 35
},
{
  name: "Chat Components",
  page: "ChatEffects",
  icon: MessageCircle,
  description: "Chat bubbles, bots, messaging UI",
  gradient: "from-blue-500 to-indigo-600",
  borderColor: "border-blue-500",
  category: "chat",
  count: 20
},
{
  name: "AI Agent",
  page: "AIAgentEffects",
  icon: Bot,
  description: "AI interfaces, agent UIs, prompts",
  gradient: "from-purple-500 to-violet-600",
  borderColor: "border-purple-500",
  category: "agent",
  count: 15
},
{
  name: "Loading Spinners",
  page: "LoadingSpinners",
  icon: Loader2,
  description: "Pulse, heartbeat & branded loaders",
  gradient: "from-violet-500 to-pink-600",
  borderColor: "border-pink-500",
  category: "visual",
  count: 20
},
{
  name: "Gaming Effects",
  page: "GamingEffects",
  icon: Gamepad2,
  description: "Retro, Sci-Fi, FPS, RPG game UI",
  gradient: "from-orange-500 to-red-600",
  borderColor: "border-orange-500",
  category: "gaming",
  count: 100
},
{
  name: "Abstract Animations",
  page: "AbstractAnimations",
  icon: Sparkles,
  description: "Mesmerizing abstract visuals",
  gradient: "from-fuchsia-500 to-violet-600",
  borderColor: "border-fuchsia-500",
  category: "creative",
  count: 40
},
{
  name: "Admin & Dashboards",
  page: "AdminLayouts",
  icon: LayoutDashboard,
  description: "Tables, sidebars, stats, modals & more",
  gradient: "from-slate-500 to-zinc-600",
  borderColor: "border-slate-500",
  category: "admin",
  count: 25
},
{
  name: "Marketing",
  page: "MarketingEffects",
  icon: Megaphone,
  description: "CTAs, testimonials, pricing, popups",
  gradient: "from-rose-500 to-red-600",
  borderColor: "border-rose-500",
  category: "marketing",
  count: 25
},
{
  name: "Creative & Design",
  page: "CreativeEffects",
  icon: Palette,
  description: "Color pickers, layers, tools, filters",
  gradient: "from-fuchsia-500 to-pink-600",
  borderColor: "border-fuchsia-500",
  category: "creative",
  count: 25
},
{
  name: "Content & Publishing",
  page: "ContentEffects",
  icon: FileText,
  description: "Blog cards, editors, quotes, FAQs",
  gradient: "from-sky-500 to-cyan-600",
  borderColor: "border-sky-500",
  category: "content",
  count: 25
},
{
  name: "Communication",
  page: "CommunicationEffects",
  icon: Mail,
  description: "Email, chat, calls, notifications",
  gradient: "from-indigo-500 to-violet-600",
  borderColor: "border-indigo-500",
  category: "communication",
  count: 25
},
{
  name: "Social & Community",
  page: "SocialEffects",
  icon: Heart,
  description: "Posts, likes, shares, profiles, feeds",
  gradient: "from-pink-500 to-rose-600",
  borderColor: "border-pink-500",
  category: "social",
  count: 25
},
{
  name: "Productivity & Tasks",
  page: "ProductivityEffects",
  icon: CheckSquare,
  description: "Todos, timers, kanban, habits",
  gradient: "from-green-500 to-emerald-600",
  borderColor: "border-green-500",
  category: "productivity",
  count: 25
},
{
  name: "E-commerce",
  page: "EcommerceEffects",
  icon: ShoppingBag,
  description: "Products, ratings, wishlists, filters",
  gradient: "from-orange-500 to-amber-600",
  borderColor: "border-orange-500",
  category: "ecommerce",
  count: 15
},
{
  name: "Cart & Checkout",
  page: "CartCheckout",
  icon: ShoppingCart,
  description: "Cart items, payment, shipping, orders",
  gradient: "from-amber-500 to-yellow-600",
  borderColor: "border-amber-500",
  category: "ecommerce",
  count: 25
},
{
  name: "Menu Effects",
  page: "MenuEffects",
  icon: Menu,
  description: "Dropdowns, mega menus, sidebars",
  gradient: "from-lime-500 to-green-600",
  borderColor: "border-lime-500",
  category: "navigation",
  count: 20
},
{
  name: "Characters",
  page: "CharacterEffects",
  icon: Users,
  description: "Animated mascots, avatars, emojis",
  gradient: "from-red-500 to-orange-600",
  borderColor: "border-red-500",
  category: "creative",
  count: 12
},
{
  name: "Video Effects",
  page: "VideoEffects",
  icon: Video,
  description: "Video players, transitions, overlays",
  gradient: "from-purple-500 to-pink-600",
  borderColor: "border-purple-500",
  category: "content",
  count: 15
},
{
  name: "Dividers",
  page: "DividerEffects",
  icon: Layers,
  description: "Section dividers & separators",
  gradient: "from-slate-500 to-gray-600",
  borderColor: "border-slate-500",
  category: "visual",
  count: 20
}];


function CategoryCard({ category, index }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}>

      <Link to={createPageUrl(category.page)}>
        <motion.div
          onHoverStart={() => setIsHovered(true)}
          onHoverEnd={() => setIsHovered(false)}
          whileHover={{ y: -8 }}
          className="relative group">

          <motion.div
            animate={{ opacity: isHovered ? 0.5 : 0 }}
            className={`absolute -inset-2 bg-gradient-to-r ${category.gradient} rounded-3xl blur-xl transition-opacity`} />

          
          <div className="relative p-6 rounded-2xl bg-slate-900/80 border border-slate-800 group-hover:border-slate-700 transition-all overflow-hidden">
            <div className="absolute inset-0 opacity-5">
              <div className="absolute inset-0" style={{
                backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
                backgroundSize: '24px 24px'
              }} />
            </div>
            
            <div className="relative">
              <div className="flex items-start justify-between mb-4">
                <motion.div
                  animate={{ rotate: isHovered ? 360 : 0 }}
                  transition={{ duration: 0.6 }}
                  className={`inline-flex p-3 rounded-xl bg-black/70 backdrop-blur-sm border ${category.borderColor}`}
                  style={{ backdropFilter: "blur(2px)", opacity: 0.85 }}>

                  <category.icon className="w-6 h-6 text-white" />
                </motion.div>
                <span className="px-2 py-1 rounded-full bg-slate-800 text-xs text-slate-400">
                  {category.count}+ effects
                </span>
              </div>
              
              <h3 className="text-xl font-bold text-white mb-2">
                {category.name}
              </h3>
              
              <p className="text-slate-400 text-sm mb-4">
                {category.description}
              </p>
              
              <div className="flex items-center text-sm font-medium text-slate-500 group-hover:text-white transition-colors">
                <span>Explore</span>
                <motion.div
                  animate={{ x: isHovered ? 4 : 0 }}
                  transition={{ duration: 0.2 }}>

                  <ArrowRight className="w-4 h-4 ml-2" />
                </motion.div>
              </div>
            </div>
          </div>
        </motion.div>
      </Link>
    </motion.div>);

}

function FloatingParticle({ delay }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0 }}
      animate={{
        opacity: [0, 1, 1, 0],
        scale: [0, 1, 1, 0],
        y: [100, -100],
        x: [0, Math.random() * 100 - 50]
      }}
      transition={{
        duration: 4,
        delay,
        repeat: Infinity,
        repeatDelay: Math.random() * 2
      }}
      className="absolute w-2 h-2 rounded-full bg-gradient-to-r from-violet-400 to-cyan-400"
      style={{
        left: `${Math.random() * 100}%`,
        bottom: 0
      }} />);


}

export default function Home() {
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const springX = useSpring(mouseX, { stiffness: 50, damping: 20 });
  const springY = useSpring(mouseY, { stiffness: 50, damping: 20 });

  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [showRetroAd, setShowRetroAd] = useState(true);
  const [showVideoModal, setShowVideoModal] = useState(false);

  // Random glitch effect for discover text
  useEffect(() => {
    const triggerGlitch = () => {
      const element = document.querySelector('.discover-text');
      if (element) {
        element.classList.add('glitching');
        setTimeout(() => element.classList.remove('glitching'), 400);
      }
    };

    // Trigger 5 random glitches within 60 seconds
    const times = Array(5).fill(0).map(() => Math.random() * 60000).sort((a, b) => a - b);
    const timeouts = times.map((time) => setTimeout(triggerGlitch, time));

    const interval = setInterval(() => {
      const newTimes = Array(5).fill(0).map(() => Math.random() * 60000).sort((a, b) => a - b);
      newTimes.forEach((time, i) => {
        setTimeout(triggerGlitch, time);
      });
    }, 60000);

    return () => {
      timeouts.forEach((t) => clearTimeout(t));
      clearInterval(interval);
    };
  }, []);

  const { data: appSettings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || {};
    },
    initialData: {}
  });

  useEffect(() => {
    const handleMouseMove = (e) => {
      mouseX.set(e.clientX - window.innerWidth / 2);
      mouseY.set(e.clientY - window.innerHeight / 2);
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  // All derived state AFTER all hooks
  const seeItInActionEnabled = appSettings?.see_it_in_action_enabled === true;
  const isRetroAdEnabled = appSettings?.enabled_features?.includes("retroAdBanner");
  const selectedBanner = appSettings?.selected_banner || "retroInfomercial";
  const bannerConfig = appSettings?.banner_configs?.[selectedBanner] || {};
  const heroStyle = appSettings?.hero_style || {};
  const walkthroughVideo = appSettings?.walkthrough_video || {};
  const coffeeBanner = appSettings?.coffee_banner || {};
  const heroLayout = appSettings?.hero_layout || "default";

  const filteredCategories = categories.filter((cat) => {
    const matchesSearch = cat.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cat.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === "all" || cat.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="relative overflow-hidden -mt-24">
      {/* Hero Section */}
      <section className={`relative ${heroLayout === "split" ? "min-h-[50vh]" : "min-h-[50vh]"} flex items-center justify-center pt-20 pb-12`}>
        {/* Background gradient covering EVERYTHING including top area behind nav */}
        <div className="absolute -top-24 inset-x-0 bottom-0 bg-gradient-to-b from-blue-950/60 via-blue-800/50 via-30% to-slate-950" />

        {/* Subtle Vignette Effect */}
        <div className="absolute inset-0 bg-gradient-radial from-transparent via-transparent to-black/40" style={{ backgroundImage: "radial-gradient(circle at center, transparent 0%, transparent 60%, rgba(0,0,0,0.4) 100%)" }} />

        {/* Animated Background */}
        <div className="absolute inset-0 overflow-hidden">
          <motion.div
            style={{ x: springX, y: springY }}
            className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-500/20 rounded-full blur-3xl" />
          

          <motion.div
            style={{ x: springX, y: springY }}
            className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl" />
          

          <motion.div
            style={{ x: springX, y: springY }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-teal-500/10 rounded-full blur-3xl" />
          


          {[...Array(12)].map((_, i) =>
          <FloatingParticle key={i} delay={i * 0.3} />
          )}
        </div>

        {/* Grid Pattern */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)`,
            backgroundSize: '50px 50px'
          }} />
        </div>

        <div className="mx-auto pt-10 pr-4 pl-4 relative max-w-7xl sm:px-6 lg:px-8">
          {heroLayout === "split" ?
          <div className="grid md:grid-cols-2 gap-8 items-start">
              {/* Left - Content */}
              <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="flex flex-col items-center text-center"
              style={{ height: '550px' }}>

                <div className="mt-5 mr-10 mb-5 ml-20 pt-9 flex flex-col items-center justify-center h-full space-y-6">
                  <TypewriterHero />

                  <div className="relative max-w-2xl mx-auto px-4">
                    <p className="bg-transparent text-slate-300 mb-2 text-base discover-text md:text-lg relative z-10">OBSESS | LEARN | BUILD | CREATE 

                  </p>
                    <p className="text-base md:text-lg text-white font-semibold relative z-10">Copy & Paste 850+ Prompts or Code for Effects +
(Create Apps, Sites, Tools...)
                  </p>
                    <style>{`
                      @keyframes random-glitch {
                        0%, 100% { text-shadow: none; transform: translate(0); filter: none; }
                        10% { text-shadow: -3px 0 #ff00ff, 3px 0 #00ffff; transform: translate(-2px, 1px); filter: hue-rotate(90deg); }
                        20% { text-shadow: 3px 0 #ff00ff, -3px 0 #00ffff; transform: translate(2px, -1px); filter: hue-rotate(-90deg); }
                        30% { text-shadow: -2px 0 #00ffff, 2px 0 #ff00ff; transform: translate(-1px, 2px); }
                        40% { text-shadow: 2px 0 #00ffff, -2px 0 #ff00ff; transform: translate(1px, -2px); }
                      }
                      .discover-text.glitching { animation: random-glitch 0.4s ease-in-out; }
                    `}</style>
                  </div>

                  <Link to={createPageUrl("Explore")}>
                    <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="explore-hero-btn relative inline-flex items-center gap-2 px-8 py-3 rounded-xl font-semibold overflow-hidden">

                    <div className="absolute inset-0 bg-slate-900/30 rounded-xl" />
                    <div className="rounded-xl absolute inset-0 border-2 border-violet-500" />
                    <span className="relative z-10 flex items-center gap-2 text-white explore-btn-content">
                      <Zap className="w-5 h-5 text-violet-400" />
                      <span>Explore Effects</span>
                      <ArrowRight className="w-4 h-4" />
                    </span>
                    <style>{`
                      .explore-hero-btn:hover .explore-btn-content { animation: explore-glitch 0.3s ease-in-out infinite; }
                      .explore-hero-btn:hover { animation: btn-shake 0.3s ease-in-out infinite; }
                      @keyframes explore-glitch {
                        0%, 100% { text-shadow: none; filter: none; }
                        20% { text-shadow: -2px 0 #ff00ff, 2px 0 #00ffff; filter: hue-rotate(10deg); }
                        40% { text-shadow: 2px 0 #ff00ff, -2px 0 #00ffff; filter: hue-rotate(-10deg); }
                        60% { text-shadow: -1px 0 #00ffff, 1px 0 #ff00ff; filter: hue-rotate(5deg); }
                        80% { text-shadow: 1px 0 #00ffff, -1px 0 #ff00ff; filter: hue-rotate(-5deg); }
                      }
                      @keyframes btn-shake {
                        0%, 100% { transform: translate(0) scale(1.02); }
                        10% { transform: translate(-1px, 1px) scale(1.02); }
                        20% { transform: translate(1px, -1px) scale(1.02); }
                        30% { transform: translate(-1px, 0) scale(1.02); }
                        40% { transform: translate(1px, 1px) scale(1.02); }
                        50% { transform: translate(0, -1px) scale(1.02); }
                      }
                      `}</style>
                    </motion.button>
                  </Link>
                </div>
              </motion.div>

              {/* Right - Video */}
              <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              style={{ height: '550px' }}
              className="flex flex-col justify-center">

                <div className="mt-1 space-y-6">
                  <div className="relative rounded-2xl overflow-hidden border-3 border-violet-600 shadow-[0_0_40px_rgba(139,92,246,0.4)]">
                    <div className="aspect-video bg-black">
                      {walkthroughVideo.youtube_url && typeof walkthroughVideo.youtube_url === 'string' &&
                    <iframe
                      width="100%"
                      height="100%"
                      src={`https://www.youtube.com/embed/${walkthroughVideo.youtube_url.includes('v=') ? walkthroughVideo.youtube_url.split('v=')[1]?.split('&')[0] : walkthroughVideo.youtube_url.split('/').pop()}?autoplay=0&rel=0`}
                      title="App Walkthrough"
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                      className="w-full h-full" />

                    }
                    </div>
                  </div>
                  <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setShowVideoModal(true)}
                  className="video-cta-btn relative inline-flex items-center justify-center gap-2 px-8 py-3 rounded-xl font-semibold overflow-hidden w-full">

                    <div className="absolute inset-0 bg-slate-900/30 rounded-xl" />
                    <div className="absolute inset-0 rounded-xl border-2 border-cyan-600" />
                    <span className="relative z-10 flex items-center gap-2 text-white video-cta-content">
                      <Zap className="w-5 h-5 text-cyan-400" />
                      <span>Watch & Level Up 10x</span>
                    </span>
                    <style>{`
                      .video-cta-btn:hover .video-cta-content { animation: video-glitch 0.3s ease-in-out infinite; }
                      .video-cta-btn:hover { animation: video-shake 0.3s ease-in-out infinite; }
                      @keyframes video-glitch {
                        0%, 100% { text-shadow: none; filter: none; }
                        20% { text-shadow: -2px 0 #ff00ff, 2px 0 #00ffff; filter: hue-rotate(10deg); }
                        40% { text-shadow: 2px 0 #ff00ff, -2px 0 #00ffff; filter: hue-rotate(-10deg); }
                        60% { text-shadow: -1px 0 #00ffff, 1px 0 #ff00ff; filter: hue-rotate(5deg); }
                        80% { text-shadow: 1px 0 #00ffff, -1px 0 #ff00ff; filter: hue-rotate(-5deg); }
                      }
                      @keyframes video-shake {
                        0%, 100% { transform: translate(0) scale(1.02); }
                        10% { transform: translate(-1px, 1px) scale(1.02); }
                        20% { transform: translate(1px, -1px) scale(1.02); }
                        30% { transform: translate(-1px, 0) scale(1.02); }
                        40% { transform: translate(1px, 1px) scale(1.02); }
                        50% { transform: translate(0, -1px) scale(1.02); }
                      }
                    `}</style>
                  </motion.button>
                </div>
              </motion.div>
            </div> :

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="text-center">
            
                {/* Badge */}
                <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }} className="bg-white/5 mt-5 pt-2 pr-4 pb-2 pl-4 rounded-full inline-flex items-center gap-2 border border-white/10">

                
                  <Sparkles className="w-4 h-4 text-violet-400" />
                  <span className="text-sm text-slate-300">850+ Interactive Effects</span>
                </motion.div>

                {/* Typewriter Hero */}
                <TypewriterHero />

              <div className="relative max-w-2xl mx-auto mb-8 -mt-3">
              <p className="text-slate-400 mb-2 text-lg md:text-xl relative z-10 discover-text">Discover the power of modern UI/UX with interactive demos

              </p>
              <p className="text-lg md:text-xl text-white font-semibold relative z-10">
                Copy & Paste Prompts or Code for every effect!
              </p>
              <style>{`
                @keyframes random-glitch {
                  0%, 100% { 
                    text-shadow: none; 
                    transform: translate(0);
                    filter: none;
                  }
                  10% { 
                    text-shadow: -3px 0 #ff00ff, 3px 0 #00ffff; 
                    transform: translate(-2px, 1px);
                    filter: hue-rotate(90deg);
                  }
                  20% { 
                    text-shadow: 3px 0 #ff00ff, -3px 0 #00ffff; 
                    transform: translate(2px, -1px);
                    filter: hue-rotate(-90deg);
                  }
                  30% { 
                    text-shadow: -2px 0 #00ffff, 2px 0 #ff00ff; 
                    transform: translate(-1px, 2px);
                  }
                  40% { 
                    text-shadow: 2px 0 #00ffff, -2px 0 #ff00ff; 
                    transform: translate(1px, -2px);
                  }
                }
                .discover-text.glitching {
                  animation: random-glitch 0.4s ease-in-out;
                }
              `}</style>
              </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4 justify-center">

              <Link to={createPageUrl("Explore")}>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="explore-hero-btn relative inline-flex items-center gap-2 px-8 py-3 rounded-xl font-semibold overflow-hidden">

                  {/* Dark background with 30% opacity */}
                  <div className="absolute inset-0 bg-slate-900/30 rounded-xl" />
                  
                  {/* Purple border */}
                  <div className="absolute inset-0 rounded-xl border-2 border-violet-500" />
                  
                  {/* Content */}
                  <span className="relative z-10 flex items-center gap-2 text-white explore-btn-content">
                    <Zap className="w-5 h-5 text-violet-400" />
                    <span>Explore Effects</span>
                    <ArrowRight className="w-4 h-4" />
                  </span>
                  
                  {/* Glitch animation on hover for entire button */}
                  <style>{`
                    .explore-hero-btn:hover .explore-btn-content {
                      animation: explore-glitch 0.3s ease-in-out infinite;
                    }
                    .explore-hero-btn:hover {
                      animation: btn-shake 0.3s ease-in-out infinite;
                    }
                    @keyframes explore-glitch {
                      0%, 100% { text-shadow: none; filter: none; }
                      20% { text-shadow: -2px 0 #ff00ff, 2px 0 #00ffff; filter: hue-rotate(10deg); }
                      40% { text-shadow: 2px 0 #ff00ff, -2px 0 #00ffff; filter: hue-rotate(-10deg); }
                      60% { text-shadow: -1px 0 #00ffff, 1px 0 #ff00ff; filter: hue-rotate(5deg); }
                      80% { text-shadow: 1px 0 #00ffff, -1px 0 #ff00ff; filter: hue-rotate(-5deg); }
                    }
                    @keyframes btn-shake {
                      0%, 100% { transform: translate(0) scale(1.02); }
                      10% { transform: translate(-1px, 1px) scale(1.02); }
                      20% { transform: translate(1px, -1px) scale(1.02); }
                      30% { transform: translate(-1px, 0) scale(1.02); }
                      40% { transform: translate(1px, 1px) scale(1.02); }
                      50% { transform: translate(0, -1px) scale(1.02); }
                    }
                  `}</style>
                </motion.button>
              </Link>
            </motion.div>
            </motion.div>
          }
        </div>
      </section>

      {/* Simple Gradient Divider */}
      <div className="relative h-px bg-gradient-to-r from-transparent via-slate-600 to-transparent" />

      {/* Cinematic Video Modal */}
      <CinematicVideoModal
        isOpen={showVideoModal}
        onClose={() => setShowVideoModal(false)}
        videoUrl="https://youtu.be/icaVEEGj1i4"
        logoUrl={appSettings?.logo_url}
        customOverlayImageUrl={appSettings?.youtube_overlay_image_url || appSettings?.logo_url}
        overlayEnabled={appSettings?.youtube_overlay_enabled !== false} />


      {/* Retro TV Infomercial Section */}
      <RetroTVShowcase />

      {/* Blockbuster Video Section */}
      <BlockbusterShowcase />

      {/* Walkthrough Video Section */}
      {seeItInActionEnabled && walkthroughVideo?.enabled && walkthroughVideo?.youtube_url &&
      <>
          {walkthroughVideo.theme === "default" ?
        <section className="relative py-20 overflow-hidden">
              <div className="absolute inset-0 bg-slate-950">
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-violet-900/20 via-slate-950 to-slate-950" />
              </div>
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12">
              
                  <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                    <span className="bg-clip-text text-transparent bg-gradient-to-r from-violet-400 to-cyan-400">
                      {walkthroughVideo.title || "See It In Action"}
                    </span>
                  </h2>
                  <p className="text-slate-400 max-w-2xl mx-auto">
                    {walkthroughVideo.description || "Watch our full feature walkthrough and learn how to build stunning UIs in minutes."}
                  </p>
                </motion.div>

                <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative max-w-4xl mx-auto rounded-2xl overflow-hidden shadow-2xl shadow-violet-500/20 border border-slate-800 bg-slate-900">
              
                  <div className="aspect-video w-full">
                    {walkthroughVideo.youtube_url && typeof walkthroughVideo.youtube_url === 'string' ?
                <iframe
                  width="100%"
                  height="100%"
                  src={`https://www.youtube.com/embed/${walkthroughVideo.youtube_url.includes('v=') ? walkthroughVideo.youtube_url.split('v=')[1]?.split('&')[0] : walkthroughVideo.youtube_url.split('/').pop()}?autoplay=0&rel=0`}
                  title="Product Walkthrough"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="w-full h-full" /> :

                null}
                  </div>
                </motion.div>
              </div>
            </section> :

        <ThemedVideoShowcase
          theme={walkthroughVideo.theme}
          videoUrl={walkthroughVideo.youtube_url}
          title={walkthroughVideo.title}
          description={walkthroughVideo.description} />

        }
        </>
      }

      {/* Features Section */}
      <section className="relative py-8 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            {[
            { icon: Zap, title: "Live Demos", desc: "Interactive previews" },
            { icon: Star, title: "Copy Code", desc: "Ready-to-use snippets" },
            { icon: Sparkles, title: "AI Prompts", desc: "Customize with AI" },
            { icon: Search, title: "Search & Filter", desc: "Find effects fast" }].
            map((feature, i) =>
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="text-center">

                <motion.div
                whileHover={{ rotate: 360, boxShadow: "0 0 20px rgba(139, 92, 246, 0.4)" }}
                transition={{ duration: 0.6 }}
                className="inline-flex p-3 rounded-xl bg-slate-800 mb-4">

                  <feature.icon className="w-6 h-6 text-violet-400" />
                </motion.div>
                <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                <p className="text-slate-400 text-sm">{feature.desc}</p>
              </motion.div>
            )}
          </div>

          {/* Ad Banner */}
          {isRetroAdEnabled && showRetroAd &&
          <div className="mb-8">
              <AdBannerManager
              bannerId={selectedBanner}
              config={bannerConfig}
              onClose={() => setShowRetroAd(false)} />
            </div>
          }

          {/* Search & Category Filters */}
          <SearchFilterEnhanced
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            activeCategory={activeCategory}
            setActiveCategory={setActiveCategory}
            resultCount={filteredCategories.length} />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredCategories.map((category, index) =>
            <CategoryCard key={category.page} category={category} index={index} />
            )}
                </div>

          {/* Coffee Banner */}
          {coffeeBanner?.enabled && coffeeBanner.image_url &&
          <div className="mt-12 mb-8">
              <motion.div
              className="relative overflow-hidden rounded-2xl shadow-2xl"
              style={{
                height: coffeeBanner.size === 'small' ? '120px' :
                coffeeBanner.size === 'large' ? '300px' :
                coffeeBanner.size === 'xl' ? '400px' :
                coffeeBanner.size === 'xxl' ? '500px' :
                coffeeBanner.size === 'jumbo' ? '600px' : '200px'
              }}>

                {/* Background - clickable only if button is disabled */}
                {!coffeeBanner.button_enabled ?
              <a
                href={coffeeBanner.link || "https://buymeacoffee.com/team44"}
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full h-full">

                    <motion.img
                  whileHover={{ scale: 1.01 }}
                  src={coffeeBanner.image_url}
                  alt="Support us"
                  className="w-full h-full object-cover cursor-pointer" />

                  </a> :

              <img
                src={coffeeBanner.image_url}
                alt="Support us"
                className="w-full h-full object-cover" />

              }

                {/* Button overlay */}
                {coffeeBanner.button_enabled && coffeeBanner.button_image &&
              <div className="absolute inset-0 flex items-center justify-center coffee-btn-wrapper">
                    <a
                  href={coffeeBanner.link || "https://buymeacoffee.com/team44"}
                  target="_blank"
                  rel="noopener noreferrer">

                      <motion.img
                    src={coffeeBanner.button_image}
                    alt="Buy me a coffee"
                    className={`max-w-[300px] max-h-[80px] object-contain cursor-pointer coffee-btn-${coffeeBanner.button_effect}`}
                    whileHover={
                    coffeeBanner.button_effect === 'bounce' ? { scale: 1.1, y: -5 } :
                    coffeeBanner.button_effect === 'shimmer' ? { scale: 1.05 } :
                    coffeeBanner.button_effect === 'glow' ? { scale: 1.05 } :
                    coffeeBanner.button_effect === 'pulse' ? { scale: 1.05 } :
                    { scale: 1.05 }
                    }
                    whileTap={{ scale: 0.95 }} />

                    </a>
                  </div>
              }
              </motion.div>
              <style>{`
                @keyframes shimmer {
                  0% { filter: brightness(1); }
                  50% { filter: brightness(1.3); }
                  100% { filter: brightness(1); }
                }
                @keyframes glow-pulse {
                  0% { filter: drop-shadow(0 0 10px rgba(255,200,0,0.6)); }
                  50% { filter: drop-shadow(0 0 30px rgba(255,200,0,1)); }
                }
                @keyframes pulse-scale {
                  0%, 100% { transform: scale(1); }
                  50% { transform: scale(1.05); }
                }
                .coffee-btn-shimmer:hover { animation: shimmer 1.5s infinite; }
                .coffee-btn-glow { animation: glow-pulse 2s infinite; }
                .coffee-btn-pulse { animation: pulse-scale 1.5s infinite; }
                .coffee-btn-shadow { filter: drop-shadow(0 10px 20px rgba(0,0,0,0.5)); }
                .coffee-btn-shadow:hover { filter: drop-shadow(0 15px 30px rgba(0,0,0,0.7)); }
              `}</style>
            </div>
          }

      </div>
      </section>

      {/* Template Showcase - Above Footer */}
      <TemplateShowcase />

      {/* Donation Banner - Above Footer */}
      <DonationBanner />

      {/* Features moved up */}
      <div className="h-1 bg-slate-950 w-full" />
    </div>);

}