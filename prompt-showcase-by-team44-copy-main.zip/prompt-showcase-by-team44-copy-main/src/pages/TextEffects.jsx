import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Type, Sparkles, Zap, Flame, Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import CategoryHeader from "@/components/effects/CategoryHeader";
import FontGenreSection from "@/components/fonts/FontGenreSection";
import FontPairingSystem from "@/components/fonts/FontPairingSystem";
import FontTipsSection from "@/components/fonts/FontTipsSection";
import { fontGenres } from "@/components/fonts/fontGenresData";
import { useQuery } from "@tanstack/react-query";

// Font samples with Google Fonts
const fontSamples = [
  { name: "Orbitron", style: { fontFamily: "'Orbitron', sans-serif" }, category: "Futuristic" },
  { name: "Creepster", style: { fontFamily: "'Creepster', cursive" }, category: "Horror" },
  { name: "Press Start 2P", style: { fontFamily: "'Press Start 2P', cursive" }, category: "Retro" },
  { name: "Righteous", style: { fontFamily: "'Righteous', cursive" }, category: "Bold" },
  { name: "Bungee Shade", style: { fontFamily: "'Bungee Shade', cursive" }, category: "3D" },
  { name: "Monoton", style: { fontFamily: "'Monoton', cursive" }, category: "Neon" },
  { name: "Fredericka the Great", style: { fontFamily: "'Fredericka the Great', cursive" }, category: "Elegant" },
  { name: "Cinzel", style: { fontFamily: "'Cinzel', serif" }, category: "Classic" },
];

// Animated Text Effects
const textEffects = [
  {
    id: "letterStagger",
    name: "Letter Stagger",
    demo: () => {
      const text = "STAGGERED";
      return (
        <div className="flex gap-1">
          {text.split("").map((char, i) => (
            <motion.span
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="text-4xl font-bold text-violet-400"
            >
              {char}
            </motion.span>
          ))}
        </div>
      );
    },
    code: `{text.split("").map((char, i) => (
  <motion.span
    key={i}
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: i * 0.1 }}
  >
    {char}
  </motion.span>
))}`,
    prompt: "Create letter stagger animation where each letter appears with a delay"
  },
  {
    id: "typewriter",
    name: "Typewriter Effect",
    demo: function TypewriterDemo() {
      const [text, setText] = useState("");
      const fullText = "Typing Effect...";
      useEffect(() => {
        let i = 0;
        const timer = setInterval(() => {
          if (i < fullText.length) {
            setText(fullText.slice(0, i + 1));
            i++;
          } else {
            clearInterval(timer);
          }
        }, 100);
        return () => clearInterval(timer);
      }, []);
      return <div className="text-3xl font-mono text-cyan-400">{text}<span className="animate-pulse">|</span></div>;
    },
    code: `const [text, setText] = useState("");
const fullText = "Typing Effect...";
useEffect(() => {
  let i = 0;
  const timer = setInterval(() => {
    if (i < fullText.length) {
      setText(fullText.slice(0, i + 1));
      i++;
    }
  }, 100);
  return () => clearInterval(timer);
}, []);`,
    prompt: "Create a typewriter animation that types text letter by letter"
  },
  {
    id: "carouselErase",
    name: "Carousel Headlines",
    demo: function CarouselDemo() {
      const words = ["Amazing", "Beautiful", "Creative"];
      const [index, setIndex] = useState(0);
      useEffect(() => {
        const timer = setInterval(() => setIndex((i) => (i + 1) % words.length), 2000);
        return () => clearInterval(timer);
      }, []);
      return (
        <div className="text-3xl font-bold">
          I am <AnimatePresence mode="wait">
            <motion.span
              key={words[index]}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-pink-400 inline-block"
            >
              {words[index]}
            </motion.span>
          </AnimatePresence>
        </div>
      );
    },
    code: `const words = ["Amazing", "Beautiful", "Creative"];
const [index, setIndex] = useState(0);
useEffect(() => {
  const timer = setInterval(() => 
    setIndex((i) => (i + 1) % words.length), 2000);
  return () => clearInterval(timer);
}, []);`,
    prompt: "Create a carousel headline that cycles through words with fade animation"
  },
  {
    id: "slideWord",
    name: "Slide Word Transition",
    demo: function SlideWordDemo() {
      const words = ["Slide", "Glide", "Flow"];
      const [index, setIndex] = useState(0);
      useEffect(() => {
        const timer = setInterval(() => setIndex((i) => (i + 1) % words.length), 2000);
        return () => clearInterval(timer);
      }, []);
      return (
        <div className="overflow-hidden h-10">
          <AnimatePresence mode="wait">
            <motion.div
              key={words[index]}
              initial={{ x: 100 }}
              animate={{ x: 0 }}
              exit={{ x: -100 }}
              className="text-3xl font-bold text-emerald-400"
            >
              {words[index]}
            </motion.div>
          </AnimatePresence>
        </div>
      );
    },
    code: `<motion.div
  key={word}
  initial={{ x: 100 }}
  animate={{ x: 0 }}
  exit={{ x: -100 }}
>
  {word}
</motion.div>`,
    prompt: "Create sliding word transitions from right to left"
  },
  {
    id: "curvedText",
    name: "Curved Text Arc",
    demo: () => {
      const text = "CURVED TEXT ARC";
      const chars = text.split("");
      const radius = 80;
      return (
        <div className="relative h-32 w-64">
          {chars.map((char, i) => {
            const angle = (i / chars.length) * Math.PI - Math.PI / 2;
            const x = Math.cos(angle) * radius;
            const y = Math.sin(angle) * radius;
            return (
              <span
                key={i}
                className="absolute text-xl font-bold text-amber-400"
                style={{
                  left: `50%`,
                  top: `50%`,
                  transform: `translate(${x}px, ${y}px) rotate(${angle + Math.PI / 2}rad)`
                }}
              >
                {char}
              </span>
            );
          })}
        </div>
      );
    },
    code: `const angle = (i / chars.length) * Math.PI - Math.PI / 2;
const x = Math.cos(angle) * radius;
const y = Math.sin(angle) * radius;
transform: \`translate(\${x}px, \${y}px) rotate(\${angle + Math.PI/2}rad)\``,
    prompt: "Create text that follows a curved arc path"
  },
  {
    id: "explosion",
    name: "Explosion Fragmented",
    demo: function ExplosionDemo() {
      const [explode, setExplode] = useState(false);
      return (
        <div>
          <div className="relative h-20">
            {"BOOM!".split("").map((char, i) => (
              <motion.span
                key={i}
                animate={explode ? {
                  x: (Math.random() - 0.5) * 200,
                  y: (Math.random() - 0.5) * 200,
                  opacity: 0,
                  rotate: Math.random() * 360
                } : { x: 0, y: 0, opacity: 1, rotate: 0 }}
                transition={{ duration: 1 }}
                className="inline-block text-4xl font-bold text-red-500"
              >
                {char}
              </motion.span>
            ))}
          </div>
          <Button onClick={() => setExplode(!explode)} size="sm">Toggle Explosion</Button>
        </div>
      );
    },
    code: `animate={{
  x: (Math.random() - 0.5) * 200,
  y: (Math.random() - 0.5) * 200,
  opacity: 0,
  rotate: Math.random() * 360
}}`,
    prompt: "Create an explosion effect where letters fragment and scatter"
  },
  {
    id: "scramble",
    name: "Scramble Animation",
    demo: function ScrambleDemo() {
      const [text, setText] = useState("SCRAMBLE");
      const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
      const scramble = () => {
        let iterations = 0;
        const target = "SCRAMBLE";
        const interval = setInterval(() => {
          setText(target.split("").map((char, i) => {
            if (i < iterations) return target[i];
            return chars[Math.floor(Math.random() * chars.length)];
          }).join(""));
          if (iterations >= target.length) clearInterval(interval);
          iterations += 1 / 3;
        }, 30);
      };
      return (
        <div>
          <div className="text-3xl font-mono text-green-400 mb-2">{text}</div>
          <Button onClick={scramble} size="sm">Scramble</Button>
        </div>
      );
    },
    code: `setText(target.split("").map((char, i) => {
  if (i < iterations) return target[i];
  return chars[Math.floor(Math.random() * chars.length)];
}).join(""));`,
    prompt: "Create a scramble effect that randomizes letters before revealing the final text"
  },
  {
    id: "countdown",
    name: "Number Countdown",
    demo: function CountdownDemo() {
      const [count, setCount] = useState(10);
      useEffect(() => {
        if (count > 0) {
          const timer = setTimeout(() => setCount(count - 1), 200);
          return () => clearTimeout(timer);
        }
      }, [count]);
      return (
        <div>
          <motion.div
            key={count}
            initial={{ scale: 1.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="text-5xl font-bold text-orange-400"
          >
            {count}
          </motion.div>
          <Button onClick={() => setCount(10)} size="sm" className="mt-2">Reset</Button>
        </div>
      );
    },
    code: `<motion.div
  key={count}
  initial={{ scale: 1.5, opacity: 0 }}
  animate={{ scale: 1, opacity: 1 }}
>
  {count}
</motion.div>`,
    prompt: "Create an animated countdown with scale effect on each number change"
  },
  {
    id: "extraction",
    name: "Text Extraction",
    demo: () => {
      return (
        <div className="relative h-20">
          {"EXTRACT".split("").map((char, i) => (
            <motion.span
              key={i}
              initial={{ y: 0 }}
              animate={{ y: [-10, 0, -10] }}
              transition={{ delay: i * 0.1, repeat: Infinity, duration: 1 }}
              className="inline-block text-3xl font-bold text-teal-400"
            >
              {char}
            </motion.span>
          ))}
        </div>
      );
    },
    code: `<motion.span
  initial={{ y: 0 }}
  animate={{ y: [-10, 0, -10] }}
  transition={{ delay: i * 0.1, repeat: Infinity }}
>
  {char}
</motion.span>`,
    prompt: "Create a bouncing extraction animation for each letter"
  },
  {
    id: "wordStagger",
    name: "Word Staggered Reveal",
    demo: () => {
      const words = "Staggered word reveal animation".split(" ");
      return (
        <div className="flex flex-wrap gap-2">
          {words.map((word, i) => (
            <motion.span
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.2 }}
              className="text-2xl font-semibold text-indigo-400"
            >
              {word}
            </motion.span>
          ))}
        </div>
      );
    },
    code: `{words.map((word, i) => (
  <motion.span
    key={i}
    initial={{ opacity: 0, x: -20 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ delay: i * 0.2 }}
  >
    {word}
  </motion.span>
))}`,
    prompt: "Create a word-by-word reveal animation with stagger delay"
  },
  {
    id: "neonGlow",
    name: "Neon Glow Text",
    demo: () => {
      return (
        <div className="text-4xl font-bold text-cyan-400" style={{ textShadow: "0 0 10px #00ffff, 0 0 20px #00ffff, 0 0 30px #00ffff" }}>
          NEON GLOW
        </div>
      );
    },
    code: `style={{ 
  textShadow: "0 0 10px #00ffff, 0 0 20px #00ffff, 0 0 30px #00ffff" 
}}`,
    prompt: "Create neon glow effect with multiple text shadows"
  },
  {
    id: "glitch",
    name: "Glitch Text",
    demo: () => {
      return (
        <div className="relative inline-block">
          <style>{`
            @keyframes glitch {
              0%, 100% { transform: translate(0); }
              20% { transform: translate(-2px, 2px); }
              40% { transform: translate(2px, -2px); }
              60% { transform: translate(-2px, -2px); }
              80% { transform: translate(2px, 2px); }
            }
            .glitch-text { animation: glitch 0.3s infinite; }
          `}</style>
          <div className="text-4xl font-bold text-purple-400 glitch-text">GLITCH</div>
        </div>
      );
    },
    code: `@keyframes glitch {
  0%, 100% { transform: translate(0); }
  20% { transform: translate(-2px, 2px); }
  40% { transform: translate(2px, -2px); }
}
.glitch-text { animation: glitch 0.3s infinite; }`,
    prompt: "Create a glitching text effect with random position shifts"
  },
  {
    id: "wave",
    name: "Wave Text",
    demo: () => {
      return (
        <div className="flex">
          {"WAVE".split("").map((char, i) => (
            <motion.span
              key={i}
              animate={{ y: [0, -10, 0] }}
              transition={{ delay: i * 0.1, repeat: Infinity, duration: 0.6 }}
              className="text-4xl font-bold text-blue-400"
            >
              {char}
            </motion.span>
          ))}
        </div>
      );
    },
    code: `<motion.span
  animate={{ y: [0, -10, 0] }}
  transition={{ 
    delay: i * 0.1, 
    repeat: Infinity, 
    duration: 0.6 
  }}
>
  {char}
</motion.span>`,
    prompt: "Create a wave effect where letters bounce up and down sequentially"
  },
  {
    id: "fadeInUp",
    name: "Fade In Up",
    demo: () => {
      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-3xl font-bold text-pink-400"
        >
          Fade In Up
        </motion.div>
      );
    },
    code: `<motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.8 }}
>
  Fade In Up
</motion.div>`,
    prompt: "Create a fade in animation with upward movement"
  },
  {
    id: "rotate3d",
    name: "3D Rotate Text",
    demo: () => {
      return (
        <motion.div
          animate={{ rotateY: 360 }}
          transition={{ repeat: Infinity, duration: 3, ease: "linear" }}
          className="text-4xl font-bold text-yellow-400"
          style={{ transformStyle: "preserve-3d" }}
        >
          3D ROTATE
        </motion.div>
      );
    },
    code: `<motion.div
  animate={{ rotateY: 360 }}
  transition={{ 
    repeat: Infinity, 
    duration: 3, 
    ease: "linear" 
  }}
  style={{ transformStyle: "preserve-3d" }}
>
  3D ROTATE
</motion.div>`,
    prompt: "Create a 3D rotation effect on text"
  },
  {
    id: "rainbow",
    name: "Rainbow Gradient",
    demo: () => {
      return (
        <div
          className="text-5xl font-bold"
          style={{
            background: "linear-gradient(90deg, red, orange, yellow, green, blue, indigo, violet)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text"
          }}
        >
          RAINBOW
        </div>
      );
    },
    code: `style={{
  background: "linear-gradient(90deg, red, orange, yellow, green, blue, indigo, violet)",
  WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent"
}}`,
    prompt: "Create a rainbow gradient text effect"
  },
  {
    id: "bounce",
    name: "Bounce Text",
    demo: () => {
      return (
        <motion.div
          animate={{ y: [0, -20, 0] }}
          transition={{ repeat: Infinity, duration: 0.8 }}
          className="text-4xl font-bold text-green-400"
        >
          BOUNCE
        </motion.div>
      );
    },
    code: `<motion.div
  animate={{ y: [0, -20, 0] }}
  transition={{ 
    repeat: Infinity, 
    duration: 0.8 
  }}
>
  BOUNCE
</motion.div>`,
    prompt: "Create a bouncing text animation"
  },
  {
    id: "flicker",
    name: "Flicker Neon",
    demo: () => {
      return (
        <div className="relative">
          <style>{`
            @keyframes flicker {
              0%, 100% { opacity: 1; }
              50% { opacity: 0.3; }
            }
            .flicker-text { animation: flicker 0.15s infinite; }
          `}</style>
          <div className="text-4xl font-bold text-pink-500 flicker-text" style={{ textShadow: "0 0 20px #ec4899" }}>
            FLICKER
          </div>
        </div>
      );
    },
    code: `@keyframes flicker {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.3; }
}
.flicker-text { animation: flicker 0.15s infinite; }`,
    prompt: "Create a flickering neon text effect"
  },
  {
    id: "shadow3d",
    name: "3D Shadow Text",
    demo: () => {
      return (
        <div
          className="text-5xl font-bold text-white"
          style={{
            textShadow: "1px 1px 0 #000, 2px 2px 0 #000, 3px 3px 0 #000, 4px 4px 0 #000, 5px 5px 0 #000"
          }}
        >
          3D SHADOW
        </div>
      );
    },
    code: `style={{
  textShadow: "1px 1px 0 #000, 2px 2px 0 #000, 3px 3px 0 #000"
}}`,
    prompt: "Create a 3D shadow text effect with layered shadows"
  },
  {
    id: "pulse",
    name: "Pulse Scale",
    demo: () => {
      return (
        <motion.div
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ repeat: Infinity, duration: 1 }}
          className="text-4xl font-bold text-red-400"
        >
          PULSE
        </motion.div>
      );
    },
    code: `<motion.div
  animate={{ scale: [1, 1.2, 1] }}
  transition={{ 
    repeat: Infinity, 
    duration: 1 
  }}
>
  PULSE
</motion.div>`,
    prompt: "Create a pulsing scale animation"
  },
  {
    id: "split",
    name: "Split Reveal",
    demo: () => {
      const text = "SPLIT";
      return (
        <div className="flex gap-1">
          {text.split("").map((char, i) => (
            <motion.span
              key={i}
              initial={{ x: i % 2 === 0 ? -50 : 50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: i * 0.1 }}
              className="text-4xl font-bold text-violet-400"
            >
              {char}
            </motion.span>
          ))}
        </div>
      );
    },
    code: `initial={{ x: i % 2 === 0 ? -50 : 50, opacity: 0 }}
animate={{ x: 0, opacity: 1 }}
transition={{ delay: i * 0.1 }}`,
    prompt: "Create a split reveal animation where letters come from alternating sides"
  },
  {
    id: "blur",
    name: "Blur In",
    demo: () => {
      return (
        <motion.div
          initial={{ filter: "blur(10px)", opacity: 0 }}
          animate={{ filter: "blur(0px)", opacity: 1 }}
          transition={{ duration: 1 }}
          className="text-4xl font-bold text-cyan-400"
        >
          BLUR IN
        </motion.div>
      );
    },
    code: `<motion.div
  initial={{ filter: "blur(10px)", opacity: 0 }}
  animate={{ filter: "blur(0px)", opacity: 1 }}
  transition={{ duration: 1 }}
>
  BLUR IN
</motion.div>`,
    prompt: "Create a blur-in animation where text goes from blurred to sharp"
  },
  {
    id: "shimmer",
    name: "Shimmer Shine",
    demo: () => {
      return (
        <div className="relative overflow-hidden inline-block">
          <style>{`
            @keyframes shimmer {
              0% { background-position: -200% center; }
              100% { background-position: 200% center; }
            }
            .shimmer-text {
              background: linear-gradient(90deg, #fff 0%, #ffd700 50%, #fff 100%);
              background-size: 200% auto;
              -webkit-background-clip: text;
              -webkit-text-fill-color: transparent;
              background-clip: text;
              animation: shimmer 3s linear infinite;
            }
          `}</style>
          <div className="text-4xl font-bold shimmer-text">
            SHIMMER
          </div>
        </div>
      );
    },
    code: `@keyframes shimmer {
  0% { background-position: -200% center; }
  100% { background-position: 200% center; }
}
background: linear-gradient(90deg, #fff 0%, #ffd700 50%, #fff 100%);
animation: shimmer 3s linear infinite;`,
    prompt: "Create a shimmering shine effect that moves across text"
  },
  {
    id: "float",
    name: "Floating Text",
    demo: () => {
      return (
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
          className="text-4xl font-bold text-purple-400"
        >
          FLOAT
        </motion.div>
      );
    },
    code: `<motion.div
  animate={{ y: [0, -10, 0] }}
  transition={{ 
    repeat: Infinity, 
    duration: 3, 
    ease: "easeInOut" 
  }}
>
  FLOAT
</motion.div>`,
    prompt: "Create a gentle floating animation"
  },
  {
    id: "typing",
    name: "Typing Indicator",
    demo: () => {
      return (
        <div className="flex gap-2 items-center text-2xl">
          <span className="text-slate-400">Typing</span>
          {[0, 1, 2].map((i) => (
            <motion.span
              key={i}
              animate={{ opacity: [0.3, 1, 0.3] }}
              transition={{ repeat: Infinity, duration: 1.5, delay: i * 0.2 }}
              className="w-2 h-2 rounded-full bg-slate-400"
            />
          ))}
        </div>
      );
    },
    code: `{[0, 1, 2].map((i) => (
  <motion.span
    key={i}
    animate={{ opacity: [0.3, 1, 0.3] }}
    transition={{ 
      repeat: Infinity, 
      duration: 1.5, 
      delay: i * 0.2 
    }}
  />
))}`,
    prompt: "Create animated typing indicator dots"
  },
  {
    id: "fire",
    name: "Fire Text",
    demo: () => {
      return (
        <div
          className="text-5xl font-bold"
          style={{
            background: "linear-gradient(180deg, #ff0000 0%, #ff7700 50%, #ffaa00 100%)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text",
            textShadow: "0 0 20px #ff0000"
          }}
        >
          FIRE
        </div>
      );
    },
    code: `style={{
  background: "linear-gradient(180deg, #ff0000, #ff7700, #ffaa00)",
  WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent",
  textShadow: "0 0 20px #ff0000"
}}`,
    prompt: "Create a fire effect with red-orange-yellow gradient"
  },
  {
    id: "zigzag",
    name: "Zigzag Wave",
    demo: () => {
      return (
        <div className="flex">
          {"ZIGZAG".split("").map((char, i) => (
            <motion.span
              key={i}
              animate={{ y: i % 2 === 0 ? [-5, 5] : [5, -5] }}
              transition={{ repeat: Infinity, duration: 0.5, repeatType: "reverse" }}
              className="text-3xl font-bold text-yellow-400"
            >
              {char}
            </motion.span>
          ))}
        </div>
      );
    },
    code: `animate={{ y: i % 2 === 0 ? [-5, 5] : [5, -5] }}
transition={{ repeat: Infinity, duration: 0.5, repeatType: "reverse" }}`,
    prompt: "Create alternating up-down zigzag animation"
  },
  {
    id: "spin",
    name: "Spinning Letters",
    demo: () => {
      return (
        <div className="flex gap-1">
          {"SPIN".split("").map((char, i) => (
            <motion.span
              key={i}
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 2, delay: i * 0.2, ease: "linear" }}
              className="inline-block text-4xl font-bold text-emerald-400"
            >
              {char}
            </motion.span>
          ))}
        </div>
      );
    },
    code: `<motion.span
  animate={{ rotate: 360 }}
  transition={{ repeat: Infinity, duration: 2, delay: i * 0.2, ease: "linear" }}
  className="inline-block"
/>`,
    prompt: "Create spinning letters with stagger delay"
  },
  {
    id: "flip",
    name: "Flip Card Effect",
    demo: () => {
      return (
        <motion.div
          animate={{ rotateX: [0, 180, 360] }}
          transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
          className="text-4xl font-bold text-blue-400"
          style={{ transformStyle: "preserve-3d" }}
        >
          FLIP
        </motion.div>
      );
    },
    code: `<motion.div
  animate={{ rotateX: [0, 180, 360] }}
  transition={{ repeat: Infinity, duration: 3 }}
  style={{ transformStyle: "preserve-3d" }}
/>`,
    prompt: "Create a 3D flip card animation for text"
  },
  {
    id: "skew",
    name: "Skew Animation",
    demo: () => {
      return (
        <motion.div
          animate={{ skewX: [0, 10, -10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="text-4xl font-bold text-pink-400"
        >
          SKEW
        </motion.div>
      );
    },
    code: `<motion.div
  animate={{ skewX: [0, 10, -10, 0] }}
  transition={{ repeat: Infinity, duration: 2 }}
/>`,
    prompt: "Create skewing animation that tilts text left and right"
  },
  {
    id: "swipe",
    name: "Swipe Reveal",
    demo: () => {
      return (
        <div className="relative overflow-hidden">
          <motion.div
            initial={{ x: "-100%" }}
            animate={{ x: "100%" }}
            transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
          />
          <div className="text-3xl font-bold text-violet-400">SWIPE</div>
        </div>
      );
    },
    code: `<motion.div
  initial={{ x: "-100%" }}
  animate={{ x: "100%" }}
  transition={{ repeat: Infinity, duration: 2 }}
  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
/>`,
    prompt: "Create a swipe reveal animation with a moving gradient overlay"
  },
  {
    id: "elastic",
    name: "Elastic Bounce",
    demo: () => {
      return (
        <motion.div
          animate={{ scale: [1, 1.3, 0.9, 1.1, 1] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
          className="text-4xl font-bold text-orange-400"
        >
          ELASTIC
        </motion.div>
      );
    },
    code: `<motion.div
  animate={{ scale: [1, 1.3, 0.9, 1.1, 1] }}
  transition={{ repeat: Infinity, duration: 1.5 }}
/>`,
    prompt: "Create elastic bounce effect with scale keyframes"
  },
  {
    id: "chromatic",
    name: "Chromatic Aberration",
    demo: () => {
      return (
        <div className="relative">
          <div className="absolute text-4xl font-bold text-red-500" style={{ transform: "translate(-2px, 0)" }}>CHROMA</div>
          <div className="absolute text-4xl font-bold text-blue-500" style={{ transform: "translate(2px, 0)" }}>CHROMA</div>
          <div className="text-4xl font-bold text-white">CHROMA</div>
        </div>
      );
    },
    code: `<div className="absolute text-red-500" style={{ transform: "translate(-2px, 0)" }}>TEXT</div>
<div className="absolute text-blue-500" style={{ transform: "translate(2px, 0)" }}>TEXT</div>
<div className="text-white">TEXT</div>`,
    prompt: "Create chromatic aberration effect with RGB color split"
  },
  {
    id: "typeDelete",
    name: "Type & Delete",
    demo: function TypeDeleteDemo() {
      const [text, setText] = useState("");
      const [isDeleting, setIsDeleting] = useState(false);
      const fullText = "Type Delete";
      useEffect(() => {
        const timer = setTimeout(() => {
          if (!isDeleting && text.length < fullText.length) {
            setText(fullText.slice(0, text.length + 1));
          } else if (!isDeleting && text.length === fullText.length) {
            setTimeout(() => setIsDeleting(true), 1000);
          } else if (isDeleting && text.length > 0) {
            setText(text.slice(0, -1));
          } else if (isDeleting && text.length === 0) {
            setIsDeleting(false);
          }
        }, isDeleting ? 50 : 100);
        return () => clearTimeout(timer);
      }, [text, isDeleting]);
      return <div className="text-3xl font-mono text-green-400">{text}<span className="animate-pulse">|</span></div>;
    },
    code: `// Toggle between typing and deleting
if (!isDeleting && text.length < fullText.length) {
  setText(fullText.slice(0, text.length + 1));
} else if (isDeleting && text.length > 0) {
  setText(text.slice(0, -1));
}`,
    prompt: "Create typewriter that types then deletes text in a loop"
  },
  {
    id: "splitFlip",
    name: "Split & Flip",
    demo: () => {
      return (
        <div className="flex gap-1">
          {"FLIP".split("").map((char, i) => (
            <motion.span
              key={i}
              animate={{ rotateY: [0, 180] }}
              transition={{ repeat: Infinity, duration: 1, delay: i * 0.1, repeatType: "reverse" }}
              className="inline-block text-3xl font-bold text-cyan-400"
            >
              {char}
            </motion.span>
          ))}
        </div>
      );
    },
    code: `<motion.span
  animate={{ rotateY: [0, 180] }}
  transition={{ repeat: Infinity, duration: 1, delay: i * 0.1, repeatType: "reverse" }}
/>`,
    prompt: "Create letter-by-letter vertical flip animation"
  },
  {
    id: "perspective",
    name: "3D Perspective",
    demo: () => {
      return (
        <div style={{ perspective: "500px" }}>
          <motion.div
            animate={{ rotateX: [0, 15, -15, 0] }}
            transition={{ repeat: Infinity, duration: 3 }}
            className="text-4xl font-bold text-indigo-400"
          >
            3D VIEW
          </motion.div>
        </div>
      );
    },
    code: `<div style={{ perspective: "500px" }}>
  <motion.div
    animate={{ rotateX: [0, 15, -15, 0] }}
    transition={{ repeat: Infinity, duration: 3 }}
  />
</div>`,
    prompt: "Create 3D perspective tilt animation"
  },
  {
    id: "rainbow2",
    name: "Rainbow Shift",
    demo: () => {
      return (
        <div className="relative">
          <style>{`
            @keyframes rainbow-shift {
              0% { filter: hue-rotate(0deg); }
              100% { filter: hue-rotate(360deg); }
            }
            .rainbow-shift { animation: rainbow-shift 3s linear infinite; }
          `}</style>
          <div className="text-4xl font-bold text-pink-500 rainbow-shift">
            RAINBOW
          </div>
        </div>
      );
    },
    code: `@keyframes rainbow-shift {
  0% { filter: hue-rotate(0deg); }
  100% { filter: hue-rotate(360deg); }
}
.rainbow-shift { animation: rainbow-shift 3s linear infinite; }`,
    prompt: "Create rainbow color shift using hue-rotate filter"
  },
  {
    id: "scatter",
    name: "Letter Scatter",
    demo: function ScatterDemo() {
      const [scattered, setScattered] = useState(false);
      return (
        <div>
          <div className="relative h-20">
            {"SCATTER".split("").map((char, i) => (
              <motion.span
                key={i}
                animate={scattered ? {
                  x: (Math.random() - 0.5) * 100,
                  y: (Math.random() - 0.5) * 100,
                  rotate: Math.random() * 180
                } : { x: 0, y: 0, rotate: 0 }}
                transition={{ duration: 0.5 }}
                className="inline-block text-3xl font-bold text-teal-400"
              >
                {char}
              </motion.span>
            ))}
          </div>
          <Button onClick={() => setScattered(!scattered)} size="sm">Scatter</Button>
        </div>
      );
    },
    code: `animate={{
  x: (Math.random() - 0.5) * 100,
  y: (Math.random() - 0.5) * 100,
  rotate: Math.random() * 180
}}`,
    prompt: "Create letter scatter animation with random positions"
  },
  {
    id: "squeeze",
    name: "Squeeze & Stretch",
    demo: () => {
      return (
        <motion.div
          animate={{ scaleX: [1, 0.7, 1.3, 1], scaleY: [1, 1.3, 0.7, 1] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
          className="text-4xl font-bold text-rose-400"
        >
          SQUEEZE
        </motion.div>
      );
    },
    code: `<motion.div
  animate={{ scaleX: [1, 0.7, 1.3, 1], scaleY: [1, 1.3, 0.7, 1] }}
  transition={{ repeat: Infinity, duration: 1.5 }}
/>`,
    prompt: "Create squeeze and stretch animation with scale"
  },
  {
    id: "neonPulse",
    name: "Neon Pulse",
    demo: () => {
      return (
        <div className="relative">
          <style>{`
            @keyframes neon-pulse {
              0%, 100% { text-shadow: 0 0 10px #0ff, 0 0 20px #0ff, 0 0 30px #0ff; }
              50% { text-shadow: 0 0 20px #0ff, 0 0 40px #0ff, 0 0 60px #0ff; }
            }
            .neon-pulse { animation: neon-pulse 1.5s ease-in-out infinite; }
          `}</style>
          <div className="text-4xl font-bold text-cyan-400 neon-pulse">
            NEON
          </div>
        </div>
      );
    },
    code: `@keyframes neon-pulse {
  0%, 100% { text-shadow: 0 0 10px #0ff, 0 0 20px #0ff, 0 0 30px #0ff; }
  50% { text-shadow: 0 0 20px #0ff, 0 0 40px #0ff, 0 0 60px #0ff; }
}`,
    prompt: "Create pulsing neon glow effect with shadow animation"
  },
  {
    id: "ripple",
    name: "Ripple Wave",
    demo: () => {
      return (
        <div className="flex">
          {"RIPPLE".split("").map((char, i) => (
            <motion.span
              key={i}
              animate={{ scale: [1, 1.3, 1] }}
              transition={{ repeat: Infinity, duration: 1, delay: i * 0.1 }}
              className="inline-block text-3xl font-bold text-purple-400"
            >
              {char}
            </motion.span>
          ))}
        </div>
      );
    },
    code: `<motion.span
  animate={{ scale: [1, 1.3, 1] }}
  transition={{ repeat: Infinity, duration: 1, delay: i * 0.1 }}
/>`,
    prompt: "Create ripple effect with sequential scale animation"
  },
  {
    id: "wobble",
    name: "Wobble Jello",
    demo: () => {
      return (
        <motion.div
          animate={{ rotate: [0, 5, -5, 3, -3, 0] }}
          transition={{ repeat: Infinity, duration: 1 }}
          className="text-4xl font-bold text-amber-400"
        >
          WOBBLE
        </motion.div>
      );
    },
    code: `<motion.div
  animate={{ rotate: [0, 5, -5, 3, -3, 0] }}
  transition={{ repeat: Infinity, duration: 1 }}
/>`,
    prompt: "Create wobble jello effect with rotation keyframes"
  },
];

export default function TextEffects() {
  const [copiedId, setCopiedId] = useState(null);
  const [copiedPrompt, setCopiedPrompt] = useState(null);

  const copyCode = (code, id) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const copyPrompt = (prompt, id) => {
    navigator.clipboard.writeText(prompt);
    setCopiedPrompt(id);
    setTimeout(() => setCopiedPrompt(null), 2000);
  };

  return (
    <div className="min-h-screen pb-12">
      <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Creepster&family=Press+Start+2P&family=Righteous&family=Bungee+Shade&family=Monoton&family=Fredericka+the+Great&family=Cinzel:wght@400;700&display=swap" rel="stylesheet" />
      
      <CategoryHeader
        title="Text Effects & Typography"
        description="50+ animated text effects, interactive typography, and custom fonts"
        icon={Type}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* Section 1: Font Pairing System & Tips */}
        <section className="mb-12">
          <div className="grid lg:grid-cols-2 gap-6">
            <FontTipsSection />
            <FontPairingSystem />
          </div>
        </section>

        {/* Section 2: Custom Fonts by Genre */}
        <section>
          <div className="flex items-center gap-2 mb-8">
            <Type className="w-8 h-8 text-violet-400" />
            <h2 className="text-3xl font-bold text-white">Custom Fonts & Styles</h2>
            <span className="text-sm text-slate-400 italic ml-2">Just tell AI what font ya want and where you want it!</span>
          </div>
          
          <div className="mb-6 p-4 bg-violet-500/10 border border-violet-500/20 rounded-xl">
            <p className="text-sm text-slate-300 mb-3">
              <span className="text-violet-400 font-semibold">💡 Font 101:</span> Click any genre accordion to expand and hover over fonts for usage tips, best practices, and target audience insights. Fonts are organized by use case to help you choose the perfect typeface for your project.
            </p>
            <p className="text-xs text-purple-400">
              <span className="font-semibold">Usage Percentages:</span> The percentage shown on each font card indicates how frequently that font is used in its category context (e.g., 75% means it's highly popular for that specific use case).
            </p>
          </div>

          <div className="grid lg:grid-cols-1 gap-6">
            <div className="space-y-4">
              {fontGenres.map((genre, index) => (
                <FontGenreSection key={genre.name} genre={genre} fonts={genre.fonts} index={index} />
              ))}
            </div>
          </div>
        </section>

        {/* Section 2: Animated Typography */}
        <section>
          <div className="flex items-center gap-3 mb-8">
            <Sparkles className="w-8 h-8 text-cyan-400" />
            <h2 className="text-3xl font-bold text-white">Animated Typography</h2>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {textEffects.slice(0, 22).map((effect, index) => (
              <motion.div
                key={effect.id}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
                className="p-6 rounded-xl bg-slate-900/50 border border-slate-800 hover:border-cyan-500 transition-all"
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold text-white">{effect.name}</h3>
                </div>
                
                <div className="bg-black/50 rounded-lg p-8 mb-4 min-h-[120px] flex items-center justify-center">
                  {effect.demo()}
                </div>

                <div className="mb-3">
                  <p className="text-xs text-slate-500 mb-2">AI PROMPT:</p>
                  <p className="text-sm text-slate-300 italic">"{effect.prompt}"</p>
                </div>

                <div className="bg-slate-950 rounded-lg p-3 mb-4">
                  <pre className="text-xs text-slate-400 overflow-x-auto">
                    <code>{effect.code}</code>
                  </pre>
                </div>

                <style>{`
                  .glitch-btn-effect:hover .glitch-content {
                    animation: btn-glitch 0.3s ease-in-out infinite;
                  }
                  .glitch-btn-effect:hover {
                    animation: btn-shake-mini 0.3s ease-in-out infinite;
                  }
                  @keyframes btn-glitch {
                    0%, 100% { text-shadow: none; filter: none; }
                    20% { text-shadow: -1px 0 #ff00ff, 1px 0 #00ffff; filter: hue-rotate(10deg); }
                    40% { text-shadow: 1px 0 #ff00ff, -1px 0 #00ffff; filter: hue-rotate(-10deg); }
                    60% { text-shadow: -1px 0 #00ffff, 1px 0 #ff00ff; filter: hue-rotate(5deg); }
                    80% { text-shadow: 1px 0 #00ffff, -1px 0 #ff00ff; filter: hue-rotate(-5deg); }
                  }
                  @keyframes btn-shake-mini {
                    0%, 100% { transform: translate(0); }
                    10% { transform: translate(-1px, 1px); }
                    20% { transform: translate(1px, -1px); }
                    30% { transform: translate(-1px, 0); }
                    40% { transform: translate(1px, 1px); }
                    50% { transform: translate(0, -1px); }
                  }
                `}</style>

                <div className="flex gap-2">
                  <Button
                    onClick={() => copyCode(effect.code, effect.id)}
                    size="sm"
                    variant="outline"
                    className="flex-1 glitch-btn-effect bg-black border-violet-500 hover:bg-violet-500/10"
                  >
                    <span className="glitch-content flex items-center justify-center w-full">
                      {copiedId === effect.id ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                      {copiedId === effect.id ? "Copied!" : "Copy Code"}
                    </span>
                  </Button>
                  <Button
                    onClick={() => copyPrompt(effect.prompt, effect.id)}
                    size="sm"
                    variant="outline"
                    className="flex-1 glitch-btn-effect bg-black border-cyan-500 hover:bg-cyan-500/10"
                  >
                    <span className="glitch-content flex items-center justify-center w-full">
                      {copiedPrompt === effect.id ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                      {copiedPrompt === effect.id ? "Copied!" : "Copy Prompt"}
                    </span>
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Section 3: Text Effects */}
        <section>
          <div className="flex items-center gap-3 mb-8">
            <Zap className="w-8 h-8 text-pink-400" />
            <h2 className="text-3xl font-bold text-white">Interactive Text Effects</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {textEffects.slice(22).map((effect, index) => (
              <motion.div
                key={effect.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
                className="p-6 rounded-xl bg-slate-900/50 border border-slate-800 hover:border-pink-500 transition-all"
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-white">{effect.name}</h3>
                </div>
                
                <div className="bg-black/50 rounded-lg p-6 mb-3 min-h-[100px] flex items-center justify-center">
                  {effect.demo()}
                </div>

                <p className="text-xs text-slate-500 mb-2">AI: {effect.prompt}</p>

                <style>{`
                  .glitch-btn-effect:hover .glitch-content {
                    animation: btn-glitch 0.3s ease-in-out infinite;
                  }
                  .glitch-btn-effect:hover {
                    animation: btn-shake-mini 0.3s ease-in-out infinite;
                  }
                  @keyframes btn-glitch {
                    0%, 100% { text-shadow: none; filter: none; }
                    20% { text-shadow: -1px 0 #ff00ff, 1px 0 #00ffff; filter: hue-rotate(10deg); }
                    40% { text-shadow: 1px 0 #ff00ff, -1px 0 #00ffff; filter: hue-rotate(-10deg); }
                    60% { text-shadow: -1px 0 #00ffff, 1px 0 #ff00ff; filter: hue-rotate(5deg); }
                    80% { text-shadow: 1px 0 #00ffff, -1px 0 #ff00ff; filter: hue-rotate(-5deg); }
                  }
                  @keyframes btn-shake-mini {
                    0%, 100% { transform: translate(0); }
                    10% { transform: translate(-1px, 1px); }
                    20% { transform: translate(1px, -1px); }
                    30% { transform: translate(-1px, 0); }
                    40% { transform: translate(1px, 1px); }
                    50% { transform: translate(0, -1px); }
                  }
                `}</style>

                <div className="flex gap-2">
                  <Button
                    onClick={() => copyCode(effect.code, effect.id)}
                    size="sm"
                    variant="outline"
                    className="flex-1 glitch-btn-effect bg-black border-violet-500 hover:bg-violet-500/10"
                  >
                    <span className="glitch-content flex items-center justify-center w-full">
                      {copiedId === effect.id ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                      {copiedId === effect.id ? "Copied!" : "Copy Code"}
                    </span>
                  </Button>
                  <Button
                    onClick={() => copyPrompt(effect.prompt, effect.id)}
                    size="sm"
                    variant="outline"
                    className="flex-1 glitch-btn-effect bg-black border-cyan-500 hover:bg-cyan-500/10"
                  >
                    <span className="glitch-content flex items-center justify-center w-full">
                      {copiedPrompt === effect.id ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                      {copiedPrompt === effect.id ? "Copied!" : "Copy Prompt"}
                    </span>
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

      </div>
    </div>
  );
}