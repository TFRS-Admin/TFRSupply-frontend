import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { FileText, Plus, Trash2, Edit3, Copy, Eye, Save, X, Layers, ArrowUp, ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import CategoryHeader from "@/components/effects/CategoryHeader";

const heroTypes = [
  { id: "centered", name: "Centered Hero", preview: "text-center" },
  { id: "left", name: "Left Aligned", preview: "text-left" },
  { id: "split", name: "Split Layout", preview: "grid grid-cols-2" },
  { id: "minimal", name: "Minimal", preview: "py-8" },
  { id: "fullscreen", name: "Fullscreen", preview: "min-h-screen" },
];

const dividerTypes = [
  { id: "wave", name: "Wave" },
  { id: "animatedWave", name: "Animated Wave" },
  { id: "diagonal", name: "Diagonal" },
  { id: "curved", name: "Curved" },
  { id: "zigzag", name: "Zigzag" },
  { id: "cloud", name: "Cloud" },
  { id: "mountain", name: "Mountain" },
  { id: "none", name: "None" },
];

const gradients = [
  { id: "violet", name: "Violet", class: "from-violet-600 to-purple-600" },
  { id: "cyan", name: "Cyan", class: "from-cyan-500 to-blue-600" },
  { id: "emerald", name: "Emerald", class: "from-emerald-500 to-teal-600" },
  { id: "rose", name: "Rose", class: "from-rose-500 to-pink-600" },
  { id: "amber", name: "Amber", class: "from-amber-500 to-orange-600" },
  { id: "slate", name: "Slate", class: "from-slate-600 to-slate-800" },
];

function TemplateCard({ template, onEdit, onDelete, onDuplicate, onPreview }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden hover:border-slate-700 transition-all group"
    >
      {/* Preview */}
      <div className={`h-32 bg-gradient-to-br ${gradients.find(g => g.id === template.hero?.gradient)?.class || "from-violet-600 to-purple-600"} relative`}>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-white/80 text-sm font-medium">{template.hero?.type || "centered"}</span>
        </div>
        {template.divider?.type && template.divider.type !== "none" && (
          <div className="absolute bottom-0 left-0 right-0 h-4 bg-slate-900" style={{ clipPath: template.divider.type === "wave" ? "ellipse(60% 100% at 50% 100%)" : "polygon(0 100%, 50% 0, 100% 100%)" }} />
        )}
      </div>
      
      <div className="p-4">
        <h3 className="text-white font-semibold mb-1">{template.name}</h3>
        <p className="text-slate-400 text-sm mb-3">{template.description || "Custom template"}</p>
        
        <div className="flex flex-wrap gap-1 mb-3">
          <span className="px-2 py-0.5 bg-violet-500/20 text-violet-400 text-xs rounded">Hero: {template.hero?.type || "centered"}</span>
          <span className="px-2 py-0.5 bg-cyan-500/20 text-cyan-400 text-xs rounded">Divider: {template.divider?.type || "wave"}</span>
        </div>
        
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => onPreview(template)} className="flex-1">
            <Eye className="w-3 h-3 mr-1" /> Preview
          </Button>
          <Button size="sm" variant="outline" onClick={() => onEdit(template)}>
            <Edit3 className="w-3 h-3" />
          </Button>
          <Button size="sm" variant="outline" onClick={() => onDuplicate(template)}>
            <Copy className="w-3 h-3" />
          </Button>
          <Button size="sm" variant="destructive" onClick={() => onDelete(template.id)}>
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}

function TemplateEditor({ template, onSave, onCancel }) {
  const [form, setForm] = useState({
    name: template?.name || "",
    description: template?.description || "",
    hero: template?.hero || { type: "centered", gradient: "violet", height: "medium", alignment: "center" },
    divider: template?.divider || { type: "wave", animated: true, speed: 8 },
    footer: template?.footer || { type: "standard", showSocial: true, showNewsletter: false },
  });

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70"
    >
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">{template ? "Edit Template" : "Create Template"}</h2>
          <Button variant="ghost" size="icon" onClick={onCancel}><X className="w-5 h-5" /></Button>
        </div>
        
        <div className="p-6 space-y-6">
          {/* Basic Info */}
          <div className="space-y-4">
            <div>
              <Label className="text-white">Template Name</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="My Template" className="bg-slate-800 border-slate-700 text-white mt-1" />
            </div>
            <div>
              <Label className="text-white">Description</Label>
              <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="A brief description" className="bg-slate-800 border-slate-700 text-white mt-1" />
            </div>
          </div>

          {/* Hero Section */}
          <div className="p-4 bg-slate-800/50 rounded-xl space-y-4">
            <h3 className="text-white font-semibold flex items-center gap-2"><ArrowUp className="w-4 h-4" /> Hero Section</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-slate-400 text-sm">Layout</Label>
                <Select value={form.hero.type} onValueChange={(v) => setForm({ ...form, hero: { ...form.hero, type: v } })}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {heroTypes.map(h => <SelectItem key={h.id} value={h.id}>{h.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-slate-400 text-sm">Gradient</Label>
                <Select value={form.hero.gradient} onValueChange={(v) => setForm({ ...form, hero: { ...form.hero, gradient: v } })}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {gradients.map(g => <SelectItem key={g.id} value={g.id}>{g.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Divider Section */}
          <div className="p-4 bg-slate-800/50 rounded-xl space-y-4">
            <h3 className="text-white font-semibold flex items-center gap-2"><Layers className="w-4 h-4" /> Divider Transition</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-slate-400 text-sm">Type</Label>
                <Select value={form.divider.type} onValueChange={(v) => setForm({ ...form, divider: { ...form.divider, type: v } })}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {dividerTypes.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-slate-400 text-sm">Animation Speed: {form.divider.speed}s</Label>
                <input type="range" min="2" max="15" value={form.divider.speed} onChange={(e) => setForm({ ...form, divider: { ...form.divider, speed: Number(e.target.value) } })} className="w-full accent-violet-500 mt-2" />
              </div>
            </div>
            <label className="flex items-center gap-2 text-slate-300 text-sm">
              <input type="checkbox" checked={form.divider.animated} onChange={(e) => setForm({ ...form, divider: { ...form.divider, animated: e.target.checked } })} className="accent-violet-500" />
              Enable Animation
            </label>
          </div>

          {/* Footer Section */}
          <div className="p-4 bg-slate-800/50 rounded-xl space-y-4">
            <h3 className="text-white font-semibold flex items-center gap-2"><ArrowDown className="w-4 h-4" /> Footer Elements</h3>
            <div className="flex flex-wrap gap-4">
              <label className="flex items-center gap-2 text-slate-300 text-sm">
                <input type="checkbox" checked={form.footer.showSocial} onChange={(e) => setForm({ ...form, footer: { ...form.footer, showSocial: e.target.checked } })} className="accent-violet-500" />
                Show Social Links
              </label>
              <label className="flex items-center gap-2 text-slate-300 text-sm">
                <input type="checkbox" checked={form.footer.showNewsletter} onChange={(e) => setForm({ ...form, footer: { ...form.footer, showNewsletter: e.target.checked } })} className="accent-violet-500" />
                Show Newsletter
              </label>
            </div>
          </div>
        </div>
        
        <div className="p-6 border-t border-slate-800 flex gap-3 justify-end">
          <Button variant="outline" onClick={onCancel}>Cancel</Button>
          <Button onClick={() => onSave(form)} className="bg-violet-600 hover:bg-violet-700">
            <Save className="w-4 h-4 mr-2" /> Save Template
          </Button>
        </div>
      </div>
    </motion.div>
  );
}

function TemplatePreview({ template, onClose }) {
  const gradient = gradients.find(g => g.id === template.hero?.gradient)?.class || "from-violet-600 to-purple-600";
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/90 overflow-y-auto"
    >
      <Button onClick={onClose} className="fixed top-4 right-4 z-50" variant="outline">
        <X className="w-4 h-4 mr-2" /> Close Preview
      </Button>
      
      {/* Hero */}
      <div className={`min-h-[50vh] bg-gradient-to-br ${gradient} flex items-center justify-center relative`}>
        <div className={`max-w-4xl mx-auto px-8 py-16 ${template.hero?.type === "left" ? "text-left" : "text-center"}`}>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Your Page Title</h1>
          <p className="text-xl text-white/80">Your page subtitle goes here</p>
        </div>
        
        {/* Divider */}
        {template.divider?.type && template.divider.type !== "none" && (
          <div className="absolute bottom-0 left-0 right-0">
            <svg viewBox="0 0 1200 120" className="w-full h-16" preserveAspectRatio="none">
              {template.divider.type === "wave" && (
                <motion.path
                  d="M0,60 C300,120 600,0 900,60 C1050,90 1150,30 1200,60 L1200,120 L0,120 Z"
                  fill="#0f172a"
                  animate={template.divider.animated ? {
                    d: [
                      "M0,60 C300,120 600,0 900,60 C1050,90 1150,30 1200,60 L1200,120 L0,120 Z",
                      "M0,80 C300,20 600,100 900,40 C1050,70 1150,50 1200,80 L1200,120 L0,120 Z",
                      "M0,60 C300,120 600,0 900,60 C1050,90 1150,30 1200,60 L1200,120 L0,120 Z"
                    ]
                  } : {}}
                  transition={{ duration: template.divider.speed || 8, repeat: Infinity, ease: "easeInOut" }}
                />
              )}
              {template.divider.type === "diagonal" && <polygon points="0,120 1200,0 1200,120" fill="#0f172a" />}
              {template.divider.type === "curved" && <ellipse cx="600" cy="120" rx="700" ry="80" fill="#0f172a" />}
            </svg>
          </div>
        )}
      </div>
      
      {/* Content Area */}
      <div className="bg-slate-950 py-16 px-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-8 text-center">
            <p className="text-slate-400">Your page content goes here...</p>
          </div>
        </div>
      </div>
      
      {/* Footer Preview */}
      <div className="bg-slate-900 border-t border-slate-800 py-8 px-8">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <span className="text-slate-400">© 2024 Your App</span>
          {template.footer?.showSocial && (
            <div className="flex gap-4 text-slate-500">
              <span>Twitter</span>
              <span>GitHub</span>
              <span>Discord</span>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

export default function PageTemplates() {
  const [showEditor, setShowEditor] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [previewTemplate, setPreviewTemplate] = useState(null);
  
  const queryClient = useQueryClient();
  
  const { data: templates = [], isLoading } = useQuery({
    queryKey: ['pageTemplates'],
    queryFn: () => base44.entities.PageTemplate.list(),
  });
  
  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.PageTemplate.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['pageTemplates']);
      setShowEditor(false);
      setEditingTemplate(null);
    }
  });
  
  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PageTemplate.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['pageTemplates']);
      setShowEditor(false);
      setEditingTemplate(null);
    }
  });
  
  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.PageTemplate.delete(id),
    onSuccess: () => queryClient.invalidateQueries(['pageTemplates'])
  });
  
  const handleSave = (form) => {
    if (editingTemplate?.id) {
      updateMutation.mutate({ id: editingTemplate.id, data: form });
    } else {
      createMutation.mutate(form);
    }
  };
  
  const handleDuplicate = (template) => {
    createMutation.mutate({ ...template, name: `${template.name} (Copy)`, id: undefined });
  };
  
  return (
    <div className="min-h-screen">
      <CategoryHeader icon={FileText} title="Page Templates" description="Create and manage reusable page templates with hero sections, dividers, and footer elements" gradient="#8b5cf6, #ec4899" />
      
      <div className="max-w-7xl mx-auto px-4 pb-20">
        <div className="flex items-center justify-between mb-8">
          <p className="text-slate-400">{templates.length} templates saved</p>
          <Button onClick={() => { setEditingTemplate(null); setShowEditor(true); }} className="bg-violet-600 hover:bg-violet-700">
            <Plus className="w-4 h-4 mr-2" /> Create Template
          </Button>
        </div>
        
        {isLoading ? (
          <div className="text-center py-12 text-slate-400">Loading templates...</div>
        ) : templates.length === 0 ? (
          <div className="text-center py-16 bg-slate-900/50 border border-slate-800 rounded-2xl">
            <FileText className="w-12 h-12 text-slate-600 mx-auto mb-4" />
            <h3 className="text-white font-semibold mb-2">No templates yet</h3>
            <p className="text-slate-400 mb-4">Create your first page template to get started</p>
            <Button onClick={() => setShowEditor(true)} className="bg-violet-600 hover:bg-violet-700">
              <Plus className="w-4 h-4 mr-2" /> Create Template
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {templates.map((template) => (
              <TemplateCard
                key={template.id}
                template={template}
                onEdit={(t) => { setEditingTemplate(t); setShowEditor(true); }}
                onDelete={(id) => deleteMutation.mutate(id)}
                onDuplicate={handleDuplicate}
                onPreview={setPreviewTemplate}
              />
            ))}
          </div>
        )}
      </div>
      
      <AnimatePresence>
        {showEditor && (
          <TemplateEditor
            template={editingTemplate}
            onSave={handleSave}
            onCancel={() => { setShowEditor(false); setEditingTemplate(null); }}
          />
        )}
        {previewTemplate && (
          <TemplatePreview template={previewTemplate} onClose={() => setPreviewTemplate(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}