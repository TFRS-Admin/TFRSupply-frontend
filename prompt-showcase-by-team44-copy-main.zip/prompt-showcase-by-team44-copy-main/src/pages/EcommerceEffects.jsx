import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ShoppingBag, ShoppingCart, CreditCard, Tag, Heart, Star, Package, Truck, Search, Filter, Percent, Gift, ArrowRight, Check, X, Plus, Minus } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

// Product Card with Quick Actions
function ProductCardEffect() {
  const [isHovered, setIsHovered] = useState(false);
  const [liked, setLiked] = useState(false);

  return (
    <EffectCard title="Product Card" description="Hover to reveal quick actions" whenToUse="Product listings, category pages, featured items, search results.">
      <div 
        className="w-48 mx-auto"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className="relative rounded-xl overflow-hidden bg-slate-800">
          <div className="h-40 bg-gradient-to-br from-violet-500/30 to-cyan-500/30" />
          <AnimatePresence>
            {isHovered && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-black/40 flex items-center justify-center gap-2"
              >
                <motion.button
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="p-2 rounded-full bg-white text-slate-900"
                >
                  <ShoppingCart className="w-4 h-4" />
                </motion.button>
                <motion.button
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.1 }}
                  onClick={() => setLiked(!liked)}
                  className={`p-2 rounded-full ${liked ? "bg-pink-500 text-white" : "bg-white text-slate-900"}`}
                >
                  <Heart className={`w-4 h-4 ${liked ? "fill-current" : ""}`} />
                </motion.button>
              </motion.div>
            )}
          </AnimatePresence>
          <span className="absolute top-2 left-2 px-2 py-0.5 rounded bg-red-500 text-white text-xs">-20%</span>
        </div>
        <div className="p-3">
          <p className="text-white text-sm font-medium">Product Name</p>
          <div className="flex items-center gap-2">
            <span className="text-violet-400 font-bold">$79.99</span>
            <span className="text-slate-500 line-through text-sm">$99.99</span>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Add to Cart Animation
function AddToCartEffect() {
  const [added, setAdded] = useState(false);
  const [cartCount, setCartCount] = useState(0);

  const handleAdd = () => {
    setAdded(true);
    setCartCount(c => c + 1);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <EffectCard title="Add to Cart" description="Animated cart feedback" whenToUse="Product pages, quick add buttons, cart interactions.">
      <div className="flex flex-col items-center gap-4">
        <div className="relative">
          <ShoppingCart className="w-8 h-8 text-white" />
          <AnimatePresence>
            {cartCount > 0 && (
              <motion.span
                key={cartCount}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-2 -right-2 w-5 h-5 bg-violet-500 rounded-full text-white text-xs flex items-center justify-center"
              >
                {cartCount}
              </motion.span>
            )}
          </AnimatePresence>
        </div>
        <motion.button
          onClick={handleAdd}
          whileTap={{ scale: 0.95 }}
          className={`px-6 py-2 rounded-lg font-medium transition-colors ${added ? "bg-green-500" : "bg-violet-500 hover:bg-violet-600"} text-white`}
        >
          <AnimatePresence mode="wait">
            {added ? (
              <motion.span key="added" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="flex items-center gap-2">
                <Check className="w-4 h-4" /> Added!
              </motion.span>
            ) : (
              <motion.span key="add" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="flex items-center gap-2">
                <Plus className="w-4 h-4" /> Add to Cart
              </motion.span>
            )}
          </AnimatePresence>
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Quantity Selector
function QuantitySelectorEffect() {
  const [qty, setQty] = useState(1);

  return (
    <EffectCard title="Quantity Selector" description="Animated increment/decrement" whenToUse="Cart items, product pages, order forms.">
      <div className="flex items-center gap-3">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => setQty(Math.max(1, qty - 1))}
          className="w-10 h-10 rounded-lg bg-slate-800 text-white flex items-center justify-center hover:bg-slate-700"
        >
          <Minus className="w-4 h-4" />
        </motion.button>
        <motion.span
          key={qty}
          initial={{ scale: 1.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-12 text-center text-2xl font-bold text-white"
        >
          {qty}
        </motion.span>
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => setQty(qty + 1)}
          className="w-10 h-10 rounded-lg bg-violet-500 text-white flex items-center justify-center hover:bg-violet-600"
        >
          <Plus className="w-4 h-4" />
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Star Rating
function StarRatingEffect() {
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);

  return (
    <EffectCard title="Star Rating" description="Interactive review stars" whenToUse="Product reviews, feedback forms, rating systems.">
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map(star => (
          <motion.button
            key={star}
            whileHover={{ scale: 1.2 }}
            whileTap={{ scale: 0.9 }}
            onMouseEnter={() => setHover(star)}
            onMouseLeave={() => setHover(0)}
            onClick={() => setRating(star)}
            className="p-1"
          >
            <Star className={`w-8 h-8 ${star <= (hover || rating) ? "text-amber-400 fill-amber-400" : "text-slate-600"}`} />
          </motion.button>
        ))}
      </div>
      <p className="text-slate-400 text-sm mt-2">{rating > 0 ? `You rated ${rating} star${rating > 1 ? "s" : ""}` : "Click to rate"}</p>
    </EffectCard>
  );
}

// Price Tag Animation
function PriceTagEffect() {
  const [showSale, setShowSale] = useState(true);

  return (
    <EffectCard title="Price Tag" description="Sale price animation" whenToUse="Discounts, flash sales, promotional pricing." controls={
      <Button onClick={() => setShowSale(!showSale)} variant="outline" size="sm" className="text-slate-900">Toggle Sale</Button>
    }>
      <div className="text-center">
        <AnimatePresence mode="wait">
          {showSale ? (
            <motion.div key="sale" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }}>
              <div className="flex items-center justify-center gap-2 mb-1">
                <span className="text-slate-500 line-through text-lg">$199.99</span>
                <motion.span animate={{ rotate: [0, -10, 10, 0] }} transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 2 }} className="px-2 py-0.5 bg-red-500 text-white text-sm rounded">-50%</motion.span>
              </div>
              <span className="text-4xl font-bold text-white">$99.99</span>
            </motion.div>
          ) : (
            <motion.div key="regular" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }}>
              <span className="text-4xl font-bold text-white">$199.99</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Shipping Progress
function ShippingProgressEffect() {
  const [step, setStep] = useState(1);
  const steps = ["Ordered", "Shipped", "In Transit", "Delivered"];

  return (
    <EffectCard title="Shipping Progress" description="Order tracking visualization" whenToUse="Order confirmation, tracking pages, delivery updates." controls={
      <Button onClick={() => setStep((step % 4) + 1)} variant="outline" size="sm" className="text-slate-900">Next Step</Button>
    }>
      <div className="w-full px-4">
        <div className="flex items-center justify-between mb-2">
          {steps.map((s, i) => (
            <div key={s} className="flex flex-col items-center">
              <motion.div
                animate={{ scale: i + 1 === step ? 1.2 : 1, backgroundColor: i + 1 <= step ? "#8b5cf6" : "#334155" }}
                className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs"
              >
                {i + 1 <= step ? <Check className="w-4 h-4" /> : i + 1}
              </motion.div>
              <span className={`text-xs mt-1 ${i + 1 <= step ? "text-violet-400" : "text-slate-500"}`}>{s}</span>
            </div>
          ))}
        </div>
        <div className="h-1 bg-slate-700 rounded-full overflow-hidden">
          <motion.div animate={{ width: `${((step - 1) / 3) * 100}%` }} className="h-full bg-violet-500" />
        </div>
      </div>
    </EffectCard>
  );
}

// Wishlist Heart
function WishlistHeartEffect() {
  const [items, setItems] = useState([false, false, false]);

  const toggle = (i) => {
    const newItems = [...items];
    newItems[i] = !newItems[i];
    setItems(newItems);
  };

  return (
    <EffectCard title="Wishlist Toggle" description="Animated heart favorites" whenToUse="Product listings, saved items, favorites feature.">
      <div className="flex gap-4">
        {items.map((liked, i) => (
          <motion.button
            key={i}
            onClick={() => toggle(i)}
            whileTap={{ scale: 0.8 }}
            className="p-3 rounded-xl bg-slate-800"
          >
            <motion.div animate={liked ? { scale: [1, 1.5, 1] } : {}}>
              <Heart className={`w-6 h-6 ${liked ? "text-pink-500 fill-pink-500" : "text-slate-400"}`} />
            </motion.div>
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Promo Code Input
function PromoCodeEffect() {
  const [code, setCode] = useState("");
  const [applied, setApplied] = useState(false);
  const [error, setError] = useState(false);

  const apply = () => {
    if (code.toUpperCase() === "SAVE20") {
      setApplied(true);
      setError(false);
    } else {
      setError(true);
      setTimeout(() => setError(false), 1500);
    }
  };

  return (
    <EffectCard title="Promo Code" description="Code validation animation" whenToUse="Checkout pages, cart summary, discount application.">
      <div className="w-full max-w-xs mx-auto">
        <div className="flex gap-2">
          <motion.input
            animate={error ? { x: [-5, 5, -5, 5, 0] } : {}}
            type="text"
            placeholder="Enter code (try SAVE20)"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            disabled={applied}
            className={`flex-1 px-3 py-2 rounded-lg bg-slate-800 text-white text-sm border ${error ? "border-red-500" : applied ? "border-green-500" : "border-slate-700"}`}
          />
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={apply}
            disabled={applied}
            className={`px-4 py-2 rounded-lg font-medium ${applied ? "bg-green-500" : "bg-violet-500"} text-white`}
          >
            {applied ? <Check className="w-4 h-4" /> : "Apply"}
          </motion.button>
        </div>
        {applied && <p className="text-green-400 text-sm mt-2">20% discount applied!</p>}
      </div>
    </EffectCard>
  );
}

// Size Selector
function SizeSelectorEffect() {
  const [selected, setSelected] = useState("M");
  const sizes = ["XS", "S", "M", "L", "XL"];

  return (
    <EffectCard title="Size Selector" description="Interactive size picker" whenToUse="Clothing products, size selection, variant picker.">
      <div className="flex gap-2">
        {sizes.map(size => (
          <motion.button
            key={size}
            onClick={() => setSelected(size)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`w-10 h-10 rounded-lg font-medium transition-colors ${selected === size ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400 hover:bg-slate-700"}`}
          >
            {size}
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Color Swatch
function ColorSwatchEffect() {
  const [selected, setSelected] = useState(0);
  const colors = ["#8b5cf6", "#06b6d4", "#f43f5e", "#22c55e", "#eab308"];

  return (
    <EffectCard title="Color Swatch" description="Product color selection" whenToUse="Product variants, color options, customization.">
      <div className="flex gap-3">
        {colors.map((color, i) => (
          <motion.button
            key={color}
            onClick={() => setSelected(i)}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className={`w-8 h-8 rounded-full border-2 ${selected === i ? "border-white" : "border-transparent"}`}
            style={{ backgroundColor: color }}
          >
            {selected === i && <Check className="w-4 h-4 text-white mx-auto" />}
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Flash Sale Timer
function FlashSaleEffect() {
  const [time, setTime] = useState({ h: 2, m: 45, s: 30 });

  React.useEffect(() => {
    const interval = setInterval(() => {
      setTime(t => {
        let { h, m, s } = t;
        s--;
        if (s < 0) { s = 59; m--; }
        if (m < 0) { m = 59; h--; }
        if (h < 0) { h = 23; }
        return { h, m, s };
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const pad = (n) => String(n).padStart(2, '0');

  return (
    <EffectCard title="Flash Sale Timer" description="Urgency countdown" whenToUse="Limited time offers, flash sales, deal countdowns.">
      <div className="text-center">
        <div className="flex items-center justify-center gap-1 mb-2">
          <Percent className="w-5 h-5 text-red-400" />
          <span className="text-red-400 font-bold">FLASH SALE</span>
        </div>
        <div className="flex gap-2 justify-center">
          {[
            { label: "HRS", value: time.h },
            { label: "MIN", value: time.m },
            { label: "SEC", value: time.s }
          ].map(({ label, value }) => (
            <div key={label} className="bg-slate-800 rounded-lg p-3">
              <motion.span key={value} initial={{ y: -10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="text-2xl font-bold text-white block">
                {pad(value)}
              </motion.span>
              <span className="text-xs text-slate-500">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Cart Mini Preview
function CartMiniEffect() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <EffectCard title="Cart Mini Preview" description="Hoverable cart dropdown" whenToUse="Navigation headers, quick cart access, mini checkout.">
      <div className="relative">
        <button
          onMouseEnter={() => setIsOpen(true)}
          onMouseLeave={() => setIsOpen(false)}
          className="p-3 rounded-lg bg-slate-800 text-white relative"
        >
          <ShoppingBag className="w-6 h-6" />
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-violet-500 rounded-full text-xs flex items-center justify-center">3</span>
        </button>
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              onMouseEnter={() => setIsOpen(true)}
              onMouseLeave={() => setIsOpen(false)}
              className="absolute top-full right-0 mt-2 w-64 bg-slate-800 rounded-xl p-4 shadow-xl border border-slate-700"
            >
              {[1, 2].map(i => (
                <div key={i} className="flex gap-3 mb-3">
                  <div className="w-12 h-12 rounded bg-slate-700" />
                  <div className="flex-1">
                    <p className="text-white text-sm">Product {i}</p>
                    <p className="text-violet-400 text-sm">$49.99</p>
                  </div>
                </div>
              ))}
              <div className="border-t border-slate-700 pt-3 mt-3">
                <div className="flex justify-between text-white mb-3">
                  <span>Total:</span>
                  <span className="font-bold">$99.98</span>
                </div>
                <button className="w-full py-2 bg-violet-500 rounded-lg text-white font-medium">Checkout</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Filter Tags
function FilterTagsEffect() {
  const [tags, setTags] = useState(["Electronics", "Under $100", "4+ Stars"]);

  const remove = (tag) => setTags(tags.filter(t => t !== tag));

  return (
    <EffectCard title="Filter Tags" description="Removable filter chips" whenToUse="Search results, filtered products, active filters display.">
      <div className="flex flex-wrap gap-2">
        <AnimatePresence>
          {tags.map(tag => (
            <motion.span
              key={tag}
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0 }}
              className="flex items-center gap-1 px-3 py-1 rounded-full bg-violet-500/20 text-violet-400 text-sm"
            >
              {tag}
              <button onClick={() => remove(tag)} className="hover:text-white">
                <X className="w-3 h-3" />
              </button>
            </motion.span>
          ))}
        </AnimatePresence>
        {tags.length === 0 && <span className="text-slate-500 text-sm">No filters active</span>}
      </div>
    </EffectCard>
  );
}

// Stock Indicator
function StockIndicatorEffect() {
  const [stock, setStock] = useState(5);

  return (
    <EffectCard title="Stock Indicator" description="Low stock urgency display" whenToUse="Product availability, inventory levels, urgency messaging." controls={
      <Button onClick={() => setStock(Math.max(0, stock - 1))} variant="outline" size="sm" className="text-slate-900">Decrease Stock</Button>
    }>
      <div className="text-center">
        {stock > 10 ? (
          <span className="text-green-400 flex items-center gap-2 justify-center">
            <Check className="w-4 h-4" /> In Stock
          </span>
        ) : stock > 0 ? (
          <motion.span animate={{ opacity: [1, 0.5, 1] }} transition={{ duration: 1, repeat: Infinity }} className="text-amber-400 flex items-center gap-2 justify-center">
            <Package className="w-4 h-4" /> Only {stock} left!
          </motion.span>
        ) : (
          <span className="text-red-400 flex items-center gap-2 justify-center">
            <X className="w-4 h-4" /> Out of Stock
          </span>
        )}
      </div>
    </EffectCard>
  );
}

// Buy Now Button
function BuyNowEffect() {
  const [processing, setProcessing] = useState(false);

  const handleBuy = () => {
    setProcessing(true);
    setTimeout(() => setProcessing(false), 2000);
  };

  return (
    <EffectCard title="Buy Now Button" description="Premium checkout CTA" whenToUse="Product pages, quick purchase, one-click buy.">
      <motion.button
        onClick={handleBuy}
        disabled={processing}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className="relative px-8 py-3 bg-gradient-to-r from-violet-500 to-cyan-500 rounded-xl text-white font-semibold overflow-hidden"
      >
        <AnimatePresence mode="wait">
          {processing ? (
            <motion.span key="processing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2">
              <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
              Processing...
            </motion.span>
          ) : (
            <motion.span key="buy" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" /> Buy Now
            </motion.span>
          )}
        </AnimatePresence>
      </motion.button>
    </EffectCard>
  );
}

export default function EcommerceEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <ProductCardEffect />, name: "Product Card", category: "product" },
    { component: <AddToCartEffect />, name: "Add to Cart", category: "cart" },
    { component: <QuantitySelectorEffect />, name: "Quantity Selector", category: "cart" },
    { component: <StarRatingEffect />, name: "Star Rating", category: "review" },
    { component: <PriceTagEffect />, name: "Price Tag", category: "product" },
    { component: <ShippingProgressEffect />, name: "Shipping Progress", category: "order" },
    { component: <WishlistHeartEffect />, name: "Wishlist Toggle", category: "product" },
    { component: <PromoCodeEffect />, name: "Promo Code", category: "checkout" },
    { component: <SizeSelectorEffect />, name: "Size Selector", category: "product" },
    { component: <ColorSwatchEffect />, name: "Color Swatch", category: "product" },
    { component: <FlashSaleEffect />, name: "Flash Sale Timer", category: "promotion" },
    { component: <CartMiniEffect />, name: "Cart Mini Preview", category: "cart" },
    { component: <FilterTagsEffect />, name: "Filter Tags", category: "search" },
    { component: <StockIndicatorEffect />, name: "Stock Indicator", category: "product" },
    { component: <BuyNowEffect />, name: "Buy Now Button", category: "checkout" },
  ];

  const filtered = effects.filter(e => 
    e.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
    (activeCategory === "all" || e.category === activeCategory)
  );

  return (
    <div className="min-h-screen">
      <CategoryHeader 
        icon={ShoppingBag} 
        title="E-commerce Effects" 
        description="Product cards, cart interactions, checkout components, and shopping UI patterns" 
        gradient="#f43f5e, #8b5cf6" 
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <SearchFilter
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          activeCategory={activeCategory}
          setActiveCategory={setActiveCategory}
          resultCount={filtered.length}
        />

        <p className="text-slate-400 text-sm mb-8">
          Showing {filtered.length} e-commerce effects
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((effect, i) => (
            <motion.div
              key={effect.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              {effect.component}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}