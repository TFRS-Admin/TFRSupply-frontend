import React from "react";
import TemplateInitializer from "@/components/onboarding/TemplateInitializer";

export default function AdminInitializerPreview() {
  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center relative p-8">
      <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:50px_50px]" />
      
      <div className="relative z-10 text-center mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Template Initializer Preview</h1>
        <p className="text-slate-400">This page allows you to view the setup wizard as a new user would see it.</p>
        <p className="text-xs text-slate-500 mt-2">(The initialization action is disabled in this preview)</p>
      </div>

      <div className="relative z-20 w-full max-w-4xl h-[600px] bg-slate-900/50 rounded-xl border border-slate-800 flex items-center justify-center overflow-hidden">
        {/* Render the component in preview mode */}
        <TemplateInitializer previewMode={true} />
      </div>
    </div>
  );
}