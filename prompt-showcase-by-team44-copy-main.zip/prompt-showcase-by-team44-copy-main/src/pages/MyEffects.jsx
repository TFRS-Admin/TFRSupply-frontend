import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, Trash2, Copy, Check, Search, FolderOpen, User, LogIn, Sun, Moon, Monitor, Plus, Folder, X, Edit2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import CategoryHeader from "@/components/effects/CategoryHeader";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

export default function MyEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [copiedId, setCopiedId] = useState(null);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [localEffects, setLocalEffects] = useState([]);
  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'dark');
  const [folders, setFolders] = useState(() => JSON.parse(localStorage.getItem('effectFolders') || '[]'));
  const [selectedFolder, setSelectedFolder] = useState(null);
  const [showFolderModal, setShowFolderModal] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");
  const queryClient = useQueryClient();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const isAuth = await base44.auth.isAuthenticated();
        if (isAuth) {
          const userData = await base44.auth.me();
          setUser(userData);
        }
      } catch (e) {
        console.log("Not authenticated");
      } finally {
        setIsLoading(false);
      }
    };
    checkAuth();
    const stored = localStorage.getItem('savedEffects');
    if (stored) setLocalEffects(JSON.parse(stored));
  }, []);

  useEffect(() => {
    localStorage.setItem('theme', theme);
    document.documentElement.classList.toggle('light-theme', theme === 'light');
  }, [theme]);

  const { data: dbEffects = [] } = useQuery({
    queryKey: ['savedEffects', user?.email],
    queryFn: () => base44.entities.SavedEffect.filter({ created_by: user.email }),
    enabled: !!user
  });

  const deleteFromDb = useMutation({
    mutationFn: (id) => base44.entities.SavedEffect.delete(id),
    onSuccess: () => queryClient.invalidateQueries(['savedEffects'])
  });

  const effects = user ? dbEffects : localEffects;

  // Folder management
  const createFolder = () => {
    if (!newFolderName.trim()) return;
    const newFolder = { id: Date.now(), name: newFolderName, effectIds: [] };
    const updated = [...folders, newFolder];
    setFolders(updated);
    localStorage.setItem('effectFolders', JSON.stringify(updated));
    setNewFolderName("");
    setShowFolderModal(false);
  };

  const deleteFolder = (folderId) => {
    const updated = folders.filter(f => f.id !== folderId);
    setFolders(updated);
    localStorage.setItem('effectFolders', JSON.stringify(updated));
    if (selectedFolder === folderId) setSelectedFolder(null);
  };

  const addToFolder = (effectId, folderId) => {
    const updated = folders.map(f => 
      f.id === folderId 
        ? { ...f, effectIds: [...new Set([...f.effectIds, effectId])] }
        : f
    );
    setFolders(updated);
    localStorage.setItem('effectFolders', JSON.stringify(updated));
  };

  const removeFromFolder = (effectId, folderId) => {
    const updated = folders.map(f => 
      f.id === folderId 
        ? { ...f, effectIds: f.effectIds.filter(id => id !== effectId) }
        : f
    );
    setFolders(updated);
    localStorage.setItem('effectFolders', JSON.stringify(updated));
  };

  const filteredByFolder = selectedFolder 
    ? effects.filter(e => folders.find(f => f.id === selectedFolder)?.effectIds.includes(e.id))
    : effects;

  const deleteEffect = (id) => {
    if (user) {
      deleteFromDb.mutate(id);
    } else {
      const updated = localEffects.filter(e => e.id !== id);
      setLocalEffects(updated);
      localStorage.setItem('savedEffects', JSON.stringify(updated));
    }
  };

  const copyCode = async (effect) => {
    await navigator.clipboard.writeText(effect.code);
    setCopiedId(effect.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleLogin = () => {
    base44.auth.redirectToLogin(window.location.href);
  };

  const filtered = filteredByFolder.filter(e => e.name?.toLowerCase().includes(searchQuery.toLowerCase()));

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div>
      <CategoryHeader icon={Heart} title="My Saved Effects" description={user ? `Saved to your account (${user.email})` : "Saved locally on this device"} gradient="#ec4899" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* User Settings Card */}
        <Card className="bg-slate-900/50 border-slate-800 mb-8">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <User className="w-5 h-5" /> User Settings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <p className="text-white font-medium mb-1">Theme Mode</p>
                <p className="text-slate-400 text-sm">Choose your preferred appearance</p>
              </div>
              <div className="flex gap-2 bg-slate-800 p-1 rounded-xl">
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setTheme('light')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${theme === 'light' ? 'bg-white text-slate-900' : 'text-slate-400 hover:text-white'}`}
                >
                  <Sun className="w-4 h-4" />
                  <span className="text-sm font-medium">Light</span>
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setTheme('dark')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${theme === 'dark' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'}`}
                >
                  <Moon className="w-4 h-4" />
                  <span className="text-sm font-medium">Dark</span>
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setTheme('system')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${theme === 'system' ? 'bg-violet-500 text-white' : 'text-slate-400 hover:text-white'}`}
                >
                  <Monitor className="w-4 h-4" />
                  <span className="text-sm font-medium">System</span>
                </motion.button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Auth Banner for Guests */}
        {!user && (
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-6 p-4 rounded-xl bg-gradient-to-r from-violet-500/10 to-cyan-500/10 border border-violet-500/20">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-3">
                <User className="w-5 h-5 text-violet-400" />
                <div>
                  <p className="text-white font-medium">Save effects to your account</p>
                  <p className="text-slate-400 text-sm">Sign in to sync across devices and share effects</p>
                </div>
              </div>
              <Button onClick={handleLogin} className="bg-gradient-to-r from-violet-500 to-cyan-500">
                <LogIn className="w-4 h-4 mr-2" /> Sign In
              </Button>
            </div>
          </motion.div>
        )}

        {/* Folders Section */}
        <Card className="bg-slate-900/50 border-slate-800 mb-6">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-white flex items-center gap-2 text-base">
                <Folder className="w-4 h-4" /> Collections
              </CardTitle>
              <button onClick={() => setShowFolderModal(true)} className="p-1.5 rounded-lg bg-violet-500/20 text-violet-400 hover:bg-violet-500/30">
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setSelectedFolder(null)}
                className={`px-3 py-1.5 rounded-lg text-sm transition-colors ${!selectedFolder ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400 hover:text-white"}`}
              >
                All Effects
              </button>
              {folders.map(folder => (
                <div key={folder.id} className="flex items-center gap-1">
                  <button
                    onClick={() => setSelectedFolder(folder.id)}
                    className={`px-3 py-1.5 rounded-l-lg text-sm transition-colors ${selectedFolder === folder.id ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400 hover:text-white"}`}
                  >
                    {folder.name} ({folder.effectIds.length})
                  </button>
                  <button
                    onClick={() => deleteFolder(folder.id)}
                    className="px-2 py-1.5 rounded-r-lg bg-slate-800 text-red-400 hover:bg-red-500/20"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Create Folder Modal */}
        <AnimatePresence>
          {showFolderModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm"
              onClick={() => setShowFolderModal(false)}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-slate-900 border border-slate-700 rounded-xl p-6 w-full max-w-sm mx-4"
              >
                <h3 className="text-lg font-semibold text-white mb-4">Create New Collection</h3>
                <Input
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                  placeholder="Collection name..."
                  className="bg-slate-800 border-slate-700 text-white mb-4"
                  onKeyDown={(e) => e.key === 'Enter' && createFolder()}
                />
                <div className="flex gap-2">
                  <button onClick={() => setShowFolderModal(false)} className="flex-1 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700">Cancel</button>
                  <button onClick={createFolder} className="flex-1 py-2 rounded-lg bg-violet-500 text-white hover:bg-violet-600">Create</button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Search */}
        <div className="relative mb-8">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <Input type="text" placeholder="Search saved effects..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-12 py-6 bg-slate-900/50 border-slate-700 text-white placeholder:text-slate-500 rounded-xl" />
        </div>

        {effects.length === 0 ? (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center py-20">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-slate-800 flex items-center justify-center">
              <FolderOpen className="w-10 h-10 text-slate-600" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">No saved effects yet</h3>
            <p className="text-slate-400 mb-6 max-w-md mx-auto">Click the heart icon on any effect to save it here.</p>
            <Button variant="outline" onClick={() => window.location.href = '/'}>Browse Effects</Button>
          </motion.div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800">
                <p className="text-slate-400 text-sm">Total Saved</p>
                <p className="text-2xl font-bold text-white">{effects.length}</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800">
                <p className="text-slate-400 text-sm">Storage</p>
                <p className="text-lg font-semibold text-white">{user ? "Cloud" : "Local"}</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800">
                <p className="text-slate-400 text-sm">Filtered</p>
                <p className="text-2xl font-bold text-white">{filtered.length}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <AnimatePresence>
                {filtered.map((effect) => (
                  <motion.div key={effect.id} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} layout>
                    <Card className="bg-slate-900/50 border-slate-800 overflow-hidden hover:border-slate-700 transition-colors">
                      <CardHeader className="pb-2">
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle className="text-lg text-white">{effect.name}</CardTitle>
                            <CardDescription className="text-slate-400 text-sm">
                              {new Date(effect.savedAt || effect.created_date).toLocaleDateString()}
                            </CardDescription>
                          </div>
                          <div className="flex gap-1">
                            <button onClick={() => copyCode(effect)} className="p-2 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white transition-colors">
                              {copiedId === effect.id ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                            </button>
                            {folders.length > 0 && (
                              <select
                                onChange={(e) => {
                                  if (e.target.value) addToFolder(effect.id, parseInt(e.target.value));
                                  e.target.value = "";
                                }}
                                className="p-1 rounded-lg bg-slate-800 text-slate-300 text-xs border-none cursor-pointer"
                                defaultValue=""
                              >
                                <option value="" disabled>+ Add to...</option>
                                {folders.map(f => (
                                  <option key={f.id} value={f.id}>{f.name}</option>
                                ))}
                              </select>
                            )}
                            <button onClick={() => deleteEffect(effect.id)} className="p-2 rounded-lg hover:bg-red-500/20 text-slate-300 hover:text-red-400 transition-colors">
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 max-h-32 overflow-hidden">
                          <pre className="text-xs text-slate-400 overflow-hidden">
                            <code>{effect.code?.slice(0, 200)}...</code>
                          </pre>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </>
        )}
      </div>
    </div>
  );
}