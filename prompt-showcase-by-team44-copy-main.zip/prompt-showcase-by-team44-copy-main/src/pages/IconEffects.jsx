import React, { useState } from "react";
import { motion } from "framer-motion";
import { 
  Home, User, Settings, Mail, Bell, Search, Heart, Star, Zap, Sun, Moon, Cloud, 
  Folder, File, Image, Video, Music, Camera, Mic, Phone, MapPin, Calendar, Clock, 
  Lock, Unlock, Eye, EyeOff, Check, X, Plus, Minus, ChevronRight, ChevronDown,
  ArrowUp, ArrowDown, ArrowLeft, ArrowRight, RefreshCw, Download, Upload, Share,
  Copy, Trash, Edit, Save, Send, Play, Pause, Volume2, Sparkles, Wand2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import CategoryHeader from "@/components/effects/CategoryHeader";
import { useQuery } from "@tanstack/react-query";

const allIcons = [
  { name: "Home", icon: Home }, { name: "User", icon: User }, { name: "Settings", icon: Settings },
  { name: "Mail", icon: Mail }, { name: "Bell", icon: Bell }, { name: "Search", icon: Search },
  { name: "Heart", icon: Heart }, { name: "Star", icon: Star }, { name: "Zap", icon: Zap },
  { name: "Sun", icon: Sun }, { name: "Moon", icon: Moon }, { name: "Cloud", icon: Cloud },
  { name: "Folder", icon: Folder }, { name: "File", icon: File }, { name: "Image", icon: Image },
  { name: "Video", icon: Video }, { name: "Music", icon: Music }, { name: "Camera", icon: Camera },
  { name: "Mic", icon: Mic }, { name: "Phone", icon: Phone }, { name: "MapPin", icon: MapPin },
  { name: "Calendar", icon: Calendar }, { name: "Clock", icon: Clock }, { name: "Lock", icon: Lock },
  { name: "Unlock", icon: Unlock }, { name: "Eye", icon: Eye }, { name: "EyeOff", icon: EyeOff },
  { name: "Check", icon: Check }, { name: "X", icon: X }, { name: "Plus", icon: Plus },
  { name: "Minus", icon: Minus }, { name: "ChevronRight", icon: ChevronRight }, { name: "ChevronDown", icon: ChevronDown },
  { name: "ArrowUp", icon: ArrowUp }, { name: "ArrowDown", icon: ArrowDown }, { name: "ArrowLeft", icon: ArrowLeft },
  { name: "ArrowRight", icon: ArrowRight }, { name: "RefreshCw", icon: RefreshCw }, { name: "Download", icon: Download },
  { name: "Upload", icon: Upload }, { name: "Share", icon: Share }, { name: "Copy", icon: Copy },
  { name: "Trash", icon: Trash }, { name: "Edit", icon: Edit }, { name: "Save", icon: Save },
  { name: "Send", icon: Send }, { name: "Play", icon: Play }, { name: "Pause", icon: Pause },
  { name: "Volume2", icon: Volume2 }, { name: "Sparkles", icon: Sparkles },
];

const iconEffects = [
  { id: "spin", name: "Spin", animation: { rotate: 360 }, transition: { duration: 1, repeat: Infinity, ease: "linear" } },
  { id: "pulse", name: "Pulse", animation: { scale: [1, 1.2, 1] }, transition: { duration: 0.6, repeat: Infinity } },
  { id: "bounce", name: "Bounce", animation: { y: [0, -10, 0] }, transition: { duration: 0.5, repeat: Infinity } },
  { id: "shake", name: "Shake", animation: { x: [-3, 3, -3, 3, 0] }, transition: { duration: 0.4, repeat: Infinity } },
  { id: "flip", name: "Flip", animation: { rotateY: 360 }, transition: { duration: 0.8, repeat: Infinity } },
  { id: "swing", name: "Swing", animation: { rotate: [-10, 10, -10] }, transition: { duration: 0.5, repeat: Infinity } },
  { id: "float", name: "Float", animation: { y: [-5, 5, -5] }, transition: { duration: 2, repeat: Infinity } },
  { id: "heartbeat", name: "Heartbeat", animation: { scale: [1, 1.3, 1, 1.3, 1] }, transition: { duration: 1, repeat: Infinity } },
  { id: "flash", name: "Flash", animation: { opacity: [1, 0, 1] }, transition: { duration: 0.5, repeat: Infinity } },
  { id: "rubber", name: "Rubber", animation: { scaleX: [1, 1.25, 0.75, 1.15, 0.95, 1] }, transition: { duration: 0.6, repeat: Infinity } },
];

const iconStyles = [
  { id: "default", name: "Default", className: "text-white" },
  { id: "glow", name: "Glow", className: "text-violet-400", style: { filter: "drop-shadow(0 0 8px #8b5cf6)" } },
  { id: "gold", name: "Gold", className: "text-yellow-400", style: { filter: "drop-shadow(0 0 4px #fbbf24)" } },
  { id: "neon-cyan", name: "Neon Cyan", className: "text-cyan-400", style: { filter: "drop-shadow(0 0 10px #06b6d4)" } },
  { id: "neon-pink", name: "Neon Pink", className: "text-pink-400", style: { filter: "drop-shadow(0 0 10px #ec4899)" } },
  { id: "shadow", name: "Shadow", className: "text-white", style: { filter: "drop-shadow(3px 3px 0 rgba(0,0,0,0.5))" } },
  { id: "3d", name: "3D", className: "text-white", style: { filter: "drop-shadow(2px 2px 0 #8b5cf6) drop-shadow(4px 4px 0 #06b6d4)" } },
];

// Icon Badge Packs - 35 themed collections
const iconBadgePacks = [
  // Original 10
  { id: "minimal", name: "Minimal", description: "Clean, simple outlines", bg: "bg-slate-900", border: "border-slate-700", iconColor: "text-slate-300", icons: [Home, User, Settings, Mail, Bell], prompt: "Create minimal icon badges with clean slate backgrounds, thin borders, and subtle gray icons for a professional look." },
  { id: "neon", name: "Neon Glow", description: "Vibrant glowing effects", bg: "bg-slate-950", border: "border-violet-500", iconColor: "text-violet-400", glow: true, icons: [Zap, Star, Sparkles, Heart, Eye], prompt: "Create neon glowing icon badges with dark backgrounds, vibrant violet borders with box-shadow glow effects." },
  { id: "gradient", name: "Gradient Pop", description: "Colorful gradient backgrounds", bg: "bg-gradient-to-br from-pink-500 to-violet-600", border: "border-pink-400", iconColor: "text-white", icons: [Camera, Image, Video, Music, Mic], prompt: "Create gradient icon badges with pink-to-violet gradient backgrounds and white icons for bold visual impact." },
  { id: "frosted", name: "Frosted Glass", description: "Glassmorphism style", bg: "bg-white/10 backdrop-blur-md", border: "border-white/20", iconColor: "text-white", icons: [Cloud, Sun, Moon, MapPin, Calendar], prompt: "Create glassmorphism icon badges using backdrop-blur, semi-transparent white backgrounds, and subtle borders." },
  { id: "dark", name: "Dark Mode", description: "Sleek dark theme", bg: "bg-slate-800", border: "border-slate-600", iconColor: "text-cyan-400", icons: [Lock, Eye, Shield, Key, Unlock], prompt: "Create dark mode icon badges with slate-800 backgrounds, subtle borders, and cyan accent icons." },
  { id: "success", name: "Success States", description: "Green positive actions", bg: "bg-emerald-500/20", border: "border-emerald-500", iconColor: "text-emerald-400", icons: [Check, ArrowUp, Download, Save, Send], prompt: "Create success state icon badges with green/emerald tints, matching borders, for positive action indicators." },
  { id: "warning", name: "Warning States", description: "Orange caution indicators", bg: "bg-amber-500/20", border: "border-amber-500", iconColor: "text-amber-400", icons: [Bell, Clock, RefreshCw, Edit, Minus], prompt: "Create warning state icon badges with amber/orange tints for caution and attention indicators." },
  { id: "danger", name: "Danger States", description: "Red alert actions", bg: "bg-red-500/20", border: "border-red-500", iconColor: "text-red-400", icons: [X, Trash, EyeOff, Lock, Minus], prompt: "Create danger state icon badges with red tints and borders for destructive action indicators." },
  { id: "social", name: "Social Actions", description: "Engagement icons", bg: "bg-gradient-to-br from-rose-500 to-pink-600", border: "border-rose-400", iconColor: "text-white", icons: [Heart, Star, Share, Send, MessageCircle], prompt: "Create social action icon badges with rose-to-pink gradients for engagement and sharing features." },
  { id: "navigation", name: "Navigation", description: "Directional controls", bg: "bg-slate-800", border: "border-indigo-500", iconColor: "text-indigo-400", icons: [ArrowUp, ArrowDown, ArrowLeft, ArrowRight, ChevronRight], prompt: "Create navigation icon badges with indigo accents for directional and navigation controls." },
  // 25 NEW Badge Packs
  { id: "ocean", name: "Ocean Depths", description: "Deep sea blues", bg: "bg-gradient-to-br from-blue-600 to-cyan-800", border: "border-cyan-400", iconColor: "text-cyan-200", icons: [Cloud, Eye, Search, Mail, Bell], prompt: "Create ocean-themed icon badges with deep blue-to-cyan gradients and light cyan icons." },
  { id: "sunset", name: "Sunset Vibes", description: "Warm orange-pink", bg: "bg-gradient-to-br from-orange-500 to-pink-600", border: "border-orange-300", iconColor: "text-white", icons: [Sun, Heart, Star, Camera, Music], prompt: "Create sunset-themed badges with warm orange-to-pink gradients evoking golden hour." },
  { id: "forest", name: "Forest Green", description: "Natural earthy tones", bg: "bg-gradient-to-br from-green-700 to-emerald-900", border: "border-green-400", iconColor: "text-green-200", icons: [Home, MapPin, Cloud, Sun, Eye], prompt: "Create forest-themed badges with deep green gradients and natural, earthy aesthetics." },
  { id: "royal", name: "Royal Purple", description: "Luxurious purple", bg: "bg-gradient-to-br from-purple-700 to-indigo-900", border: "border-purple-400", iconColor: "text-purple-200", icons: [Star, Crown, Heart, Sparkles, Eye], prompt: "Create royal purple badges with deep purple gradients for premium, luxurious features." },
  { id: "fire", name: "Fire & Flame", description: "Hot red-orange", bg: "bg-gradient-to-br from-red-600 to-orange-500", border: "border-red-400", iconColor: "text-yellow-200", icons: [Zap, Star, Heart, Play, Send], prompt: "Create fire-themed badges with red-to-orange gradients and yellow icons for hot/trending items." },
  { id: "ice", name: "Ice Crystal", description: "Cool frozen blues", bg: "bg-gradient-to-br from-cyan-400 to-blue-600", border: "border-cyan-200", iconColor: "text-white", icons: [Cloud, Star, Moon, Eye, Search], prompt: "Create ice crystal badges with cool cyan-to-blue gradients and crisp white icons." },
  { id: "midnight", name: "Midnight Black", description: "Pure dark elegance", bg: "bg-black", border: "border-slate-600", iconColor: "text-slate-300", icons: [Moon, Star, Eye, Lock, Settings], prompt: "Create midnight black badges with pure black backgrounds for dark mode elegance." },
  { id: "gold", name: "Gold Luxury", description: "Premium golden", bg: "bg-gradient-to-br from-yellow-500 to-amber-600", border: "border-yellow-300", iconColor: "text-yellow-900", icons: [Star, Crown, Heart, Check, Sparkles], prompt: "Create luxury gold badges with yellow-to-amber gradients for premium features." },
  { id: "silver", name: "Silver Chrome", description: "Metallic finish", bg: "bg-gradient-to-br from-slate-300 to-slate-500", border: "border-slate-200", iconColor: "text-slate-800", icons: [Settings, Lock, Shield, Eye, Check], prompt: "Create silver chrome badges with metallic gray gradients for modern tech aesthetics." },
  { id: "retro", name: "Retro 80s", description: "Synthwave colors", bg: "bg-gradient-to-br from-pink-500 via-purple-500 to-cyan-500", border: "border-pink-400", iconColor: "text-white", icons: [Music, Video, Play, Star, Zap], prompt: "Create retro 80s badges with synthwave pink-purple-cyan gradients." },
  { id: "pastel", name: "Soft Pastel", description: "Gentle light colors", bg: "bg-gradient-to-br from-pink-200 to-purple-200", border: "border-pink-300", iconColor: "text-purple-600", icons: [Heart, Star, Cloud, Sun, Sparkles], prompt: "Create soft pastel badges with light pink-to-purple gradients for gentle UI." },
  { id: "neonPink", name: "Neon Pink", description: "Hot pink glow", bg: "bg-slate-950", border: "border-pink-500", iconColor: "text-pink-400", glow: true, icons: [Heart, Star, Zap, Music, Camera], prompt: "Create neon pink badges with dark backgrounds and glowing hot pink accents." },
  { id: "neonGreen", name: "Neon Green", description: "Matrix green glow", bg: "bg-slate-950", border: "border-green-500", iconColor: "text-green-400", glow: true, icons: [Eye, Lock, Shield, Check, Zap], prompt: "Create neon green badges with Matrix-inspired glowing green on black." },
  { id: "neonOrange", name: "Neon Orange", description: "Electric orange", bg: "bg-slate-950", border: "border-orange-500", iconColor: "text-orange-400", glow: true, icons: [Zap, Star, Sun, Bell, Send], prompt: "Create neon orange badges with electric orange glow effects." },
  { id: "monochrome", name: "Monochrome", description: "Black & white only", bg: "bg-white", border: "border-black", iconColor: "text-black", icons: [Home, User, Settings, Mail, Bell], prompt: "Create monochrome badges with pure black and white for minimalist design." },
  { id: "outline", name: "Outline Only", description: "Transparent with border", bg: "bg-transparent", border: "border-slate-500 border-2", iconColor: "text-slate-400", icons: [Home, Search, Heart, Star, Settings], prompt: "Create outline-only badges with transparent backgrounds and visible borders." },
  { id: "duotone", name: "Duotone Blue", description: "Two-tone effect", bg: "bg-blue-100", border: "border-blue-500", iconColor: "text-blue-600", icons: [Cloud, Mail, Bell, Search, Eye], prompt: "Create duotone badges with light blue backgrounds and darker blue icons." },
  { id: "candy", name: "Candy Colors", description: "Sweet bright colors", bg: "bg-gradient-to-br from-pink-400 via-yellow-300 to-cyan-400", border: "border-white", iconColor: "text-white", icons: [Heart, Star, Sparkles, Sun, Music], prompt: "Create candy-colored badges with sweet pink-yellow-cyan gradients." },
  { id: "earth", name: "Earth Tones", description: "Natural browns", bg: "bg-gradient-to-br from-amber-700 to-stone-700", border: "border-amber-500", iconColor: "text-amber-200", icons: [Home, MapPin, Sun, Cloud, Eye], prompt: "Create earth tone badges with natural brown gradients for organic aesthetics." },
  { id: "space", name: "Deep Space", description: "Galaxy dark purple", bg: "bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900", border: "border-purple-500", iconColor: "text-purple-300", icons: [Star, Moon, Eye, Sparkles, Zap], prompt: "Create deep space badges with galaxy-inspired dark purple gradients." },
  { id: "spring", name: "Spring Fresh", description: "Light greens", bg: "bg-gradient-to-br from-green-300 to-emerald-400", border: "border-green-500", iconColor: "text-green-800", icons: [Sun, Cloud, Heart, Star, Check], prompt: "Create spring-themed badges with fresh light green gradients." },
  { id: "autumn", name: "Autumn Leaves", description: "Fall orange-brown", bg: "bg-gradient-to-br from-orange-600 to-red-700", border: "border-orange-400", iconColor: "text-orange-100", icons: [Home, Heart, Star, Cloud, MapPin], prompt: "Create autumn-themed badges with fall orange-to-red gradients." },
  { id: "winter", name: "Winter Frost", description: "Icy white-blue", bg: "bg-gradient-to-br from-white to-blue-200", border: "border-blue-300", iconColor: "text-blue-600", icons: [Cloud, Moon, Star, Eye, Heart], prompt: "Create winter frost badges with icy white-to-blue gradients." },
  { id: "tech", name: "Tech Circuit", description: "Digital green lines", bg: "bg-slate-900", border: "border-green-500", iconColor: "text-green-400", icons: [Settings, Lock, Eye, Zap, Check], prompt: "Create tech circuit badges with circuit board green-on-dark aesthetics." },
  { id: "gaming", name: "Gaming RGB", description: "Multicolor RGB", bg: "bg-gradient-to-r from-red-500 via-green-500 to-blue-500", border: "border-white", iconColor: "text-white", icons: [Play, Star, Zap, Heart, Eye], prompt: "Create gaming RGB badges with multicolor gradients for gamer aesthetics." },
];

// Need additional icons for badge packs
import { Shield, Key, MessageCircle, Crown } from "lucide-react";

function IconCard({ iconData, selectedEffect, selectedStyle }) {
  const Icon = iconData.icon;
  
  // Only apply animation if not "none"
  const effect = selectedEffect !== "none" ? iconEffects.find(e => e.id === selectedEffect) : null;
  // Only apply style if not "default"
  const style = iconStyles.find(s => s.id === selectedStyle);

  // Reset animation and style when none/default is selected
  const animationProps = effect ? { animate: effect.animation, transition: effect.transition } : { animate: {}, transition: {} };
  const styleProps = style?.style || {};
  const styleClassName = style?.className || "text-white";

  return (
    <motion.div whileHover={{ scale: 1.05 }} className="p-4 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-violet-500/50 transition-all flex flex-col items-center gap-2">
      <motion.div 
        key={`${selectedEffect}-${selectedStyle}`} // Force re-render on change
        {...animationProps}
        className="p-3 rounded-lg bg-slate-900"
      >
        <Icon className={`w-6 h-6 ${styleClassName}`} style={styleProps} />
      </motion.div>
      <span className="text-xs text-slate-400">{iconData.name}</span>
    </motion.div>
  );
}

export default function IconEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedEffect, setSelectedEffect] = useState("none");
  const [selectedStyle, setSelectedStyle] = useState("default");
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedPrompt, setCopiedPrompt] = useState(false);

  const filteredIcons = allIcons.filter(icon => icon.name.toLowerCase().includes(searchQuery.toLowerCase()));

  const generateCode = () => {
    const effect = iconEffects.find(e => e.id === selectedEffect);
    const style = iconStyles.find(s => s.id === selectedStyle);
    return `import { motion } from "framer-motion";
import { Heart } from "lucide-react";

export function AnimatedIcon() {
  return (
    <motion.div${effect ? `\n      animate={${JSON.stringify(effect.animation)}}\n      transition={${JSON.stringify(effect.transition)}}` : ""}>
      <Heart className="${style?.className || "text-white"} w-6 h-6"${style?.style ? ` style={${JSON.stringify(style.style)}}` : ""} />
    </motion.div>
  );
}`;
  };

  const generatePrompt = () => {
    const effect = iconEffects.find(e => e.id === selectedEffect);
    const style = iconStyles.find(s => s.id === selectedStyle);
    return `Create an animated icon using Lucide React and Framer Motion. Apply ${effect?.name || "no"} animation effect with ${style?.name || "default"} styling. The icon should be responsive and accessible.`;
  };

  const copyCode = async () => {
    await navigator.clipboard.writeText(generateCode());
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const copyPrompt = async () => {
    await navigator.clipboard.writeText(generatePrompt());
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2000);
  };

  return (
    <div>
      <CategoryHeader icon={Sparkles} title="Icons & Effects" description="50 free icons from Lucide React with animations" gradient="#f59e0b" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <Card className="bg-gradient-to-r from-violet-500/10 to-cyan-500/10 border-violet-500/20 mb-8">
          <CardContent className="pt-6">
            <h3 className="text-lg font-semibold text-white mb-2">📦 About Lucide Icons</h3>
            <p className="text-slate-300 text-sm mb-4">Lucide is a beautiful open-source icon library with 1000+ icons. Free to use!</p>
            <div className="flex flex-wrap gap-2">
              {["MIT License", "Tree-shakeable", "Customizable", "React Ready"].map(tag => (
                <span key={tag} className="px-3 py-1 rounded-full bg-slate-800 text-slate-300 text-xs">✓ {tag}</span>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="pb-2"><CardTitle className="text-white text-sm">🎬 Animation</CardTitle></CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                <button onClick={() => setSelectedEffect("none")} className={`px-3 py-1 rounded-lg text-xs ${selectedEffect === "none" ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400"}`}>None</button>
                {iconEffects.map(effect => (
                  <button key={effect.id} onClick={() => setSelectedEffect(effect.id)} className={`px-3 py-1 rounded-lg text-xs ${selectedEffect === effect.id ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400"}`}>{effect.name}</button>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="pb-2"><CardTitle className="text-white text-sm">🎨 Style</CardTitle></CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {iconStyles.map(style => (
                  <button key={style.id} onClick={() => setSelectedStyle(style.id)} className={`px-3 py-1 rounded-lg text-xs ${selectedStyle === style.id ? "bg-cyan-500 text-white" : "bg-slate-800 text-slate-400"}`}>{style.name}</button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="relative mb-6">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <Input type="text" placeholder="Search icons..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-12 py-6 bg-slate-900/50 border-slate-700 text-white rounded-xl" />
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-3 mb-8">
          {filteredIcons.map((icon) => (
            <IconCard key={icon.name} iconData={icon} selectedEffect={selectedEffect} selectedStyle={selectedStyle} />
          ))}
        </div>

        {/* Icon Badge Packs Section */}
        <Card className="bg-slate-900/50 border-slate-800 mb-8">
          <CardHeader>
            <CardTitle className="text-white">🎨 Icon Badge Packs (35 Themed Collections)</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-slate-400 text-sm mb-6">Preview different icon badge styles for your app's categories, navigation, and status indicators. Click "Copy Prompt" to use in AI.</p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {iconBadgePacks.map((pack) => (
                <motion.div
                  key={pack.id}
                  whileHover={{ scale: 1.02, y: -4 }}
                  className="p-4 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-violet-500/50 transition-all group"
                >
                  <h4 className="text-white font-medium text-sm mb-1">{pack.name}</h4>
                  <p className="text-slate-500 text-xs mb-3">{pack.description}</p>
                  <div className="flex gap-2 flex-wrap mb-3">
                    {pack.icons.map((Icon, i) => (
                      <div
                        key={i}
                        className={`p-2 rounded-lg border ${pack.bg} ${pack.border}`}
                        style={pack.glow ? { boxShadow: "0 0 12px rgba(139, 92, 246, 0.4)" } : {}}
                      >
                        <Icon className={`w-4 h-4 ${pack.iconColor}`} />
                      </div>
                    ))}
                  </div>
                  {pack.prompt && (
                    <button
                      onClick={async () => {
                        await navigator.clipboard.writeText(pack.prompt);
                      }}
                      className="w-full text-xs px-2 py-1 rounded bg-violet-500/20 text-violet-400 hover:bg-violet-500/30 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      📋 Copy Prompt
                    </button>
                  )}
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader>
            <div className="flex items-center justify-between flex-wrap gap-2">
              <CardTitle className="text-white">Generated Code</CardTitle>
              <div className="flex gap-2">
                <motion.button onClick={copyCode} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} className="h-9 px-4 rounded-lg border-2 border-cyan-500 relative overflow-hidden">
                  <motion.div className="absolute inset-0 bg-cyan-500" initial={{ width: "0%" }} animate={{ width: copiedCode ? "100%" : "0%" }} />
                  <span className={`relative z-10 flex items-center gap-1 text-sm font-medium ${copiedCode ? "text-white" : "text-cyan-400"}`}>
                    {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    {copiedCode ? "Copied!" : "Copy Code"}
                  </span>
                </motion.button>
                <motion.button onClick={copyPrompt} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} className="h-9 px-4 rounded-lg border-2 border-purple-500 relative overflow-hidden">
                  <motion.div className="absolute inset-0 bg-purple-500" initial={{ width: "0%" }} animate={{ width: copiedPrompt ? "100%" : "0%" }} />
                  <span className={`relative z-10 flex items-center gap-1 text-sm font-medium ${copiedPrompt ? "text-white" : "text-purple-400"}`}>
                    {copiedPrompt ? <Check className="w-4 h-4" /> : <Wand2 className="w-4 h-4" />}
                    {copiedPrompt ? "Copied!" : "Copy Prompt"}
                  </span>
                </motion.button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 overflow-x-auto text-xs text-slate-300">
              <code>{generateCode()}</code>
            </pre>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}