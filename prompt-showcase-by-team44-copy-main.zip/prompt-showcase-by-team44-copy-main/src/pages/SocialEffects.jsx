import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, MessageCircle, Share2, Bookmark, MoreHorizontal, ThumbsUp, Send, Image, Video, Smile, MapPin, Tag, Users, UserPlus, UserMinus, Bell, Settings, Camera, Edit, Link2, Calendar, Award, TrendingUp, Hash, AtSign, Globe, Lock, Eye, Play } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// Social Post Card
function SocialPostEffect() {
  const [liked, setLiked] = useState(false);
  const [likes, setLikes] = useState(128);
  const [saved, setSaved] = useState(false);
  return (
    <EffectCard title="Social Post Card" description="Feed post with actions" whenToUse="Social feeds, timelines, news feeds.">
      <div className="w-full bg-slate-800 rounded-xl overflow-hidden">
        <div className="flex items-center gap-3 p-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-pink-500" />
          <div className="flex-1">
            <p className="text-white font-medium text-sm">Sarah Johnson</p>
            <p className="text-slate-500 text-xs">2 hours ago • 🌍</p>
          </div>
          <button className="p-2 hover:bg-slate-700 rounded-full"><MoreHorizontal className="w-4 h-4 text-slate-400" /></button>
        </div>
        <div className="h-40 bg-gradient-to-br from-violet-500/30 to-cyan-500/30" />
        <div className="p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex gap-4">
              <motion.button onClick={() => { setLiked(!liked); setLikes(l => liked ? l - 1 : l + 1); }} whileTap={{ scale: 0.8 }}>
                <Heart className={`w-6 h-6 ${liked ? "text-red-500 fill-red-500" : "text-slate-400"}`} />
              </motion.button>
              <button><MessageCircle className="w-6 h-6 text-slate-400" /></button>
              <button><Send className="w-6 h-6 text-slate-400" /></button>
            </div>
            <motion.button onClick={() => setSaved(!saved)} whileTap={{ scale: 0.8 }}>
              <Bookmark className={`w-6 h-6 ${saved ? "text-white fill-white" : "text-slate-400"}`} />
            </motion.button>
          </div>
          <p className="text-white text-sm font-medium">{likes} likes</p>
          <p className="text-slate-300 text-sm"><span className="font-medium">sarah</span> Enjoying the sunset 🌅</p>
        </div>
      </div>
    </EffectCard>
  );
}

// Like Button Animation
function LikeButtonEffect() {
  const [liked, setLiked] = useState(false);
  return (
    <EffectCard title="Like Animation" description="Heart burst on click" whenToUse="Like buttons, favorites, reactions.">
      <motion.button onClick={() => setLiked(!liked)} whileTap={{ scale: 0.8 }} className="relative">
        <AnimatePresence>
          {liked && (
            <>
              {[...Array(6)].map((_, i) => (
                <motion.div key={i} initial={{ scale: 0, opacity: 1 }} animate={{ scale: 2, opacity: 0, x: Math.cos(i * 60 * Math.PI / 180) * 30, y: Math.sin(i * 60 * Math.PI / 180) * 30 }} transition={{ duration: 0.5 }} className="absolute inset-0 flex items-center justify-center">
                  <Heart className="w-3 h-3 text-red-500 fill-red-500" />
                </motion.div>
              ))}
            </>
          )}
        </AnimatePresence>
        <motion.div animate={liked ? { scale: [1, 1.3, 1] } : {}} transition={{ duration: 0.3 }}>
          <Heart className={`w-12 h-12 ${liked ? "text-red-500 fill-red-500" : "text-slate-400"}`} />
        </motion.div>
      </motion.button>
    </EffectCard>
  );
}

// Follow Button
function FollowButtonEffect() {
  const [following, setFollowing] = useState(false);
  return (
    <EffectCard title="Follow Button" description="Toggle follow state" whenToUse="Profile cards, user lists, suggestions.">
      <motion.button onClick={() => setFollowing(!following)} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} className={`flex items-center gap-2 px-6 py-2 rounded-full font-medium ${following ? "bg-slate-700 text-white" : "bg-violet-500 text-white"}`}>
        {following ? <><UserMinus className="w-4 h-4" /> Following</> : <><UserPlus className="w-4 h-4" /> Follow</>}
      </motion.button>
    </EffectCard>
  );
}

// Stories Row
function StoriesRowEffect() {
  return (
    <EffectCard title="Stories Row" description="Horizontal story avatars" whenToUse="Story feeds, status updates, highlights.">
      <div className="flex gap-4 overflow-x-auto py-2 px-1">
        <div className="flex flex-col items-center flex-shrink-0">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-slate-700 to-slate-600 flex items-center justify-center border-2 border-dashed border-slate-500">
            <Camera className="w-6 h-6 text-slate-400" />
          </div>
          <span className="text-slate-400 text-xs mt-1">Add story</span>
        </div>
        {["Alice", "Bob", "Carol", "Dave"].map((name, i) => (
          <motion.div key={name} whileHover={{ scale: 1.05 }} className="flex flex-col items-center flex-shrink-0 cursor-pointer">
            <div className="p-0.5 rounded-full bg-gradient-to-tr from-amber-500 via-pink-500 to-violet-500">
              <div className="w-16 h-16 rounded-full bg-slate-800 p-0.5">
                <div className="w-full h-full rounded-full bg-gradient-to-br from-violet-500/50 to-pink-500/50" />
              </div>
            </div>
            <span className="text-white text-xs mt-1">{name}</span>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Profile Header
function ProfileHeaderEffect() {
  return (
    <EffectCard title="Profile Header" description="User profile banner" whenToUse="Profile pages, user details, about.">
      <div className="w-full">
        <div className="h-20 bg-gradient-to-r from-violet-500 to-pink-500 rounded-t-xl relative">
          <div className="absolute -bottom-8 left-4">
            <div className="w-20 h-20 rounded-full bg-slate-800 border-4 border-slate-900 bg-gradient-to-br from-violet-500 to-pink-500" />
          </div>
        </div>
        <div className="pt-10 pb-3 px-4 bg-slate-800 rounded-b-xl">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-white font-bold">Sarah Johnson</h3>
              <p className="text-slate-400 text-sm">@sarahj</p>
            </div>
            <button className="px-4 py-1.5 bg-violet-500 rounded-full text-white text-sm">Follow</button>
          </div>
          <p className="text-slate-300 text-sm mt-2">Designer & Developer ✨ Building cool stuff</p>
          <div className="flex gap-4 mt-3 text-sm">
            <span className="text-white"><strong>1.2K</strong> <span className="text-slate-400">Following</span></span>
            <span className="text-white"><strong>45K</strong> <span className="text-slate-400">Followers</span></span>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Comment Input
function CommentInputEffect() {
  return (
    <EffectCard title="Comment Input" description="Reply to post input" whenToUse="Comments, replies, feedback.">
      <div className="flex items-center gap-3 w-full">
        <div className="w-8 h-8 rounded-full bg-violet-500 flex-shrink-0" />
        <div className="flex-1 flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-full">
          <input type="text" placeholder="Add a comment..." className="flex-1 bg-transparent text-white text-sm outline-none" />
          <button className="text-slate-400 hover:text-violet-400"><Smile className="w-5 h-5" /></button>
        </div>
        <button className="text-violet-400 font-medium text-sm">Post</button>
      </div>
    </EffectCard>
  );
}

// Share Sheet
function ShareSheetEffect() {
  const [show, setShow] = useState(false);
  return (
    <EffectCard title="Share Sheet" description="Sharing options modal" whenToUse="Content sharing, social actions.">
      <button onClick={() => setShow(true)} className="flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-lg text-slate-400"><Share2 className="w-4 h-4" /> Share</button>
      <AnimatePresence>
        {show && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 flex items-end justify-center z-50 p-4" onClick={() => setShow(false)}>
            <motion.div initial={{ y: 100 }} animate={{ y: 0 }} exit={{ y: 100 }} onClick={e => e.stopPropagation()} className="w-full max-w-sm bg-slate-800 rounded-2xl p-4">
              <h4 className="text-white font-medium mb-4">Share to</h4>
              <div className="grid grid-cols-4 gap-4 mb-4">
                {["Twitter", "Facebook", "WhatsApp", "Copy"].map(p => (
                  <button key={p} className="flex flex-col items-center gap-2">
                    <div className="w-12 h-12 bg-slate-700 rounded-full flex items-center justify-center"><Share2 className="w-5 h-5 text-slate-400" /></div>
                    <span className="text-slate-400 text-xs">{p}</span>
                  </button>
                ))}
              </div>
              <button onClick={() => setShow(false)} className="w-full py-2 bg-slate-700 rounded-lg text-slate-300">Cancel</button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </EffectCard>
  );
}

// Notification Item
function NotificationItemEffect() {
  return (
    <EffectCard title="Notification Item" description="Activity notification row" whenToUse="Notification lists, activity feeds.">
      <div className="space-y-2 w-full">
        {[
          { action: "liked your photo", time: "2m", icon: Heart, color: "red" },
          { action: "started following you", time: "1h", icon: UserPlus, color: "violet" },
          { action: "commented on your post", time: "3h", icon: MessageCircle, color: "blue" }
        ].map((n, i) => (
          <motion.div key={i} whileHover={{ x: 4 }} className="flex items-center gap-3 p-2 hover:bg-slate-800 rounded-lg cursor-pointer">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-slate-600" />
              <div className={`absolute -bottom-1 -right-1 w-5 h-5 bg-${n.color}-500 rounded-full flex items-center justify-center`}>
                <n.icon className="w-3 h-3 text-white" />
              </div>
            </div>
            <div className="flex-1">
              <p className="text-white text-sm"><span className="font-medium">username</span> {n.action}</p>
              <p className="text-slate-500 text-xs">{n.time} ago</p>
            </div>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Hashtag
function HashtagEffect() {
  const tags = ["design", "uidesign", "webdev", "react", "tailwind"];
  return (
    <EffectCard title="Hashtags" description="Clickable topic tags" whenToUse="Posts, discovery, trending topics.">
      <div className="flex flex-wrap gap-2">
        {tags.map(tag => (
          <motion.button key={tag} whileHover={{ scale: 1.05 }} className="px-3 py-1.5 bg-slate-800 hover:bg-violet-500/20 rounded-full text-sm text-slate-400 hover:text-violet-400">
            <Hash className="w-3 h-3 inline mr-1" />{tag}
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// User Mention
function UserMentionEffect() {
  return (
    <EffectCard title="User Mentions" description="@username display" whenToUse="Comments, posts, tagging.">
      <p className="text-slate-300 text-sm">
        Hey <motion.span whileHover={{ scale: 1.05 }} className="text-violet-400 cursor-pointer inline-block">@sarah</motion.span> and <motion.span whileHover={{ scale: 1.05 }} className="text-violet-400 cursor-pointer inline-block">@john</motion.span>, check this out! 🎉
      </p>
    </EffectCard>
  );
}

// Post Composer
function PostComposerEffect() {
  return (
    <EffectCard title="Post Composer" description="Create new post UI" whenToUse="Creating posts, status updates.">
      <div className="w-full bg-slate-800 rounded-xl p-4">
        <div className="flex gap-3 mb-3">
          <div className="w-10 h-10 rounded-full bg-violet-500 flex-shrink-0" />
          <textarea placeholder="What's happening?" className="flex-1 bg-transparent text-white resize-none outline-none" rows={2} />
        </div>
        <div className="flex items-center justify-between pt-3 border-t border-slate-700">
          <div className="flex gap-2">
            <button className="p-2 hover:bg-slate-700 rounded-full"><Image className="w-5 h-5 text-violet-400" /></button>
            <button className="p-2 hover:bg-slate-700 rounded-full"><Video className="w-5 h-5 text-violet-400" /></button>
            <button className="p-2 hover:bg-slate-700 rounded-full"><MapPin className="w-5 h-5 text-violet-400" /></button>
            <button className="p-2 hover:bg-slate-700 rounded-full"><Smile className="w-5 h-5 text-violet-400" /></button>
          </div>
          <button className="px-4 py-1.5 bg-violet-500 rounded-full text-white text-sm font-medium">Post</button>
        </div>
      </div>
    </EffectCard>
  );
}

// Trending Topics
function TrendingTopicsEffect() {
  return (
    <EffectCard title="Trending Topics" description="Popular hashtags list" whenToUse="Discover pages, sidebars, explore.">
      <div className="space-y-3 w-full">
        <h4 className="text-white font-medium flex items-center gap-2"><TrendingUp className="w-4 h-4 text-violet-400" /> Trending</h4>
        {[
          { topic: "#ReactJS", posts: "12.4K" },
          { topic: "#Design", posts: "8.2K" },
          { topic: "#WebDev", posts: "5.1K" }
        ].map((t, i) => (
          <motion.div key={t.topic} whileHover={{ x: 4 }} className="flex items-center justify-between p-2 hover:bg-slate-800 rounded-lg cursor-pointer">
            <div>
              <p className="text-slate-400 text-xs">{i + 1} • Trending</p>
              <p className="text-white font-medium">{t.topic}</p>
              <p className="text-slate-500 text-xs">{t.posts} posts</p>
            </div>
            <button className="p-2 hover:bg-slate-700 rounded-full"><MoreHorizontal className="w-4 h-4 text-slate-400" /></button>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Who to Follow
function WhoToFollowEffect() {
  const [following, setFollowing] = useState([false, false, false]);
  return (
    <EffectCard title="Who to Follow" description="User suggestions" whenToUse="Sidebars, onboarding, discovery.">
      <div className="space-y-3 w-full">
        <h4 className="text-white font-medium">Who to follow</h4>
        {["Alice Chen", "Bob Smith", "Carol White"].map((name, i) => (
          <div key={name} className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-pink-500" />
            <div className="flex-1">
              <p className="text-white text-sm font-medium">{name}</p>
              <p className="text-slate-500 text-xs">@{name.toLowerCase().replace(" ", "")}</p>
            </div>
            <motion.button onClick={() => setFollowing(f => f.map((v, j) => j === i ? !v : v))} whileTap={{ scale: 0.95 }} className={`px-3 py-1 rounded-full text-xs font-medium ${following[i] ? "bg-slate-700 text-white" : "bg-white text-slate-900"}`}>
              {following[i] ? "Following" : "Follow"}
            </motion.button>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Image Grid
function ImageGridEffect() {
  return (
    <EffectCard title="Image Grid" description="Multi-image post layout" whenToUse="Photo posts, galleries, albums.">
      <div className="grid grid-cols-2 gap-1 rounded-xl overflow-hidden w-full h-40">
        <div className="bg-gradient-to-br from-violet-500/50 to-pink-500/50" />
        <div className="grid grid-rows-2 gap-1">
          <div className="bg-gradient-to-br from-cyan-500/50 to-blue-500/50" />
          <div className="bg-gradient-to-br from-amber-500/50 to-orange-500/50 relative">
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-white font-bold">+3</div>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Video Post
function VideoPostEffect() {
  const [playing, setPlaying] = useState(false);
  return (
    <EffectCard title="Video Post" description="Video content player" whenToUse="Video feeds, reels, clips.">
      <div className="relative w-full h-48 bg-slate-800 rounded-xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-violet-500/30 to-cyan-500/30" />
        <motion.button onClick={() => setPlaying(!playing)} whileHover={{ scale: 1.1 }} className="absolute inset-0 flex items-center justify-center">
          {playing ? (
            <div className="w-12 h-12 bg-white/90 rounded-full flex items-center justify-center gap-1">
              <div className="w-2 h-6 bg-slate-900 rounded" />
              <div className="w-2 h-6 bg-slate-900 rounded" />
            </div>
          ) : (
            <div className="w-12 h-12 bg-white/90 rounded-full flex items-center justify-center">
              <Play className="w-6 h-6 text-slate-900 ml-1" />
            </div>
          )}
        </motion.button>
        <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/70 rounded text-white text-xs">1:24</div>
      </div>
    </EffectCard>
  );
}

// Poll
function PollEffect() {
  const [voted, setVoted] = useState(-1);
  const options = [
    { text: "React", votes: 45 },
    { text: "Vue", votes: 30 },
    { text: "Angular", votes: 15 },
    { text: "Svelte", votes: 10 }
  ];
  const total = options.reduce((a, b) => a + b.votes, 0);
  return (
    <EffectCard title="Poll" description="Voting options" whenToUse="Engagement, surveys, opinions.">
      <div className="space-y-2 w-full">
        {options.map((opt, i) => (
          <motion.button key={opt.text} onClick={() => setVoted(i)} disabled={voted >= 0} whileHover={voted < 0 ? { scale: 1.01 } : {}} className="w-full relative overflow-hidden rounded-lg border border-slate-700 p-3 text-left">
            {voted >= 0 && (
              <motion.div initial={{ width: 0 }} animate={{ width: `${(opt.votes / total) * 100}%` }} className={`absolute inset-y-0 left-0 ${voted === i ? "bg-violet-500/30" : "bg-slate-700/50"}`} />
            )}
            <div className="relative flex justify-between">
              <span className={`text-sm ${voted === i ? "text-violet-400" : "text-white"}`}>{opt.text}</span>
              {voted >= 0 && <span className="text-slate-400 text-sm">{Math.round((opt.votes / total) * 100)}%</span>}
            </div>
          </motion.button>
        ))}
        <p className="text-slate-500 text-xs">{total} votes • 2 hours left</p>
      </div>
    </EffectCard>
  );
}

// Badge/Verified
function VerifiedBadgeEffect() {
  return (
    <EffectCard title="Verified Badge" description="Account verification mark" whenToUse="Profiles, usernames, trust indicators.">
      <div className="flex items-center gap-2">
        <span className="text-white font-medium">Sarah Johnson</span>
        <motion.div whileHover={{ rotate: 360 }} transition={{ duration: 0.5 }} className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
          <svg className="w-3 h-3 text-white" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Location Tag
function LocationTagEffect() {
  return (
    <EffectCard title="Location Tag" description="Geotagged location" whenToUse="Posts, check-ins, places.">
      <motion.button whileHover={{ scale: 1.02 }} className="flex items-center gap-2 text-slate-400 hover:text-violet-400">
        <MapPin className="w-4 h-4" />
        <span className="text-sm">San Francisco, CA</span>
      </motion.button>
    </EffectCard>
  );
}

// Privacy Selector
function PrivacySelectorEffect() {
  const [privacy, setPrivacy] = useState("public");
  const options = [
    { id: "public", icon: Globe, label: "Public" },
    { id: "friends", icon: Users, label: "Friends" },
    { id: "private", icon: Lock, label: "Only me" }
  ];
  return (
    <EffectCard title="Privacy Selector" description="Post visibility options" whenToUse="Post creation, sharing settings.">
      <div className="flex gap-2">
        {options.map(opt => (
          <motion.button key={opt.id} onClick={() => setPrivacy(opt.id)} whileTap={{ scale: 0.95 }} className={`flex items-center gap-2 px-3 py-2 rounded-lg ${privacy === opt.id ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400"}`}>
            <opt.icon className="w-4 h-4" />
            <span className="text-sm">{opt.label}</span>
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Event Card
function EventCardEffect() {
  const [interested, setInterested] = useState(false);
  return (
    <EffectCard title="Event Card" description="Social event display" whenToUse="Events, meetups, gatherings.">
      <div className="bg-slate-800 rounded-xl overflow-hidden w-full">
        <div className="h-24 bg-gradient-to-r from-violet-500/50 to-pink-500/50" />
        <div className="p-3">
          <div className="flex items-center gap-2 text-violet-400 text-xs mb-1">
            <Calendar className="w-3 h-3" /> Dec 15 • 7:00 PM
          </div>
          <h4 className="text-white font-medium">Design Meetup SF</h4>
          <p className="text-slate-400 text-xs mt-1 flex items-center gap-1"><MapPin className="w-3 h-3" /> San Francisco</p>
          <div className="flex items-center justify-between mt-3">
            <div className="flex -space-x-2">
              {[1, 2, 3].map(i => <div key={i} className="w-6 h-6 rounded-full bg-slate-600 border-2 border-slate-800" />)}
              <span className="ml-2 text-slate-400 text-xs">+42 going</span>
            </div>
            <motion.button onClick={() => setInterested(!interested)} whileTap={{ scale: 0.95 }} className={`px-3 py-1 rounded-full text-xs ${interested ? "bg-violet-500 text-white" : "bg-slate-700 text-slate-300"}`}>
              {interested ? "Interested ✓" : "Interested?"}
            </motion.button>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Achievement Badge
function AchievementBadgeEffect() {
  return (
    <EffectCard title="Achievement Badge" description="Gamification rewards" whenToUse="Profiles, rewards, milestones.">
      <div className="flex gap-4">
        {[
          { icon: Award, label: "Early Adopter", color: "amber" },
          { icon: TrendingUp, label: "Top Creator", color: "violet" },
          { icon: Heart, label: "100 Likes", color: "pink" }
        ].map(b => (
          <motion.div key={b.label} whileHover={{ y: -4, rotate: 5 }} className="text-center">
            <div className={`w-14 h-14 bg-${b.color}-500/20 rounded-xl flex items-center justify-center mb-1`}>
              <b.icon className={`w-7 h-7 text-${b.color}-400`} />
            </div>
            <span className="text-slate-400 text-xs">{b.label}</span>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Bio Link
function BioLinkEffect() {
  return (
    <EffectCard title="Bio Link" description="Profile link button" whenToUse="Link in bio, profile links.">
      <motion.a href="#" whileHover={{ scale: 1.02 }} className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-violet-500 to-pink-500 rounded-lg text-white">
        <Link2 className="w-4 h-4" />
        <span className="text-sm font-medium">myportfolio.com</span>
      </motion.a>
    </EffectCard>
  );
}

// Live Badge
function LiveBadgeEffect() {
  return (
    <EffectCard title="Live Badge" description="Streaming indicator" whenToUse="Live streams, broadcasts, real-time.">
      <motion.div animate={{ scale: [1, 1.05, 1] }} transition={{ duration: 1, repeat: Infinity }} className="flex items-center gap-2 px-3 py-1.5 bg-red-500 rounded-full">
        <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
        <span className="text-white text-sm font-bold">LIVE</span>
      </motion.div>
    </EffectCard>
  );
}

// Repost/Retweet Button
function RepostButtonEffect() {
  const [reposted, setReposted] = useState(false);
  const [count, setCount] = useState(42);
  return (
    <EffectCard title="Repost Button" description="Share/retweet action" whenToUse="Social posts, content sharing.">
      <motion.button onClick={() => { setReposted(!reposted); setCount(c => reposted ? c - 1 : c + 1); }} whileTap={{ scale: 0.9 }} className={`flex items-center gap-2 ${reposted ? "text-green-400" : "text-slate-400"}`}>
        <motion.div animate={reposted ? { rotate: 360 } : {}} transition={{ duration: 0.3 }}>
          <Repeat className="w-5 h-5" />
        </motion.div>
        <span className="text-sm">{count}</span>
      </motion.button>
    </EffectCard>
  );
}

const Repeat = ({ className }) => <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m17 1 4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="m7 23-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>;

// Mute User
function MuteUserEffect() {
  const [muted, setMuted] = useState(false);
  return (
    <EffectCard title="Mute User" description="User mute toggle" whenToUse="Privacy controls, moderation.">
      <motion.button onClick={() => setMuted(!muted)} whileTap={{ scale: 0.95 }} className={`flex items-center gap-2 px-4 py-2 rounded-lg ${muted ? "bg-amber-500/20 text-amber-400" : "bg-slate-800 text-slate-400"}`}>
        <Bell className={`w-5 h-5 ${muted ? "line-through" : ""}`} />
        <span>{muted ? "Unmute" : "Mute"}</span>
      </motion.button>
    </EffectCard>
  );
}

// Pinned Post
function PinnedPostEffect() {
  return (
    <EffectCard title="Pinned Post" description="Highlighted post indicator" whenToUse="Profile pinned content, featured.">
      <div className="bg-slate-800 rounded-xl p-4 border border-violet-500/50 relative w-full">
        <div className="absolute -top-2 left-4 px-2 py-0.5 bg-violet-500 rounded-full text-white text-xs flex items-center gap-1">
          <svg className="w-3 h-3" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.4 7.4H22l-6 4.6 2.3 7-6.3-4.6L5.7 21 8 14l-6-4.6h7.6z"/></svg>
          Pinned
        </div>
        <p className="text-white text-sm mt-2">This is my most important post that I want everyone to see first!</p>
      </div>
    </EffectCard>
  );
}

// Blocked User State
function BlockedUserEffect() {
  return (
    <EffectCard title="Blocked User" description="Blocked profile state" whenToUse="Privacy, user blocking.">
      <div className="text-center py-6 bg-slate-800 rounded-xl w-full">
        <div className="w-16 h-16 rounded-full bg-slate-700 mx-auto mb-3 flex items-center justify-center">
          <Lock className="w-8 h-8 text-slate-500" />
        </div>
        <h4 className="text-white font-medium">@blocked_user</h4>
        <p className="text-slate-500 text-sm mt-1">You blocked this account</p>
        <button className="mt-3 px-4 py-1.5 bg-slate-700 rounded-lg text-slate-300 text-sm">Unblock</button>
      </div>
    </EffectCard>
  );
}

export default function SocialEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <SocialPostEffect />, name: "Social Post Card" },
    { component: <LikeButtonEffect />, name: "Like Animation" },
    { component: <FollowButtonEffect />, name: "Follow Button" },
    { component: <StoriesRowEffect />, name: "Stories Row" },
    { component: <ProfileHeaderEffect />, name: "Profile Header" },
    { component: <CommentInputEffect />, name: "Comment Input" },
    { component: <ShareSheetEffect />, name: "Share Sheet" },
    { component: <NotificationItemEffect />, name: "Notification Item" },
    { component: <HashtagEffect />, name: "Hashtags" },
    { component: <UserMentionEffect />, name: "User Mentions" },
    { component: <PostComposerEffect />, name: "Post Composer" },
    { component: <TrendingTopicsEffect />, name: "Trending Topics" },
    { component: <WhoToFollowEffect />, name: "Who to Follow" },
    { component: <ImageGridEffect />, name: "Image Grid" },
    { component: <VideoPostEffect />, name: "Video Post" },
    { component: <PollEffect />, name: "Poll" },
    { component: <VerifiedBadgeEffect />, name: "Verified Badge" },
    { component: <LocationTagEffect />, name: "Location Tag" },
    { component: <PrivacySelectorEffect />, name: "Privacy Selector" },
    { component: <EventCardEffect />, name: "Event Card" },
    { component: <AchievementBadgeEffect />, name: "Achievement Badge" },
    { component: <BioLinkEffect />, name: "Bio Link" },
    { component: <LiveBadgeEffect />, name: "Live Badge" },
    { component: <RepostButtonEffect />, name: "Repost Button" },
    { component: <MuteUserEffect />, name: "Mute User" },
    { component: <PinnedPostEffect />, name: "Pinned Post" },
    { component: <BlockedUserEffect />, name: "Blocked User" },
  ];

  const filtered = effects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={Heart} title="Social & Community" description="25 components for social networks, communities, and user engagement" gradient="#ec4899, #f43f5e" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((effect, i) => <motion.div key={effect.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>{effect.component}</motion.div>)}
        </div>
      </div>
    </div>
  );
}