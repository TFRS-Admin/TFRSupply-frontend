import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Palette, Wand2, Image, Layers, Sparkles, PenTool, Move, RotateCcw, Maximize2, Grid, Type, Droplet, Sun, Moon, Brush, Scissors, Copy, Download, Eye, EyeOff, Lock, Unlock, ChevronDown, Play, Pause, ZoomIn, ZoomOut, Undo, Redo } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// Layer Panel
function LayerPanelEffect() {
  const [layers, setLayers] = useState([
    { id: 1, name: "Text Layer", visible: true, locked: false },
    { id: 2, name: "Background", visible: true, locked: true },
    { id: 3, name: "Shape 1", visible: false, locked: false }
  ]);
  return (
    <EffectCard title="Layer Panel" description="Photoshop-style layer management" whenToUse="Design tools, image editors, creative apps.">
      <div className="w-full bg-slate-800 rounded-lg p-2 space-y-1">
        {layers.map((layer, i) => (
          <motion.div key={layer.id} whileHover={{ x: 2 }} className={`flex items-center gap-2 p-2 rounded ${i === 0 ? "bg-violet-500/20" : "hover:bg-slate-700"}`}>
            <button onClick={() => setLayers(l => l.map(x => x.id === layer.id ? { ...x, visible: !x.visible } : x))} className="text-slate-400 hover:text-white">
              {layer.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
            </button>
            <div className="w-6 h-6 rounded bg-slate-600" />
            <span className="flex-1 text-white text-xs">{layer.name}</span>
            <button className="text-slate-400 hover:text-white">{layer.locked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}</button>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Color Picker
function ColorPickerEffect() {
  const [hue, setHue] = useState(260);
  return (
    <EffectCard title="Color Picker" description="Advanced color selection tool" whenToUse="Design tools, theme customization, styling.">
      <div className="space-y-3">
        <div className="w-full h-24 rounded-lg relative overflow-hidden" style={{ background: `linear-gradient(to right, white, hsl(${hue}, 100%, 50%))` }}>
          <div className="absolute inset-0" style={{ background: "linear-gradient(to top, black, transparent)" }} />
          <motion.div drag dragConstraints={{ left: 0, right: 140, top: 0, bottom: 80 }} className="absolute w-4 h-4 border-2 border-white rounded-full shadow-lg cursor-move" style={{ top: 20, left: 100 }} />
        </div>
        <div className="h-4 rounded-full" style={{ background: "linear-gradient(to right, #f00, #ff0, #0f0, #0ff, #00f, #f0f, #f00)" }}>
          <input type="range" min="0" max="360" value={hue} onChange={e => setHue(e.target.value)} className="w-full h-full opacity-0 cursor-pointer" />
        </div>
        <div className="flex gap-2">
          <div className="w-8 h-8 rounded" style={{ backgroundColor: `hsl(${hue}, 70%, 50%)` }} />
          <span className="text-white text-sm font-mono">hsl({hue}, 70%, 50%)</span>
        </div>
      </div>
    </EffectCard>
  );
}

// Tool Palette
function ToolPaletteEffect() {
  const [active, setActive] = useState(0);
  const tools = [
    { icon: Move, label: "Move" },
    { icon: PenTool, label: "Pen" },
    { icon: Type, label: "Text" },
    { icon: Brush, label: "Brush" },
    { icon: Droplet, label: "Fill" },
    { icon: Scissors, label: "Cut" }
  ];
  return (
    <EffectCard title="Tool Palette" description="Creative tools sidebar" whenToUse="Design editors, drawing apps, creative suites.">
      <div className="flex flex-col gap-1 bg-slate-800 rounded-lg p-2">
        {tools.map((tool, i) => (
          <motion.button key={i} onClick={() => setActive(i)} whileHover={{ scale: 1.05 }} className={`p-3 rounded-lg flex items-center gap-2 ${active === i ? "bg-violet-500 text-white" : "text-slate-400 hover:bg-slate-700"}`}>
            <tool.icon className="w-4 h-4" />
            <span className="text-xs">{tool.label}</span>
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Canvas Controls
function CanvasControlsEffect() {
  const [zoom, setZoom] = useState(100);
  return (
    <EffectCard title="Canvas Controls" description="Zoom and pan controls" whenToUse="Image editors, design tools, maps.">
      <div className="flex items-center gap-2 bg-slate-800 rounded-lg p-2">
        <button onClick={() => setZoom(Math.max(25, zoom - 25))} className="p-2 hover:bg-slate-700 rounded"><ZoomOut className="w-4 h-4 text-slate-400" /></button>
        <div className="flex-1 h-1 bg-slate-700 rounded-full">
          <motion.div animate={{ width: `${zoom}%` }} className="h-full bg-violet-500 rounded-full" />
        </div>
        <span className="text-white text-xs w-12 text-center">{zoom}%</span>
        <button onClick={() => setZoom(Math.min(200, zoom + 25))} className="p-2 hover:bg-slate-700 rounded"><ZoomIn className="w-4 h-4 text-slate-400" /></button>
      </div>
    </EffectCard>
  );
}

// Gradient Builder
function GradientBuilderEffect() {
  const [angle, setAngle] = useState(90);
  return (
    <EffectCard title="Gradient Builder" description="Create custom gradients" whenToUse="Background design, button styles, creative effects.">
      <div className="space-y-3">
        <div className="h-24 rounded-lg" style={{ background: `linear-gradient(${angle}deg, #8b5cf6, #06b6d4, #22c55e)` }} />
        <div className="flex items-center gap-3">
          <span className="text-slate-400 text-xs">Angle:</span>
          <input type="range" min="0" max="360" value={angle} onChange={e => setAngle(e.target.value)} className="flex-1" />
          <span className="text-white text-xs w-8">{angle}°</span>
        </div>
        <div className="flex gap-2">
          {["#8b5cf6", "#06b6d4", "#22c55e"].map(c => (
            <div key={c} className="w-8 h-8 rounded-lg border-2 border-slate-600" style={{ backgroundColor: c }} />
          ))}
          <button className="w-8 h-8 rounded-lg border-2 border-dashed border-slate-600 flex items-center justify-center text-slate-500">+</button>
        </div>
      </div>
    </EffectCard>
  );
}

// Font Selector
function FontSelectorEffect() {
  const [font, setFont] = useState("Inter");
  const fonts = ["Inter", "Playfair", "Roboto", "Montserrat", "Space Grotesk"];
  return (
    <EffectCard title="Font Selector" description="Typography chooser" whenToUse="Design tools, text editors, theme customization.">
      <div className="space-y-2">
        {fonts.map(f => (
          <motion.button key={f} onClick={() => setFont(f)} whileHover={{ x: 4 }} className={`w-full p-3 rounded-lg text-left flex items-center justify-between ${font === f ? "bg-violet-500/20 border border-violet-500" : "bg-slate-800"}`}>
            <span className="text-white" style={{ fontFamily: f }}>{f}</span>
            {font === f && <div className="w-2 h-2 bg-violet-500 rounded-full" />}
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Image Filter
function ImageFilterEffect() {
  const [filter, setFilter] = useState("none");
  const filters = ["none", "grayscale", "sepia", "saturate", "contrast"];
  return (
    <EffectCard title="Image Filters" description="Apply visual effects" whenToUse="Photo editors, image processing, creative apps.">
      <div className="space-y-3">
        <div className="h-24 bg-gradient-to-br from-violet-500 to-pink-500 rounded-lg" style={{ filter: filter === "none" ? "" : `${filter}(${filter === "saturate" || filter === "contrast" ? 2 : 1})` }} />
        <div className="flex gap-1 overflow-x-auto">
          {filters.map(f => (
            <button key={f} onClick={() => setFilter(f)} className={`px-3 py-1 rounded text-xs whitespace-nowrap ${filter === f ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400"}`}>{f}</button>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Artboard Selector
function ArtboardSelectorEffect() {
  const [size, setSize] = useState("instagram");
  const sizes = { instagram: "1080×1080", story: "1080×1920", twitter: "1200×675", poster: "1920×1080" };
  return (
    <EffectCard title="Artboard Sizes" description="Preset canvas dimensions" whenToUse="Social media tools, design templates, exports.">
      <div className="grid grid-cols-2 gap-2">
        {Object.entries(sizes).map(([key, val]) => (
          <motion.button key={key} onClick={() => setSize(key)} whileHover={{ scale: 1.02 }} className={`p-3 rounded-lg text-left ${size === key ? "bg-violet-500/20 border border-violet-500" : "bg-slate-800"}`}>
            <p className="text-white text-sm capitalize">{key}</p>
            <p className="text-slate-500 text-xs">{val}</p>
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// History Panel
function HistoryPanelEffect() {
  const [step, setStep] = useState(4);
  const actions = ["New Document", "Add Text", "Change Color", "Move Layer", "Add Shape", "Resize"];
  return (
    <EffectCard title="History Panel" description="Undo/redo with history" whenToUse="Design editors, document tools, creative apps.">
      <div className="space-y-2">
        <div className="flex gap-2 mb-2">
          <button onClick={() => setStep(Math.max(0, step - 1))} className="p-2 bg-slate-800 rounded hover:bg-slate-700"><Undo className="w-4 h-4 text-slate-400" /></button>
          <button onClick={() => setStep(Math.min(5, step + 1))} className="p-2 bg-slate-800 rounded hover:bg-slate-700"><Redo className="w-4 h-4 text-slate-400" /></button>
        </div>
        <div className="bg-slate-800 rounded-lg p-2 space-y-1 max-h-32 overflow-y-auto">
          {actions.map((action, i) => (
            <button key={i} onClick={() => setStep(i)} className={`w-full p-2 rounded text-left text-xs ${i === step ? "bg-violet-500/20 text-white" : i < step ? "text-slate-400" : "text-slate-600"}`}>{action}</button>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Transform Controls
function TransformControlsEffect() {
  const [rotation, setRotation] = useState(0);
  const [scale, setScale] = useState(100);
  return (
    <EffectCard title="Transform Controls" description="Rotate, scale, flip" whenToUse="Image editors, design tools, object manipulation.">
      <div className="space-y-4">
        <motion.div animate={{ rotate: rotation, scale: scale / 100 }} className="w-20 h-20 mx-auto bg-gradient-to-br from-violet-500 to-pink-500 rounded-lg" />
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <RotateCcw className="w-4 h-4 text-slate-400" />
            <input type="range" min="0" max="360" value={rotation} onChange={e => setRotation(e.target.value)} className="flex-1" />
            <span className="text-xs text-white w-8">{rotation}°</span>
          </div>
          <div className="flex items-center gap-2">
            <Maximize2 className="w-4 h-4 text-slate-400" />
            <input type="range" min="50" max="150" value={scale} onChange={e => setScale(e.target.value)} className="flex-1" />
            <span className="text-xs text-white w-8">{scale}%</span>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Opacity Slider
function OpacitySliderEffect() {
  const [opacity, setOpacity] = useState(100);
  return (
    <EffectCard title="Opacity Slider" description="Transparency control" whenToUse="Layer editing, overlays, blending.">
      <div className="space-y-3">
        <div className="relative h-20 rounded-lg overflow-hidden" style={{ backgroundImage: "repeating-conic-gradient(#1e293b 0% 25%, #0f172a 0% 50%)", backgroundSize: "16px 16px" }}>
          <div className="absolute inset-0 bg-violet-500" style={{ opacity: opacity / 100 }} />
        </div>
        <div className="flex items-center gap-2">
          <span className="text-slate-400 text-xs">Opacity:</span>
          <input type="range" min="0" max="100" value={opacity} onChange={e => setOpacity(e.target.value)} className="flex-1" />
          <span className="text-white text-xs w-8">{opacity}%</span>
        </div>
      </div>
    </EffectCard>
  );
}

// Grid Overlay Toggle
function GridOverlayEffect() {
  const [show, setShow] = useState(true);
  return (
    <EffectCard title="Grid Overlay" description="Alignment guides" whenToUse="Design precision, alignment, layout.">
      <div className="space-y-3">
        <div className="relative h-32 bg-slate-800 rounded-lg overflow-hidden">
          {show && (
            <div className="absolute inset-0" style={{ backgroundImage: "linear-gradient(to right, rgba(139,92,246,0.1) 1px, transparent 1px), linear-gradient(rgba(139,92,246,0.1) 1px, transparent 1px)", backgroundSize: "20px 20px" }} />
          )}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 bg-violet-500/50 rounded" />
          </div>
        </div>
        <button onClick={() => setShow(!show)} className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm ${show ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400"}`}>
          <Grid className="w-4 h-4" /> {show ? "Hide Grid" : "Show Grid"}
        </button>
      </div>
    </EffectCard>
  );
}

// Blend Mode Selector
function BlendModeEffect() {
  const [mode, setMode] = useState("normal");
  const modes = ["normal", "multiply", "screen", "overlay", "darken", "lighten"];
  return (
    <EffectCard title="Blend Modes" description="Layer blending options" whenToUse="Photo editing, compositing, effects.">
      <div className="space-y-3">
        <div className="relative h-20 rounded-lg overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-violet-500 to-pink-500" />
          <div className="absolute inset-0 bg-gradient-to-b from-cyan-500 to-blue-500" style={{ mixBlendMode: mode }} />
        </div>
        <select value={mode} onChange={e => setMode(e.target.value)} className="w-full p-2 bg-slate-800 rounded-lg text-white text-sm border border-slate-700">
          {modes.map(m => <option key={m} value={m}>{m}</option>)}
        </select>
      </div>
    </EffectCard>
  );
}

// Brush Size
function BrushSizeEffect() {
  const [size, setSize] = useState(20);
  return (
    <EffectCard title="Brush Size" description="Dynamic brush preview" whenToUse="Drawing apps, painting tools, editors.">
      <div className="space-y-4">
        <div className="h-32 bg-slate-800 rounded-lg flex items-center justify-center">
          <motion.div animate={{ width: size * 2, height: size * 2 }} className="bg-white rounded-full" style={{ boxShadow: "0 0 10px rgba(255,255,255,0.5)" }} />
        </div>
        <div className="flex items-center gap-3">
          <Brush className="w-4 h-4 text-slate-400" />
          <input type="range" min="5" max="50" value={size} onChange={e => setSize(e.target.value)} className="flex-1" />
          <span className="text-white text-xs w-8">{size}px</span>
        </div>
      </div>
    </EffectCard>
  );
}

// Swatch Palette
function SwatchPaletteEffect() {
  const [selected, setSelected] = useState(0);
  const colors = ["#8b5cf6", "#06b6d4", "#22c55e", "#f59e0b", "#ef4444", "#ec4899", "#6366f1", "#14b8a6"];
  return (
    <EffectCard title="Swatch Palette" description="Quick color selection" whenToUse="Design tools, theme builders, styling.">
      <div className="grid grid-cols-4 gap-2">
        {colors.map((c, i) => (
          <motion.button key={c} onClick={() => setSelected(i)} whileHover={{ scale: 1.1 }} className={`w-10 h-10 rounded-lg ${selected === i ? "ring-2 ring-white ring-offset-2 ring-offset-slate-900" : ""}`} style={{ backgroundColor: c }} />
        ))}
      </div>
    </EffectCard>
  );
}

// Export Options
function ExportOptionsEffect() {
  const [format, setFormat] = useState("png");
  return (
    <EffectCard title="Export Options" description="File format and quality" whenToUse="Design exports, downloads, sharing.">
      <div className="space-y-3">
        <div className="flex gap-2">
          {["png", "jpg", "svg", "pdf"].map(f => (
            <button key={f} onClick={() => setFormat(f)} className={`flex-1 py-2 rounded-lg text-xs uppercase ${format === f ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400"}`}>{f}</button>
          ))}
        </div>
        <div className="bg-slate-800 rounded-lg p-3">
          <div className="flex justify-between text-xs mb-2">
            <span className="text-slate-400">Quality</span>
            <span className="text-white">High (100%)</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-slate-400">Size</span>
            <span className="text-white">1920 × 1080</span>
          </div>
        </div>
        <button className="w-full py-2 bg-violet-500 rounded-lg text-white text-sm flex items-center justify-center gap-2">
          <Download className="w-4 h-4" /> Export
        </button>
      </div>
    </EffectCard>
  );
}

// Alignment Tools
function AlignmentToolsEffect() {
  return (
    <EffectCard title="Alignment Tools" description="Object positioning controls" whenToUse="Layout design, object arrangement, precision.">
      <div className="space-y-3">
        <div className="flex gap-1 bg-slate-800 rounded-lg p-2">
          {["Left", "Center", "Right", "Top", "Middle", "Bottom"].map(a => (
            <button key={a} className="flex-1 py-2 hover:bg-slate-700 rounded text-xs text-slate-400 hover:text-white">{a[0]}</button>
          ))}
        </div>
        <div className="flex gap-2">
          <button className="flex-1 py-2 bg-slate-800 rounded-lg text-slate-400 text-xs hover:bg-slate-700">Distribute H</button>
          <button className="flex-1 py-2 bg-slate-800 rounded-lg text-slate-400 text-xs hover:bg-slate-700">Distribute V</button>
        </div>
      </div>
    </EffectCard>
  );
}

// Shape Library
function ShapeLibraryEffect() {
  return (
    <EffectCard title="Shape Library" description="Pre-made vector shapes" whenToUse="Design tools, illustrations, quick creation.">
      <div className="grid grid-cols-4 gap-2">
        <div className="w-12 h-12 bg-violet-500 rounded" />
        <div className="w-12 h-12 bg-cyan-500 rounded-full" />
        <div className="w-0 h-0 border-l-6 border-r-6 border-b-12 border-transparent border-b-pink-500" style={{ borderLeftWidth: 24, borderRightWidth: 24, borderBottomWidth: 40, marginTop: 4 }} />
        <div className="w-12 h-12 bg-amber-500 rounded-lg rotate-45 scale-75" />
        <div className="w-12 h-12 border-4 border-green-500 rounded" />
        <div className="w-12 h-12 border-4 border-red-500 rounded-full" />
        <div className="w-12 h-12 bg-indigo-500" style={{ clipPath: "polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)" }} />
        <div className="w-12 h-12 bg-teal-500" style={{ clipPath: "polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)" }} />
      </div>
    </EffectCard>
  );
}

// Text Styling
function TextStylingEffect() {
  const [bold, setBold] = useState(true);
  const [italic, setItalic] = useState(false);
  const [underline, setUnderline] = useState(false);
  return (
    <EffectCard title="Text Styling" description="Typography controls" whenToUse="Text editors, design tools, documents.">
      <div className="space-y-3">
        <div className="flex gap-1 bg-slate-800 rounded-lg p-1">
          <button onClick={() => setBold(!bold)} className={`flex-1 py-2 rounded text-sm font-bold ${bold ? "bg-violet-500 text-white" : "text-slate-400"}`}>B</button>
          <button onClick={() => setItalic(!italic)} className={`flex-1 py-2 rounded text-sm italic ${italic ? "bg-violet-500 text-white" : "text-slate-400"}`}>I</button>
          <button onClick={() => setUnderline(!underline)} className={`flex-1 py-2 rounded text-sm underline ${underline ? "bg-violet-500 text-white" : "text-slate-400"}`}>U</button>
        </div>
        <p className={`text-white text-lg ${bold ? "font-bold" : ""} ${italic ? "italic" : ""} ${underline ? "underline" : ""}`}>Sample Text</p>
      </div>
    </EffectCard>
  );
}

// Dark/Light Mode Toggle
function ThemeToggleEffect() {
  const [dark, setDark] = useState(true);
  return (
    <EffectCard title="Theme Toggle" description="Dark/light mode switch" whenToUse="App settings, preference toggles, theming.">
      <motion.button onClick={() => setDark(!dark)} className={`relative w-20 h-10 rounded-full p-1 ${dark ? "bg-slate-700" : "bg-amber-100"}`}>
        <motion.div animate={{ x: dark ? 0 : 40 }} className={`w-8 h-8 rounded-full flex items-center justify-center ${dark ? "bg-slate-900" : "bg-amber-400"}`}>
          {dark ? <Moon className="w-4 h-4 text-slate-400" /> : <Sun className="w-4 h-4 text-white" />}
        </motion.div>
      </motion.button>
    </EffectCard>
  );
}

// Quick Actions Bar
function QuickActionsEffect() {
  return (
    <EffectCard title="Quick Actions" description="Floating tool shortcuts" whenToUse="Design apps, editors, productivity tools.">
      <div className="flex gap-1 bg-slate-800 rounded-full p-2">
        {[Copy, Download, Eye, Wand2, Sparkles].map((Icon, i) => (
          <motion.button key={i} whileHover={{ scale: 1.1 }} className="p-3 hover:bg-violet-500/20 rounded-full">
            <Icon className="w-4 h-4 text-slate-400 hover:text-violet-400" />
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Timeline Scrubber
function TimelineScrubberEffect() {
  const [position, setPosition] = useState(30);
  const [playing, setPlaying] = useState(false);
  return (
    <EffectCard title="Timeline Scrubber" description="Animation timeline control" whenToUse="Video editors, animation tools, motion design.">
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <button onClick={() => setPlaying(!playing)} className="p-2 bg-slate-800 rounded-lg">
            {playing ? <Pause className="w-4 h-4 text-white" /> : <Play className="w-4 h-4 text-white" />}
          </button>
          <div className="flex-1 relative h-8 bg-slate-800 rounded-lg">
            <div className="absolute inset-y-0 left-0 bg-violet-500/30 rounded-l-lg" style={{ width: `${position}%` }} />
            <input type="range" min="0" max="100" value={position} onChange={e => setPosition(e.target.value)} className="absolute inset-0 w-full opacity-0 cursor-pointer" />
            <div className="absolute top-0 bottom-0 w-0.5 bg-violet-500" style={{ left: `${position}%` }} />
          </div>
          <span className="text-white text-xs font-mono w-12">00:{String(Math.floor(position / 100 * 60)).padStart(2, "0")}</span>
        </div>
      </div>
    </EffectCard>
  );
}

// Properties Panel
function PropertiesPanelEffect() {
  return (
    <EffectCard title="Properties Panel" description="Object properties editor" whenToUse="Design tools, settings, configuration.">
      <div className="bg-slate-800 rounded-lg p-3 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-slate-400 text-xs">Position</span>
          <div className="flex gap-2">
            <input type="text" defaultValue="120" className="w-12 px-2 py-1 bg-slate-900 rounded text-white text-xs text-center" />
            <input type="text" defaultValue="80" className="w-12 px-2 py-1 bg-slate-900 rounded text-white text-xs text-center" />
          </div>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-slate-400 text-xs">Size</span>
          <div className="flex gap-2">
            <input type="text" defaultValue="200" className="w-12 px-2 py-1 bg-slate-900 rounded text-white text-xs text-center" />
            <input type="text" defaultValue="150" className="w-12 px-2 py-1 bg-slate-900 rounded text-white text-xs text-center" />
          </div>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-slate-400 text-xs">Rotation</span>
          <input type="text" defaultValue="0°" className="w-12 px-2 py-1 bg-slate-900 rounded text-white text-xs text-center" />
        </div>
      </div>
    </EffectCard>
  );
}

// Asset Library
function AssetLibraryEffect() {
  return (
    <EffectCard title="Asset Library" description="Reusable design assets" whenToUse="Design systems, component libraries, templates.">
      <div className="grid grid-cols-3 gap-2">
        {[1, 2, 3, 4, 5, 6].map(i => (
          <motion.div key={i} whileHover={{ scale: 1.05 }} className="aspect-square bg-slate-800 rounded-lg flex items-center justify-center cursor-pointer hover:ring-2 ring-violet-500">
            <Image className="w-6 h-6 text-slate-600" />
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

export default function CreativeEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <LayerPanelEffect />, name: "Layer Panel" },
    { component: <ColorPickerEffect />, name: "Color Picker" },
    { component: <ToolPaletteEffect />, name: "Tool Palette" },
    { component: <CanvasControlsEffect />, name: "Canvas Controls" },
    { component: <GradientBuilderEffect />, name: "Gradient Builder" },
    { component: <FontSelectorEffect />, name: "Font Selector" },
    { component: <ImageFilterEffect />, name: "Image Filters" },
    { component: <ArtboardSelectorEffect />, name: "Artboard Sizes" },
    { component: <HistoryPanelEffect />, name: "History Panel" },
    { component: <TransformControlsEffect />, name: "Transform Controls" },
    { component: <OpacitySliderEffect />, name: "Opacity Slider" },
    { component: <GridOverlayEffect />, name: "Grid Overlay" },
    { component: <BlendModeEffect />, name: "Blend Modes" },
    { component: <BrushSizeEffect />, name: "Brush Size" },
    { component: <SwatchPaletteEffect />, name: "Swatch Palette" },
    { component: <ExportOptionsEffect />, name: "Export Options" },
    { component: <AlignmentToolsEffect />, name: "Alignment Tools" },
    { component: <ShapeLibraryEffect />, name: "Shape Library" },
    { component: <TextStylingEffect />, name: "Text Styling" },
    { component: <ThemeToggleEffect />, name: "Theme Toggle" },
    { component: <QuickActionsEffect />, name: "Quick Actions" },
    { component: <TimelineScrubberEffect />, name: "Timeline Scrubber" },
    { component: <PropertiesPanelEffect />, name: "Properties Panel" },
    { component: <AssetLibraryEffect />, name: "Asset Library" },
  ];

  const filtered = effects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={Palette} title="Creative & Design Tools" description="25 components for building design editors, creative apps, and artistic tools" gradient="#ec4899, #8b5cf6" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((effect, i) => <motion.div key={effect.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>{effect.component}</motion.div>)}
        </div>
      </div>
    </div>
  );
}