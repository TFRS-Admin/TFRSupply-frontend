import React, { useState } from "react";
import { motion } from "framer-motion";
import { MousePointerClick, Search, X, Check, Copy, Wand2, Heart, ShoppingCart } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import CategoryHeader from "@/components/effects/CategoryHeader";
import { Button } from "@/components/ui/button";
import OnboardingTour, { useTour } from "@/components/onboarding/OnboardingTour";
import { useQuery } from "@tanstack/react-query";

const buttonEffects = [
  { id: 1, name: "Ripple", type: "fill", category: "interaction", code: `<motion.button whileTap={{ scale: 0.95 }}>\n  <motion.div initial={{ scale: 0 }} whileTap={{ scale: 4, opacity: 0 }} />\n</motion.button>` },
  { id: 2, name: "Fill Animation", type: "fill", category: "interaction", code: `<motion.button className="overflow-hidden">\n  <motion.div initial={{ x: "-100%" }} whileHover={{ x: 0 }} />\n</motion.button>` },
  { id: 3, name: "3D Press", type: "transform", category: "confirmation", code: `<motion.button whileTap={{ y: 2, boxShadow: "none" }} />` },
  { id: 4, name: "Shake", type: "shake", category: "input", code: `<motion.button whileHover={{ x: [-5, 5, -5, 5, 0] }} />` },
  { id: 5, name: "Loading State", type: "state", category: "confirmation", code: `<button disabled>\n  <Loader2 className="animate-spin" /> Loading...\n</button>` },
  { id: 6, name: "Like Button", type: "state", category: "interaction", code: `<motion.button onClick={() => setLiked(!liked)}>\n  <Heart className={liked ? "fill-red-500" : ""} />\n</motion.button>` },
  { id: 7, name: "Add to Cart", type: "state", category: "confirmation", code: `<motion.button whileTap={{ scale: 0.95 }}>\n  <ShoppingCart /> Add to Cart\n</motion.button>` },
  { id: 8, name: "Download Progress", type: "progress", category: "confirmation", code: `<div className="overflow-hidden">\n  <motion.div animate={{ width: \`\${progress}%\` }} />\n</div>` },
  { id: 9, name: "Magnetic Follow", type: "transform", category: "interaction", code: `<motion.button onMouseMove={handleMove} animate={{ x: offset.x, y: offset.y }} />` },
  { id: 10, name: "Border Animation", type: "stroke", category: "interaction", code: `<motion.div animate={{ backgroundPosition: ["0%", "100%"] }}>\n  <button>Animated Border</button>\n</motion.div>` },
  { id: 11, name: "Glow", type: "glow", category: "interaction", code: `<motion.button whileHover={{ boxShadow: "0 0 20px rgba(139,92,246,0.8)" }} />` },
  { id: 12, name: "Neon Glow", type: "glow", category: "interaction", code: `<motion.button whileHover={{ textShadow: "0 0 10px #8b5cf6" }} />` },
  { id: 13, name: "Liquid Fill", type: "fill", category: "interaction", code: `<button className="overflow-hidden">\n  <motion.div initial={{ height: 0 }} whileHover={{ height: "100%" }} />\n</button>` },
  { id: 14, name: "Gradient Border", type: "stroke", category: "interaction", code: `<motion.div animate={{ rotate: 360 }} className="gradient-border">\n  <button>Rotating Border</button>\n</motion.div>` },
  { id: 15, name: "Pulse Ring", type: "glow", category: "interaction", code: `<div className="relative">\n  <motion.div animate={{ scale: [1, 2], opacity: [0.5, 0] }} />\n  <button>Pulse</button>\n</div>` },
  { id: 16, name: "Confetti", type: "particle", category: "confirmation", code: `import confetti from 'canvas-confetti';\nconfetti({ particleCount: 100 });` },
  { id: 17, name: "Glitch", type: "glitch", category: "interaction", code: `<motion.button whileHover={{ textShadow: ["-2px 0 #ff00ff, 2px 0 #00ffff"] }} />` },
  { id: 18, name: "Morphing Shape", type: "transform", category: "state", code: `<motion.button animate={{ borderRadius: ["12px", "24px", "12px"] }} />` },
  { id: 19, name: "Spotlight", type: "glow", category: "interaction", code: `<button className="overflow-hidden">\n  <motion.div initial={{ scale: 0 }} whileHover={{ scale: 2 }} />\n</button>` },
  { id: 20, name: "Elastic Bounce", type: "transform", category: "interaction", code: `<motion.button whileHover={{ scale: [1, 1.2, 0.9, 1.1, 1] }} />` },
];

const animationTypes = ["all", "fill", "glow", "shake", "transform", "stroke", "state", "progress", "particle", "glitch"];
const categories = ["all", "interaction", "confirmation", "input", "state"];

function InteractiveButtonDemo({ effect, speed, intensity }) {
  const [isLiked, setIsLiked] = useState(false);
  const [isAdded, setIsAdded] = useState(false);
  const [progress, setProgress] = useState(0);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setMousePos({
      x: e.clientX - rect.left - rect.width / 2,
      y: e.clientY - rect.top - rect.height / 2
    });
  };

  const handleDownload = () => {
    setProgress(0);
    const interval = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          return 100;
        }
        return p + 10;
      });
    }, 100);
  };

  const getButtonContent = () => {
    switch (effect.id) {
      case 1: // Ripple
        return (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="relative px-8 py-3 rounded-xl bg-violet-600 text-white font-semibold overflow-hidden"
          >
            <span className="relative z-10">Click for Ripple</span>
            <motion.div
              className="absolute inset-0 bg-white/30 rounded-full"
              initial={{ scale: 0, opacity: 1 }}
              whileTap={{ scale: 4, opacity: 0 }}
              transition={{ duration: speed * 2 }}
            />
          </motion.button>
        );

      case 2: // Fill Animation
        return (
          <motion.button
            whileHover={{ scale: 1.02 }}
            className="relative px-8 py-3 rounded-xl bg-slate-800 text-white font-semibold overflow-hidden group"
          >
            <span className="relative z-10 group-hover:text-white transition-colors">Hover to Fill</span>
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-violet-500 to-cyan-500"
              initial={{ x: "-100%" }}
              whileHover={{ x: 0 }}
              transition={{ duration: speed * 2 }}
            />
          </motion.button>
        );

      case 3: // 3D Press
        return (
          <motion.button
            whileHover={{ y: -2 }}
            whileTap={{ y: 2, boxShadow: "0 0 0 rgba(0,0,0,0)" }}
            className="px-8 py-3 rounded-xl bg-gradient-to-b from-violet-500 to-violet-700 text-white font-semibold shadow-[0_8px_20px_rgba(139,92,246,0.5)]"
            transition={{ type: "spring", stiffness: 400, damping: 10 }}
          >
            Press Me
          </motion.button>
        );

      case 4: // Shake
        return (
          <motion.button
            whileHover={{ x: [-5 * intensity, 5 * intensity, -5 * intensity, 5 * intensity, 0] }}
            transition={{ duration: speed }}
            className="px-8 py-3 rounded-xl bg-red-500 text-white font-semibold"
          >
            Shake Effect
          </motion.button>
        );

      case 5: // Loading State
        return (
          <motion.button
            animate={{ opacity: [1, 0.7, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="px-8 py-3 rounded-xl bg-blue-500 text-white font-semibold flex items-center gap-2 cursor-wait"
            disabled
          >
            <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
            Loading...
          </motion.button>
        );

      case 6: // Like Button
        return (
          <motion.button
            onClick={() => setIsLiked(!isLiked)}
            whileTap={{ scale: 0.9 }}
            className={`px-8 py-3 rounded-xl font-semibold flex items-center gap-2 transition-colors ${isLiked ? "bg-red-500 text-white" : "bg-slate-700 text-white"}`}
          >
            <motion.div animate={isLiked ? { scale: [1, 1.3, 1] } : {}} transition={{ duration: 0.3 }}>
              <Heart className={`w-5 h-5 ${isLiked ? "fill-white" : ""}`} />
            </motion.div>
            {isLiked ? "Liked!" : "Like"}
          </motion.button>
        );

      case 7: // Add to Cart
        return (
          <motion.button
            onClick={() => { setIsAdded(true); setTimeout(() => setIsAdded(false), 2000); }}
            whileTap={{ scale: 0.95 }}
            className={`px-8 py-3 rounded-xl font-semibold flex items-center gap-2 transition-all ${isAdded ? "bg-green-500" : "bg-violet-600"} text-white`}
          >
            <motion.div animate={isAdded ? { rotate: 360 } : {}} transition={{ duration: 0.5 }}>
              {isAdded ? <Check className="w-5 h-5" /> : <ShoppingCart className="w-5 h-5" />}
            </motion.div>
            {isAdded ? "Added!" : "Add to Cart"}
          </motion.button>
        );

      case 8: // Download Progress
        return (
          <div className="space-y-2 w-full max-w-xs">
            <button
              onClick={handleDownload}
              className="w-full px-8 py-3 rounded-xl bg-cyan-600 text-white font-semibold hover:bg-cyan-700 transition-colors"
              disabled={progress > 0 && progress < 100}
            >
              {progress === 0 ? "Download" : progress === 100 ? "✓ Complete!" : `${progress}%`}
            </button>
            {progress > 0 && progress < 100 && (
              <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-cyan-500 to-blue-500"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.2 }}
                />
              </div>
            )}
          </div>
        );

      case 9: // Magnetic Follow
        return (
          <motion.button
            onMouseMove={handleMouseMove}
            animate={{ x: mousePos.x * 0.15 * intensity, y: mousePos.y * 0.15 * intensity }}
            transition={{ type: "spring", stiffness: 150, damping: 15, duration: speed }}
            className="px-8 py-3 rounded-xl bg-gradient-to-r from-pink-500 to-violet-600 text-white font-semibold"
          >
            Magnetic Button
          </motion.button>
        );

      case 10: // Border Animation
        return (
          <div className="relative">
            <motion.div
              animate={{ backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] }}
              transition={{ duration: 3 / speed, repeat: Infinity }}
              className="absolute -inset-[2px] rounded-xl bg-gradient-to-r from-violet-500 via-cyan-500 to-violet-500"
              style={{ backgroundSize: "200% 100%" }}
            />
            <button className="relative px-8 py-3 rounded-xl bg-slate-900 text-white font-semibold">
              Animated Border
            </button>
          </div>
        );

      case 11: // Glow
        return (
          <motion.button
            whileHover={{
              boxShadow: `0 0 ${20 * intensity}px rgba(139, 92, 246, ${0.8 * intensity})`
            }}
            transition={{ duration: speed }}
            className="px-8 py-3 rounded-xl bg-violet-500 text-white font-semibold"
          >
            Glow Effect
          </motion.button>
        );

      case 12: // Neon Glow
        return (
          <motion.button
            whileHover={{
              textShadow: `0 0 ${10 * intensity}px #8b5cf6, 0 0 ${20 * intensity}px #8b5cf6`,
              boxShadow: `0 0 ${30 * intensity}px rgba(139,92,246,0.6), inset 0 0 ${20 * intensity}px rgba(139,92,246,0.3)`
            }}
            transition={{ duration: speed }}
            className="px-8 py-3 rounded-xl bg-slate-900 border-2 border-violet-500 text-white font-semibold"
          >
            Neon Glow
          </motion.button>
        );

      case 13: // Liquid Fill
        return (
          <button className="relative px-8 py-3 rounded-xl bg-slate-800 text-white font-semibold overflow-hidden group">
            <span className="relative z-10">Liquid Fill</span>
            <motion.div
              className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-cyan-500 to-violet-500"
              initial={{ height: "0%" }}
              whileHover={{ height: "100%" }}
              transition={{ duration: speed * 2 }}
            />
          </button>
        );

      case 14: // Gradient Border
        return (
          <div className="relative">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              className="absolute -inset-1 rounded-xl bg-gradient-to-r from-violet-500 via-cyan-500 to-pink-500 opacity-75 blur-sm"
            />
            <button className="relative px-8 py-3 rounded-xl bg-slate-900 text-white font-semibold">
              Rotating Border
            </button>
          </div>
        );

      case 15: // Pulse Ring
        return (
          <div className="relative flex items-center justify-center">
            {[0, 1, 2].map(i => (
              <motion.div
                key={i}
                animate={{ scale: [1, 2 * intensity], opacity: [0.5, 0] }}
                transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.5 }}
                className="absolute w-24 h-12 rounded-xl bg-violet-500"
              />
            ))}
            <button className="relative px-8 py-3 rounded-xl bg-violet-600 text-white font-semibold z-10">
              Pulse Ring
            </button>
          </div>
        );

      case 16: // Confetti
        return (
          <button
            onClick={() => {
              const colors = ['#8b5cf6', '#06b6d4', '#ec4899', '#f59e0b'];
              const confetti = Array.from({ length: 30 }).map((_, i) => ({
                id: i,
                x: Math.random() * 100,
                y: -10,
                color: colors[Math.floor(Math.random() * colors.length)]
              }));
            }}
            className="px-8 py-3 rounded-xl bg-gradient-to-r from-pink-500 to-yellow-500 text-white font-semibold"
          >
            🎉 Confetti
          </button>
        );

      case 17: // Glitch
        return (
          <motion.button
            whileHover={{
              textShadow: [
                "none",
                "-2px 0 #ff00ff, 2px 0 #00ffff",
                "2px 0 #ff00ff, -2px 0 #00ffff",
                "-1px 0 #00ffff, 1px 0 #ff00ff",
                "none"
              ]
            }}
            transition={{ duration: 0.3 * speed, repeat: 5 }}
            className="px-8 py-3 rounded-xl bg-slate-900 border border-cyan-500 text-white font-semibold"
          >
            Glitch Effect
          </motion.button>
        );

      case 18: // Morphing Shape
        return (
          <motion.button
            whileHover={{ borderRadius: ["12px", "24px", "12px", "24px", "12px"] }}
            transition={{ duration: speed * 3, repeat: Infinity }}
            className="px-8 py-3 bg-gradient-to-r from-violet-500 to-pink-500 text-white font-semibold"
          >
            Morphing
          </motion.button>
        );

      case 19: // Spotlight
        return (
          <motion.button
            whileHover={{ scale: 1.05 }}
            className="relative px-8 py-3 rounded-xl bg-slate-900 text-white font-semibold overflow-hidden group"
          >
            <span className="relative z-10">Spotlight</span>
            <motion.div
              className="absolute w-full h-full rounded-full bg-gradient-radial from-white/20 to-transparent blur-xl"
              initial={{ scale: 0, opacity: 0, x: "-50%", y: "-50%", left: "50%", top: "50%" }}
              whileHover={{ scale: 3 * intensity, opacity: 1 }}
              transition={{ duration: speed }}
              style={{ position: "absolute" }}
            />
          </motion.button>
        );

      case 20: // Elastic Bounce
        return (
          <motion.button
            whileHover={{ scale: [1, 1.2 * intensity, 0.95, 1.1, 1] }}
            transition={{ duration: speed * 2, type: "spring", stiffness: 300 }}
            className="px-8 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-semibold"
          >
            Elastic Bounce
          </motion.button>
        );

      default:
        return (
          <button className="px-8 py-3 rounded-xl bg-slate-700 text-white font-semibold">
            {effect.name}
          </button>
        );
    }
  };

  return (
    <div className="flex items-center justify-center min-h-[160px] bg-slate-950 rounded-xl border border-slate-800 p-6" data-tour="preview-area">
      {getButtonContent()}
    </div>
  );
}

export default function ButtonShowcase() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState("all");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedEffect, setSelectedEffect] = useState(buttonEffects[0]);
  const [speed, setSpeed] = useState(0.3);
  const [intensity, setIntensity] = useState(1);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedPrompt, setCopiedPrompt] = useState(false);

  const { shouldShowTour } = useTour("buttonGallery");

  const filteredEffects = buttonEffects.filter((effect) => {
    const matchesSearch = effect.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === "all" || effect.type === selectedType;
    const matchesCategory = selectedCategory === "all" || effect.category === selectedCategory;
    return matchesSearch && matchesType && matchesCategory;
  });

  const copyCode = async () => {
    await navigator.clipboard.writeText(selectedEffect.code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const copyPrompt = async () => {
    const prompt = `Create a ${selectedEffect.name} button effect in React using Framer Motion. The effect should be ${selectedEffect.category} and use ${selectedEffect.type} animation type. Make it smooth with adjustable speed and intensity parameters. Here's a reference:\n\n${selectedEffect.code}`;
    await navigator.clipboard.writeText(prompt);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2000);
  };

  return (
    <div className="min-h-screen">
      {shouldShowTour && <OnboardingTour tourId="buttonGallery" />}
      
      <CategoryHeader
        icon={MousePointerClick}
        title="Button Effect Showcase"
        description="Interactive gallery with live previews and adjustable parameters"
        gradient="#8b5cf6, #06b6d4"
      />

      <div className="max-w-7xl mx-auto px-4 pb-20">
        {/* Filters */}
        <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div>
              <Label className="text-slate-400 text-sm mb-2">Search Effects</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by name..."
                  className="pl-10 bg-slate-800 border-slate-700 text-white"
                />
              </div>
            </div>

            <div>
              <Label className="text-slate-400 text-sm mb-2">Animation Type</Label>
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {animationTypes.map((type) => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-slate-400 text-sm mb-2">Category</Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-400">
              Showing <span className="text-white font-semibold">{filteredEffects.length}</span> of {buttonEffects.length} effects
            </span>
            {(searchQuery || selectedType !== "all" || selectedCategory !== "all") && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setSearchQuery("");
                  setSelectedType("all");
                  setSelectedCategory("all");
                }}
              >
                <X className="w-3 h-3 mr-1" /> Clear Filters
              </Button>
            )}
          </div>
        </div>

        {/* Effect Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Effect List */}
          <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4" data-tour="effect-list">
            {filteredEffects.map((effect) => (
              <motion.div
                key={effect.id}
                onClick={() => setSelectedEffect(effect)}
                whileHover={{ y: -4 }}
                className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                  selectedEffect?.id === effect.id
                    ? "bg-violet-500/10 border-violet-500 shadow-lg shadow-violet-500/20"
                    : "bg-slate-900/50 border-slate-800 hover:border-slate-700"
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-white font-semibold">{effect.name}</h3>
                  {selectedEffect?.id === effect.id && <Check className="w-5 h-5 text-violet-400" />}
                </div>
                <div className="flex gap-2 text-xs">
                  <span className="px-2 py-0.5 rounded bg-violet-500/20 text-violet-400">{effect.type}</span>
                  <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-400">{effect.category}</span>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Live Preview & Controls */}
          <div className="lg:sticky lg:top-24 h-fit">
            <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 space-y-6">
              <div>
                <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
                  <MousePointerClick className="w-4 h-4" />
                  Live Preview
                </h3>
                <p className="text-slate-400 text-sm mb-4">
                  {selectedEffect ? `Previewing: ${selectedEffect.name}` : "Select an effect"}
                </p>
              </div>

              {selectedEffect && (
                <>
                  <InteractiveButtonDemo
                    effect={selectedEffect}
                    speed={speed}
                    intensity={intensity}
                  />

                  {/* Controls */}
                  <div className="space-y-4 pt-4 border-t border-slate-800" data-tour="controls">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label className="text-slate-400 text-sm">Speed</Label>
                        <span className="text-white text-sm font-mono">{speed.toFixed(1)}s</span>
                      </div>
                      <input
                        type="range"
                        min="0.1"
                        max="1"
                        step="0.1"
                        value={speed}
                        onChange={(e) => setSpeed(Number(e.target.value))}
                        className="w-full accent-violet-500"
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label className="text-slate-400 text-sm">Intensity</Label>
                        <span className="text-white text-sm font-mono">{intensity.toFixed(1)}x</span>
                      </div>
                      <input
                        type="range"
                        min="0.5"
                        max="2"
                        step="0.1"
                        value={intensity}
                        onChange={(e) => setIntensity(Number(e.target.value))}
                        className="w-full accent-violet-500"
                      />
                    </div>
                  </div>

                  {/* Export Actions */}
                  <div className="grid grid-cols-2 gap-3 pt-4 border-t border-slate-800" data-tour="export-buttons">
                    <motion.button
                      onClick={copyPrompt}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className="relative px-4 py-2 rounded-lg font-semibold overflow-hidden group border-2 border-purple-500"
                    >
                      <div className="absolute inset-0 bg-purple-500/20" />
                      <div className="absolute inset-0 bg-purple-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                      <span className="relative z-10 text-purple-400 group-hover:text-white flex items-center justify-center gap-2 text-sm">
                        {copiedPrompt ? (
                          <><Check className="w-4 h-4" /> Copied!</>
                        ) : (
                          <><Wand2 className="w-4 h-4" /> Copy Prompt</>
                        )}
                      </span>
                    </motion.button>
                    <motion.button
                      onClick={copyCode}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className="relative px-4 py-2 rounded-lg font-semibold overflow-hidden group"
                    >
                      <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-blue-500" />
                      <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-cyan-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                      <span className="relative z-10 text-white flex items-center justify-center gap-2 text-sm">
                        {copiedCode ? (
                          <><Check className="w-4 h-4" /> Copied!</>
                        ) : (
                          <><Copy className="w-4 h-4" /> Copy Code</>
                        )}
                      </span>
                    </motion.button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}