import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, Search, Trash2, Copy, Check, Wand2, ArrowRight, ExternalLink } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import SearchFilter from "@/components/effects/SearchFilter";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import DynamicEffectPreview from "@/components/effects/DynamicEffectPreview";
import { useQuery } from "@tanstack/react-query";

// Add glitch hover effect
const glitchStyles = `
  .glitch-hover-btn:hover {
    animation: btn-glitch 0.3s ease-in-out;
  }
  @keyframes btn-glitch {
    0%, 100% { transform: translate(0); }
    10% { transform: translate(-1px, 1px); }
    20% { transform: translate(1px, -1px); }
    30% { transform: translate(-1px, 0); }
    40% { transform: translate(1px, 1px); }
    50% { transform: translate(0, -1px); }
  }
`;

export default function Favorites() {
  const [favorites, setFavorites] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [copiedCode, setCopiedCode] = useState({});
  const [copiedPrompt, setCopiedPrompt] = useState({});
  const [codeProgress, setCodeProgress] = useState({});
  const [promptProgress, setPromptProgress] = useState({});
  const [hoveredCard, setHoveredCard] = useState(null);

  useEffect(() => {
    const loadFavorites = async () => {
      try {
        const user = await base44.auth.me().catch(() => null);
        if (user) {
          // Load from DB if logged in
          const dbFavorites = await base44.entities.SavedEffect.list();
          setFavorites(dbFavorites);
        } else {
          // Load from localStorage if not logged in
          const saved = JSON.parse(localStorage.getItem('savedEffects') || '[]');
          setFavorites(saved);
        }
      } catch (err) {
        console.error("Error loading favorites:", err);
        // Fallback to local
        const saved = JSON.parse(localStorage.getItem('savedEffects') || '[]');
        setFavorites(saved);
      }
    };

    loadFavorites();
    
    // Listen for updates from other components
    window.addEventListener('favoritesUpdated', loadFavorites);
    // Refresh interval to catch any missed updates or propagation delays
    const interval = setInterval(loadFavorites, 5000);
    return () => {
      window.removeEventListener('favoritesUpdated', loadFavorites);
      clearInterval(interval);
    };
  }, []);

  const removeFavorite = async (id) => {
    try {
      const user = await base44.auth.me().catch(() => null);
      if (user) {
        await base44.entities.SavedEffect.delete(id);
        // Refresh list
        const dbFavorites = await base44.entities.SavedEffect.list();
        setFavorites(dbFavorites);
      } else {
        const newFavorites = favorites.filter(f => f.id !== id);
        setFavorites(newFavorites);
        localStorage.setItem('savedEffects', JSON.stringify(newFavorites));
      }
      // Dispatch event to update EffectCards
      window.dispatchEvent(new Event('favoritesUpdated'));
    } catch (err) {
      console.error("Error removing favorite:", err);
    }
  };

  const handleCopyCode = async (id, code) => {
    setCodeProgress(prev => ({ ...prev, [id]: 0 }));
    const interval = setInterval(() => {
      setCodeProgress(prev => {
        const current = prev[id] || 0;
        if (current >= 100) {
          clearInterval(interval);
          return { ...prev, [id]: 100 };
        }
        return { ...prev, [id]: current + 10 };
      });
    }, 30);
    await navigator.clipboard.writeText(code);
    setTimeout(() => {
      setCopiedCode(prev => ({ ...prev, [id]: true }));
      setTimeout(() => { 
        setCopiedCode(prev => ({ ...prev, [id]: false })); 
        setCodeProgress(prev => ({ ...prev, [id]: 0 }));
      }, 2000);
    }, 300);
  };

  const handleCopyPrompt = async (id, prompt) => {
    setPromptProgress(prev => ({ ...prev, [id]: 0 }));
    const interval = setInterval(() => {
      setPromptProgress(prev => {
        const current = prev[id] || 0;
        if (current >= 100) {
          clearInterval(interval);
          return { ...prev, [id]: 100 };
        }
        return { ...prev, [id]: current + 10 };
      });
    }, 30);
    await navigator.clipboard.writeText(prompt);
    setTimeout(() => {
      setCopiedPrompt(prev => ({ ...prev, [id]: true }));
      setTimeout(() => { 
        setCopiedPrompt(prev => ({ ...prev, [id]: false })); 
        setPromptProgress(prev => ({ ...prev, [id]: 0 }));
      }, 2000);
    }, 300);
  };

  const filteredFavorites = favorites.filter(effect => {
    const matchesSearch = (effect.name || "").toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (effect.description || "").toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSearch;
  });

  return (
    <div className="min-h-screen">
      <style>{glitchStyles}</style>
      <CategoryHeader 
        icon={Heart} 
        title="Your Favorites" 
        description="Collection of your saved effects and components" 
        gradient="#8b5cf6, #06b6d4" 
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <SearchFilter 
          searchQuery={searchQuery} 
          setSearchQuery={setSearchQuery} 
          activeCategory={activeCategory} 
          setActiveCategory={setActiveCategory} 
          resultCount={filteredFavorites.length} 
        />

        {filteredFavorites.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20 bg-slate-900/50 rounded-2xl border border-slate-800"
          >
            <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-6">
              <Heart className="w-10 h-10 text-slate-600" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">No favorites yet</h3>
            <p className="text-slate-400 mb-8 max-w-md mx-auto">
              Browse the effects library and click the heart icon to save your favorite components here.
            </p>
            <Link to={createPageUrl("Explore")}>
              <Button className="bg-violet-600 hover:bg-violet-700">
                Explore Effects <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
              {filteredFavorites.map((effect) => (
                <motion.div
                  key={effect.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="bg-slate-900/50 border border-slate-800 rounded-xl overflow-hidden group hover:border-violet-500/50 transition-all"
                >
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="text-lg font-bold text-white">{effect.name}</h3>
                          {effect.sourcePage && (
                            <Link 
                              to={`${createPageUrl(effect.sourcePage)}#${effect.anchor || effect.name.toLowerCase().replace(/\s+/g, '-')}`}
                              className="flex items-center gap-1 px-2 py-1 rounded-md bg-violet-500/20 text-violet-400 hover:bg-violet-500/30 transition-colors text-xs font-medium group/link"
                            >
                              <span>{effect.sourcePage}</span>
                              <ExternalLink className="w-3 h-3 group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5 transition-transform" />
                            </Link>
                          )}
                        </div>
                        <p className="text-sm text-slate-400 line-clamp-2">{effect.description}</p>
                      </div>
                      <button 
                        onClick={() => removeFavorite(effect.id)}
                        className="p-2 rounded-lg hover:bg-red-500/10 text-slate-400 hover:text-red-500 transition-colors flex-shrink-0"
                        title="Remove from favorites"
                      >
                        <Heart className="w-5 h-5 fill-current text-red-500" />
                      </button>
                    </div>

                    {/* Interactive Preview / Screenshot */}
                    <div 
                      className="relative bg-slate-950 rounded-lg border border-slate-800 mb-4 min-h-[200px] overflow-hidden group/preview cursor-pointer"
                      onMouseEnter={() => setHoveredCard(effect.id)}
                      onMouseLeave={() => setHoveredCard(null)}
                    >
                      {effect.screenshot ? (
                        <>
                          <img 
                            src={effect.screenshot} 
                            alt={effect.name} 
                            className="w-full h-full object-cover"
                          />
                          {hoveredCard === effect.id && (
                            <Link 
                              to={`${createPageUrl(effect.sourcePage)}#${effect.anchor}`}
                              className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center gap-3 transition-all"
                            >
                              <ExternalLink className="w-8 h-8 text-violet-400" />
                              <span className="text-white font-medium">View Original Effect</span>
                              <span className="text-xs text-slate-400">on {effect.sourcePage} page</span>
                            </Link>
                          )}
                        </>
                      ) : (
                        <div className="flex items-center justify-center h-full">
                          <DynamicEffectPreview effectData={effect} />
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center gap-2 mb-3">
                      {/* Copy Code Button - Cyan */}
                      <motion.button
                        onClick={() => handleCopyCode(effect.id, effect.code)}
                        className="relative flex-1 h-10 rounded-lg border-2 border-cyan-500 overflow-hidden group/btn glitch-hover-btn"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <motion.div
                          className="absolute inset-0 bg-cyan-500"
                          initial={{ width: "0%" }}
                          animate={{ width: copiedCode[effect.id] ? "100%" : `${codeProgress[effect.id] || 0}%` }}
                          transition={{ duration: 0.1 }}
                        />
                        <span className={`relative z-10 flex items-center justify-center gap-1 text-xs font-medium transition-colors ${copiedCode[effect.id] || (codeProgress[effect.id] || 0) > 50 ? "text-slate-900" : "text-cyan-400"}`}>
                          {copiedCode[effect.id] ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                          {copiedCode[effect.id] ? "Copied!" : "Copy Code"}
                        </span>
                      </motion.button>

                      {/* Copy Prompt Button - Purple */}
                      <motion.button
                        onClick={() => handleCopyPrompt(effect.id, effect.prompt)}
                        className="relative flex-1 h-10 rounded-lg border-2 border-purple-500 overflow-hidden group/btn glitch-hover-btn"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <motion.div
                          className="absolute inset-0 bg-purple-500"
                          initial={{ width: "0%" }}
                          animate={{ width: copiedPrompt[effect.id] ? "100%" : `${promptProgress[effect.id] || 0}%` }}
                          transition={{ duration: 0.1 }}
                        />
                        <span className={`relative z-10 flex items-center justify-center gap-1 text-xs font-medium transition-colors ${copiedPrompt[effect.id] || (promptProgress[effect.id] || 0) > 50 ? "text-slate-900" : "text-purple-400"}`}>
                          {copiedPrompt[effect.id] ? <Check className="w-3 h-3" /> : <Wand2 className="w-3 h-3" />}
                          {copiedPrompt[effect.id] ? "Copied!" : "Copy Prompt"}
                        </span>
                      </motion.button>
                    </div>

                    {/* Saved Date */}
                    <div className="text-xs text-slate-500 text-center">
                      Saved {new Date(effect.savedAt).toLocaleDateString()}
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}