import React, { useState } from "react";
import { motion } from "framer-motion";
import { Layout, Search, Menu, User, Bell, Home, Settings, BarChart3, ShoppingBag, Mail, Grid, Briefcase, Image } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// Dashboard Layout
function DashboardLayout() {
  return (
    <EffectCard title="Dashboard Layout" description="Admin panel with sidebar navigation" whenToUse="Analytics dashboards, admin panels, SaaS applications, CRM systems.">
      <div className="w-full h-[280px] bg-slate-900 rounded-lg overflow-hidden flex text-xs">
        {/* Sidebar */}
        <div className="w-14 bg-slate-800 p-2 flex flex-col gap-2">
          <div className="w-8 h-8 bg-violet-500 rounded-lg mx-auto mb-4" />
          {[Home, BarChart3, User, Settings].map((Icon, i) => (
            <div key={i} className={`p-2 rounded-lg ${i === 0 ? "bg-violet-500/20 text-violet-400" : "text-slate-500 hover:bg-slate-700"}`}>
              <Icon className="w-4 h-4 mx-auto" />
            </div>
          ))}
        </div>
        {/* Main Content */}
        <div className="flex-1 p-3">
          {/* Header */}
          <div className="flex items-center justify-between mb-3">
            <span className="font-medium text-white">Dashboard</span>
            <div className="flex gap-2">
              <div className="w-6 h-6 rounded-full bg-slate-700" />
              <div className="w-6 h-6 rounded-full bg-slate-700" />
            </div>
          </div>
          {/* Stats */}
          <div className="grid grid-cols-3 gap-2 mb-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="p-2 rounded-lg bg-slate-800">
                <div className="h-2 w-8 bg-slate-600 rounded mb-1" />
                <div className="h-4 w-12 bg-violet-500/30 rounded" />
              </div>
            ))}
          </div>
          {/* Chart Area */}
          <div className="h-24 rounded-lg bg-slate-800 p-2">
            <div className="flex items-end gap-1 h-full">
              {[40, 65, 45, 80, 55, 70, 90, 60].map((h, i) => (
                <div key={i} className="flex-1 bg-violet-500/50 rounded-t" style={{ height: `${h}%` }} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Landing Page Layout
function LandingPageLayout() {
  return (
    <EffectCard title="Landing Page" description="Hero section with feature grid" whenToUse="Product launches, marketing pages, startup websites, app showcases.">
      <div className="w-full h-[280px] bg-slate-900 rounded-lg overflow-hidden text-xs">
        {/* Nav */}
        <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800">
          <div className="w-16 h-4 bg-gradient-to-r from-violet-500 to-cyan-500 rounded" />
          <div className="flex gap-3">
            {[1, 2, 3].map(i => <div key={i} className="w-10 h-2 bg-slate-700 rounded" />)}
          </div>
          <div className="w-12 h-5 bg-violet-500 rounded text-white text-[10px] flex items-center justify-center">Sign Up</div>
        </div>
        {/* Hero */}
        <div className="text-center py-6 px-4">
          <div className="h-3 w-32 bg-white/80 rounded mx-auto mb-2" />
          <div className="h-2 w-48 bg-slate-600 rounded mx-auto mb-4" />
          <div className="flex gap-2 justify-center">
            <div className="w-16 h-5 bg-violet-500 rounded" />
            <div className="w-16 h-5 bg-slate-700 rounded" />
          </div>
        </div>
        {/* Features */}
        <div className="grid grid-cols-3 gap-2 px-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="p-2 rounded-lg bg-slate-800 text-center">
              <div className="w-6 h-6 rounded-full bg-violet-500/20 mx-auto mb-1" />
              <div className="h-2 w-12 bg-slate-600 rounded mx-auto" />
            </div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Portfolio Layout
function PortfolioLayout() {
  return (
    <EffectCard title="Portfolio Grid" description="Masonry-style project showcase" whenToUse="Creative portfolios, photography sites, design showcases, galleries.">
      <div className="w-full h-[280px] bg-slate-900 rounded-lg overflow-hidden p-3 text-xs">
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-gradient-to-br from-pink-500 to-violet-500" />
            <span className="text-white font-medium">Portfolio</span>
          </div>
          <Menu className="w-4 h-4 text-slate-500" />
        </div>
        {/* Grid */}
        <div className="grid grid-cols-3 gap-2 h-48">
          <div className="row-span-2 rounded-lg bg-gradient-to-br from-violet-500/30 to-pink-500/30" />
          <div className="rounded-lg bg-gradient-to-br from-cyan-500/30 to-blue-500/30" />
          <div className="rounded-lg bg-gradient-to-br from-amber-500/30 to-orange-500/30" />
          <div className="col-span-2 rounded-lg bg-gradient-to-br from-emerald-500/30 to-teal-500/30" />
        </div>
      </div>
    </EffectCard>
  );
}

// E-commerce Grid
function EcommerceGridLayout() {
  return (
    <EffectCard title="E-commerce Grid" description="Product listing with filters" whenToUse="Online stores, marketplaces, product catalogs, shopping apps.">
      <div className="w-full h-[280px] bg-slate-900 rounded-lg overflow-hidden text-xs">
        {/* Header */}
        <div className="flex items-center justify-between px-3 py-2 border-b border-slate-800">
          <span className="text-white font-medium">Shop</span>
          <div className="flex gap-2">
            <Search className="w-4 h-4 text-slate-500" />
            <ShoppingBag className="w-4 h-4 text-slate-500" />
          </div>
        </div>
        {/* Filters */}
        <div className="flex gap-2 px-3 py-2 border-b border-slate-800">
          {["All", "New", "Sale"].map((f, i) => (
            <span key={f} className={`px-2 py-0.5 rounded-full ${i === 0 ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400"}`}>{f}</span>
          ))}
        </div>
        {/* Products */}
        <div className="grid grid-cols-2 gap-2 p-3">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="rounded-lg bg-slate-800 p-2">
              <div className="h-12 rounded bg-slate-700 mb-2" />
              <div className="h-2 w-16 bg-slate-600 rounded mb-1" />
              <div className="h-2 w-8 bg-violet-500/50 rounded" />
            </div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Blog Layout
function BlogLayout() {
  return (
    <EffectCard title="Blog Layout" description="Article list with sidebar" whenToUse="News sites, personal blogs, content platforms, documentation.">
      <div className="w-full h-[280px] bg-slate-900 rounded-lg overflow-hidden flex text-xs">
        {/* Main */}
        <div className="flex-1 p-3">
          {/* Featured */}
          <div className="h-20 rounded-lg bg-gradient-to-r from-violet-500/20 to-cyan-500/20 mb-3 p-2">
            <div className="h-2 w-24 bg-white/80 rounded mb-1" />
            <div className="h-2 w-32 bg-slate-600 rounded" />
          </div>
          {/* Articles */}
          {[1, 2].map(i => (
            <div key={i} className="flex gap-2 mb-2">
              <div className="w-12 h-12 rounded bg-slate-800 flex-shrink-0" />
              <div className="flex-1">
                <div className="h-2 w-full bg-slate-700 rounded mb-1" />
                <div className="h-2 w-2/3 bg-slate-800 rounded" />
              </div>
            </div>
          ))}
        </div>
        {/* Sidebar */}
        <div className="w-24 bg-slate-800 p-2">
          <div className="h-2 w-12 bg-slate-600 rounded mb-2" />
          {[1, 2, 3].map(i => (
            <div key={i} className="h-2 w-full bg-slate-700 rounded mb-1" />
          ))}
          <div className="mt-4 h-2 w-12 bg-slate-600 rounded mb-2" />
          <div className="flex flex-wrap gap-1">
            {[1, 2, 3, 4].map(i => (
              <span key={i} className="px-1 py-0.5 rounded bg-violet-500/20 text-violet-400 text-[8px]">tag</span>
            ))}
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Settings Page
function SettingsLayout() {
  return (
    <EffectCard title="Settings Page" description="Tabbed settings with form sections" whenToUse="User preferences, account settings, app configuration, profile pages.">
      <div className="w-full h-[280px] bg-slate-900 rounded-lg overflow-hidden text-xs p-3">
        {/* Header */}
        <div className="flex items-center gap-2 mb-3">
          <Settings className="w-4 h-4 text-violet-400" />
          <span className="text-white font-medium">Settings</span>
        </div>
        {/* Tabs */}
        <div className="flex gap-2 mb-3 border-b border-slate-800 pb-2">
          {["Profile", "Security", "Billing"].map((t, i) => (
            <span key={t} className={`px-2 py-1 rounded ${i === 0 ? "bg-violet-500/20 text-violet-400" : "text-slate-500"}`}>{t}</span>
          ))}
        </div>
        {/* Form */}
        <div className="space-y-3">
          {["Name", "Email", "Bio"].map(field => (
            <div key={field}>
              <div className="h-2 w-12 bg-slate-700 rounded mb-1" />
              <div className="h-6 w-full bg-slate-800 rounded" />
            </div>
          ))}
          <div className="flex gap-2 mt-4">
            <div className="h-6 w-16 bg-violet-500 rounded" />
            <div className="h-6 w-16 bg-slate-700 rounded" />
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Pricing Page
function PricingLayout() {
  return (
    <EffectCard title="Pricing Page" description="Tiered pricing cards comparison" whenToUse="SaaS pricing, subscription plans, membership tiers, feature comparison.">
      <div className="w-full h-[280px] bg-slate-900 rounded-lg overflow-hidden p-3 text-xs">
        {/* Header */}
        <div className="text-center mb-3">
          <div className="h-3 w-24 bg-white/80 rounded mx-auto mb-1" />
          <div className="h-2 w-40 bg-slate-600 rounded mx-auto" />
        </div>
        {/* Cards */}
        <div className="grid grid-cols-3 gap-2">
          {[
            { name: "Basic", price: "$9", highlight: false },
            { name: "Pro", price: "$29", highlight: true },
            { name: "Team", price: "$99", highlight: false }
          ].map(plan => (
            <div key={plan.name} className={`p-2 rounded-lg ${plan.highlight ? "bg-violet-500/20 border border-violet-500/50" : "bg-slate-800"}`}>
              <div className="text-slate-400 mb-1">{plan.name}</div>
              <div className={`text-lg font-bold mb-2 ${plan.highlight ? "text-violet-400" : "text-white"}`}>{plan.price}</div>
              {[1, 2, 3].map(i => (
                <div key={i} className="h-1.5 w-full bg-slate-700/50 rounded mb-1" />
              ))}
              <div className={`h-5 w-full rounded mt-2 ${plan.highlight ? "bg-violet-500" : "bg-slate-700"}`} />
            </div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Email/Inbox Layout
function InboxLayout() {
  return (
    <EffectCard title="Inbox Layout" description="Three-column email interface" whenToUse="Email clients, messaging apps, notification centers, CRM inbox.">
      <div className="w-full h-[280px] bg-slate-900 rounded-lg overflow-hidden flex text-xs">
        {/* Folders */}
        <div className="w-12 bg-slate-800 p-2">
          {[Mail, Bell, User].map((Icon, i) => (
            <div key={i} className={`p-2 rounded-lg mb-1 ${i === 0 ? "bg-violet-500/20 text-violet-400" : "text-slate-500"}`}>
              <Icon className="w-3 h-3 mx-auto" />
            </div>
          ))}
        </div>
        {/* List */}
        <div className="w-28 border-r border-slate-800 p-2">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className={`p-2 rounded mb-1 ${i === 1 ? "bg-violet-500/10" : ""}`}>
              <div className="h-2 w-16 bg-slate-600 rounded mb-1" />
              <div className="h-1.5 w-20 bg-slate-700 rounded" />
            </div>
          ))}
        </div>
        {/* Content */}
        <div className="flex-1 p-3">
          <div className="h-3 w-32 bg-white/80 rounded mb-2" />
          <div className="h-2 w-20 bg-slate-600 rounded mb-4" />
          <div className="space-y-1">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="h-2 w-full bg-slate-800 rounded" />
            ))}
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Social Feed
function SocialFeedLayout() {
  return (
    <EffectCard title="Social Feed" description="Card-based content feed" whenToUse="Social networks, community platforms, news feeds, activity streams.">
      <div className="w-full h-[280px] bg-slate-900 rounded-lg overflow-hidden p-3 text-xs">
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-gradient-to-br from-pink-500 to-violet-500" />
            <div>
              <div className="h-2 w-16 bg-white/80 rounded" />
              <div className="h-1.5 w-12 bg-slate-600 rounded mt-0.5" />
            </div>
          </div>
          <div className="text-slate-500">• • •</div>
        </div>
        {/* Image */}
        <div className="h-24 rounded-lg bg-gradient-to-br from-violet-500/20 to-cyan-500/20 mb-2" />
        {/* Actions */}
        <div className="flex gap-4 mb-2 text-slate-500">
          <span>♡ 128</span>
          <span>💬 24</span>
          <span>↗ 12</span>
        </div>
        <div className="h-2 w-full bg-slate-800 rounded mb-1" />
        <div className="h-2 w-2/3 bg-slate-800 rounded" />
      </div>
    </EffectCard>
  );
}

// Calendar Layout
function CalendarLayout() {
  return (
    <EffectCard title="Calendar View" description="Monthly calendar with events" whenToUse="Scheduling apps, booking systems, event planners, project timelines.">
      <div className="w-full h-[280px] bg-slate-900 rounded-lg overflow-hidden p-3 text-xs">
        {/* Header */}
        <div className="flex items-center justify-between mb-2">
          <span className="text-white font-medium">December 2024</span>
          <div className="flex gap-1">
            <span className="px-2 py-0.5 rounded bg-slate-800">‹</span>
            <span className="px-2 py-0.5 rounded bg-slate-800">›</span>
          </div>
        </div>
        {/* Days */}
        <div className="grid grid-cols-7 gap-0.5 text-center text-slate-500 mb-1">
          {["S", "M", "T", "W", "T", "F", "S"].map((d, i) => <span key={i}>{d}</span>)}
        </div>
        {/* Dates */}
        <div className="grid grid-cols-7 gap-0.5">
          {[...Array(35)].map((_, i) => {
            const day = i - 2;
            const isToday = day === 15;
            const hasEvent = [5, 12, 20, 25].includes(day);
            return (
              <div key={i} className={`h-6 rounded flex items-center justify-center ${isToday ? "bg-violet-500 text-white" : day > 0 && day <= 31 ? "text-slate-400 hover:bg-slate-800" : "text-slate-700"}`}>
                {day > 0 && day <= 31 && (
                  <div className="relative">
                    {day}
                    {hasEvent && <div className="absolute -bottom-1 left-1/2 w-1 h-1 rounded-full bg-cyan-400" />}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </EffectCard>
  );
}

// Kanban Board
function KanbanLayout() {
  return (
    <EffectCard title="Kanban Board" description="Drag-and-drop task columns" whenToUse="Project management, task tracking, workflow visualization, agile boards.">
      <div className="w-full h-[280px] bg-slate-900 rounded-lg overflow-hidden p-3 text-xs">
        <div className="flex gap-2 h-full">
          {["To Do", "In Progress", "Done"].map((col, ci) => (
            <div key={col} className="flex-1 bg-slate-800/50 rounded-lg p-2">
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-300">{col}</span>
                <span className="w-4 h-4 rounded bg-slate-700 text-slate-500 flex items-center justify-center">{ci + 2}</span>
              </div>
              {[1, 2].map(i => (
                <div key={i} className="p-2 rounded bg-slate-800 mb-2">
                  <div className="h-2 w-full bg-slate-600 rounded mb-1" />
                  <div className="h-1.5 w-2/3 bg-slate-700 rounded" />
                  <div className="flex items-center justify-between mt-2">
                    <span className={`px-1 py-0.5 rounded text-[8px] ${ci === 0 ? "bg-red-500/20 text-red-400" : ci === 1 ? "bg-amber-500/20 text-amber-400" : "bg-green-500/20 text-green-400"}`}>
                      {ci === 0 ? "High" : ci === 1 ? "Med" : "Low"}
                    </span>
                    <div className="w-4 h-4 rounded-full bg-slate-700" />
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Chat/Messaging Layout
function MessagingLayout() {
  return (
    <EffectCard title="Messaging Layout" description="Chat interface with contacts" whenToUse="Chat apps, customer support, team messaging, direct messages.">
      <div className="w-full h-[280px] bg-slate-900 rounded-lg overflow-hidden flex text-xs">
        {/* Contacts */}
        <div className="w-20 border-r border-slate-800 p-2">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className={`flex items-center gap-1 p-1 rounded mb-1 ${i === 2 ? "bg-violet-500/10" : ""}`}>
              <div className="w-6 h-6 rounded-full bg-slate-700 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="h-1.5 w-10 bg-slate-600 rounded" />
              </div>
            </div>
          ))}
        </div>
        {/* Chat */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <div className="p-2 border-b border-slate-800 flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-violet-500/30" />
            <span className="text-white">Chat Name</span>
          </div>
          {/* Messages */}
          <div className="flex-1 p-2 space-y-2">
            <div className="flex gap-1">
              <div className="w-5 h-5 rounded-full bg-slate-700 flex-shrink-0" />
              <div className="px-2 py-1 rounded-lg bg-slate-800 max-w-[60%]">
                <div className="h-1.5 w-20 bg-slate-600 rounded" />
              </div>
            </div>
            <div className="flex gap-1 justify-end">
              <div className="px-2 py-1 rounded-lg bg-violet-500/30 max-w-[60%]">
                <div className="h-1.5 w-16 bg-violet-400/50 rounded" />
              </div>
            </div>
          </div>
          {/* Input */}
          <div className="p-2 border-t border-slate-800">
            <div className="h-6 bg-slate-800 rounded-full" />
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

export default function PageLayouts() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const layouts = [
    { component: <DashboardLayout />, name: "Dashboard", category: "admin" },
    { component: <LandingPageLayout />, name: "Landing Page", category: "marketing" },
    { component: <PortfolioLayout />, name: "Portfolio", category: "creative" },
    { component: <EcommerceGridLayout />, name: "E-commerce Grid", category: "ecommerce" },
    { component: <BlogLayout />, name: "Blog", category: "content" },
    { component: <SettingsLayout />, name: "Settings", category: "admin" },
    { component: <PricingLayout />, name: "Pricing", category: "marketing" },
    { component: <InboxLayout />, name: "Inbox", category: "communication" },
    { component: <SocialFeedLayout />, name: "Social Feed", category: "social" },
    { component: <CalendarLayout />, name: "Calendar", category: "productivity" },
    { component: <KanbanLayout />, name: "Kanban Board", category: "productivity" },
    { component: <MessagingLayout />, name: "Messaging", category: "communication" },
  ];

  const filtered = layouts.filter(l => 
    l.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
    (activeCategory === "all" || l.category === activeCategory)
  );

  return (
    <div className="min-h-screen">
      <CategoryHeader 
        icon={Layout} 
        title="Page Layouts" 
        description="Complete page structures for dashboards, landing pages, portfolios, and more" 
        gradient="#06b6d4, #8b5cf6" 
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <SearchFilter
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          activeCategory={activeCategory}
          setActiveCategory={setActiveCategory}
          resultCount={filtered.length}
        />

        <p className="text-slate-400 text-sm mb-8">
          Showing {filtered.length} page layouts
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((layout, i) => (
            <motion.div
              key={layout.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              {layout.component}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}