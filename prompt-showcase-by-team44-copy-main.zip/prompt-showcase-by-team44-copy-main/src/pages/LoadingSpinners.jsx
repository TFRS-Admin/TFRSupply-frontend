import React, { useState } from "react";
import { motion } from "framer-motion";
import { Loader2 } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

const LOGO_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d0e11f7107236669e8813/774e948d3_Team44-Purple-png.png";

// Pulse / Heartbeat Logo Spinner
function PulseHeartbeat() {
  return (
    <EffectCard 
      title="Pulse Heartbeat" 
      description="Rhythmic pulsing for page transitions"
      whenToUse="Perfect for page transitions, initial app loading, or when fetching critical data. The heartbeat rhythm creates anticipation."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <motion.div
          animate={{
            scale: [1, 1.15, 1, 1.15, 1],
            opacity: [0.8, 1, 0.8, 1, 0.8]
          }}
          transition={{
            duration: 1.2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="relative"
        >
          <motion.div
            animate={{
              boxShadow: [
                "0 0 20px rgba(139, 92, 246, 0.3)",
                "0 0 40px rgba(139, 92, 246, 0.6)",
                "0 0 20px rgba(139, 92, 246, 0.3)",
                "0 0 40px rgba(139, 92, 246, 0.6)",
                "0 0 20px rgba(139, 92, 246, 0.3)"
              ]
            }}
            transition={{ duration: 1.2, repeat: Infinity }}
            className="rounded-full"
          >
            <img src={LOGO_URL} alt="Logo" className="w-20 h-20 object-contain" />
          </motion.div>
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Breathing Glow
function BreathingGlow() {
  return (
    <EffectCard 
      title="Breathing Glow" 
      description="Soft inhale/exhale animation"
      whenToUse="Ideal for meditation apps, calm loading states, or when you want users to wait patiently without stress."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <motion.div
          animate={{
            scale: [1, 1.08, 1],
            filter: [
              "drop-shadow(0 0 10px rgba(6, 182, 212, 0.4))",
              "drop-shadow(0 0 30px rgba(6, 182, 212, 0.8))",
              "drop-shadow(0 0 10px rgba(6, 182, 212, 0.4))"
            ]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <img src={LOGO_URL} alt="Logo" className="w-20 h-20 object-contain" />
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Orbital Spinner
function OrbitalSpinner() {
  return (
    <EffectCard 
      title="Orbital Spinner" 
      description="Dots orbiting around the logo"
      whenToUse="Great for data synchronization, cloud operations, or when multiple processes are running simultaneously."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative">
          <img src={LOGO_URL} alt="Logo" className="w-16 h-16 object-contain relative z-10" />
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              className="absolute inset-0 flex items-center justify-center"
              animate={{ rotate: 360 }}
              transition={{
                duration: 2 + i * 0.5,
                repeat: Infinity,
                ease: "linear",
                delay: i * 0.2
              }}
            >
              <div
                className={`absolute w-3 h-3 rounded-full ${
                  i === 0 ? "bg-violet-500" : i === 1 ? "bg-cyan-500" : "bg-teal-500"
                }`}
                style={{ transform: `translateY(-${35 + i * 8}px)` }}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Ripple Pulse
function RipplePulse() {
  return (
    <EffectCard 
      title="Ripple Pulse" 
      description="Expanding rings from center"
      whenToUse="Perfect for notifications, alerts, or when you want to draw attention to something important being processed."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative">
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              className="absolute inset-0 flex items-center justify-center"
              initial={{ scale: 0.8, opacity: 0.8 }}
              animate={{
                scale: [0.8, 2],
                opacity: [0.6, 0]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: i * 0.6,
                ease: "easeOut"
              }}
            >
              <div className="w-20 h-20 rounded-full border-2 border-violet-500" />
            </motion.div>
          ))}
          <motion.div
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 0.8, repeat: Infinity }}
          >
            <img src={LOGO_URL} alt="Logo" className="w-16 h-16 object-contain relative z-10" />
          </motion.div>
        </div>
      </div>
    </EffectCard>
  );
}

// Bounce Loader
function BounceLoader() {
  return (
    <EffectCard 
      title="Bounce Loader" 
      description="Playful bouncing animation"
      whenToUse="Best for playful apps, games, or when you want to add personality to your loading states."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <motion.div
          animate={{
            y: [0, -30, 0],
            scaleY: [1, 0.9, 1.1, 1],
            scaleX: [1, 1.1, 0.9, 1]
          }}
          transition={{
            duration: 0.8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <img src={LOGO_URL} alt="Logo" className="w-16 h-16 object-contain" />
        </motion.div>
        <motion.div
          className="absolute mt-20 w-12 h-3 bg-black/30 rounded-full blur-sm"
          animate={{
            scaleX: [1, 0.6, 1],
            opacity: [0.5, 0.2, 0.5]
          }}
          transition={{ duration: 0.8, repeat: Infinity }}
        />
      </div>
    </EffectCard>
  );
}

// Rotate Flip
function RotateFlip() {
  return (
    <EffectCard 
      title="Rotate Flip" 
      description="3D rotation effect"
      whenToUse="Great for coin flips, decision-making moments, or when content is being refreshed/updated."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50 perspective-1000">
        <motion.div
          animate={{ rotateY: 360 }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          style={{ transformStyle: "preserve-3d" }}
        >
          <img src={LOGO_URL} alt="Logo" className="w-16 h-16 object-contain" />
        </motion.div>
      </div>
    </EffectCard>
  );
}

// DNA Helix
function DNAHelix() {
  return (
    <EffectCard 
      title="DNA Helix" 
      description="Double helix spinning effect"
      whenToUse="Perfect for biotech, science apps, or when processing complex data transformations."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative">
          <img src={LOGO_URL} alt="Logo" className="w-12 h-12 object-contain relative z-10" />
          {[...Array(8)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute left-1/2 top-1/2"
              animate={{
                rotateY: 360
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "linear",
                delay: i * 0.1
              }}
              style={{
                transformStyle: "preserve-3d"
              }}
            >
              <motion.div
                className={`w-2 h-2 rounded-full ${i % 2 === 0 ? "bg-violet-500" : "bg-cyan-500"}`}
                style={{
                  transform: `translateX(${Math.cos(i * 0.8) * 30}px) translateY(${(i - 4) * 8}px)`
                }}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Morphing Shape
function MorphingShape() {
  return (
    <EffectCard 
      title="Morphing Shape" 
      description="Shape-shifting background"
      whenToUse="Ideal for creative apps, AI processing, or when content is being generated/transformed."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative">
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-violet-500/30 to-cyan-500/30"
            animate={{
              borderRadius: ["30% 70% 70% 30% / 30% 30% 70% 70%", "70% 30% 30% 70% / 70% 70% 30% 30%", "30% 70% 70% 30% / 30% 30% 70% 70%"]
            }}
            transition={{ duration: 4, repeat: Infinity }}
            style={{ width: 100, height: 100, margin: -20 }}
          />
          <motion.div
            animate={{ rotate: [0, 5, -5, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <img src={LOGO_URL} alt="Logo" className="w-16 h-16 object-contain relative z-10" />
          </motion.div>
        </div>
      </div>
    </EffectCard>
  );
}

// Progress Ring
function ProgressRing() {
  return (
    <EffectCard 
      title="Progress Ring" 
      description="Circular progress indicator"
      whenToUse="Best for uploads, downloads, or any operation where you can show actual progress percentage."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative">
          <svg className="w-24 h-24 -rotate-90">
            <circle cx="48" cy="48" r="40" fill="none" stroke="#1e293b" strokeWidth="4" />
            <motion.circle
              cx="48" cy="48" r="40"
              fill="none"
              stroke="url(#progressGrad)"
              strokeWidth="4"
              strokeLinecap="round"
              strokeDasharray="251.2"
              initial={{ strokeDashoffset: 251.2 }}
              animate={{ strokeDashoffset: [251.2, 0, 251.2] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            />
            <defs>
              <linearGradient id="progressGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#8b5cf6" />
                <stop offset="100%" stopColor="#06b6d4" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <img src={LOGO_URL} alt="Logo" className="w-10 h-10 object-contain" />
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Typing Dots
function TypingDots() {
  return (
    <EffectCard 
      title="Typing Dots" 
      description="Chat-style loading indicator"
      whenToUse="Perfect for chat applications, AI responses, or when content is being generated in real-time."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="flex items-center gap-4">
          <img src={LOGO_URL} alt="Logo" className="w-12 h-12 object-contain" />
          <div className="flex gap-1">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                className="w-3 h-3 rounded-full bg-violet-500"
                animate={{ y: [0, -10, 0] }}
                transition={{
                  duration: 0.6,
                  repeat: Infinity,
                  delay: i * 0.15
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Glitch Loader
function GlitchLoader() {
  return (
    <EffectCard 
      title="Glitch Loader" 
      description="Cyberpunk glitch effect"
      whenToUse="Great for tech/hacker themes, error recovery, or when reconnecting to services."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative">
          <motion.img
            src={LOGO_URL}
            alt="Logo"
            className="w-16 h-16 object-contain relative z-10"
            animate={{
              x: [0, -2, 2, 0],
              filter: [
                "hue-rotate(0deg)",
                "hue-rotate(90deg)",
                "hue-rotate(-90deg)",
                "hue-rotate(0deg)"
              ]
            }}
            transition={{ duration: 0.3, repeat: Infinity, repeatDelay: 1.5 }}
          />
          <motion.img
            src={LOGO_URL}
            alt=""
            className="absolute inset-0 w-16 h-16 object-contain opacity-50"
            style={{ filter: "hue-rotate(120deg)" }}
            animate={{ x: [0, 3, -3, 0], opacity: [0, 0.5, 0.5, 0] }}
            transition={{ duration: 0.2, repeat: Infinity, repeatDelay: 2 }}
          />
          <motion.img
            src={LOGO_URL}
            alt=""
            className="absolute inset-0 w-16 h-16 object-contain opacity-50"
            style={{ filter: "hue-rotate(-120deg)" }}
            animate={{ x: [0, -3, 3, 0], opacity: [0, 0.5, 0.5, 0] }}
            transition={{ duration: 0.2, repeat: Infinity, repeatDelay: 2, delay: 0.1 }}
          />
        </div>
      </div>
    </EffectCard>
  );
}

// Elastic Bounce
function ElasticBounce() {
  return (
    <EffectCard 
      title="Elastic Bounce" 
      description="Stretchy elastic animation"
      whenToUse="Perfect for playful interfaces, games, or when you want to add fun personality to loading states."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <motion.div
          animate={{
            scaleY: [1, 1.4, 0.8, 1.2, 1],
            scaleX: [1, 0.8, 1.2, 0.9, 1]
          }}
          transition={{
            duration: 1,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <img src={LOGO_URL} alt="Logo" className="w-16 h-16 object-contain" />
        </motion.div>
      </div>
    </EffectCard>
  );
}

// === NEW 20 LOADERS ===

// 1. Double Orbit
function DoubleOrbit() {
  return (
    <EffectCard 
      title="Double Orbit" 
      description="Two orbiting rings in opposite directions"
      whenToUse="Complex data processing or multi-step operations."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative">
          <motion.div
            className="absolute inset-0 w-24 h-24 border-2 border-violet-500/30 border-t-violet-500 rounded-full"
            style={{ margin: -16 }}
            animate={{ rotate: 360 }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
          />
          <motion.div
            className="absolute inset-0 w-16 h-16 border-2 border-cyan-500/30 border-b-cyan-500 rounded-full"
            animate={{ rotate: -360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          />
          <img src={LOGO_URL} alt="Logo" className="w-10 h-10 object-contain relative z-10" />
        </div>
      </div>
    </EffectCard>
  );
}

// 2. Liquid Fill
function LiquidFill() {
  return (
    <EffectCard 
      title="Liquid Fill" 
      description="Logo filling up with liquid"
      whenToUse="Uploads or long loading processes."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative w-20 h-20 overflow-hidden rounded-full border border-slate-800">
          <img src={LOGO_URL} alt="Logo" className="absolute inset-0 w-full h-full object-contain p-2 z-10 mix-blend-overlay" />
          <motion.div 
            className="absolute bottom-0 left-0 right-0 bg-violet-600"
            initial={{ height: "0%" }}
            animate={{ height: ["0%", "100%", "0%"] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          />
          <div className="absolute inset-0 bg-black/20 z-20" />
        </div>
      </div>
    </EffectCard>
  );
}

// 3. Neon Flicker
function NeonFlicker() {
  return (
    <EffectCard 
      title="Neon Flicker" 
      description="Faulty neon sign effect"
      whenToUse="Cyberpunk or retro themed apps."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <motion.div
          animate={{ opacity: [1, 0.4, 1, 0.4, 1, 0.2, 1] }}
          transition={{ duration: 2, repeat: Infinity, times: [0, 0.1, 0.2, 0.3, 0.4, 0.5, 1] }}
          style={{ filter: "drop-shadow(0 0 10px #8b5cf6)" }}
        >
          <img src={LOGO_URL} alt="Logo" className="w-20 h-20 object-contain" />
        </motion.div>
      </div>
    </EffectCard>
  );
}

// 4. Spin Scale
function SpinScale() {
  return (
    <EffectCard 
      title="Spin & Scale" 
      description="Rotating while pulsating"
      whenToUse="Energetic loading states."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <motion.div
          animate={{ 
            rotate: 360,
            scale: [1, 1.2, 1]
          }}
          transition={{ 
            rotate: { duration: 2, repeat: Infinity, ease: "linear" },
            scale: { duration: 1, repeat: Infinity, ease: "easeInOut" }
          }}
        >
          <img src={LOGO_URL} alt="Logo" className="w-16 h-16 object-contain" />
        </motion.div>
      </div>
    </EffectCard>
  );
}

// 5. Radar Scan
function RadarScan() {
  return (
    <EffectCard 
      title="Radar Scan" 
      description="Scanning line effect"
      whenToUse="Searching or scanning operations."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative w-24 h-24 rounded-full border border-slate-800 overflow-hidden bg-slate-900">
          <div className="absolute inset-0 flex items-center justify-center">
             <img src={LOGO_URL} alt="Logo" className="w-12 h-12 object-contain opacity-50" />
          </div>
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-transparent via-violet-500/20 to-transparent"
            style={{ transformOrigin: "bottom center" }}
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          />
          <div className="absolute inset-0 border border-violet-500/20 rounded-full" />
          <div className="absolute inset-4 border border-violet-500/20 rounded-full" />
        </div>
      </div>
    </EffectCard>
  );
}

// 6. Hexagon Pulse
function HexagonPulse() {
  return (
    <EffectCard 
      title="Hexagon Pulse" 
      description="Hexagonal border pulse"
      whenToUse="Sci-fi or tech interfaces."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative">
          <img src={LOGO_URL} alt="Logo" className="w-16 h-16 object-contain relative z-10" />
          <svg className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-28 h-28" viewBox="0 0 100 100">
            <motion.path
              d="M50 0 L93.3 25 L93.3 75 L50 100 L6.7 75 L6.7 25 Z"
              fill="none"
              stroke="#06b6d4"
              strokeWidth="2"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 1 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            />
          </svg>
        </div>
      </div>
    </EffectCard>
  );
}

// 7. Bouncing Dots
function BouncingDots() {
  return (
    <EffectCard 
      title="Bouncing Dots" 
      description="Dots bouncing under logo"
      whenToUse="Playful wait times."
    >
      <div className="h-40 flex flex-col items-center justify-center bg-slate-950/50 gap-4">
        <img src={LOGO_URL} alt="Logo" className="w-14 h-14 object-contain" />
        <div className="flex gap-2">
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              className="w-2 h-2 rounded-full bg-white"
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.1 }}
            />
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// 8. Blur Reveal
function BlurReveal() {
  return (
    <EffectCard 
      title="Blur Reveal" 
      description="Blur in and out"
      whenToUse="Subtle background loading."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <motion.div
          animate={{ filter: ["blur(0px)", "blur(10px)", "blur(0px)"], opacity: [1, 0.5, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <img src={LOGO_URL} alt="Logo" className="w-20 h-20 object-contain" />
        </motion.div>
      </div>
    </EffectCard>
  );
}

// 9. Glitch Shake
function GlitchShake() {
  return (
    <EffectCard 
      title="Glitch Shake" 
      description="Violent glitch shake"
      whenToUse="Critical errors or high energy moments."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <motion.div
          animate={{ x: [-2, 2, -1, 3, 0], y: [1, -2, 0, -1, 0] }}
          transition={{ duration: 0.2, repeat: Infinity, repeatDelay: 1 }}
        >
          <img src={LOGO_URL} alt="Logo" className="w-16 h-16 object-contain" style={{ filter: "contrast(1.2)" }} />
        </motion.div>
      </div>
    </EffectCard>
  );
}

// 10. Ripple Out
function RippleOut() {
  return (
    <EffectCard 
      title="Ripple Out" 
      description="Logo creating ripples"
      whenToUse="Broadcasting or connecting."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative">
          <img src={LOGO_URL} alt="Logo" className="w-14 h-14 object-contain relative z-10" />
          {[1, 2, 3].map((i) => (
            <motion.div
              key={i}
              className="absolute inset-0 rounded-full border border-violet-500"
              initial={{ scale: 1, opacity: 1 }}
              animate={{ scale: 2.5, opacity: 0 }}
              transition={{ duration: 2, repeat: Infinity, delay: i * 0.5 }}
            />
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// 11. Flip Card
function FlipCard() {
  return (
    <EffectCard 
      title="Flip Card" 
      description="Vertical flip"
      whenToUse="Card based interfaces."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50 perspective-1000">
        <motion.div
          animate={{ rotateX: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          style={{ transformStyle: "preserve-3d" }}
        >
          <img src={LOGO_URL} alt="Logo" className="w-16 h-16 object-contain" />
        </motion.div>
      </div>
    </EffectCard>
  );
}

// 12. Fade Scale
function FadeScale() {
  return (
    <EffectCard 
      title="Fade Scale" 
      description="Simple fade and scale"
      whenToUse="Minimalist loading."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <motion.div
          animate={{ opacity: [0.3, 1, 0.3], scale: [0.9, 1.1, 0.9] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          <img src={LOGO_URL} alt="Logo" className="w-16 h-16 object-contain" />
        </motion.div>
      </div>
    </EffectCard>
  );
}

// 13. Border Chase
function BorderChase() {
  return (
    <EffectCard 
      title="Border Chase" 
      description="Border lines chasing"
      whenToUse="Container loading."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative p-4">
          <motion.div 
            className="absolute inset-0 border-t-2 border-violet-500"
            animate={{ x: ["-100%", "100%"] }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            style={{ overflow: "hidden" }}
          />
           <img src={LOGO_URL} alt="Logo" className="w-14 h-14 object-contain" />
        </div>
      </div>
    </EffectCard>
  );
}

// 14. Swinging Pendulum
function SwingingPendulum() {
  return (
    <EffectCard 
      title="Pendulum" 
      description="Swinging motion"
      whenToUse="Waiting for server response."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <motion.div
          style={{ originY: 0 }}
          animate={{ rotate: [20, -20, 20] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
        >
           <div className="h-10 w-0.5 bg-slate-700 mx-auto" />
           <img src={LOGO_URL} alt="Logo" className="w-12 h-12 object-contain" />
        </motion.div>
      </div>
    </EffectCard>
  );
}

// 15. Satellite
function Satellite() {
  return (
    <EffectCard 
      title="Satellite" 
      description="Single dot orbiting closely"
      whenToUse="Small component loading."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative">
          <img src={LOGO_URL} alt="Logo" className="w-12 h-12 object-contain" />
          <motion.div
            className="absolute inset-0 w-20 h-20 -m-4 border border-dashed border-slate-700 rounded-full"
            animate={{ rotate: 360 }}
            transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
          >
             <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-cyan-500 rounded-full shadow-[0_0_10px_#06b6d4]" />
          </motion.div>
        </div>
      </div>
    </EffectCard>
  );
}

// 16. Snake
function Snake() {
  return (
    <EffectCard 
      title="Snake" 
      description="Snake moving around logo"
      whenToUse="Playful loading."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative p-2">
            <svg className="w-20 h-20 absolute inset-0">
                <motion.rect 
                    width="100%" height="100%" 
                    fill="none" 
                    stroke="#8b5cf6" 
                    strokeWidth="4"
                    strokeDasharray="20 200"
                    animate={{ strokeDashoffset: -220 }}
                    transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                />
            </svg>
            <img src={LOGO_URL} alt="Logo" className="w-16 h-16 object-contain p-2" />
        </div>
      </div>
    </EffectCard>
  );
}

// 17. Color Shift Filter
function ColorShiftFilter() {
  return (
    <EffectCard 
      title="Color Shift" 
      description="Hue rotating filter"
      whenToUse="Artistic loading."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <motion.div
          animate={{ filter: ["hue-rotate(0deg)", "hue-rotate(360deg)"] }}
          transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
        >
          <img src={LOGO_URL} alt="Logo" className="w-16 h-16 object-contain" />
        </motion.div>
      </div>
    </EffectCard>
  );
}

// 18. Jiggle
function Jiggle() {
  return (
    <EffectCard 
      title="Jiggle" 
      description="Nervous jiggle"
      whenToUse="User attention required."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <motion.div
          animate={{ rotate: [0, -5, 5, -5, 5, 0] }}
          transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 1 }}
        >
          <img src={LOGO_URL} alt="Logo" className="w-16 h-16 object-contain" />
        </motion.div>
      </div>
    </EffectCard>
  );
}

// 19. Ghost
function Ghost() {
  return (
    <EffectCard 
      title="Ghost" 
      description="Ghostly trail"
      whenToUse="Smooth transitions."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative">
           <motion.div
            className="absolute inset-0 opacity-50"
            animate={{ x: [-10, 10], opacity: [0, 0.5, 0] }}
            transition={{ duration: 1, repeat: Infinity, yoyo: Infinity }}
           >
               <img src={LOGO_URL} alt="Ghost" className="w-16 h-16 object-contain" />
           </motion.div>
           <img src={LOGO_URL} alt="Logo" className="w-16 h-16 object-contain relative z-10" />
        </div>
      </div>
    </EffectCard>
  );
}

// 20. Spotlight Reveal
function SpotlightReveal() {
  return (
    <EffectCard 
      title="Spotlight" 
      description="Spotlight passing over"
      whenToUse="Premium content loading."
    >
      <div className="h-40 flex items-center justify-center bg-slate-950/50">
        <div className="relative overflow-hidden w-20 h-20 rounded-xl bg-slate-900">
             <div className="absolute inset-0 flex items-center justify-center opacity-30">
                <img src={LOGO_URL} alt="Logo" className="w-14 h-14 object-contain grayscale" />
             </div>
             <motion.div 
                className="absolute inset-0 flex items-center justify-center bg-slate-900"
                style={{ 
                    maskImage: "radial-gradient(circle, white 30%, transparent 70%)",
                    WebkitMaskImage: "radial-gradient(circle, white 30%, transparent 70%)"
                }}
                animate={{ x: ["-100%", "100%"], y: ["-100%", "100%"] }}
                transition={{ duration: 2, repeat: Infinity }}
             >
                 <img src={LOGO_URL} alt="Logo" className="w-14 h-14 object-contain" />
             </motion.div>
        </div>
      </div>
    </EffectCard>
  );
}

export default function LoadingSpinners() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <PulseHeartbeat />, name: "Pulse Heartbeat" },
    { component: <BreathingGlow />, name: "Breathing Glow" },
    { component: <OrbitalSpinner />, name: "Orbital Spinner" },
    { component: <RipplePulse />, name: "Ripple Pulse" },
    { component: <BounceLoader />, name: "Bounce Loader" },
    { component: <RotateFlip />, name: "Rotate Flip" },
    { component: <DNAHelix />, name: "DNA Helix" },
    { component: <MorphingShape />, name: "Morphing Shape" },
    { component: <ProgressRing />, name: "Progress Ring" },
    { component: <TypingDots />, name: "Typing Dots" },
    { component: <GlitchLoader />, name: "Glitch Loader" },
    { component: <ElasticBounce />, name: "Elastic Bounce" },
    // New Effects
    { component: <DoubleOrbit />, name: "Double Orbit" },
    { component: <LiquidFill />, name: "Liquid Fill" },
    { component: <NeonFlicker />, name: "Neon Flicker" },
    { component: <SpinScale />, name: "Spin & Scale" },
    { component: <RadarScan />, name: "Radar Scan" },
    { component: <HexagonPulse />, name: "Hexagon Pulse" },
    { component: <BouncingDots />, name: "Bouncing Dots" },
    { component: <BlurReveal />, name: "Blur Reveal" },
    { component: <GlitchShake />, name: "Glitch Shake" },
    { component: <RippleOut />, name: "Ripple Out" },
    { component: <FlipCard />, name: "Flip Card" },
    { component: <FadeScale />, name: "Fade Scale" },
    { component: <BorderChase />, name: "Border Chase" },
    { component: <SwingingPendulum />, name: "Pendulum" },
    { component: <Satellite />, name: "Satellite" },
    { component: <Snake />, name: "Snake" },
    { component: <ColorShiftFilter />, name: "Color Shift" },
    { component: <Jiggle />, name: "Jiggle" },
    { component: <Ghost />, name: "Ghost" },
    { component: <SpotlightReveal />, name: "Spotlight" },
  ];

  const filtered = effects.filter(e => 
    e.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div>
      <CategoryHeader 
        icon={Loader2} 
        title="Loading Spinners" 
        description="Beautiful loading animations using the Team44 logo with pulse, heartbeat, and more effects" 
        gradient="#8b5cf6" 
      />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <SearchFilter 
          searchQuery={searchQuery} 
          setSearchQuery={setSearchQuery} 
          activeCategory={activeCategory} 
          setActiveCategory={setActiveCategory} 
          resultCount={filtered.length} 
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((effect, i) => (
            <div key={i}>{effect.component}</div>
          ))}
        </div>
      </div>
    </div>
  );
}