import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, ChevronRight, Home, User, Settings, Mail, Bell, Search, Layers, Heart, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

const menuItems = [
  { icon: Home, label: "Dashboard" },
  { icon: User, label: "Profile" },
  { icon: Mail, label: "Messages" },
  { icon: Bell, label: "Notifications" },
  { icon: Settings, label: "Settings" },
];

// Full Screen Overlay Menu
function FullScreenMenu() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <EffectCard title="Full Screen Overlay" description="Covers entire viewport" whenToUse="Dramatic navigation reveal for portfolio sites or minimal designs.">
      <div className="relative w-full h-[250px] bg-slate-900 rounded-xl overflow-hidden">
        <div className="p-4">
          <button onClick={() => setIsOpen(true)} className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700">
            <Menu className="w-6 h-6 text-white" />
          </button>
        </div>
        
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-gradient-to-br from-violet-900 to-slate-900 flex flex-col items-center justify-center"
            >
              <button onClick={() => setIsOpen(false)} className="absolute top-4 right-4 p-2">
                <X className="w-6 h-6 text-white" />
              </button>
              <nav className="space-y-4">
                {menuItems.map((item, i) => (
                  <motion.button
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="flex items-center gap-3 text-white text-xl hover:text-violet-400 transition-colors"
                  >
                    <item.icon className="w-6 h-6" />
                    {item.label}
                  </motion.button>
                ))}
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Blur Background Slide Menu
function BlurSlideMenu() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <EffectCard title="Blur Background Slide" description="Slides in with backdrop blur" whenToUse="Modern mobile menus that maintain context of the main content.">
      <div className="relative w-full h-[250px] bg-slate-900 rounded-xl overflow-hidden">
        <img src="https://images.unsplash.com/photo-1519681393784-d120267933ba?w=400&h=300&fit=crop" alt="bg" className="absolute inset-0 w-full h-full object-cover opacity-50" />
        <div className="relative p-4">
          <button onClick={() => setIsOpen(true)} className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 backdrop-blur-sm">
            <Menu className="w-6 h-6 text-white" />
          </button>
        </div>
        
        <AnimatePresence>
          {isOpen && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsOpen(false)}
                className="absolute inset-0 bg-black/50 backdrop-blur-md"
              />
              <motion.div
                initial={{ x: "-100%" }}
                animate={{ x: 0 }}
                exit={{ x: "-100%" }}
                transition={{ type: "spring", damping: 25 }}
                className="absolute left-0 top-0 bottom-0 w-48 bg-slate-900/90 backdrop-blur-xl border-r border-white/10 p-4"
              >
                <nav className="space-y-2 mt-8">
                  {menuItems.map((item, i) => (
                    <motion.button
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="w-full flex items-center gap-3 p-2 rounded-lg text-white hover:bg-white/10"
                    >
                      <item.icon className="w-5 h-5" />
                      <span className="text-sm">{item.label}</span>
                    </motion.button>
                  ))}
                </nav>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Detached Floating Menu
function DetachedFloatingMenu() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <EffectCard title="Detached Floating" description="Floats with gap from edge">
      <div className="relative w-full h-[250px] bg-slate-900 rounded-xl overflow-hidden">
        <div className="p-4">
          <button onClick={() => setIsOpen(!isOpen)} className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700">
            <Menu className="w-6 h-6 text-white" />
          </button>
        </div>
        
        <AnimatePresence>
          {isOpen && (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsOpen(false)} className="absolute inset-0 bg-black/30" />
              <motion.div
                initial={{ opacity: 0, x: -20, scale: 0.95 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, x: -20, scale: 0.95 }}
                className="absolute left-4 top-16 bottom-4 w-44 bg-slate-800 rounded-2xl shadow-2xl p-3 border border-slate-700"
              >
                <nav className="space-y-1">
                  {menuItems.map((item, i) => (
                    <button key={i} className="w-full flex items-center gap-3 p-2.5 rounded-xl text-slate-300 hover:bg-slate-700 hover:text-white transition-colors">
                      <item.icon className="w-4 h-4" />
                      <span className="text-sm">{item.label}</span>
                    </button>
                  ))}
                </nav>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Push Content Menu
function PushContentMenu() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <EffectCard title="Push Content" description="Pushes main content aside">
      <div className="relative w-full h-[250px] bg-slate-900 rounded-xl overflow-hidden flex">
        <motion.div animate={{ width: isOpen ? 140 : 0 }} className="bg-slate-800 overflow-hidden flex-shrink-0">
          <nav className="p-3 space-y-1 w-[140px]">
            {menuItems.map((item, i) => (
              <button key={i} className="w-full flex items-center gap-2 p-2 rounded-lg text-slate-300 hover:bg-slate-700 text-sm">
                <item.icon className="w-4 h-4" />
                {item.label}
              </button>
            ))}
          </nav>
        </motion.div>
        <div className="flex-1 p-4">
          <button onClick={() => setIsOpen(!isOpen)} className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700">
            <Menu className="w-6 h-6 text-white" />
          </button>
          <p className="mt-4 text-slate-400 text-sm">Content area pushes aside</p>
        </div>
      </div>
    </EffectCard>
  );
}

// Morph From Button
function MorphButtonMenu() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <EffectCard title="Morph from Button" description="Menu expands from trigger">
      <div className="relative w-full h-[250px] bg-slate-900 rounded-xl flex items-center justify-center">
        <AnimatePresence mode="wait">
          {!isOpen ? (
            <motion.button
              key="button"
              layoutId="menu"
              onClick={() => setIsOpen(true)}
              className="px-6 py-3 bg-gradient-to-r from-violet-500 to-cyan-500 rounded-xl text-white font-medium"
            >
              Open Menu
            </motion.button>
          ) : (
            <motion.div
              key="menu"
              layoutId="menu"
              className="w-48 bg-gradient-to-br from-violet-500 to-cyan-500 rounded-2xl p-1"
            >
              <div className="bg-slate-900 rounded-xl p-3">
                <button onClick={() => setIsOpen(false)} className="w-full text-right mb-2">
                  <X className="w-4 h-4 text-slate-400 ml-auto" />
                </button>
                <nav className="space-y-1">
                  {menuItems.slice(0, 4).map((item, i) => (
                    <button key={i} className="w-full flex items-center gap-2 p-2 rounded-lg text-slate-300 hover:bg-slate-800 text-sm">
                      <item.icon className="w-4 h-4" />
                      {item.label}
                    </button>
                  ))}
                </nav>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Circular Radial Menu
function RadialMenu() {
  const [isOpen, setIsOpen] = useState(false);
  const icons = [Home, User, Mail, Bell, Star];

  return (
    <EffectCard title="Radial Menu" description="Items fan out in circle" whenToUse="Quick actions, creative tools, or unique mobile navigation.">
      <div className="relative w-full h-[250px] bg-slate-900 rounded-xl flex items-center justify-center">
        <div className="relative">
          <AnimatePresence>
            {isOpen && icons.map((Icon, i) => {
              const angle = (i / icons.length) * Math.PI - Math.PI / 2;
              const x = Math.cos(angle) * 60;
              const y = Math.sin(angle) * 60;
              return (
                <motion.button
                  key={i}
                  initial={{ scale: 0, x: 0, y: 0 }}
                  animate={{ scale: 1, x, y }}
                  exit={{ scale: 0, x: 0, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center hover:bg-violet-500 transition-colors"
                >
                  <Icon className="w-4 h-4 text-white" />
                </motion.button>
              );
            })}
          </AnimatePresence>
          <motion.button
            onClick={() => setIsOpen(!isOpen)}
            animate={{ rotate: isOpen ? 45 : 0 }}
            className="relative z-10 w-14 h-14 rounded-full bg-gradient-to-r from-violet-500 to-cyan-500 flex items-center justify-center"
          >
            <span className="text-white text-2xl">+</span>
          </motion.button>
        </div>
      </div>
    </EffectCard>
  );
}

// Bottom Sheet Menu
function BottomSheetMenu() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <EffectCard title="Bottom Sheet" description="Slides up from bottom" whenToUse="Mobile-first actions, sharing options, or quick settings.">
      <div className="relative w-full h-[250px] bg-slate-900 rounded-xl overflow-hidden">
        <div className="p-4">
          <button onClick={() => setIsOpen(true)} className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700">
            <Menu className="w-6 h-6 text-white" />
          </button>
        </div>
        
        <AnimatePresence>
          {isOpen && (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsOpen(false)} className="absolute inset-0 bg-black/50" />
              <motion.div
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ type: "spring", damping: 25 }}
                className="absolute bottom-0 left-0 right-0 bg-slate-800 rounded-t-3xl p-4"
              >
                <div className="w-12 h-1 bg-slate-600 rounded-full mx-auto mb-4" />
                <nav className="grid grid-cols-3 gap-3">
                  {menuItems.map((item, i) => (
                    <button key={i} className="flex flex-col items-center gap-1 p-3 rounded-xl hover:bg-slate-700">
                      <item.icon className="w-5 h-5 text-slate-300" />
                      <span className="text-xs text-slate-400">{item.label}</span>
                    </button>
                  ))}
                </nav>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Accordion Sidebar
function AccordionSidebar() {
  const [openSection, setOpenSection] = useState(null);
  const sections = [
    { title: "Main", items: ["Dashboard", "Home"] },
    { title: "Account", items: ["Profile", "Settings"] },
    { title: "Support", items: ["Help", "Contact"] }
  ];

  return (
    <EffectCard title="Accordion Sidebar" description="Expandable sections">
      <div className="w-full h-[250px] bg-slate-800 rounded-xl p-3 overflow-auto">
        {sections.map((section, i) => (
          <div key={i} className="mb-2">
            <button
              onClick={() => setOpenSection(openSection === i ? null : i)}
              className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-700 text-white"
            >
              <span className="text-sm font-medium">{section.title}</span>
              <motion.div animate={{ rotate: openSection === i ? 90 : 0 }}>
                <ChevronRight className="w-4 h-4" />
              </motion.div>
            </button>
            <AnimatePresence>
              {openSection === i && (
                <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }} className="overflow-hidden">
                  <div className="pl-4 py-1 space-y-1">
                    {section.items.map((item, j) => (
                      <button key={j} className="w-full text-left p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700 text-sm">
                        {item}
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Mega Menu
function MegaMenu() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <EffectCard title="Mega Menu" description="Large dropdown with sections">
      <div className="relative w-full h-[250px] bg-slate-900 rounded-xl">
        <div className="flex items-center gap-4 p-4 border-b border-slate-800">
          <button onMouseEnter={() => setIsOpen(true)} onMouseLeave={() => setIsOpen(false)} className="text-white hover:text-violet-400 relative">
            Products
            <AnimatePresence>
              {isOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute top-full left-0 mt-2 w-64 bg-slate-800 rounded-xl p-4 shadow-2xl z-10"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-slate-500 mb-2">Category 1</p>
                      {["Item A", "Item B", "Item C"].map((item, i) => (
                        <button key={i} className="block w-full text-left text-sm text-slate-300 hover:text-white py-1">{item}</button>
                      ))}
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 mb-2">Category 2</p>
                      {["Item D", "Item E", "Item F"].map((item, i) => (
                        <button key={i} className="block w-full text-left text-sm text-slate-300 hover:text-white py-1">{item}</button>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </button>
          <span className="text-slate-400">About</span>
          <span className="text-slate-400">Contact</span>
        </div>
      </div>
    </EffectCard>
  );
}

// Icon-Only Sidebar
function IconOnlySidebar() {
  const [hovered, setHovered] = useState(null);

  return (
    <EffectCard title="Icon-Only Sidebar" description="Compact with tooltips">
      <div className="flex h-[250px]">
        <div className="w-16 bg-slate-800 rounded-l-xl p-2 space-y-2">
          {menuItems.map((item, i) => (
            <div key={i} className="relative" onMouseEnter={() => setHovered(i)} onMouseLeave={() => setHovered(null)}>
              <button className={`w-full p-3 rounded-xl transition-colors ${hovered === i ? "bg-violet-500" : "hover:bg-slate-700"}`}>
                <item.icon className="w-5 h-5 text-white mx-auto" />
              </button>
              <AnimatePresence>
                {hovered === i && (
                  <motion.div
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    className="absolute left-full top-1/2 -translate-y-1/2 ml-2 px-3 py-1.5 bg-slate-700 rounded-lg whitespace-nowrap z-10"
                  >
                    <span className="text-white text-sm">{item.label}</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
        <div className="flex-1 bg-slate-900 rounded-r-xl p-4">
          <p className="text-slate-400 text-sm">Hover icons for labels</p>
        </div>
      </div>
    </EffectCard>
  );
}

// NEW MENU EFFECTS

// Expanding Cards Menu
function ExpandingCardsMenu() {
  const [expanded, setExpanded] = useState(null);

  return (
    <EffectCard title="Expanding Cards" description="Cards expand on hover" whenToUse="Dashboard navigation or feature selection with visual previews.">
      <div className="flex gap-1 h-[200px] p-4">
        {menuItems.slice(0, 4).map((item, i) => (
          <motion.div
            key={i}
            animate={{ flex: expanded === i ? 3 : 1 }}
            onHoverStart={() => setExpanded(i)}
            onHoverEnd={() => setExpanded(null)}
            className="bg-gradient-to-b from-slate-700 to-slate-800 rounded-xl cursor-pointer overflow-hidden flex flex-col justify-end p-3"
          >
            <item.icon className="w-5 h-5 text-white mb-2" />
            <AnimatePresence>
              {expanded === i && (
                <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-white text-sm font-medium">
                  {item.label}
                </motion.span>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Stacked Cards Menu
function StackedCardsMenu() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <EffectCard title="Stacked Cards" description="Cards fan out from stack" whenToUse="Creative portfolio navigation or card-based selections.">
      <div className="relative h-[250px] flex items-center justify-center">
        <div className="relative" onClick={() => setIsOpen(!isOpen)}>
          {menuItems.slice(0, 4).map((item, i) => (
            <motion.div
              key={i}
              animate={{
                y: isOpen ? i * -50 : i * -5,
                x: isOpen ? (i - 1.5) * 60 : i * 2,
                rotate: isOpen ? (i - 1.5) * 5 : i * 2,
                scale: isOpen ? 1 : 1 - i * 0.05
              }}
              className="absolute w-24 h-32 bg-gradient-to-br from-violet-500 to-cyan-500 rounded-xl flex items-center justify-center cursor-pointer shadow-xl"
              style={{ zIndex: 10 - i }}
            >
              <item.icon className="w-8 h-8 text-white" />
            </motion.div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Sliding Panels Menu
function SlidingPanelsMenu() {
  const [activePanel, setActivePanel] = useState(0);

  return (
    <EffectCard title="Sliding Panels" description="Horizontal sliding sections" whenToUse="Multi-step wizards or category-based navigation.">
      <div className="h-[200px] overflow-hidden rounded-xl">
        <div className="flex gap-2 mb-2 px-2">
          {menuItems.slice(0, 3).map((item, i) => (
            <button key={i} onClick={() => setActivePanel(i)} className={`px-3 py-1 rounded-lg text-sm transition-colors ${activePanel === i ? "bg-violet-500 text-white" : "bg-slate-700 text-slate-300"}`}>
              {item.label}
            </button>
          ))}
        </div>
        <motion.div animate={{ x: `-${activePanel * 100}%` }} transition={{ type: "spring", damping: 20 }} className="flex">
          {menuItems.slice(0, 3).map((item, i) => (
            <div key={i} className="min-w-full p-4 bg-slate-800 rounded-xl">
              <item.icon className="w-8 h-8 text-violet-400 mb-2" />
              <p className="text-white font-medium">{item.label} Content</p>
              <p className="text-slate-400 text-sm">Panel {i + 1} details here</p>
            </div>
          ))}
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Command Palette
function CommandPaletteMenu() {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState("");

  const filtered = menuItems.filter(item => item.label.toLowerCase().includes(query.toLowerCase()));

  return (
    <EffectCard title="Command Palette" description="Spotlight search style" whenToUse="Power user shortcuts, global search, or quick actions.">
      <div className="relative h-[250px] bg-slate-900 rounded-xl p-4">
        <button onClick={() => setIsOpen(true)} className="flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-lg text-slate-400 text-sm">
          <Search className="w-4 h-4" /> Press ⌘K to search...
        </button>
        
        <AnimatePresence>
          {isOpen && (
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="absolute inset-4 bg-slate-800 rounded-xl shadow-2xl border border-slate-700 overflow-hidden">
              <div className="p-3 border-b border-slate-700">
                <input type="text" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Type a command..." className="w-full bg-transparent text-white outline-none" autoFocus />
              </div>
              <div className="p-2 max-h-32 overflow-auto">
                {filtered.map((item, i) => (
                  <button key={i} className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-slate-700 text-white text-sm">
                    <item.icon className="w-4 h-4 text-slate-400" />
                    {item.label}
                  </button>
                ))}
              </div>
              <div className="p-2 border-t border-slate-700 text-xs text-slate-500">
                <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-white">ESC to close</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Morphing Tabs
function MorphingTabsMenu() {
  const [active, setActive] = useState(0);

  return (
    <EffectCard title="Morphing Tabs" description="Animated indicator follows selection" whenToUse="Seamless tab navigation with visual continuity.">
      <div className="h-[200px] p-4">
        <div className="relative flex gap-1 bg-slate-800 rounded-xl p-1 mb-4">
          <motion.div layoutId="activeTab" className="absolute inset-y-1 bg-violet-500 rounded-lg" style={{ width: `${100 / 4}%`, left: `${(active / 4) * 100}%` }} />
          {menuItems.slice(0, 4).map((item, i) => (
            <button key={i} onClick={() => setActive(i)} className={`relative z-10 flex-1 py-2 text-sm font-medium transition-colors ${active === i ? "text-white" : "text-slate-400"}`}>
              {item.label}
            </button>
          ))}
        </div>
        <div className="bg-slate-800 rounded-xl p-4">
          <p className="text-white">Content for {menuItems[active].label}</p>
        </div>
      </div>
    </EffectCard>
  );
}

// Dock Menu (macOS style)
function DockMenu() {
  const [hovered, setHovered] = useState(null);

  return (
    <EffectCard title="Dock Menu" description="macOS dock magnification" whenToUse="Desktop-like app launchers or prominent tool access.">
      <div className="h-[200px] flex items-end justify-center pb-4">
        <div className="flex items-end gap-1 bg-slate-800/80 backdrop-blur-sm rounded-2xl px-3 py-2">
          {menuItems.map((item, i) => {
            const distance = hovered !== null ? Math.abs(hovered - i) : 3;
            const scale = hovered !== null ? Math.max(1, 1.5 - distance * 0.25) : 1;
            return (
              <motion.button
                key={i}
                animate={{ scale, y: hovered === i ? -10 : 0 }}
                onHoverStart={() => setHovered(i)}
                onHoverEnd={() => setHovered(null)}
                className="p-3 bg-gradient-to-br from-slate-600 to-slate-700 rounded-xl"
              >
                <item.icon className="w-6 h-6 text-white" />
              </motion.button>
            );
          })}
        </div>
      </div>
    </EffectCard>
  );
}

// Notification Center
function NotificationCenterMenu() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <EffectCard title="Notification Center" description="Slide-in notification panel" whenToUse="Notification systems, activity feeds, or alerts.">
      <div className="relative h-[250px] bg-slate-900 rounded-xl overflow-hidden">
        <div className="p-4">
          <button onClick={() => setIsOpen(!isOpen)} className="relative p-2 rounded-lg bg-slate-800 hover:bg-slate-700">
            <Bell className="w-6 h-6 text-white" />
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">3</span>
          </button>
        </div>
        
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25 }}
              className="absolute right-0 top-0 bottom-0 w-56 bg-slate-800 border-l border-slate-700 p-3"
            >
              <h4 className="text-white font-medium mb-3">Notifications</h4>
              {[1, 2, 3].map(i => (
                <div key={i} className="p-2 mb-2 bg-slate-700 rounded-lg">
                  <p className="text-white text-sm">Notification {i}</p>
                  <p className="text-slate-400 text-xs">Just now</p>
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Context Menu
function ContextMenuEffect() {
  const [menuPos, setMenuPos] = useState(null);

  const handleContextMenu = (e) => {
    e.preventDefault();
    setMenuPos({ x: e.nativeEvent.offsetX, y: e.nativeEvent.offsetY });
  };

  return (
    <EffectCard title="Context Menu" description="Right-click popup menu" whenToUse="File managers, editors, or secondary action menus.">
      <div className="relative h-[200px] bg-slate-800 rounded-xl" onContextMenu={handleContextMenu} onClick={() => setMenuPos(null)}>
        <p className="absolute inset-0 flex items-center justify-center text-slate-400 text-sm">Right-click anywhere</p>
        <AnimatePresence>
          {menuPos && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute bg-slate-700 rounded-lg shadow-xl border border-slate-600 py-1 w-36 z-10"
              style={{ left: menuPos.x, top: menuPos.y }}
            >
              {["Copy", "Paste", "Delete", "Rename"].map((action, i) => (
                <button key={i} className="w-full text-left px-3 py-1.5 text-sm text-white hover:bg-slate-600">{action}</button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Breadcrumb Trail Menu
function BreadcrumbTrailMenu() {
  const [path, setPath] = useState(["Home", "Products", "Electronics"]);

  return (
    <EffectCard title="Breadcrumb Trail" description="Animated path navigation" whenToUse="Deep navigation hierarchies or file system browsing.">
      <div className="h-[150px] p-4">
        <div className="flex items-center gap-2 mb-4">
          {path.map((item, i) => (
            <motion.div key={item} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="flex items-center gap-2">
              {i > 0 && <ChevronRight className="w-4 h-4 text-slate-500" />}
              <button onClick={() => setPath(path.slice(0, i + 1))} className={`text-sm ${i === path.length - 1 ? "text-white font-medium" : "text-slate-400 hover:text-white"}`}>
                {item}
              </button>
            </motion.div>
          ))}
        </div>
        <div className="flex gap-2">
          <button onClick={() => setPath([...path, "Item"])} className="px-3 py-1 bg-violet-500 rounded text-white text-sm">Add Level</button>
          <button onClick={() => setPath(path.slice(0, -1))} className="px-3 py-1 bg-slate-700 rounded text-white text-sm" disabled={path.length <= 1}>Go Back</button>
        </div>
      </div>
    </EffectCard>
  );
}

export default function MenuEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <FullScreenMenu />, name: "Full Screen Overlay" },
    { component: <BlurSlideMenu />, name: "Blur Background Slide" },
    { component: <DetachedFloatingMenu />, name: "Detached Floating" },
    { component: <PushContentMenu />, name: "Push Content" },
    { component: <MorphButtonMenu />, name: "Morph from Button" },
    { component: <RadialMenu />, name: "Radial Menu" },
    { component: <BottomSheetMenu />, name: "Bottom Sheet" },
    { component: <AccordionSidebar />, name: "Accordion Sidebar" },
    { component: <MegaMenu />, name: "Mega Menu" },
    { component: <IconOnlySidebar />, name: "Icon-Only Sidebar" },
    // NEW MENUS
    { component: <ExpandingCardsMenu />, name: "Expanding Cards" },
    { component: <StackedCardsMenu />, name: "Stacked Cards" },
    { component: <SlidingPanelsMenu />, name: "Sliding Panels" },
    { component: <CommandPaletteMenu />, name: "Command Palette" },
    { component: <MorphingTabsMenu />, name: "Morphing Tabs" },
    { component: <DockMenu />, name: "Dock Menu" },
    { component: <NotificationCenterMenu />, name: "Notification Center" },
    { component: <ContextMenuEffect />, name: "Context Menu" },
    { component: <BreadcrumbTrailMenu />, name: "Breadcrumb Trail" },
  ];

  const filtered = effects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div>
      <CategoryHeader icon={Menu} title="Menu Effects" description="Sidebars, overlays, dropdowns and navigation patterns" gradient="#f59e0b" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((effect, i) => <div key={i}>{effect.component}</div>)}
        </div>
      </div>
    </div>
  );
}