import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MousePointerClick, Loader2, Check, X, Send, Heart, ShoppingCart, Download, Star, Bookmark, Share2, Save, Upload, Cloud, Lock, ArrowUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// Ripple Effect
function RippleEffect() {
  const [ripples, setRipples] = useState([]);

  const handleClick = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const id = Date.now();
    setRipples(prev => [...prev, { id, x: e.clientX - rect.left, y: e.clientY - rect.top }]);
    setTimeout(() => setRipples(prev => prev.filter(r => r.id !== id)), 600);
  };

  return (
    <EffectCard title="Ripple Effect" description="Material Design click ripple" whenToUse="Essential for touch feedback on mobile apps and Material Design interfaces.">
      <div className="p-8 flex justify-center">
        <button onClick={handleClick} className="relative overflow-hidden px-8 py-4 rounded-xl bg-gradient-to-r from-violet-500 to-purple-600 text-white font-semibold shadow-lg">
          <span className="relative z-10">Click Me</span>
          {ripples.map(r => <motion.span key={r.id} initial={{ scale: 0, opacity: 0.5 }} animate={{ scale: 4, opacity: 0 }} className="absolute w-20 h-20 rounded-full bg-white/30" style={{ left: r.x - 40, top: r.y - 40 }} />)}
        </button>
      </div>
    </EffectCard>
  );
}

// Fill Animation
function FillAnimationEffect() {
  const [direction, setDirection] = useState("left");
  const dirs = { left: "before:left-0", right: "before:right-0", center: "before:left-1/2 before:-translate-x-1/2" };

  return (
    <EffectCard title="Fill Animation" description="Background fills on hover" whenToUse="Great for navigation buttons, CTAs, or any button that needs visual state feedback." controls={<div className="flex gap-2">{Object.keys(dirs).map(d => <Button key={d} variant={direction === d ? "default" : "outline"} size="sm" onClick={() => setDirection(d)}>{d}</Button>)}</div>}>
      <div className="p-8 flex justify-center">
        <button className={`relative overflow-hidden px-8 py-4 rounded-xl border-2 border-cyan-500 text-cyan-400 font-semibold transition-colors duration-300 hover:text-white before:absolute before:top-0 before:bottom-0 before:w-0 hover:before:w-full before:bg-cyan-500 before:-z-10 before:transition-all before:duration-300 ${dirs[direction]}`}>
          Hover Me
        </button>
      </div>
    </EffectCard>
  );
}

// 3D Press
function Press3DEffect() {
  return (
    <EffectCard title="3D Press" description="Button depresses on click" whenToUse="Perfect for game UIs, arcade buttons, or adding tactile feel to primary actions.">
      <div className="p-8 flex justify-center">
        <motion.button whileHover={{ y: -2 }} whileTap={{ y: 4 }} className="relative px-8 py-4 rounded-xl bg-gradient-to-b from-emerald-400 to-emerald-600 text-white font-semibold shadow-[0_6px_0_0_#047857] active:shadow-[0_2px_0_0_#047857] transition-shadow">
          Press Me
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Shake on Error
function ShakeOnErrorEffect() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState(false);
  const [shakeKey, setShakeKey] = useState(0);

  const handleSubmit = () => { if (!email.includes("@")) { setError(true); setShakeKey(k => k + 1); setTimeout(() => setError(false), 2000); } else setError(false); };

  return (
    <EffectCard title="Shake on Error" description="Invalid input triggers shake">
      <div className="p-6 space-y-4">
        <div className="space-y-2"><Label className="text-slate-300">Email</Label><Input type="text" placeholder="Enter email..." value={email} onChange={(e) => setEmail(e.target.value)} className={`bg-slate-800 border-slate-700 text-white ${error ? "border-red-500" : ""}`} /></div>
        <motion.div key={shakeKey} animate={error ? { x: [0, -10, 10, -10, 10, 0] } : {}} transition={{ duration: 0.4 }}>
          <Button onClick={handleSubmit} variant={error ? "destructive" : "default"} className="w-full">{error ? "Invalid!" : "Submit"}</Button>
        </motion.div>
        {error && <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-red-400 text-sm">Please enter valid email</motion.p>}
      </div>
    </EffectCard>
  );
}

// Loading State
function LoadingStateEffect() {
  const [state, setState] = useState("idle");

  const handleClick = () => { setState("loading"); setTimeout(() => { setState(Math.random() > 0.3 ? "success" : "error"); setTimeout(() => setState("idle"), 2000); }, 2000); };
  const content = { idle: { icon: Send, text: "Submit", bg: "bg-gradient-to-r from-violet-500 to-purple-600" }, loading: { icon: Loader2, text: "Processing...", bg: "bg-slate-600" }, success: { icon: Check, text: "Success!", bg: "bg-emerald-500" }, error: { icon: X, text: "Error!", bg: "bg-red-500" } };
  const { icon: Icon, text, bg } = content[state];

  return (
    <EffectCard title="Loading State" description="Button with states" whenToUse="Essential for form submissions, API calls, or any async operation feedback.">
      <div className="p-8 flex justify-center">
        <motion.button onClick={handleClick} disabled={state === "loading"} whileHover={state === "idle" ? { scale: 1.02 } : {}} whileTap={state === "idle" ? { scale: 0.98 } : {}} className={`relative overflow-hidden px-8 py-4 rounded-xl text-white font-semibold ${bg} min-w-[180px] disabled:cursor-not-allowed`}>
          <AnimatePresence mode="wait">
            <motion.span key={state} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="flex items-center justify-center gap-2">
              <Icon className={`w-5 h-5 ${state === "loading" ? "animate-spin" : ""}`} />{text}
            </motion.span>
          </AnimatePresence>
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Like Button
function LikeButtonEffect() {
  const [liked, setLiked] = useState(false);
  const [count, setCount] = useState(42);

  return (
    <EffectCard title="Like Button" description="Animated heart" whenToUse="Social media apps, content platforms, or anywhere users express appreciation.">
      <div className="p-8 flex justify-center">
        <motion.button onClick={() => { setLiked(!liked); setCount(c => liked ? c - 1 : c + 1); }} whileTap={{ scale: 0.9 }} className={`flex items-center gap-3 px-6 py-3 rounded-full border-2 ${liked ? "border-pink-500 bg-pink-500/10" : "border-slate-600"}`}>
          <motion.div animate={liked ? { scale: [1, 1.3, 1] } : { scale: 1 }}><Heart className={`w-6 h-6 ${liked ? "fill-pink-500 text-pink-500" : "text-slate-400"}`} /></motion.div>
          <AnimatePresence mode="wait"><motion.span key={count} initial={{ opacity: 0, y: liked ? 10 : -10 }} animate={{ opacity: 1, y: 0 }} className={`font-semibold ${liked ? "text-pink-400" : "text-slate-300"}`}>{count}</motion.span></AnimatePresence>
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Add to Cart
function AddToCartEffect() {
  const [added, setAdded] = useState(false);

  return (
    <EffectCard title="Add to Cart" description="Cart button animation" whenToUse="E-commerce sites for confirming items added to shopping cart.">
      <div className="p-8 flex justify-center">
        <motion.button onClick={() => { setAdded(true); setTimeout(() => setAdded(false), 2000); }} disabled={added} whileHover={!added ? { scale: 1.02 } : {}} className={`relative overflow-hidden px-8 py-4 rounded-xl font-semibold min-w-[200px] ${added ? "bg-emerald-500 text-white" : "bg-gradient-to-r from-amber-500 to-orange-500 text-white"}`}>
          <AnimatePresence mode="wait">
            {added ? <motion.span key="added" initial={{ opacity: 0, scale: 0.5 }} animate={{ opacity: 1, scale: 1 }} className="flex items-center justify-center gap-2"><Check className="w-5 h-5" /> Added!</motion.span> : <motion.span key="add" className="flex items-center justify-center gap-2"><ShoppingCart className="w-5 h-5" /> Add to Cart</motion.span>}
          </AnimatePresence>
          {added && <motion.div initial={{ x: "-100%" }} animate={{ x: "100%" }} className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent" />}
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Download Progress
function DownloadProgressEffect() {
  const [state, setState] = useState("idle");
  const [progress, setProgress] = useState(0);

  const handleDownload = () => {
    if (state !== "idle") return;
    setState("downloading"); setProgress(0);
    const interval = setInterval(() => {
      setProgress(p => { if (p >= 100) { clearInterval(interval); setState("complete"); setTimeout(() => { setState("idle"); setProgress(0); }, 2000); return 100; } return p + Math.random() * 15; });
    }, 200);
  };

  return (
    <EffectCard title="Download Progress" description="Button with progress" whenToUse="File downloads, software installers, or any action with trackable progress.">
      <div className="p-8 flex justify-center">
        <motion.button onClick={handleDownload} disabled={state !== "idle"} whileHover={state === "idle" ? { scale: 1.02 } : {}} className="relative overflow-hidden px-8 py-4 rounded-xl bg-slate-800 border border-slate-700 text-white font-semibold min-w-[200px] disabled:cursor-not-allowed">
          {state === "downloading" && <motion.div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-cyan-500" initial={{ width: "0%" }} animate={{ width: `${progress}%` }} style={{ opacity: 0.3 }} />}
          <span className="relative z-10 flex items-center justify-center gap-2">
            {state === "idle" && <><Download className="w-5 h-5" /> Download</>}
            {state === "downloading" && <><Loader2 className="w-5 h-5 animate-spin" /> {Math.min(100, Math.round(progress))}%</>}
            {state === "complete" && <><Check className="w-5 h-5 text-emerald-400" /> Complete!</>}
          </span>
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Magnetic Button
function MagneticButtonEffect() {
  const buttonRef = useRef(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e) => { if (!buttonRef.current) return; const rect = buttonRef.current.getBoundingClientRect(); setPosition({ x: (e.clientX - rect.left - rect.width / 2) * 0.2, y: (e.clientY - rect.top - rect.height / 2) * 0.2 }); };

  return (
    <EffectCard title="Magnetic Button" description="Follows cursor" whenToUse="Creative portfolios, landing pages, or when you want to add playful interaction.">
      <div className="p-8 flex justify-center" onMouseMove={handleMouseMove} onMouseLeave={() => setPosition({ x: 0, y: 0 })}>
        <motion.button ref={buttonRef} animate={{ x: position.x, y: position.y }} transition={{ type: "spring", stiffness: 150, damping: 15 }} className="px-8 py-4 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 text-white font-semibold shadow-lg">
          Hover Around
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Border Animation
function BorderAnimationEffect() {
  return (
    <EffectCard title="Border Animation" description="Animated border stroke">
      <div className="p-8 flex justify-center">
        <div className="relative group">
          <svg className="absolute inset-0 w-full h-full" viewBox="0 0 200 60">
            <motion.rect x="2" y="2" width="196" height="56" rx="12" fill="none" stroke="url(#borderGrad)" strokeWidth="2" strokeDasharray="500" initial={{ strokeDashoffset: 500 }} whileHover={{ strokeDashoffset: 0 }} transition={{ duration: 0.8 }} />
            <defs><linearGradient id="borderGrad"><stop offset="0%" stopColor="#8b5cf6" /><stop offset="100%" stopColor="#06b6d4" /></linearGradient></defs>
          </svg>
          <button className="relative px-8 py-4 text-white font-semibold">Hover Me</button>
        </div>
      </div>
    </EffectCard>
  );
}

// Glow Button
function GlowButtonEffect() {
  return (
    <EffectCard title="Glow Button" description="Hover glow effect">
      <div className="p-8 flex justify-center">
        <motion.button whileHover={{ boxShadow: "0 0 30px rgba(139, 92, 246, 0.5), 0 0 60px rgba(6, 182, 212, 0.3)" }} className="px-8 py-4 rounded-xl bg-gradient-to-r from-violet-500 to-cyan-500 text-white font-semibold transition-shadow">
          Glow Hover
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Icon Button
function IconButtonEffect() {
  const [bookmarked, setBookmarked] = useState(false);

  return (
    <EffectCard title="Icon Buttons" description="Animated icon actions">
      <div className="p-8 flex justify-center gap-4">
        {[{ icon: Heart, active: false }, { icon: Bookmark, active: bookmarked, toggle: () => setBookmarked(!bookmarked) }, { icon: Share2, active: false }, { icon: Star, active: false }].map((btn, i) => (
          <motion.button key={i} whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={btn.toggle} className={`p-3 rounded-xl ${btn.active ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400 hover:text-white"}`}>
            <btn.icon className={`w-5 h-5 ${btn.active ? "fill-current" : ""}`} />
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Toggle Button
function ToggleButtonEffect() {
  const [isOn, setIsOn] = useState(false);

  return (
    <EffectCard title="Toggle Button" description="Switch-style toggle">
      <div className="p-8 flex flex-col items-center gap-4">
        <button onClick={() => setIsOn(!isOn)} className={`w-20 h-10 rounded-full p-1 transition-colors ${isOn ? "bg-violet-500" : "bg-slate-700"}`}>
          <motion.div animate={{ x: isOn ? 40 : 0 }} className="w-8 h-8 rounded-full bg-white shadow-lg" />
        </button>
        <p className="text-slate-300">{isOn ? "ON" : "OFF"}</p>
      </div>
    </EffectCard>
  );
}

// Split Button
function SplitButtonEffect() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <EffectCard title="Split Button" description="Button with dropdown">
      <div className="p-8 flex justify-center">
        <div className="relative flex">
          <button className="px-6 py-3 bg-violet-500 text-white font-medium rounded-l-xl hover:bg-violet-600">Save</button>
          <button onClick={() => setIsOpen(!isOpen)} className="px-3 py-3 bg-violet-600 text-white rounded-r-xl border-l border-violet-400 hover:bg-violet-700">▼</button>
          <AnimatePresence>
            {isOpen && (
              <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="absolute top-full left-0 right-0 mt-2 bg-slate-800 rounded-xl border border-slate-700 overflow-hidden">
                {["Save as...", "Save & Close", "Discard"].map(item => <button key={item} onClick={() => setIsOpen(false)} className="w-full px-4 py-2 text-left text-slate-300 hover:bg-slate-700 text-sm">{item}</button>)}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </EffectCard>
  );
}

// Floating Action Button
function FABEffect() {
  const [isExpanded, setIsExpanded] = useState(false);
  const actions = [{ icon: Heart, color: "bg-pink-500" }, { icon: Star, color: "bg-amber-500" }, { icon: Share2, color: "bg-cyan-500" }];

  return (
    <EffectCard title="Floating Action" description="Expandable FAB" whenToUse="Perfect for mobile apps with primary actions that need quick access from any screen.">
      <div className="relative h-[200px] flex items-end justify-end p-6">
        <AnimatePresence>
          {isExpanded && actions.map((action, i) => (
            <motion.button key={i} initial={{ scale: 0, y: 0 }} animate={{ scale: 1, y: -(i + 1) * 50 }} exit={{ scale: 0, y: 0 }} className={`absolute bottom-6 right-6 w-10 h-10 rounded-full ${action.color} flex items-center justify-center shadow-lg`}>
              <action.icon className="w-5 h-5 text-white" />
            </motion.button>
          ))}
        </AnimatePresence>
        <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => setIsExpanded(!isExpanded)} className="relative z-10 w-14 h-14 rounded-full bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center shadow-lg">
          <motion.span animate={{ rotate: isExpanded ? 45 : 0 }} className="text-white text-2xl">+</motion.span>
        </motion.button>
      </div>
    </EffectCard>
  );
}

// ===== NEW BUTTON EFFECTS =====

// Neon Glow Button
function NeonGlowEffect() {
  return (
    <EffectCard title="Neon Glow" description="Cyberpunk neon effect" whenToUse="Ideal for gaming sites, nightlife apps, or futuristic/cyberpunk themed interfaces.">
      <div className="p-8 flex justify-center">
        <motion.button 
          whileHover={{ 
            boxShadow: "0 0 5px #fff, 0 0 10px #fff, 0 0 20px #0ff, 0 0 30px #0ff, 0 0 40px #0ff",
            textShadow: "0 0 5px #fff, 0 0 10px #fff, 0 0 20px #0ff"
          }}
          className="px-8 py-4 rounded-xl bg-transparent border-2 border-cyan-400 text-cyan-400 font-bold uppercase tracking-wider transition-all"
        >
          Neon
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Liquid Fill Button
function LiquidFillEffect() {
  return (
    <EffectCard title="Liquid Fill" description="Water wave fill animation" whenToUse="Great for progress indicators, loading states, or creative CTAs that need visual interest.">
      <div className="p-8 flex justify-center">
        <button className="relative px-8 py-4 rounded-xl bg-slate-800 text-white font-semibold overflow-hidden group">
          <span className="relative z-10">Hover Me</span>
          <motion.div 
            className="absolute inset-0 bg-gradient-to-r from-violet-500 to-cyan-500"
            initial={{ y: "100%" }}
            whileHover={{ y: "0%" }}
            transition={{ duration: 0.4, ease: "easeOut" }}
          />
        </button>
      </div>
    </EffectCard>
  );
}

// Shake Effect
function ShakeEffect() {
  return (
    <EffectCard title="Shake Button" description="Attention-grabbing shake" whenToUse="Use sparingly to draw attention to important CTAs or notifications that need immediate action.">
      <div className="p-8 flex justify-center">
        <motion.button 
          whileHover={{ x: [0, -5, 5, -5, 5, 0] }}
          transition={{ duration: 0.5 }}
          className="px-8 py-4 rounded-xl bg-red-500 text-white font-semibold"
        >
          Shake Me!
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Gradient Border Button
function GradientBorderEffect() {
  return (
    <EffectCard title="Gradient Border" description="Animated rainbow border" whenToUse="Perfect for premium features, special offers, or when you want to highlight an exclusive action.">
      <div className="p-8 flex justify-center">
        <div className="relative p-[2px] rounded-xl overflow-hidden">
          <motion.div 
            className="absolute inset-0 bg-gradient-to-r from-violet-500 via-pink-500 via-cyan-500 to-violet-500"
            animate={{ backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] }}
            transition={{ duration: 3, repeat: Infinity }}
            style={{ backgroundSize: "200% 200%" }}
          />
          <button className="relative px-8 py-4 rounded-xl bg-slate-900 text-white font-semibold">
            Premium
          </button>
        </div>
      </div>
    </EffectCard>
  );
}

// Slide Text Button
function SlideTextEffect() {
  return (
    <EffectCard title="Slide Text" description="Text slides on hover" whenToUse="Good for navigation buttons where you want to show a secondary label or icon on interaction.">
      <div className="p-8 flex justify-center">
        <button className="relative px-8 py-4 rounded-xl bg-violet-500 text-white font-semibold overflow-hidden group">
          <span className="block transition-transform duration-300 group-hover:-translate-y-full">Click Me</span>
          <span className="absolute inset-0 flex items-center justify-center translate-y-full transition-transform duration-300 group-hover:translate-y-0">Let's Go!</span>
        </button>
      </div>
    </EffectCard>
  );
}

// Pulse Ring Button
function PulseRingEffect() {
  return (
    <EffectCard title="Pulse Ring" description="Expanding pulse rings" whenToUse="Excellent for call-to-action buttons that need to draw continuous attention without being annoying.">
      <div className="p-8 flex justify-center">
        <div className="relative">
          {[1, 2, 3].map(i => (
            <motion.div
              key={i}
              className="absolute inset-0 rounded-full border-2 border-violet-500"
              animate={{ scale: [1, 2], opacity: [0.5, 0] }}
              transition={{ duration: 2, repeat: Infinity, delay: i * 0.4 }}
            />
          ))}
          <button className="relative px-8 py-4 rounded-full bg-violet-500 text-white font-semibold z-10">
            Subscribe
          </button>
        </div>
      </div>
    </EffectCard>
  );
}

// Neumorphic Button
function NeumorphicEffect() {
  return (
    <EffectCard title="Neumorphic" description="Soft UI pressed effect" whenToUse="Best for minimalist interfaces, settings panels, or calculator-style UIs with a modern feel.">
      <div className="p-8 flex justify-center bg-slate-800 rounded-xl">
        <motion.button 
          className="px-8 py-4 rounded-xl bg-slate-800 text-slate-300 font-semibold"
          style={{ boxShadow: "8px 8px 16px #1e1e2e, -8px -8px 16px #3a3a5a" }}
          whileTap={{ boxShadow: "inset 4px 4px 8px #1e1e2e, inset -4px -4px 8px #3a3a5a" }}
        >
          Neumorphic
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Confetti Button
function ConfettiEffect() {
  const [showConfetti, setShowConfetti] = useState(false);
  
  return (
    <EffectCard title="Confetti Burst" description="Celebration particles" whenToUse="Perfect for success states, achievements, rewards, or any celebratory user action.">
      <div className="p-8 flex justify-center">
        <div className="relative">
          <AnimatePresence>
            {showConfetti && [...Array(12)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 rounded-full"
                style={{ 
                  backgroundColor: ["#8b5cf6", "#06b6d4", "#f59e0b", "#ef4444", "#22c55e"][i % 5],
                  left: "50%", top: "50%"
                }}
                initial={{ x: 0, y: 0, scale: 0 }}
                animate={{ 
                  x: Math.cos(i * 30 * Math.PI / 180) * 80,
                  y: Math.sin(i * 30 * Math.PI / 180) * 80 - 20,
                  scale: [0, 1, 0]
                }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.8 }}
              />
            ))}
          </AnimatePresence>
          <motion.button 
            whileTap={{ scale: 0.95 }}
            onClick={() => { setShowConfetti(true); setTimeout(() => setShowConfetti(false), 1000); }}
            className="px-8 py-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-white font-semibold"
          >
            🎉 Celebrate!
          </motion.button>
        </div>
      </div>
    </EffectCard>
  );
}

// Rotating Icon Button
function RotatingIconEffect() {
  return (
    <EffectCard title="Rotating Icon" description="Icon spins on hover" whenToUse="Great for refresh buttons, settings, or any action that implies rotation or change.">
      <div className="p-8 flex justify-center">
        <motion.button 
          whileHover="hover"
          className="flex items-center gap-2 px-6 py-3 rounded-xl bg-cyan-500 text-white font-semibold"
        >
          <motion.span variants={{ hover: { rotate: 360 } }} transition={{ duration: 0.5 }}>
            <Send className="w-5 h-5" />
          </motion.span>
          Refresh
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Typewriter Button
function TypewriterEffect() {
  const [text, setText] = useState("Click");
  const [isTyping, setIsTyping] = useState(false);
  
  const handleClick = () => {
    if (isTyping) return;
    setIsTyping(true);
    setText("");
    const newText = "Success!";
    let i = 0;
    const interval = setInterval(() => {
      setText(newText.slice(0, i + 1));
      i++;
      if (i >= newText.length) {
        clearInterval(interval);
        setTimeout(() => { setText("Click"); setIsTyping(false); }, 1500);
      }
    }, 100);
  };
  
  return (
    <EffectCard title="Typewriter" description="Text types on click" whenToUse="Use for confirmation buttons where you want to show a message after the action completes.">
      <div className="p-8 flex justify-center">
        <motion.button 
          onClick={handleClick}
          whileTap={{ scale: 0.95 }}
          className="px-8 py-4 rounded-xl bg-slate-800 border border-slate-600 text-white font-mono min-w-[140px]"
        >
          {text}<motion.span animate={{ opacity: [1, 0] }} transition={{ duration: 0.5, repeat: Infinity }}>|</motion.span>
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Underline Slide Button
function UnderlineSlideEffect() {
  return (
    <EffectCard title="Underline Slide" description="Animated underline" whenToUse="Ideal for text links, navigation items, or minimal button styles in clean interfaces.">
      <div className="p-8 flex justify-center">
        <button className="relative px-4 py-2 text-white font-semibold group">
          <span>Learn More</span>
          <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-violet-500 to-cyan-500 transition-all duration-300 group-hover:w-full" />
        </button>
      </div>
    </EffectCard>
  );
}

// Scale Up Button
function ScaleUpEffect() {
  return (
    <EffectCard title="Scale Up" description="Grows on hover" whenToUse="Simple and effective for any interactive element that needs subtle feedback on hover.">
      <div className="p-8 flex justify-center">
        <motion.button 
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          className="px-8 py-4 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 text-white font-semibold shadow-lg"
        >
          Scale Me
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Flip Card Button
function FlipCardEffect() {
  const [isFlipped, setIsFlipped] = useState(false);
  
  return (
    <EffectCard title="Flip Card" description="3D flip reveal" whenToUse="Great for reveal interactions, before/after states, or card selection interfaces.">
      <div className="p-8 flex justify-center perspective-1000">
        <motion.div
          className="relative w-32 h-16 cursor-pointer"
          style={{ transformStyle: "preserve-3d" }}
          animate={{ rotateY: isFlipped ? 180 : 0 }}
          onClick={() => setIsFlipped(!isFlipped)}
        >
          <div className="absolute inset-0 rounded-xl bg-violet-500 flex items-center justify-center text-white font-semibold backface-hidden">
            Front
          </div>
          <div 
            className="absolute inset-0 rounded-xl bg-cyan-500 flex items-center justify-center text-white font-semibold"
            style={{ transform: "rotateY(180deg)", backfaceVisibility: "hidden" }}
          >
            Back!
          </div>
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Shadow Pop Button
function ShadowPopEffect() {
  return (
    <EffectCard title="Shadow Pop" description="Shadow lifts on hover" whenToUse="Best for card-like buttons or elements that need to feel clickable and interactive.">
      <div className="p-8 flex justify-center">
        <motion.button 
          whileHover={{ y: -4, boxShadow: "0 20px 40px rgba(139, 92, 246, 0.3)" }}
          className="px-8 py-4 rounded-xl bg-violet-500 text-white font-semibold shadow-lg transition-shadow"
        >
          Lift Me
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Glitch Button
function GlitchButtonEffect() {
  return (
    <EffectCard title="Glitch Effect" description="Cyberpunk glitch animation" whenToUse="Perfect for tech/hacker themes, error states, or edgy brand aesthetics.">
      <div className="p-8 flex justify-center">
        <motion.button 
          className="relative px-8 py-4 rounded-xl bg-slate-900 border border-violet-500 text-violet-400 font-bold uppercase tracking-wider overflow-hidden group"
          whileHover="hover"
        >
          <span className="relative z-10">Glitch</span>
          <motion.span 
            className="absolute inset-0 flex items-center justify-center text-cyan-400 opacity-0"
            variants={{ hover: { x: [0, -2, 2, 0], opacity: [0, 0.8, 0.8, 0] } }}
            transition={{ duration: 0.2, repeat: Infinity }}
          >
            Glitch
          </motion.span>
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Elastic Button
function ElasticEffect() {
  return (
    <EffectCard title="Elastic" description="Bouncy spring animation" whenToUse="Great for playful interfaces, games, or when you want to add personality to interactions.">
      <div className="p-8 flex justify-center">
        <motion.button 
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.9 }}
          transition={{ type: "spring", stiffness: 400, damping: 10 }}
          className="px-8 py-4 rounded-xl bg-emerald-500 text-white font-semibold"
        >
          Bouncy!
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Morphing Button
function MorphingEffect() {
  const [isMorphed, setIsMorphed] = useState(false);
  
  return (
    <EffectCard title="Morphing Shape" description="Shape transforms on click" whenToUse="Ideal for state changes like follow/unfollow, add/remove, or expand/collapse actions.">
      <div className="p-8 flex justify-center">
        <motion.button 
          onClick={() => setIsMorphed(!isMorphed)}
          animate={{ borderRadius: isMorphed ? "50%" : "12px", width: isMorphed ? 56 : 140 }}
          className="h-14 bg-gradient-to-r from-violet-500 to-pink-500 text-white font-semibold flex items-center justify-center"
        >
          {isMorphed ? <Check className="w-6 h-6" /> : "Subscribe"}
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Spotlight Button
function SpotlightEffect() {
  return (
    <EffectCard title="Spotlight" description="Light follows cursor" whenToUse="Great for premium features, highlighted CTAs, or creating a sense of discovery.">
      <div className="p-8 flex justify-center">
        <motion.button 
          className="relative px-8 py-4 rounded-xl bg-slate-800 text-white font-semibold overflow-hidden"
          whileHover="hover"
        >
          <motion.div 
            className="absolute w-20 h-20 bg-white/20 rounded-full blur-xl"
            variants={{ hover: { x: [-40, 80], opacity: [0, 1, 0] } }}
            transition={{ duration: 0.8, repeat: Infinity }}
          />
          <span className="relative z-10">Spotlight</span>
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Text Scramble Button
function TextScrambleEffect() {
  const [text, setText] = useState("DECODE");
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  
  const scramble = () => {
    let iterations = 0;
    const interval = setInterval(() => {
      setText(prev => prev.split("").map((char, i) => 
        i < iterations ? "DECODE"[i] : chars[Math.floor(Math.random() * chars.length)]
      ).join(""));
      iterations += 0.5;
      if (iterations > 6) clearInterval(interval);
    }, 50);
  };
  
  return (
    <EffectCard title="Text Scramble" description="Matrix-style text effect" whenToUse="Perfect for tech themes, password/security features, or creating mystery/intrigue.">
      <div className="p-8 flex justify-center">
        <button 
          onMouseEnter={scramble}
          className="px-8 py-4 rounded-xl bg-slate-900 border border-green-500 text-green-400 font-mono font-bold tracking-widest"
        >
          {text}
        </button>
      </div>
    </EffectCard>
  );
}

// Particle Trail Button
function ParticleTrailEffect() {
  const [particles, setParticles] = useState([]);
  
  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const id = Date.now();
    setParticles(prev => [...prev.slice(-10), { id, x: e.clientX - rect.left, y: e.clientY - rect.top }]);
  };
  
  return (
    <EffectCard title="Particle Trail" description="Sparkles follow cursor" whenToUse="Great for magical/fantasy themes, premium features, or adding delight to interactions.">
      <div className="p-8 flex justify-center">
        <motion.button 
          onMouseMove={handleMouseMove}
          onMouseLeave={() => setParticles([])}
          className="relative px-8 py-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-white font-semibold overflow-hidden"
        >
          {particles.map(p => (
            <motion.div
              key={p.id}
              className="absolute w-2 h-2 bg-white rounded-full pointer-events-none"
              style={{ left: p.x, top: p.y }}
              initial={{ scale: 1, opacity: 1 }}
              animate={{ scale: 0, opacity: 0 }}
              transition={{ duration: 0.5 }}
            />
          ))}
          <span className="relative z-10">✨ Magic</span>
        </motion.button>
      </div>
    </EffectCard>
  );
}

// ===== 20 MORE NEW BUTTON EFFECTS =====

// Radar Ping Button
function RadarPingEffect() {
  return (
    <EffectCard title="Radar Ping" description="Pulsing radar animation" whenToUse="Location-based apps, notifications, or showing something is active/live.">
      <div className="p-8 flex justify-center">
        <div className="relative">
          <motion.div className="absolute inset-0 rounded-full bg-green-500/30" animate={{ scale: [1, 2.5], opacity: [0.6, 0] }} transition={{ duration: 1.5, repeat: Infinity }} />
          <motion.div className="absolute inset-0 rounded-full bg-green-500/30" animate={{ scale: [1, 2.5], opacity: [0.6, 0] }} transition={{ duration: 1.5, repeat: Infinity, delay: 0.5 }} />
          <button className="relative px-6 py-3 rounded-full bg-green-500 text-white font-semibold z-10">Live Now</button>
        </div>
      </div>
    </EffectCard>
  );
}

// Swipe to Action
function SwipeActionEffect() {
  const [swiped, setSwiped] = useState(false);
  return (
    <EffectCard title="Swipe Action" description="Drag to confirm" whenToUse="Delete confirmations, unlock actions, or important irreversible operations.">
      <div className="p-8 flex justify-center">
        <div className="relative w-56 h-12 rounded-full bg-slate-800 overflow-hidden">
          <span className="absolute inset-0 flex items-center justify-center text-slate-500 text-sm">Swipe to confirm →</span>
          <motion.div
            drag="x"
            dragConstraints={{ left: 0, right: 160 }}
            dragElastic={0}
            onDragEnd={(e, info) => { if (info.offset.x > 120) setSwiped(true); }}
            className={`absolute left-1 top-1 w-10 h-10 rounded-full ${swiped ? "bg-green-500" : "bg-violet-500"} flex items-center justify-center cursor-grab z-10`}
          >
            {swiped ? <Check className="w-5 h-5 text-white" /> : <span className="text-white">→</span>}
          </motion.div>
          {swiped && <motion.div initial={{ width: 0 }} animate={{ width: "100%" }} className="absolute inset-0 bg-green-500/20" />}
        </div>
      </div>
    </EffectCard>
  );
}

// Double Click Button
function DoubleClickEffect() {
  const [clicks, setClicks] = useState(0);
  const [confirmed, setConfirmed] = useState(false);
  
  const handleClick = () => {
    if (clicks === 0) {
      setClicks(1);
      setTimeout(() => setClicks(0), 2000);
    } else {
      setConfirmed(true);
      setTimeout(() => { setConfirmed(false); setClicks(0); }, 2000);
    }
  };
  
  return (
    <EffectCard title="Double Click" description="Two clicks to confirm" whenToUse="Dangerous actions like delete, or when you want to prevent accidental clicks.">
      <div className="p-8 flex justify-center">
        <motion.button onClick={handleClick} whileTap={{ scale: 0.95 }} className={`px-6 py-3 rounded-xl font-semibold ${confirmed ? "bg-green-500 text-white" : clicks === 1 ? "bg-amber-500 text-white" : "bg-red-500 text-white"}`}>
          {confirmed ? "Confirmed!" : clicks === 1 ? "Click again" : "Delete"}
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Hold to Activate
function HoldButtonEffect() {
  const [progress, setProgress] = useState(0);
  const [activated, setActivated] = useState(false);
  const intervalRef = useRef(null);

  const startHold = () => {
    intervalRef.current = setInterval(() => {
      setProgress(p => {
        if (p >= 100) { clearInterval(intervalRef.current); setActivated(true); return 100; }
        return p + 5;
      });
    }, 50);
  };
  
  const stopHold = () => {
    clearInterval(intervalRef.current);
    if (!activated) setProgress(0);
  };

  return (
    <EffectCard title="Hold to Activate" description="Press and hold" whenToUse="Emergency actions, power buttons, or confirming critical operations.">
      <div className="p-8 flex justify-center">
        <motion.button
          onMouseDown={startHold}
          onMouseUp={stopHold}
          onMouseLeave={stopHold}
          className={`relative px-8 py-4 rounded-xl font-semibold overflow-hidden ${activated ? "bg-green-500" : "bg-red-500"} text-white`}
        >
          <motion.div className="absolute inset-0 bg-white/30" style={{ width: `${progress}%` }} />
          <span className="relative z-10">{activated ? "Activated!" : "Hold Me"}</span>
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Countdown Button
function CountdownEffect() {
  const [counting, setCounting] = useState(false);
  const [count, setCount] = useState(3);
  
  const startCountdown = () => {
    setCounting(true);
    setCount(3);
    const interval = setInterval(() => {
      setCount(c => {
        if (c <= 1) { clearInterval(interval); setCounting(false); return 3; }
        return c - 1;
      });
    }, 1000);
  };

  return (
    <EffectCard title="Countdown" description="3-2-1 animation" whenToUse="Launch actions, game starts, or building anticipation before an action.">
      <div className="p-8 flex justify-center">
        <motion.button onClick={!counting ? startCountdown : undefined} whileTap={{ scale: 0.95 }} className="px-8 py-4 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 text-white font-semibold min-w-[120px]">
          <AnimatePresence mode="wait">
            <motion.span key={counting ? count : "launch"} initial={{ scale: 2, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0, opacity: 0 }}>
              {counting ? count : "Launch!"}
            </motion.span>
          </AnimatePresence>
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Squeeze Button
function SqueezeEffect() {
  return (
    <EffectCard title="Squeeze" description="Squishes horizontally" whenToUse="Playful interfaces, cartoon-style UIs, or when you want exaggerated feedback.">
      <div className="p-8 flex justify-center">
        <motion.button whileHover={{ scaleX: 1.1, scaleY: 0.9 }} whileTap={{ scaleX: 0.8, scaleY: 1.2 }} transition={{ type: "spring", stiffness: 400 }} className="px-8 py-4 rounded-xl bg-pink-500 text-white font-semibold">
          Squeeze Me!
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Jelly Wobble
function JellyWobbleEffect() {
  return (
    <EffectCard title="Jelly Wobble" description="Wobbly bounce animation" whenToUse="Fun/casual apps, games, or adding personality to interactions.">
      <div className="p-8 flex justify-center">
        <motion.button whileTap={{ scale: [1, 0.9, 1.1, 0.95, 1.05, 1] }} transition={{ duration: 0.5 }} className="px-8 py-4 rounded-xl bg-purple-500 text-white font-semibold">
          Wobbly!
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Color Cycle Button
function ColorCycleEffect() {
  const colors = ["from-red-500 to-orange-500", "from-orange-500 to-yellow-500", "from-yellow-500 to-green-500", "from-green-500 to-blue-500", "from-blue-500 to-purple-500", "from-purple-500 to-red-500"];
  const [colorIndex, setColorIndex] = useState(0);
  
  return (
    <EffectCard title="Color Cycle" description="Changes color on click" whenToUse="Theme selection, mood indicators, or visual feedback for repeated actions.">
      <div className="p-8 flex justify-center">
        <motion.button onClick={() => setColorIndex((colorIndex + 1) % colors.length)} whileTap={{ scale: 0.95 }} className={`px-8 py-4 rounded-xl bg-gradient-to-r ${colors[colorIndex]} text-white font-semibold transition-all duration-300`}>
          Click to Change
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Slot Machine Button
function SlotMachineEffect() {
  const emojis = ["🎰", "💎", "🍒", "⭐", "🔔", "7️⃣"];
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState(["🎰", "🎰", "🎰"]);
  
  const spin = () => {
    setSpinning(true);
    let count = 0;
    const interval = setInterval(() => {
      setResult([emojis[Math.floor(Math.random() * emojis.length)], emojis[Math.floor(Math.random() * emojis.length)], emojis[Math.floor(Math.random() * emojis.length)]]);
      count++;
      if (count > 10) { clearInterval(interval); setSpinning(false); }
    }, 100);
  };
  
  return (
    <EffectCard title="Slot Machine" description="Spin to win animation" whenToUse="Games, gamification elements, or randomized selections.">
      <div className="p-8 flex flex-col items-center gap-4">
        <div className="flex gap-2 text-3xl bg-slate-800 px-4 py-2 rounded-xl">{result.map((e, i) => <motion.span key={i} animate={spinning ? { y: [0, -10, 0] } : {}} transition={{ duration: 0.1, repeat: spinning ? Infinity : 0 }}>{e}</motion.span>)}</div>
        <motion.button onClick={spin} disabled={spinning} whileTap={{ scale: 0.95 }} className="px-6 py-2 rounded-lg bg-amber-500 text-white font-semibold">
          {spinning ? "Spinning..." : "SPIN"}
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Reveal Content Button
function RevealContentEffect() {
  const [revealed, setRevealed] = useState(false);
  
  return (
    <EffectCard title="Reveal Content" description="Expands to show content" whenToUse="Show more buttons, expandable FAQs, or hidden content sections.">
      <div className="p-8 flex justify-center">
        <motion.div animate={{ height: revealed ? "auto" : 48 }} className="overflow-hidden rounded-xl bg-slate-800">
          <button onClick={() => setRevealed(!revealed)} className="w-full px-6 py-3 bg-violet-500 text-white font-semibold flex items-center justify-center gap-2">
            {revealed ? "Hide" : "Show More"} <motion.span animate={{ rotate: revealed ? 180 : 0 }}>▼</motion.span>
          </button>
          <AnimatePresence>
            {revealed && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 text-slate-300 text-sm">
                Here's the hidden content that was revealed when you clicked the button!
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Soundwave Button
function SoundwaveEffect() {
  const [playing, setPlaying] = useState(false);
  
  return (
    <EffectCard title="Soundwave" description="Audio visualizer animation" whenToUse="Play/pause buttons, voice messages, or audio-related interactions.">
      <div className="p-8 flex justify-center">
        <button onClick={() => setPlaying(!playing)} className="flex items-center gap-3 px-6 py-3 rounded-xl bg-slate-800 text-white font-semibold">
          <div className="flex items-center gap-0.5 h-6">
            {[1, 2, 3, 4, 5].map(i => (
              <motion.div key={i} className="w-1 bg-violet-500 rounded-full" animate={playing ? { height: [8, 24, 8] } : { height: 8 }} transition={{ duration: 0.4, repeat: playing ? Infinity : 0, delay: i * 0.1 }} />
            ))}
          </div>
          {playing ? "Playing" : "Play"}
        </button>
      </div>
    </EffectCard>
  );
}

// Bookmark Fold Button
function BookmarkFoldEffect() {
  const [folded, setFolded] = useState(false);
  
  return (
    <EffectCard title="Bookmark Fold" description="Corner fold animation" whenToUse="Save/bookmark actions, page marking, or content saving features.">
      <div className="p-8 flex justify-center">
        <button onClick={() => setFolded(!folded)} className="relative w-32 h-12 bg-slate-800 text-white font-semibold rounded-lg overflow-hidden">
          <span className="relative z-10">{folded ? "Saved" : "Save"}</span>
          <motion.div animate={{ borderWidth: folded ? 20 : 0 }} className="absolute top-0 right-0 w-0 h-0 border-solid border-violet-500" style={{ borderColor: "transparent #8b5cf6 transparent transparent" }} />
        </button>
      </div>
    </EffectCard>
  );
}

// Liquid Button
function LiquidButtonEffect() {
  return (
    <EffectCard title="Liquid Blob" description="Morphing blob shape" whenToUse="Creative portfolios, artistic sites, or organic/natural themed interfaces.">
      <div className="p-8 flex justify-center">
        <motion.button className="px-8 py-4 bg-cyan-500 text-white font-semibold" style={{ borderRadius: "30% 70% 70% 30% / 30% 30% 70% 70%" }} animate={{ borderRadius: ["30% 70% 70% 30% / 30% 30% 70% 70%", "70% 30% 30% 70% / 70% 70% 30% 30%", "30% 70% 70% 30% / 30% 30% 70% 70%"] }} transition={{ duration: 4, repeat: Infinity }}>
          Liquid
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Stack Cards Button
function StackCardsEffect() {
  const [expanded, setExpanded] = useState(false);
  
  return (
    <EffectCard title="Stack Cards" description="Cards fan out on click" whenToUse="Social share buttons, action menus, or grouped action selection.">
      <div className="p-8 flex justify-center">
        <div className="relative h-16 w-32">
          {[2, 1, 0].map(i => (
            <motion.button key={i} animate={{ y: expanded ? i * -25 : 0, x: expanded ? i * 5 : 0, rotate: expanded ? i * 5 : 0 }} className={`absolute inset-0 rounded-xl font-semibold ${i === 0 ? "bg-violet-500 text-white" : i === 1 ? "bg-violet-600 text-white" : "bg-violet-700 text-white"}`} onClick={() => setExpanded(!expanded)} style={{ zIndex: 3 - i }}>
              {i === 0 && "Options"}
            </motion.button>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Neon Sign Flicker
function NeonFlickerEffect() {
  return (
    <EffectCard title="Neon Flicker" description="Flickering neon sign" whenToUse="Retro/vintage themes, bar/restaurant sites, or nostalgic aesthetics.">
      <div className="p-8 flex justify-center bg-slate-950 rounded-xl">
        <motion.button animate={{ opacity: [1, 0.8, 1, 0.9, 1, 0.7, 1], textShadow: ["0 0 10px #f0f, 0 0 20px #f0f", "0 0 5px #f0f, 0 0 10px #f0f", "0 0 10px #f0f, 0 0 20px #f0f"] }} transition={{ duration: 2, repeat: Infinity }} className="px-8 py-4 text-2xl font-bold text-pink-400 uppercase tracking-wider">
          Open
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Loading Dots Button
function LoadingDotsEffect() {
  const [loading, setLoading] = useState(false);
  
  const handleClick = () => {
    setLoading(true);
    setTimeout(() => setLoading(false), 3000);
  };
  
  return (
    <EffectCard title="Loading Dots" description="Animated ellipsis" whenToUse="Simple loading states, processing indicators, or waiting animations.">
      <div className="p-8 flex justify-center">
        <motion.button onClick={handleClick} disabled={loading} whileTap={{ scale: 0.95 }} className="px-8 py-3 rounded-xl bg-slate-700 text-white font-semibold min-w-[140px]">
          {loading ? (
            <span className="flex items-center justify-center gap-1">
              Wait
              {[0, 1, 2].map(i => <motion.span key={i} animate={{ y: [0, -5, 0] }} transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.2 }}>.</motion.span>)}
            </span>
          ) : "Submit"}
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Arrow Transform
function ArrowTransformEffect() {
  const [done, setDone] = useState(false);
  
  return (
    <EffectCard title="Arrow Transform" description="Arrow becomes checkmark" whenToUse="Send buttons, form submissions, or any action that completes a process.">
      <div className="p-8 flex justify-center">
        <motion.button onClick={() => { setDone(true); setTimeout(() => setDone(false), 2000); }} whileTap={{ scale: 0.95 }} className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold ${done ? "bg-green-500" : "bg-blue-500"} text-white`}>
          {done ? "Sent" : "Send"}
          <motion.svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2">
            <motion.path animate={done ? { d: "M4 10 L8 14 L16 6" } : { d: "M5 10 L15 10 M10 5 L15 10 L10 15" }} transition={{ duration: 0.3 }} />
          </motion.svg>
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Stretch Button
function StretchEffect() {
  const [stretched, setStretched] = useState(false);
  
  return (
    <EffectCard title="Stretch Expand" description="Button stretches wider" whenToUse="Adding items to lists, expanding selections, or revealing more options.">
      <div className="p-8 flex justify-center">
        <motion.button onClick={() => setStretched(!stretched)} animate={{ width: stretched ? 200 : 120 }} className="h-12 rounded-xl bg-teal-500 text-white font-semibold overflow-hidden">
          <motion.span animate={{ opacity: stretched ? 1 : 0 }} className="whitespace-nowrap">{stretched ? "Added to List!" : ""}</motion.span>
          <motion.span animate={{ opacity: stretched ? 0 : 1 }} className="whitespace-nowrap">{!stretched ? "Add" : ""}</motion.span>
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Heartbeat Button
function HeartbeatEffect() {
  return (
    <EffectCard title="Heartbeat" description="Pulsing heartbeat rhythm" whenToUse="Health apps, emotional CTAs, or showing something is alive/active.">
      <div className="p-8 flex justify-center">
        <motion.button animate={{ scale: [1, 1.05, 1, 1.05, 1] }} transition={{ duration: 1.2, repeat: Infinity, repeatDelay: 0.5 }} className="flex items-center gap-2 px-6 py-3 rounded-xl bg-red-500 text-white font-semibold">
          <Heart className="w-5 h-5 fill-current" /> Donate
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Shutter Button
function ShutterEffect() {
  const [captured, setCaptured] = useState(false);
  
  return (
    <EffectCard title="Camera Shutter" description="Photo capture animation" whenToUse="Camera apps, screenshot features, or any capture/record action.">
      <div className="p-8 flex justify-center">
        <motion.button onClick={() => { setCaptured(true); setTimeout(() => setCaptured(false), 500); }} className="relative w-16 h-16 rounded-full bg-white border-4 border-slate-700">
          <motion.div animate={{ scale: captured ? 0.5 : 1 }} transition={{ duration: 0.1 }} className="absolute inset-2 rounded-full bg-red-500" />
          {captured && <motion.div initial={{ opacity: 1 }} animate={{ opacity: 0 }} className="absolute inset-0 bg-white rounded-full" />}
        </motion.button>
      </div>
    </EffectCard>
  );
}

// ===== 15 SAVE BUTTON STYLES =====

// Save Style 1 - Checkmark Fill
function SaveStyle1() {
  const [saved, setSaved] = useState(false);
  return (
    <EffectCard title="Save - Checkmark Fill" description="Green checkmark fills on save">
      <div className="p-8 flex justify-center">
        <motion.button onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 2000); }} className={`relative px-6 py-3 rounded-xl font-semibold overflow-hidden ${saved ? "bg-green-500" : "bg-violet-500"} text-white min-w-[140px]`}>
          {saved ? <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} className="flex items-center gap-2"><Check className="w-5 h-5" /> Saved!</motion.span> : <span className="flex items-center gap-2"><Save className="w-5 h-5" /> Save</span>}
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Save Style 2 - Upload Arrow
function SaveStyle2() {
  const [saving, setSaving] = useState(false);
  return (
    <EffectCard title="Save - Upload Arrow" description="Arrow animates upward">
      <div className="p-8 flex justify-center">
        <motion.button onClick={() => { setSaving(true); setTimeout(() => setSaving(false), 2000); }} className="px-6 py-3 rounded-xl bg-blue-500 text-white font-semibold flex items-center gap-2 min-w-[140px] justify-center">
          <motion.div animate={saving ? { y: [-20, 0] } : {}} transition={{ duration: 0.5 }}><ArrowUp className="w-5 h-5" /></motion.div>
          {saving ? "Saving..." : "Save"}
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Save Style 3 - Progress Bar
function SaveStyle3() {
  const [progress, setProgress] = useState(0);
  const handleSave = () => {
    setProgress(0);
    const interval = setInterval(() => {
      setProgress(p => { if (p >= 100) { clearInterval(interval); setTimeout(() => setProgress(0), 1000); return 100; } return p + 10; });
    }, 100);
  };
  return (
    <EffectCard title="Save - Progress Bar" description="Filling progress indicator">
      <div className="p-8 flex justify-center">
        <button onClick={handleSave} className="relative px-6 py-3 rounded-xl bg-slate-800 text-white font-semibold overflow-hidden min-w-[140px]">
          <motion.div className="absolute inset-0 bg-violet-500" style={{ width: `${progress}%` }} />
          <span className="relative z-10">{progress === 100 ? "Saved!" : progress > 0 ? `${progress}%` : "Save"}</span>
        </button>
      </div>
    </EffectCard>
  );
}

// Save Style 4 - Spinner to Check
function SaveStyle4() {
  const [state, setState] = useState("idle");
  const handleSave = () => { setState("saving"); setTimeout(() => setState("saved"), 1500); setTimeout(() => setState("idle"), 3000); };
  return (
    <EffectCard title="Save - Spinner to Check" description="Loading spinner becomes checkmark">
      <div className="p-8 flex justify-center">
        <button onClick={handleSave} disabled={state !== "idle"} className={`px-6 py-3 rounded-xl font-semibold flex items-center gap-2 min-w-[140px] justify-center ${state === "saved" ? "bg-green-500" : "bg-violet-500"} text-white`}>
          {state === "saving" && <Loader2 className="w-5 h-5 animate-spin" />}
          {state === "saved" && <Check className="w-5 h-5" />}
          {state === "idle" && <Save className="w-5 h-5" />}
          {state === "idle" ? "Save" : state === "saving" ? "Saving..." : "Saved!"}
        </button>
      </div>
    </EffectCard>
  );
}

// Save Style 5 - Cloud Upload
function SaveStyle5() {
  const [uploading, setUploading] = useState(false);
  return (
    <EffectCard title="Save - Cloud Upload" description="Cloud icon moves up">
      <div className="p-8 flex justify-center">
        <button onClick={() => { setUploading(true); setTimeout(() => setUploading(false), 2000); }} className="px-6 py-3 rounded-xl bg-cyan-500 text-white font-semibold flex items-center gap-2">
          <motion.div animate={uploading ? { y: [-10, 0] } : {}} transition={{ duration: 0.5, repeat: uploading ? Infinity : 0 }}><Cloud className="w-5 h-5" /></motion.div>
          {uploading ? "Uploading..." : "Save to Cloud"}
        </button>
      </div>
    </EffectCard>
  );
}

// Save Style 6 - Floppy Disk Icon
function SaveStyle6() {
  const [saving, setSaving] = useState(false);
  return (
    <EffectCard title="Save - Floppy Disk" description="Retro floppy disk spin">
      <div className="p-8 flex justify-center">
        <button onClick={() => { setSaving(true); setTimeout(() => setSaving(false), 1500); }} className="px-6 py-3 rounded-xl bg-slate-700 text-white font-semibold flex items-center gap-2">
          <motion.div animate={saving ? { rotate: 360 } : {}} transition={{ duration: 0.5 }}>💾</motion.div>
          {saving ? "Saving..." : "Save"}
        </button>
      </div>
    </EffectCard>
  );
}

// Save Style 7 - Pulse Success
function SaveStyle7() {
  const [saved, setSaved] = useState(false);
  return (
    <EffectCard title="Save - Pulse Success" description="Success pulse animation">
      <div className="p-8 flex justify-center">
        <div className="relative">
          {saved && <motion.div className="absolute inset-0 rounded-xl bg-green-500" animate={{ scale: [1, 1.5], opacity: [0.5, 0] }} transition={{ duration: 0.6 }} />}
          <button onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 2000); }} className={`relative px-6 py-3 rounded-xl font-semibold ${saved ? "bg-green-500" : "bg-violet-500"} text-white`}>
            {saved ? "✓ Saved!" : "Save"}
          </button>
        </div>
      </div>
    </EffectCard>
  );
}

// Save Style 8 - Slide Drawer
function SaveStyle8() {
  const [saving, setSaving] = useState(false);
  return (
    <EffectCard title="Save - Slide Drawer" description="Text slides in drawer">
      <div className="p-8 flex justify-center">
        <button onClick={() => { setSaving(true); setTimeout(() => setSaving(false), 2000); }} className="relative px-6 py-3 rounded-xl bg-indigo-500 text-white font-semibold overflow-hidden">
          <motion.div animate={{ x: saving ? 0 : -100 }} className="flex items-center gap-2">
            <Loader2 className="w-5 h-5 animate-spin" /> Saving...
          </motion.div>
          <motion.div animate={{ x: saving ? 100 : 0 }} className="absolute inset-0 flex items-center justify-center">Save</motion.div>
        </button>
      </div>
    </EffectCard>
  );
}

// Save Style 9 - Flip Text
function SaveStyle9() {
  const [saved, setSaved] = useState(false);
  return (
    <EffectCard title="Save - Flip Text" description="3D text flip effect">
      <div className="p-8 flex justify-center">
        <motion.button onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 2000); }} style={{ perspective: 1000 }} className="px-6 py-3 rounded-xl bg-purple-500 text-white font-semibold">
          <motion.div animate={{ rotateX: saved ? 180 : 0 }} transition={{ duration: 0.6 }} style={{ transformStyle: "preserve-3d" }}>
            {saved ? "Saved!" : "Save"}
          </motion.div>
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Save Style 10 - Bookmark Drop
function SaveStyle10() {
  const [saved, setSaved] = useState(false);
  return (
    <EffectCard title="Save - Bookmark Drop" description="Bookmark icon drops down">
      <div className="p-8 flex justify-center">
        <button onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 2000); }} className="px-6 py-3 rounded-xl bg-amber-500 text-white font-semibold flex items-center gap-2">
          <motion.div animate={saved ? { y: [0, 5, 0] } : {}} transition={{ duration: 0.4 }}><Bookmark className={`w-5 h-5 ${saved ? "fill-current" : ""}`} /></motion.div>
          {saved ? "Bookmarked!" : "Save"}
        </button>
      </div>
    </EffectCard>
  );
}

// Save Style 11 - Download Bar
function SaveStyle11() {
  const [saving, setSaving] = useState(false);
  return (
    <EffectCard title="Save - Download Bar" description="Bottom progress bar">
      <div className="p-8 flex justify-center">
        <div className="relative">
          <button onClick={() => { setSaving(true); setTimeout(() => setSaving(false), 2000); }} className="px-6 py-3 rounded-xl bg-teal-500 text-white font-semibold">
            {saving ? "Saving..." : "Save"}
          </button>
          {saving && <motion.div className="absolute bottom-0 left-0 h-1 bg-white" initial={{ width: 0 }} animate={{ width: "100%" }} transition={{ duration: 2 }} />}
        </div>
      </div>
    </EffectCard>
  );
}

// Save Style 12 - Lock Secure
function SaveStyle12() {
  const [locked, setLocked] = useState(false);
  return (
    <EffectCard title="Save - Lock Secure" description="Lock icon secures save">
      <div className="p-8 flex justify-center">
        <button onClick={() => { setLocked(true); setTimeout(() => setLocked(false), 2000); }} className={`px-6 py-3 rounded-xl font-semibold flex items-center gap-2 ${locked ? "bg-emerald-500" : "bg-slate-700"} text-white`}>
          <motion.div animate={locked ? { rotate: [0, -10, 10, 0] } : {}} transition={{ duration: 0.5 }}><Lock className="w-5 h-5" /></motion.div>
          {locked ? "Secured!" : "Save Secure"}
        </button>
      </div>
    </EffectCard>
  );
}

// Save Style 13 - Ripple Success
function SaveStyle13() {
  const [saved, setSaved] = useState(false);
  return (
    <EffectCard title="Save - Ripple Success" description="Success ripple expands">
      <div className="p-8 flex justify-center">
        <div className="relative">
          {saved && [...Array(3)].map((_, i) => <motion.div key={i} className="absolute inset-0 rounded-xl border-2 border-green-500" initial={{ scale: 1, opacity: 0.6 }} animate={{ scale: 2, opacity: 0 }} transition={{ duration: 0.8, delay: i * 0.2 }} />)}
          <button onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 2000); }} className={`relative px-6 py-3 rounded-xl font-semibold ${saved ? "bg-green-500" : "bg-rose-500"} text-white z-10`}>
            {saved ? "Saved!" : "Save"}
          </button>
        </div>
      </div>
    </EffectCard>
  );
}

// Save Style 14 - Expanding Check
function SaveStyle14() {
  const [saved, setSaved] = useState(false);
  return (
    <EffectCard title="Save - Expanding Check" description="Checkmark expands out">
      <div className="p-8 flex justify-center">
        <button onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 2000); }} className={`px-6 py-3 rounded-xl font-semibold flex items-center gap-2 ${saved ? "bg-green-500" : "bg-blue-500"} text-white`}>
          {saved ? <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", bounce: 0.5 }}><Check className="w-5 h-5" /></motion.div> : <Save className="w-5 h-5" />}
          {saved ? "Saved!" : "Save"}
        </button>
      </div>
    </EffectCard>
  );
}

// Save Style 15 - Gradient Shift
function SaveStyle15() {
  const [saved, setSaved] = useState(false);
  return (
    <EffectCard title="Save - Gradient Shift" description="Gradient color transition">
      <div className="p-8 flex justify-center">
        <motion.button onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 2000); }} animate={{ background: saved ? "linear-gradient(to right, #10b981, #059669)" : "linear-gradient(to right, #8b5cf6, #7c3aed)" }} className="px-6 py-3 rounded-xl font-semibold text-white">
          {saved ? "Saved!" : "Save"}
        </motion.button>
      </div>
    </EffectCard>
  );
}

export default function ButtonEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <RippleEffect />, name: "Ripple" },
    { component: <FillAnimationEffect />, name: "Fill" },
    { component: <Press3DEffect />, name: "3D Press" },
    { component: <ShakeOnErrorEffect />, name: "Shake Error" },
    { component: <LoadingStateEffect />, name: "Loading State" },
    { component: <LikeButtonEffect />, name: "Like Button" },
    { component: <AddToCartEffect />, name: "Add to Cart" },
    { component: <DownloadProgressEffect />, name: "Download" },
    { component: <MagneticButtonEffect />, name: "Magnetic" },
    { component: <BorderAnimationEffect />, name: "Border Animation" },
    { component: <GlowButtonEffect />, name: "Glow" },
    { component: <IconButtonEffect />, name: "Icon Buttons" },
    { component: <ToggleButtonEffect />, name: "Toggle" },
    { component: <SplitButtonEffect />, name: "Split Button" },
    { component: <FABEffect />, name: "FAB" },
    // NEW BUTTONS
    { component: <NeonGlowEffect />, name: "Neon Glow" },
    { component: <LiquidFillEffect />, name: "Liquid Fill" },
    { component: <ShakeEffect />, name: "Shake" },
    { component: <GradientBorderEffect />, name: "Gradient Border" },
    { component: <SlideTextEffect />, name: "Slide Text" },
    { component: <PulseRingEffect />, name: "Pulse Ring" },
    { component: <NeumorphicEffect />, name: "Neumorphic" },
    { component: <ConfettiEffect />, name: "Confetti" },
    { component: <RotatingIconEffect />, name: "Rotating Icon" },
    { component: <TypewriterEffect />, name: "Typewriter" },
    { component: <UnderlineSlideEffect />, name: "Underline Slide" },
    { component: <ScaleUpEffect />, name: "Scale Up" },
    { component: <FlipCardEffect />, name: "Flip Card" },
    { component: <ShadowPopEffect />, name: "Shadow Pop" },
    { component: <GlitchButtonEffect />, name: "Glitch" },
    { component: <ElasticEffect />, name: "Elastic" },
    { component: <MorphingEffect />, name: "Morphing" },
    { component: <SpotlightEffect />, name: "Spotlight" },
    { component: <TextScrambleEffect />, name: "Text Scramble" },
    { component: <ParticleTrailEffect />, name: "Particle Trail" },
    // 20 MORE NEW BUTTONS
    { component: <RadarPingEffect />, name: "Radar Ping" },
    { component: <SwipeActionEffect />, name: "Swipe Action" },
    { component: <DoubleClickEffect />, name: "Double Click" },
    { component: <HoldButtonEffect />, name: "Hold to Activate" },
    { component: <CountdownEffect />, name: "Countdown" },
    { component: <SqueezeEffect />, name: "Squeeze" },
    { component: <JellyWobbleEffect />, name: "Jelly Wobble" },
    { component: <ColorCycleEffect />, name: "Color Cycle" },
    { component: <SlotMachineEffect />, name: "Slot Machine" },
    { component: <RevealContentEffect />, name: "Reveal Content" },
    { component: <SoundwaveEffect />, name: "Soundwave" },
    { component: <BookmarkFoldEffect />, name: "Bookmark Fold" },
    { component: <LiquidButtonEffect />, name: "Liquid Blob" },
    { component: <StackCardsEffect />, name: "Stack Cards" },
    { component: <NeonFlickerEffect />, name: "Neon Flicker" },
    { component: <LoadingDotsEffect />, name: "Loading Dots" },
    { component: <ArrowTransformEffect />, name: "Arrow Transform" },
    { component: <StretchEffect />, name: "Stretch Expand" },
    { component: <HeartbeatEffect />, name: "Heartbeat" },
    { component: <ShutterEffect />, name: "Camera Shutter" },
    // 15 SAVE BUTTON STYLES
    { component: <SaveStyle1 />, name: "Save - Checkmark Fill" },
    { component: <SaveStyle2 />, name: "Save - Upload Arrow" },
    { component: <SaveStyle3 />, name: "Save - Progress Bar" },
    { component: <SaveStyle4 />, name: "Save - Spinner to Check" },
    { component: <SaveStyle5 />, name: "Save - Cloud Upload" },
    { component: <SaveStyle6 />, name: "Save - Floppy Disk Icon" },
    { component: <SaveStyle7 />, name: "Save - Pulse Success" },
    { component: <SaveStyle8 />, name: "Save - Slide Drawer" },
    { component: <SaveStyle9 />, name: "Save - Flip Text" },
    { component: <SaveStyle10 />, name: "Save - Bookmark Drop" },
    { component: <SaveStyle11 />, name: "Save - Download Bar" },
    { component: <SaveStyle12 />, name: "Save - Lock Secure" },
    { component: <SaveStyle13 />, name: "Save - Ripple Success" },
    { component: <SaveStyle14 />, name: "Save - Expanding Check" },
    { component: <SaveStyle15 />, name: "Save - Gradient Shift" },
  ];

  const filtered = effects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={MousePointerClick} title="Button Effects" description="Interactive button animations and micro-interactions" gradient="#10b981" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">{filtered.map((effect, i) => <div key={i}>{effect.component}</div>)}</div>
      </div>
    </div>
  );
}