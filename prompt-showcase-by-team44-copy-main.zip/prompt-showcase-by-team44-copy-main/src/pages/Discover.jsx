import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Globe, Search, Heart, Eye, Copy, Check, User, Share2, TrendingUp, Clock, Wand2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import CategoryHeader from "@/components/effects/CategoryHeader";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

// Effect Preview Components
function NeonPreview() {
  return (
    <div className="relative w-full h-full bg-slate-950 flex items-center justify-center overflow-hidden">
      <motion.div
        animate={{ boxShadow: ["0 0 20px #ff00ff", "0 0 40px #00ffff", "0 0 20px #ff00ff"] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-cyan-500"
      >
        NEON
      </motion.div>
      <div className="absolute inset-0 bg-gradient-to-t from-purple-500/20 to-transparent" />
    </div>
  );
}

function VHSPreview() {
  return (
    <div className="relative w-full h-full bg-slate-900 overflow-hidden">
      <img src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=200&h=150&fit=crop" alt="Retro" className="w-full h-full object-cover opacity-80" />
      <div className="absolute inset-0" style={{ background: "repeating-linear-gradient(0deg, rgba(0,0,0,0.2) 0px, rgba(0,0,0,0.2) 1px, transparent 1px, transparent 2px)" }} />
      <motion.div animate={{ opacity: [0.1, 0.3, 0.1] }} transition={{ duration: 0.1, repeat: Infinity }} className="absolute inset-0 bg-red-500 mix-blend-multiply" style={{ clipPath: "inset(30% 0 60% 0)" }} />
    </div>
  );
}

function FadePreview() {
  const [show, setShow] = useState(true);
  useEffect(() => { const i = setInterval(() => setShow(s => !s), 2000); return () => clearInterval(i); }, []);
  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center">
      <AnimatePresence mode="wait">
        {show && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="w-16 h-16 rounded-xl bg-gradient-to-br from-pink-500 to-violet-500" />}
      </AnimatePresence>
    </div>
  );
}

function ParticlesPreview() {
  return (
    <div className="relative w-full h-full bg-gradient-to-b from-slate-900 to-slate-950 overflow-hidden">
      {[...Array(15)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-white rounded-full"
          style={{ left: `${Math.random() * 100}%` }}
          initial={{ y: -10, opacity: 0 }}
          animate={{ y: 150, opacity: [0, 1, 0] }}
          transition={{ duration: 2 + Math.random(), repeat: Infinity, delay: Math.random() * 2 }}
        />
      ))}
    </div>
  );
}

function ButtonPreview() {
  const [clicked, setClicked] = useState(false);
  return (
    <div className="w-full h-full bg-slate-900 flex items-center justify-center">
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => { setClicked(true); setTimeout(() => setClicked(false), 500); }}
        className="px-6 py-2 rounded-lg bg-gradient-to-r from-violet-500 to-cyan-500 text-white font-medium relative overflow-hidden"
      >
        {clicked && <motion.div initial={{ scale: 0 }} animate={{ scale: 4, opacity: 0 }} className="absolute inset-0 bg-white rounded-full" style={{ transformOrigin: "center" }} />}
        Click Me
      </motion.button>
    </div>
  );
}

function ChatPreview() {
  return (
    <div className="w-full h-full bg-slate-900 p-3 flex flex-col justify-end gap-2">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="self-start px-3 py-1.5 rounded-xl bg-slate-700 text-white text-xs">Hello!</motion.div>
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="self-end px-3 py-1.5 rounded-xl bg-violet-500 text-white text-xs">Hi there! 👋</motion.div>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }} className="self-start flex gap-1">
        {[0, 1, 2].map(i => <motion.div key={i} animate={{ y: [0, -3, 0] }} transition={{ duration: 0.5, repeat: Infinity, delay: i * 0.15 }} className="w-1.5 h-1.5 bg-slate-500 rounded-full" />)}
      </motion.div>
    </div>
  );
}

const effectPreviews = {
  "Neon Cyberpunk": NeonPreview,
  "Retro VHS Glitch": VHSPreview,
  "Smooth Page Fade": FadePreview,
  "Floating Particles": ParticlesPreview,
  "Magnetic Button": ButtonPreview,
  "Chat Bubble Bounce": ChatPreview,
};

export default function Discover() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filter, setFilter] = useState("trending");
  const [copiedId, setCopiedId] = useState(null);
  const [copiedPromptId, setCopiedPromptId] = useState(null);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const isAuth = await base44.auth.isAuthenticated();
        if (isAuth) setUser(await base44.auth.me());
      } catch (e) {}
    };
    checkAuth();
  }, []);

  const { data: publicEffects = [] } = useQuery({
    queryKey: ['publicEffects'],
    queryFn: async () => [
      { id: 1, name: "Neon Cyberpunk", author: "Team44", views: 1234, likes: 89, code: `// Neon Cyberpunk Effect\nimport { motion } from "framer-motion";\n\nexport function NeonText() {\n  return (\n    <motion.div\n      animate={{ boxShadow: ["0 0 20px #ff00ff", "0 0 40px #00ffff"] }}\n      transition={{ duration: 2, repeat: Infinity }}\n      className="text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-cyan-500"\n    >\n      NEON\n    </motion.div>\n  );\n}`, prompt: "Create a neon cyberpunk text effect with glowing animation using Framer Motion", category: "visual" },
      { id: 2, name: "Retro VHS Glitch", author: "Team44", views: 890, likes: 67, code: `// VHS Glitch Effect\nexport function VHSEffect({ children }) {\n  return (\n    <div className="relative">\n      {children}\n      <div className="absolute inset-0" style={{\n        background: "repeating-linear-gradient(0deg, rgba(0,0,0,0.2) 0px, transparent 2px)"\n      }} />\n    </div>\n  );\n}`, prompt: "Create a retro VHS glitch effect with scanlines and color distortion", category: "visual" },
      { id: 3, name: "Smooth Page Fade", author: "Team44", views: 756, likes: 54, code: `// Page Fade Transition\nimport { AnimatePresence, motion } from "framer-motion";\n\nexport function PageFade({ children }) {\n  return (\n    <motion.div\n      initial={{ opacity: 0 }}\n      animate={{ opacity: 1 }}\n      exit={{ opacity: 0 }}\n    >\n      {children}\n    </motion.div>\n  );\n}`, prompt: "Create a smooth page fade transition effect using Framer Motion AnimatePresence", category: "transition" },
      { id: 4, name: "Floating Particles", author: "Team44", views: 623, likes: 48, code: `// Floating Particles\nexport function Particles({ count = 20 }) {\n  return Array.from({ length: count }).map((_, i) => (\n    <motion.div\n      key={i}\n      className="absolute w-2 h-2 bg-white rounded-full"\n      animate={{ y: [-10, 100], opacity: [0, 1, 0] }}\n      transition={{ duration: 3, repeat: Infinity, delay: i * 0.2 }}\n    />\n  ));\n}`, prompt: "Create floating snow particles animation that fall from top to bottom", category: "visual" },
      { id: 5, name: "Magnetic Button", author: "Team44", views: 512, likes: 41, code: `// Magnetic Button\nexport function MagneticButton({ children }) {\n  return (\n    <motion.button\n      whileHover={{ scale: 1.1 }}\n      whileTap={{ scale: 0.95 }}\n      className="px-6 py-2 bg-violet-500 rounded-lg text-white"\n    >\n      {children}\n    </motion.button>\n  );\n}`, prompt: "Create a magnetic button effect that scales on hover and shrinks on click", category: "button" },
      { id: 6, name: "Chat Bubble Bounce", author: "Team44", views: 445, likes: 35, code: `// Chat Bubble\nexport function ChatBubble({ message, isOwn }) {\n  return (\n    <motion.div\n      initial={{ opacity: 0, y: 10 }}\n      animate={{ opacity: 1, y: 0 }}\n      className={isOwn ? "bg-violet-500" : "bg-slate-700"}\n    >\n      {message}\n    </motion.div>\n  );\n}`, prompt: "Create animated chat bubbles that bounce in when appearing", category: "chat" },
    ]
  });

  const copyCode = async (effect) => {
    await navigator.clipboard.writeText(effect.code);
    setCopiedId(effect.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const copyPrompt = async (effect) => {
    await navigator.clipboard.writeText(effect.prompt);
    setCopiedPromptId(effect.id);
    setTimeout(() => setCopiedPromptId(null), 2000);
  };

  const filtered = publicEffects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div>
      <CategoryHeader icon={Globe} title="Discover Effects" description="Explore public effects shared by the community" gradient="#22c55e" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {!user && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mb-6 p-4 rounded-xl bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/20">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-3">
                <User className="w-5 h-5 text-green-400" />
                <div>
                  <p className="text-white font-medium">Share your creations</p>
                  <p className="text-slate-400 text-sm">Sign in to publish effects</p>
                </div>
              </div>
              <Button onClick={() => base44.auth.redirectToLogin()} className="bg-gradient-to-r from-green-500 to-emerald-500">Sign In</Button>
            </div>
          </motion.div>
        )}

        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <Input type="text" placeholder="Search effects..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-12 py-6 bg-slate-900/50 border-slate-700 text-white rounded-xl" />
          </div>
          <div className="flex gap-2">
            <Button variant={filter === "trending" ? "default" : "outline"} onClick={() => setFilter("trending")} className={filter === "trending" ? "bg-green-500" : ""}><TrendingUp className="w-4 h-4 mr-2" /> Trending</Button>
            <Button variant={filter === "recent" ? "default" : "outline"} onClick={() => setFilter("recent")} className={filter === "recent" ? "bg-green-500" : ""}><Clock className="w-4 h-4 mr-2" /> Recent</Button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: "Public Effects", value: publicEffects.length, icon: Globe },
            { label: "Total Views", value: publicEffects.reduce((a, e) => a + e.views, 0).toLocaleString(), icon: Eye },
            { label: "Total Likes", value: publicEffects.reduce((a, e) => a + e.likes, 0), icon: Heart },
            { label: "Contributors", value: new Set(publicEffects.map(e => e.author)).size, icon: User },
          ].map((stat, i) => (
            <Card key={i} className="bg-slate-900/50 border-slate-800">
              <CardContent className="pt-4 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-green-500/20"><stat.icon className="w-5 h-5 text-green-400" /></div>
                <div><p className="text-2xl font-bold text-white">{stat.value}</p><p className="text-xs text-slate-400">{stat.label}</p></div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((effect, i) => {
            const PreviewComponent = effectPreviews[effect.name];
            return (
              <motion.div key={effect.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                <Card className="bg-slate-900/50 border-slate-800 hover:border-green-500/50 transition-all overflow-hidden">
                  <div className="h-32 overflow-hidden">
                    {PreviewComponent ? <PreviewComponent /> : (
                      <div className="w-full h-full bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center">
                        <Wand2 className="w-8 h-8 text-slate-600" />
                      </div>
                    )}
                  </div>
                  <CardContent className="pt-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-white">{effect.name}</h3>
                        <p className="text-xs text-slate-400">by {effect.author}</p>
                      </div>
                      <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 text-xs">{effect.category}</span>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-slate-400 mb-4">
                      <span className="flex items-center gap-1"><Eye className="w-3 h-3" /> {effect.views}</span>
                      <span className="flex items-center gap-1"><Heart className="w-3 h-3" /> {effect.likes}</span>
                    </div>
                    <div className="flex gap-2">
                      <motion.button onClick={() => copyCode(effect)} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} className="flex-1 h-9 rounded-lg border-2 border-cyan-500 relative overflow-hidden">
                        <motion.div className="absolute inset-0 bg-cyan-500" initial={{ width: "0%" }} animate={{ width: copiedId === effect.id ? "100%" : "0%" }} />
                        <span className={`relative z-10 flex items-center justify-center gap-1 text-xs font-medium ${copiedId === effect.id ? "text-white" : "text-cyan-400"}`}>
                          {copiedId === effect.id ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                          {copiedId === effect.id ? "Copied!" : "Code"}
                        </span>
                      </motion.button>
                      <motion.button onClick={() => copyPrompt(effect)} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} className="flex-1 h-9 rounded-lg border-2 border-purple-500 relative overflow-hidden">
                        <motion.div className="absolute inset-0 bg-purple-500" initial={{ width: "0%" }} animate={{ width: copiedPromptId === effect.id ? "100%" : "0%" }} />
                        <span className={`relative z-10 flex items-center justify-center gap-1 text-xs font-medium ${copiedPromptId === effect.id ? "text-white" : "text-purple-400"}`}>
                          {copiedPromptId === effect.id ? <Check className="w-3 h-3" /> : <Wand2 className="w-3 h-3" />}
                          {copiedPromptId === effect.id ? "Copied!" : "Prompt"}
                        </span>
                      </motion.button>
                      <Button size="sm" variant="outline" onClick={() => { navigator.clipboard.writeText(`${window.location.origin}/Discover?effect=${effect.id}`); }}><Share2 className="w-3 h-3" /></Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}