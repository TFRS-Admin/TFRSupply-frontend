import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Users, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import ToggleSwitch from "@/components/ui/toggle-switch";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// Walking Character - Cute Pixel Person
function WalkingCharacter() {
  const [isWalking, setIsWalking] = useState(true);

  return (
    <EffectCard title="Pixel Walker" description="Retro pixel art walking cycle" whenToUse="Great for loading screens, game UIs, or adding retro charm to your app." controls={
      <div className="flex items-center justify-between">
        <Label className="text-slate-300">Walking</Label>
        <ToggleSwitch checked={isWalking} onCheckedChange={setIsWalking} />
      </div>
    }>
      <div className="h-40 w-full flex items-end justify-center overflow-hidden bg-gradient-to-b from-indigo-900/30 to-slate-900">
        <motion.div
          animate={isWalking ? { x: [-150, 150] } : { x: 0 }}
          transition={{ duration: 4, repeat: Infinity, repeatType: "reverse", ease: "linear" }}
          className="relative mb-4"
        >
          {/* Cute character with face */}
          <div className="relative">
            {/* Hair */}
            <div className="absolute -top-2 left-1 w-8 h-3 bg-amber-700 rounded-t-full" />
            {/* Head */}
            <div className="w-10 h-10 rounded-lg bg-amber-200 relative">
              {/* Blush */}
              <div className="absolute bottom-2 left-0.5 w-2 h-1 bg-pink-300 rounded-full opacity-60" />
              <div className="absolute bottom-2 right-0.5 w-2 h-1 bg-pink-300 rounded-full opacity-60" />
              {/* Eyes */}
              <motion.div 
                animate={isWalking ? { scaleY: [1, 0.2, 1] } : {}}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute top-3 left-2 w-1.5 h-2 bg-slate-900 rounded-full" 
              />
              <motion.div 
                animate={isWalking ? { scaleY: [1, 0.2, 1] } : {}}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute top-3 right-2 w-1.5 h-2 bg-slate-900 rounded-full" 
              />
              {/* Smile */}
              <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-3 h-1.5 border-b-2 border-slate-700 rounded-b-full" />
            </div>
            {/* Body */}
            <div className="w-8 h-8 bg-violet-500 rounded-lg mx-auto mt-0.5" />
            {/* Arms */}
            <motion.div
              animate={isWalking ? { rotate: [-40, 40] } : { rotate: 0 }}
              transition={{ duration: 0.3, repeat: Infinity, repeatType: "reverse" }}
              className="absolute top-11 -left-1 w-3 h-1.5 bg-amber-200 rounded origin-right"
            />
            <motion.div
              animate={isWalking ? { rotate: [40, -40] } : { rotate: 0 }}
              transition={{ duration: 0.3, repeat: Infinity, repeatType: "reverse" }}
              className="absolute top-11 -right-1 w-3 h-1.5 bg-amber-200 rounded origin-left"
            />
            {/* Legs */}
            <div className="flex justify-center gap-0.5">
              <motion.div
                animate={isWalking ? { rotate: [-25, 25] } : { rotate: 0 }}
                transition={{ duration: 0.3, repeat: Infinity, repeatType: "reverse" }}
                className="w-3 h-6 bg-indigo-800 rounded-b origin-top"
              />
              <motion.div
                animate={isWalking ? { rotate: [25, -25] } : { rotate: 0 }}
                transition={{ duration: 0.3, repeat: Infinity, repeatType: "reverse" }}
                className="w-3 h-6 bg-indigo-800 rounded-b origin-top"
              />
            </div>
          </div>
        </motion.div>
        {/* Ground with grass */}
        <div className="absolute bottom-0 left-0 right-0 h-4 bg-emerald-800" />
        <div className="absolute bottom-3 left-0 right-0 flex justify-around">
          {[...Array(20)].map((_, i) => (
            <div key={i} className="w-1 h-2 bg-emerald-600 rounded-t" />
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Bouncing Blob Character - Slime Pet
function BouncingBlob() {
  const [mood, setMood] = useState("happy");
  const moods = { 
    happy: { emoji: "◠‿◠", color: "from-lime-400 to-emerald-500", glow: "lime" },
    sad: { emoji: "╥﹏╥", color: "from-blue-400 to-cyan-500", glow: "cyan" },
    angry: { emoji: "╬ಠ益ಠ", color: "from-red-400 to-orange-500", glow: "red" },
    surprised: { emoji: "◉_◉", color: "from-yellow-400 to-amber-500", glow: "amber" },
    sleepy: { emoji: "－_－", color: "from-purple-400 to-violet-500", glow: "violet" }
  };

  return (
    <EffectCard title="Slime Pet" description="Squishy slime with moods" whenToUse="Perfect for virtual pets, game characters, or status indicators with personality." controls={
      <div className="flex gap-2 flex-wrap">
        {Object.keys(moods).map(m => (
          <Button key={m} variant={mood === m ? "default" : "outline"} size="sm" onClick={() => setMood(m)} className="text-xs">
            {m}
          </Button>
        ))}
      </div>
    }>
      <div className="h-48 flex items-center justify-center bg-gradient-to-b from-slate-800 to-slate-900">
        <motion.div
          animate={{ y: [0, -25, 0], scaleY: [1, 1.15, 0.85, 1], scaleX: [1, 0.9, 1.1, 1] }}
          transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
          className="relative"
        >
          {/* Slime body with gradient */}
          <div 
            className={`w-28 h-24 rounded-[60%_60%_50%_50%] bg-gradient-to-b ${moods[mood].color} relative overflow-hidden`}
            style={{ boxShadow: `0 0 30px ${moods[mood].glow}40` }}
          >
            {/* Shine */}
            <div className="absolute top-3 left-3 w-6 h-4 bg-white/40 rounded-full rotate-[-30deg]" />
            <div className="absolute top-5 left-6 w-2 h-2 bg-white/30 rounded-full" />
            {/* Face */}
            <div className="absolute inset-0 flex items-center justify-center pt-2">
              <span className="text-xl font-bold text-slate-800 select-none">{moods[mood].emoji}</span>
            </div>
          </div>
          {/* Little antenna */}
          <motion.div
            animate={{ rotate: [-10, 10] }}
            transition={{ duration: 0.5, repeat: Infinity, repeatType: "reverse" }}
            className="absolute -top-3 left-1/2 -translate-x-1/2 w-1 h-4 bg-gradient-to-t from-emerald-400 to-lime-300 rounded-full origin-bottom"
          >
            <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-lime-300 rounded-full" />
          </motion.div>
          {/* Shadow */}
          <motion.div
            animate={{ scale: [1, 0.7, 1], opacity: [0.4, 0.2, 0.4] }}
            transition={{ duration: 1.2, repeat: Infinity }}
            className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-20 h-4 bg-black/40 rounded-full blur-md"
          />
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Pixel Sprite 8-Bit Character
function PixelSprite8Bit({ color = "#22c55e", name = "Hero" }) {
  const sprite = [
    [0,0,1,1,1,0,0,0],
    [0,1,1,1,1,1,0,0],
    [0,1,2,1,2,1,0,0],
    [0,1,1,1,1,1,0,0],
    [0,0,1,1,1,0,0,0],
    [0,1,1,3,1,1,0,0],
    [1,1,0,3,0,1,1,0],
    [0,0,1,0,1,0,0,0],
  ];
  const colors = ["transparent", color, "#fff", "#8b5cf6"];
  return (
    <div className="flex flex-col items-center">
      <motion.div className="grid gap-0" style={{ gridTemplateColumns: "repeat(8, 1fr)" }} animate={{ y: [0, -2, 0] }} transition={{ duration: 0.5, repeat: Infinity }}>
        {sprite.flat().map((p, i) => (<div key={i} className="w-3 h-3" style={{ backgroundColor: colors[p] }} />))}
      </motion.div>
      <p className="text-xs text-slate-400 mt-2 font-mono">{name}</p>
    </div>
  );
}

// Waving Robot - Cute Mech Friend
function WavingRobot() {
  const [isWaving, setIsWaving] = useState(true);
  const [isHappy, setIsHappy] = useState(true);

  return (
    <EffectCard title="Mech Buddy" description="Friendly robot companion" whenToUse="Great for AI assistant avatars, onboarding guides, or tech product mascots." controls={
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Label className="text-slate-300">Waving</Label>
          <ToggleSwitch checked={isWaving} onCheckedChange={setIsWaving} />
        </div>
        <Button size="sm" variant="outline" onClick={() => setIsHappy(!isHappy)}>
          {isHappy ? "😊" : "🤔"} Mood
        </Button>
      </div>
    }>
      <div className="h-52 flex items-center justify-center bg-gradient-to-b from-cyan-900/20 to-slate-900">
        <div className="relative">
          {/* Floating effect */}
          <motion.div
            animate={{ y: [0, -5, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            {/* Head with screen face */}
            <div className="w-24 h-20 bg-gradient-to-b from-slate-300 to-slate-400 rounded-2xl relative shadow-lg">
              {/* Screen face */}
              <div className="absolute inset-2 bg-slate-900 rounded-xl flex items-center justify-center overflow-hidden">
                {/* Scan line */}
                <motion.div
                  animate={{ y: [-20, 40] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="absolute w-full h-px bg-cyan-400/30"
                />
                {/* Eyes */}
                <div className="flex gap-4">
                  <motion.div
                    animate={isHappy ? { scaleY: [1, 0.2, 1] } : {}}
                    transition={{ duration: 3, repeat: Infinity }}
                    className={`w-3 h-4 ${isHappy ? "rounded-full bg-cyan-400" : "bg-cyan-400 rounded"}`}
                    style={!isHappy ? { clipPath: "polygon(50% 0%, 100% 100%, 0% 100%)" } : {}}
                  />
                  <motion.div
                    animate={isHappy ? { scaleY: [1, 0.2, 1] } : {}}
                    transition={{ duration: 3, repeat: Infinity }}
                    className={`w-3 h-4 ${isHappy ? "rounded-full bg-cyan-400" : "bg-cyan-400 rounded"}`}
                    style={!isHappy ? { clipPath: "polygon(50% 0%, 100% 100%, 0% 100%)" } : {}}
                  />
                </div>
              </div>
              {/* Ears/sensors */}
              <div className="absolute -left-2 top-1/2 -translate-y-1/2 w-2 h-6 bg-slate-400 rounded-l" />
              <div className="absolute -right-2 top-1/2 -translate-y-1/2 w-2 h-6 bg-slate-400 rounded-r" />
              {/* Antenna */}
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-1.5 h-4 bg-slate-400" />
              <motion.div
                animate={{ scale: [1, 1.3, 1], boxShadow: ["0 0 10px #22d3ee", "0 0 20px #22d3ee", "0 0 10px #22d3ee"] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="absolute -top-6 left-1/2 -translate-x-1/2 w-3 h-3 bg-cyan-400 rounded-full"
              />
            </div>
            {/* Neck */}
            <div className="w-4 h-2 bg-slate-500 mx-auto" />
            {/* Body */}
            <div className="w-28 h-24 bg-gradient-to-b from-slate-300 to-slate-400 rounded-2xl relative shadow-lg">
              {/* Chest plate */}
              <div className="absolute top-2 left-1/2 -translate-x-1/2 w-16 h-10 bg-slate-500 rounded-lg">
                <motion.div 
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="w-8 h-1 bg-cyan-400 rounded mx-auto mt-2"
                />
                <div className="flex justify-center gap-1 mt-2">
                  {[0,1,2].map(i => (
                    <motion.div
                      key={i}
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 0.5, repeat: Infinity, delay: i * 0.2 }}
                      className={`w-2 h-2 rounded-full ${i === 0 ? "bg-green-400" : i === 1 ? "bg-yellow-400" : "bg-red-400"}`}
                    />
                  ))}
                </div>
              </div>
            </div>
            {/* Arms */}
            <motion.div
              animate={isWaving ? { rotate: [-20, 70, -20] } : { rotate: -20 }}
              transition={{ duration: 0.6, repeat: isWaving ? Infinity : 0 }}
              className="absolute top-[88px] -right-6 origin-left"
            >
              <div className="w-7 h-4 bg-slate-400 rounded-lg" />
              <div className="w-4 h-4 bg-slate-300 rounded-lg ml-6 -mt-1" />
            </motion.div>
            <div className="absolute top-[88px] -left-10 flex">
              <div className="w-4 h-4 bg-slate-300 rounded-lg" />
              <div className="w-7 h-4 bg-slate-400 rounded-lg -ml-1" />
            </div>
          </motion.div>
          {/* Shadow */}
          <motion.div
            animate={{ scale: [1, 0.9, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-24 h-4 bg-black/30 rounded-full blur-md"
          />
        </div>
      </div>
    </EffectCard>
  );
}

// Dancing Emoji
function DancingEmoji() {
  const [emoji, setEmoji] = useState("💃");
  const emojis = ["💃", "🕺", "🎉", "⭐", "🔥"];

  return (
    <EffectCard title="Dancing Emoji" description="Animated emoji character" controls={
      <div className="flex gap-2">
        {emojis.map(e => <Button key={e} variant={emoji === e ? "default" : "outline"} size="sm" onClick={() => setEmoji(e)}>{e}</Button>)}
      </div>
    }>
      <div className="h-40 flex items-center justify-center">
        <motion.div
          animate={{
            y: [0, -20, 0],
            rotate: [0, -10, 10, -10, 0],
            scale: [1, 1.1, 1]
          }}
          transition={{ duration: 1, repeat: Infinity }}
          className="text-6xl"
        >
          {emoji}
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Swimming Fish
function SwimmingFish() {
  return (
    <EffectCard title="Swimming Fish" description="Ocean scene with fish">
      <div className="h-40 w-full overflow-hidden relative bg-gradient-to-b from-cyan-600/30 to-blue-900/50 rounded-xl">
        {/* Bubbles */}
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            animate={{ y: [100, -20], opacity: [0, 1, 0] }}
            transition={{ duration: 3, repeat: Infinity, delay: i * 0.5 }}
            className="absolute w-2 h-2 bg-white/30 rounded-full"
            style={{ left: `${20 + i * 15}%` }}
          />
        ))}
        {/* Fish */}
        {[0, 1, 2].map(i => (
          <motion.div
            key={i}
            animate={{ x: [-50, 350] }}
            transition={{ duration: 5 + i, repeat: Infinity, delay: i * 1.5, ease: "linear" }}
            className="absolute"
            style={{ top: `${30 + i * 20}%` }}
          >
            <div className={`relative ${i === 1 ? "scale-125" : i === 2 ? "scale-75" : ""}`}>
              <div className={`w-8 h-4 ${["bg-orange-400", "bg-yellow-400", "bg-pink-400"][i]} rounded-full`} />
              <div className={`absolute top-0 -right-2 w-0 h-0 border-t-[8px] border-t-transparent border-b-[8px] border-b-transparent border-l-[10px] ${["border-l-orange-400", "border-l-yellow-400", "border-l-pink-400"][i]}`} />
              <div className="absolute top-1 left-1 w-1.5 h-1.5 bg-white rounded-full" />
            </div>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// 8-Bit Character Gallery
function PixelCharacterGallery8Bit() {
  const characters = [
    { sprite: [[0,0,1,1,0,0],[0,1,2,2,1,0],[1,1,1,1,1,1],[0,1,3,3,1,0],[0,1,0,0,1,0],[0,1,0,0,1,0]], color: "#22c55e", name: "Warrior" },
    { sprite: [[0,1,1,1,1,0],[1,2,1,1,2,1],[1,1,1,1,1,1],[0,1,3,3,1,0],[0,0,1,1,0,0],[0,1,0,0,1,0]], color: "#3b82f6", name: "Mage" },
    { sprite: [[0,0,1,1,0,0],[0,1,2,2,1,0],[0,1,1,1,1,0],[1,1,3,3,1,1],[0,1,0,0,1,0],[1,0,0,0,0,1]], color: "#f59e0b", name: "Archer" },
  ];
  return (
    <div className="h-48 flex items-center justify-center gap-8 bg-slate-950 rounded-lg">
      {characters.map((char, idx) => (
        <motion.div key={idx} animate={{ y: [0, -3, 0] }} transition={{ duration: 0.6, repeat: Infinity, delay: idx * 0.2 }} className="flex flex-col items-center">
          <div className="grid gap-0" style={{ gridTemplateColumns: "repeat(6, 1fr)" }}>
            {char.sprite.flat().map((p, i) => (<div key={i} className="w-3 h-3" style={{ backgroundColor: p === 0 ? "transparent" : p === 1 ? char.color : p === 2 ? "#fff" : "#8b5cf6" }} />))}
          </div>
          <p className="text-xs mt-2" style={{ color: char.color }}>{char.name}</p>
        </motion.div>
      ))}
    </div>
  );
}

// Ghost Float - Friendly Spirit
function GhostFloat() {
  const [scared, setScared] = useState(false);
  
  return (
    <EffectCard title="Friendly Spirit" description="Adorable ghost with emotions" whenToUse="Halloween themes, spooky features, or whimsical UI elements.">
      <div className="h-48 flex items-center justify-center bg-gradient-to-b from-slate-800 to-indigo-950" onClick={() => setScared(!scared)}>
        <motion.div
          animate={{ 
            y: [0, -15, 0], 
            x: scared ? [0, -30, 30, -20, 20, 0] : [-5, 5, -5],
            rotate: scared ? [0, -10, 10, -5, 5, 0] : 0
          }}
          transition={{ 
            duration: scared ? 0.5 : 3, 
            repeat: scared ? 0 : Infinity, 
            ease: "easeInOut" 
          }}
          className="relative cursor-pointer"
        >
          {/* Glow */}
          <div className="absolute inset-0 bg-white/20 rounded-full blur-xl scale-125" />
          {/* Body */}
          <div className="w-20 h-24 bg-gradient-to-b from-white to-blue-50 rounded-t-full relative shadow-lg">
            {/* Rosy cheeks */}
            <div className="absolute top-10 left-1 w-3 h-2 bg-pink-200 rounded-full opacity-60" />
            <div className="absolute top-10 right-1 w-3 h-2 bg-pink-200 rounded-full opacity-60" />
            {/* Eyes */}
            <motion.div
              animate={scared ? { scaleY: 2, y: -2 } : { scaleY: [1, 0.1, 1] }}
              transition={{ duration: scared ? 0.1 : 4, repeat: scared ? 0 : Infinity }}
              className="absolute top-6 left-4 w-3 h-3 bg-slate-800 rounded-full"
            />
            <motion.div
              animate={scared ? { scaleY: 2, y: -2 } : { scaleY: [1, 0.1, 1] }}
              transition={{ duration: scared ? 0.1 : 4, repeat: scared ? 0 : Infinity }}
              className="absolute top-6 right-4 w-3 h-3 bg-slate-800 rounded-full"
            />
            {/* Eye shine */}
            <div className="absolute top-6 left-5 w-1 h-1 bg-white rounded-full" />
            <div className="absolute top-6 right-5 w-1 h-1 bg-white rounded-full" />
            {/* Mouth */}
            {scared ? (
              <div className="absolute bottom-5 left-1/2 -translate-x-1/2 w-4 h-4 border-2 border-slate-800 rounded-full" />
            ) : (
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-5 h-3 border-b-2 border-slate-800 rounded-b-full" />
            )}
            {/* Little arms */}
            <motion.div
              animate={{ rotate: scared ? 60 : [0, 15, 0] }}
              transition={{ duration: scared ? 0.1 : 2, repeat: scared ? 0 : Infinity }}
              className="absolute top-12 -left-2 w-4 h-2 bg-white rounded-full origin-right"
            />
            <motion.div
              animate={{ rotate: scared ? -60 : [0, -15, 0] }}
              transition={{ duration: scared ? 0.1 : 2, repeat: scared ? 0 : Infinity }}
              className="absolute top-12 -right-2 w-4 h-2 bg-white rounded-full origin-left"
            />
          </div>
          {/* Wavy bottom with transparency */}
          <div className="flex -mt-1">
            {[0, 1, 2, 3, 4].map(i => (
              <motion.div
                key={i}
                animate={{ y: [0, 4, 0], opacity: [0.9, 0.6, 0.9] }}
                transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.15 }}
                className="w-4 h-5 bg-gradient-to-b from-blue-50 to-transparent rounded-b-full"
              />
            ))}
          </div>
        </motion.div>
        <p className="absolute bottom-2 text-xs text-slate-500">Click to scare!</p>
      </div>
    </EffectCard>
  );
}

// 16-Bit Character Gallery  
function PixelCharacterGallery16Bit() {
  const characters = [
    { name: "Knight", color: "#6366f1" },
    { name: "Ninja", color: "#1f2937" },
    { name: "Healer", color: "#10b981" },
  ];
  return (
    <div className="h-48 flex items-center justify-center gap-6 bg-gradient-to-b from-slate-900 to-slate-950 rounded-lg">
      {characters.map((char, idx) => (
        <motion.div key={idx} animate={{ y: [0, -4, 0] }} transition={{ duration: 0.8, repeat: Infinity, delay: idx * 0.15 }} className="flex flex-col items-center">
          <div className="w-12 h-16 rounded-lg relative overflow-hidden" style={{ backgroundColor: char.color }}>
            <div className="absolute top-2 left-2 w-3 h-3 bg-white rounded-full" />
            <div className="absolute top-2 right-2 w-3 h-3 bg-white rounded-full" />
            <div className="absolute top-3 left-2.5 w-2 h-2 bg-slate-900 rounded-full" />
            <div className="absolute top-3 right-2.5 w-2 h-2 bg-slate-900 rounded-full" />
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 w-4 h-2 bg-pink-400 rounded-full" />
          </div>
          <p className="text-xs mt-2 text-slate-300">{char.name}</p>
        </motion.div>
      ))}
    </div>
  );
}

// 32-Bit Character Gallery
function PixelCharacterGallery32Bit() {
  const characters = [
    { name: "Samurai", gradient: "from-red-500 to-orange-500" },
    { name: "Wizard", gradient: "from-violet-500 to-purple-500" },
    { name: "Rogue", gradient: "from-slate-600 to-slate-800" },
  ];
  return (
    <div className="h-48 flex items-center justify-center gap-6 bg-gradient-to-b from-slate-900 to-slate-950 rounded-lg">
      {characters.map((char, idx) => (
        <motion.div key={idx} animate={{ y: [0, -5, 0], rotate: [0, idx % 2 === 0 ? 2 : -2, 0] }} transition={{ duration: 1, repeat: Infinity, delay: idx * 0.2 }} className="flex flex-col items-center">
          <div className={`w-14 h-20 rounded-xl bg-gradient-to-b ${char.gradient} relative overflow-hidden shadow-lg`}>
            <div className="absolute top-3 left-2 w-4 h-4 bg-white rounded-full shadow" />
            <div className="absolute top-3 right-2 w-4 h-4 bg-white rounded-full shadow" />
            <div className="absolute top-4 left-3 w-2 h-2 bg-slate-900 rounded-full" />
            <div className="absolute top-4 right-3 w-2 h-2 bg-slate-900 rounded-full" />
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-5 h-2.5 bg-pink-300 rounded-full" />
            <div className="absolute bottom-0 left-0 right-0 h-6 bg-slate-800/50" />
          </div>
          <p className="text-xs mt-2 text-white font-medium">{char.name}</p>
        </motion.div>
      ))}
    </div>
  );
}

// Spinning Star Character
function SpinningStar() {
  return (
    <EffectCard title="Spinning Star" description="Happy star character">
      <div className="h-40 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360, scale: [1, 1.1, 1] }}
          transition={{ rotate: { duration: 4, repeat: Infinity, ease: "linear" }, scale: { duration: 1, repeat: Infinity } }}
          className="relative"
        >
          <div className="w-20 h-20 bg-yellow-400 flex items-center justify-center"
            style={{ clipPath: "polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)" }}>
          </div>
          {/* Face */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative -mt-2">
              <div className="flex gap-2 mb-1">
                <motion.div animate={{ scaleY: [1, 0.1, 1] }} transition={{ duration: 3, repeat: Infinity }} className="w-2 h-2 bg-slate-900 rounded-full" />
                <motion.div animate={{ scaleY: [1, 0.1, 1] }} transition={{ duration: 3, repeat: Infinity }} className="w-2 h-2 bg-slate-900 rounded-full" />
              </div>
              <div className="w-4 h-2 border-b-2 border-slate-900 rounded-b-full mx-auto" />
            </div>
          </div>
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Rocket Character
function RocketCharacter() {
  const [isFlying, setIsFlying] = useState(true);

  return (
    <EffectCard title="Flying Rocket" description="Animated rocket ship" controls={
      <Button onClick={() => setIsFlying(!isFlying)} variant="outline" className="w-full">
        {isFlying ? "Land" : "Launch!"}
      </Button>
    }>
      <div className="h-48 flex items-center justify-center overflow-hidden">
        <motion.div
          animate={isFlying ? { y: [-20, 20], x: [-5, 5] } : { y: 40 }}
          transition={{ duration: 2, repeat: isFlying ? Infinity : 0, repeatType: "reverse" }}
          className="relative"
        >
          {/* Rocket body */}
          <div className="w-12 h-24 bg-slate-200 rounded-t-full relative">
            {/* Window */}
            <div className="absolute top-6 left-1/2 -translate-x-1/2 w-6 h-6 bg-cyan-400 rounded-full border-2 border-slate-400" />
            {/* Stripes */}
            <div className="absolute bottom-4 left-0 right-0 h-2 bg-red-500" />
          </div>
          {/* Fins */}
          <div className="absolute bottom-0 -left-3 w-0 h-0 border-t-[20px] border-t-transparent border-r-[15px] border-r-red-500" />
          <div className="absolute bottom-0 -right-3 w-0 h-0 border-t-[20px] border-t-transparent border-l-[15px] border-l-red-500" />
          {/* Flames */}
          {isFlying && (
            <motion.div
              animate={{ scaleY: [1, 1.3, 1], opacity: [1, 0.7, 1] }}
              transition={{ duration: 0.2, repeat: Infinity }}
              className="absolute -bottom-8 left-1/2 -translate-x-1/2"
            >
              <div className="w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[30px] border-t-orange-500" />
              <div className="w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[20px] border-t-yellow-400 -mt-5 mx-auto" />
            </motion.div>
          )}
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Butterfly
function ButterflyEffect() {
  return (
    <EffectCard title="Butterfly" description="Fluttering butterfly">
      <div className="h-40 w-full overflow-hidden relative">
        <motion.div
          animate={{ x: [0, 100, 200, 100, 0], y: [50, 20, 60, 30, 50] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute left-10"
        >
          <div className="relative">
            {/* Left wings */}
            <motion.div
              animate={{ rotateY: [0, 60, 0] }}
              transition={{ duration: 0.3, repeat: Infinity }}
              className="absolute -left-4 top-0 origin-right"
            >
              <div className="w-4 h-6 bg-pink-400 rounded-full" />
              <div className="w-3 h-4 bg-pink-500 rounded-full -mt-1" />
            </motion.div>
            {/* Right wings */}
            <motion.div
              animate={{ rotateY: [0, -60, 0] }}
              transition={{ duration: 0.3, repeat: Infinity }}
              className="absolute -right-4 top-0 origin-left"
            >
              <div className="w-4 h-6 bg-pink-400 rounded-full" />
              <div className="w-3 h-4 bg-pink-500 rounded-full -mt-1" />
            </motion.div>
            {/* Body */}
            <div className="w-1 h-8 bg-slate-700 rounded-full" />
            {/* Antennae */}
            <div className="absolute -top-2 -left-1 w-0.5 h-3 bg-slate-700 rotate-[-20deg] origin-bottom" />
            <div className="absolute -top-2 left-0.5 w-0.5 h-3 bg-slate-700 rotate-[20deg] origin-bottom" />
          </div>
        </motion.div>
        {/* Flowers */}
        <div className="absolute bottom-0 left-0 right-0 h-8 flex justify-around items-end">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="relative">
              <div className="w-4 h-4 bg-yellow-400 rounded-full" />
              <div className="w-1 h-6 bg-green-500 mx-auto" />
            </div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

export default function CharacterEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <WalkingCharacter />, name: "Walking Character" },
    { component: <BouncingBlob />, name: "Bouncing Blob" },
    { component: <WavingRobot />, name: "Waving Robot" },
    { component: <DancingEmoji />, name: "Dancing Emoji" },
    { component: <SwimmingFish />, name: "Swimming Fish" },
    { component: <GhostFloat />, name: "Floating Ghost" },
    { component: <SpinningStar />, name: "Spinning Star" },
    { component: <RocketCharacter />, name: "Flying Rocket" },
    { component: <ButterflyEffect />, name: "Butterfly" },
    { component: <EffectCard title="8-Bit Characters" description="Classic pixel art sprites"><PixelCharacterGallery8Bit /></EffectCard>, name: "8-Bit Gallery" },
    { component: <EffectCard title="16-Bit Characters" description="Enhanced pixel sprites"><PixelCharacterGallery16Bit /></EffectCard>, name: "16-Bit Gallery" },
    { component: <EffectCard title="32-Bit Characters" description="Detailed character sprites"><PixelCharacterGallery32Bit /></EffectCard>, name: "32-Bit Gallery" },
  ];

  const filtered = effects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div>
      <CategoryHeader icon={Users} title="Animated Characters" description="Fun animated characters and mascots for your UI" gradient="#f59e0b" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((effect, i) => <div key={i}>{effect.component}</div>)}
        </div>
      </div>
    </div>
  );
}