import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Wand2, Copy, Check, Layers, Play, Pause, RefreshCw, Sparkles, Code, Bot, Loader2, Download, ChevronDown, ChevronUp, Eye, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import ToggleSwitch from "@/components/ui/toggle-switch";
import { Label } from "@/components/ui/label";
import CategoryHeader from "@/components/effects/CategoryHeader";
import { base44 } from "@/api/base44Client";
import ReactMarkdown from "react-markdown";
import { Textarea } from "@/components/ui/textarea";
import { useQuery } from "@tanstack/react-query";

const effectCategories = {
  visual: [
    { id: "vhs", name: "VHS/CRT", icon: "📺" },
    { id: "grain", name: "Film Grain", icon: "🎞️" },
    { id: "vignette", name: "Vignette", icon: "🔲" },
    { id: "blur", name: "Blur", icon: "💨" },
    { id: "duotone", name: "Duotone", icon: "🎨" },
    { id: "sepia", name: "Sepia", icon: "📜" },
    { id: "pixelate", name: "Pixelate", icon: "🔳" },
    { id: "glitch", name: "Glitch", icon: "⚡" },
  ],
  particles: [
    { id: "particles", name: "Particles", icon: "✨" },
    { id: "confetti", name: "Confetti", icon: "🎉" },
    { id: "bubbles", name: "Bubbles", icon: "🫧" },
    { id: "sparkles", name: "Sparkles", icon: "💫" },
    { id: "rain", name: "Rain", icon: "🌧️" },
    { id: "leaves", name: "Leaves", icon: "🍂" },
  ],
  glow: [
    { id: "glow", name: "Neon Glow", icon: "💜" },
    { id: "gradient", name: "Gradient Border", icon: "🌈" },
    { id: "holographic", name: "Holographic", icon: "🌈" },
    { id: "aurora", name: "Aurora", icon: "🌌" },
    { id: "spotlight", name: "Spotlight", icon: "🔦" },
    { id: "chromatic", name: "Chromatic", icon: "🔴" },
  ],
  motion: [
    { id: "shake", name: "Screen Shake", icon: "📳" },
    { id: "pulse", name: "Pulse", icon: "💗" },
    { id: "bounce", name: "Bounce", icon: "⬆️" },
    { id: "wave", name: "Wave", icon: "🌊" },
    { id: "rotate", name: "Rotate", icon: "🔄" },
    { id: "float", name: "Float", icon: "☁️" },
  ],
  overlay: [
    { id: "scanlines", name: "Scanlines", icon: "📺" },
    { id: "noise", name: "Noise", icon: "📡" },
    { id: "matrix", name: "Matrix Rain", icon: "🟢" },
    { id: "grid", name: "Grid", icon: "📐" },
    { id: "dots", name: "Dot Pattern", icon: "⚫" },
    { id: "lines", name: "Lines", icon: "➖" },
  ],
  text: [
    { id: "typewriter", name: "Typewriter", icon: "⌨️" },
    { id: "textGlow", name: "Text Glow", icon: "✨" },
    { id: "textGradient", name: "Text Gradient", icon: "🌈" },
    { id: "scramble", name: "Scramble", icon: "🔀" },
  ]
};

const moodPresets = {
  retro: { effects: ["vhs", "grain", "vignette"], desc: "80s/90s nostalgia" },
  futuristic: { effects: ["glow", "gradient", "particles"], desc: "Cyberpunk vibes" },
  calm: { effects: ["blur", "vignette", "particles"], desc: "Peaceful & serene" },
  energetic: { effects: ["shake", "glow", "gradient"], desc: "High energy" },
  dark: { effects: ["vignette", "grain"], desc: "Moody & dramatic" },
  playful: { effects: ["particles", "glow"], desc: "Fun & whimsical" }
};

function TutorialOverlay({ onClose }) {
  const [step, setStep] = useState(0);
  const steps = [
    { title: "Welcome! 👋", desc: "Let's build amazing effects together. This builder lets you combine multiple visual effects." },
    { title: "Step 1: Choose a Mood", desc: "Start by selecting a mood preset on the left. This auto-selects effects that work well together." },
    { title: "Step 2: Toggle Effects", desc: "Enable/disable individual effects. Each has its own settings you can customize." },
    { title: "Step 3: Adjust Settings", desc: "Tweak sliders and options to fine-tune each effect's intensity and behavior." },
    { title: "Step 4: Preview Live", desc: "Watch your combined effects in the preview. Use Play/Pause to control animations." },
    { title: "Step 5: Export", desc: "Copy the generated code, download it, or share via link. You're done!" }
  ];

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <motion.div initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-md w-full">
        <div className="flex gap-1 mb-6">
          {steps.map((_, i) => (
            <motion.div key={i} className={`h-1.5 flex-1 rounded-full ${i <= step ? "bg-gradient-to-r from-violet-500 to-cyan-500" : "bg-slate-700"}`} />
          ))}
        </div>
        <div className="text-center mb-6">
          <h3 className="text-2xl font-bold text-white mb-2">{steps[step].title}</h3>
          <p className="text-slate-400">{steps[step].desc}</p>
        </div>
        <div className="flex justify-between gap-4">
          <Button variant="outline" onClick={() => step > 0 ? setStep(step - 1) : onClose()} className="flex-1 text-blue-300 border-blue-300/50 hover:bg-blue-300/10">
            {step === 0 ? "Skip" : "Back"}
          </Button>
          <Button onClick={() => step < steps.length - 1 ? setStep(step + 1) : onClose()} className="flex-1 bg-gradient-to-r from-violet-500 to-cyan-500">
            {step === steps.length - 1 ? "Start Building!" : "Next"}
          </Button>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function EffectBuilder() {
  const [showTutorial, setShowTutorial] = useState(() => !localStorage.getItem('builderTutorialSeen'));
  const [activeEffects, setActiveEffects] = useState(["vhs"]);
  const [selectedMood, setSelectedMood] = useState(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [copied, setCopied] = useState(false);
  const [showCode, setShowCode] = useState(false);
  const [expandedCategory, setExpandedCategory] = useState("visual");
  const [aiPrompt, setAiPrompt] = useState("");
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [aiResult, setAiResult] = useState(null);

  const [settings, setSettings] = useState({
    vhs: { scanlines: true, noise: 30 },
    grain: { intensity: 25 },
    particles: { count: 25, type: "snow" },
    glow: { color: "#8b5cf6", pulse: true },
    blur: { amount: 4 },
    shake: { intensity: 4 },
    vignette: { intensity: 45 },
    gradient: { animate: true, speed: 3 },
    duotone: { color1: "#8b5cf6", color2: "#06b6d4" },
    sepia: { intensity: 80 },
    pixelate: { size: 8 },
    glitch: { intensity: 50 },
    confetti: { count: 30 },
    bubbles: { count: 20 },
    sparkles: { count: 15 },
    rain: { count: 40, speed: 2 },
    leaves: { count: 10 },
    holographic: { speed: 5 },
    aurora: { speed: 3 },
    spotlight: { size: 100 },
    chromatic: { offset: 3 },
    pulse: { speed: 1 },
    bounce: { height: 10 },
    wave: { amplitude: 10 },
    rotate: { speed: 5 },
    float: { distance: 10 },
    scanlines: { opacity: 30 },
    noise: { opacity: 20 },
    matrix: { speed: 2 },
    grid: { size: 20 },
    dots: { size: 4 },
    lines: { spacing: 10 },
    typewriter: { speed: 50 },
    textGlow: { color: "#8b5cf6" },
    textGradient: { colors: ["#8b5cf6", "#06b6d4"] },
    scramble: { speed: 30 }
  });

  useEffect(() => {
    if (!showTutorial) localStorage.setItem('builderTutorialSeen', 'true');
  }, [showTutorial]);

  const toggleEffect = (id) => {
    setActiveEffects(prev => prev.includes(id) ? prev.filter(e => e !== id) : [...prev, id]);
  };

  const applyMood = (moodId) => {
    setSelectedMood(moodId);
    setActiveEffects(moodPresets[moodId].effects);
  };

  const generateWithAI = async () => {
    if (!aiPrompt.trim()) return;
    setIsAiGenerating(true);
    setAiResult(null);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert UI effect designer. Based on this description: "${aiPrompt}"
        
Analyze the request and return a JSON with:
1. effects: array of effect IDs to enable from: vhs, grain, vignette, blur, particles, glow, gradient, shake
2. settings: object with settings for each effect
3. explanation: brief explanation of why these effects work together

Available settings per effect:
- vhs: { scanlines: boolean, noise: 0-100 }
- grain: { intensity: 0-100 }
- vignette: { intensity: 0-100 }
- blur: { amount: 0-20 }
- particles: { count: 5-50, type: "snow" | "fireflies" }
- glow: { color: hex, pulse: boolean }
- gradient: { animate: boolean, speed: 1-10 }
- shake: { intensity: 0-15 }

Return ONLY valid JSON.`,
        response_json_schema: {
          type: "object",
          properties: {
            effects: { type: "array", items: { type: "string" } },
            settings: { type: "object" },
            explanation: { type: "string" }
          }
        }
      });
      
      if (result.effects) {
        setActiveEffects(result.effects);
      }
      if (result.settings) {
        setSettings(prev => ({ ...prev, ...result.settings }));
      }
      setAiResult(result);
    } catch (e) {
      setAiResult({ explanation: "AI generation failed. Try a simpler description." });
    }
    setIsAiGenerating(false);
  };

  const updateSetting = (effectId, key, value) => {
    setSettings(prev => ({ ...prev, [effectId]: { ...prev[effectId], [key]: value } }));
  };

  const generateCode = () => {
    return `import { motion } from "framer-motion";

export default function CombinedEffect({ children }) {
  return (
    <div className="relative overflow-hidden">
      {children}
      ${activeEffects.includes("vhs") ? `{/* VHS Scanlines */}
      <div className="absolute inset-0 pointer-events-none" style={{ background: "repeating-linear-gradient(0deg, rgba(0,0,0,0.15) 0px, transparent 2px)" }} />` : ""}
      ${activeEffects.includes("vignette") ? `{/* Vignette */}
      <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(ellipse, transparent 40%, rgba(0,0,0,0.5))" }} />` : ""}
      ${activeEffects.includes("particles") ? `{/* Particles - add motion component */}` : ""}
    </div>
  );
}`;
  };

  const copyCode = async () => {
    await navigator.clipboard.writeText(generateCode());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const renderPreview = () => (
    <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-slate-950">
      <img src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&h=500&fit=crop" alt="Preview" className="w-full h-full object-cover" />
      
      {activeEffects.includes("vhs") && (
        <div className="absolute inset-0 pointer-events-none" style={{ background: `repeating-linear-gradient(0deg, rgba(0,0,0,${settings.vhs.noise/200}), rgba(0,0,0,${settings.vhs.noise/200}) 1px, transparent 1px, transparent 2px)` }} />
      )}
      {activeEffects.includes("grain") && (
        <div className="absolute inset-0 pointer-events-none mix-blend-overlay animate-pulse" style={{ opacity: settings.grain.intensity/100, backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")` }} />
      )}
      {activeEffects.includes("vignette") && (
        <div className="absolute inset-0 pointer-events-none" style={{ background: `radial-gradient(ellipse at center, transparent 30%, rgba(0,0,0,${settings.vignette.intensity/100}))` }} />
      )}
      {activeEffects.includes("blur") && (
        <div className="absolute inset-0 pointer-events-none" style={{ backdropFilter: `blur(${settings.blur.amount}px)` }} />
      )}
      {activeEffects.includes("glow") && (
        <motion.div animate={settings.glow.pulse && isPlaying ? { boxShadow: [`inset 0 0 30px ${settings.glow.color}40`, `inset 0 0 60px ${settings.glow.color}60`, `inset 0 0 30px ${settings.glow.color}40`] } : {}} transition={{ duration: 1.5, repeat: Infinity }} className="absolute inset-0 pointer-events-none" />
      )}
      {activeEffects.includes("gradient") && (
        <motion.div animate={settings.gradient.animate && isPlaying ? { backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] } : {}} transition={{ duration: settings.gradient.speed, repeat: Infinity }} className="absolute inset-0 pointer-events-none border-4 rounded-xl" style={{ borderImage: "linear-gradient(90deg, #8b5cf6, #06b6d4, #ec4899, #8b5cf6) 1", backgroundSize: "300%" }} />
      )}
      {activeEffects.includes("particles") && isPlaying && (
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {Array.from({ length: settings.particles.count }).map((_, i) => (
            <motion.div key={i} className={settings.particles.type === "snow" ? "bg-white rounded-full" : "bg-yellow-400 rounded-full blur-sm"} style={{ width: 3 + Math.random() * 3, height: 3 + Math.random() * 3, left: `${Math.random() * 100}%`, position: "absolute" }} animate={settings.particles.type === "snow" ? { y: ["-10%", "110%"], opacity: [0, 1, 0] } : { y: ["80%", "20%", "80%"], opacity: [0.3, 1, 0.3] }} transition={{ duration: 3 + Math.random() * 3, delay: Math.random() * 3, repeat: Infinity }} />
          ))}
        </div>
      )}
      {activeEffects.includes("shake") && isPlaying && (
        <motion.div animate={{ x: [0, -settings.shake.intensity, settings.shake.intensity, 0] }} transition={{ duration: 0.3, repeat: Infinity }} className="absolute inset-0 pointer-events-none" />
      )}
    </div>
  );

  return (
    <div className="min-h-screen">
      <AnimatePresence>
        {showTutorial && <TutorialOverlay onClose={() => setShowTutorial(false)} />}
      </AnimatePresence>

      <CategoryHeader icon={Wand2} title="Effect Builder" description="Combine effects to create stunning visuals" gradient="#8b5cf6" />

      <div className="max-w-7xl mx-auto px-4 pb-20">
        {/* Top Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6 p-4 rounded-xl bg-slate-900/50 border border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-slate-400 text-sm">Active:</span>
            {activeEffects.length > 0 ? activeEffects.map(id => (
              <span key={id} className="px-2 py-1 rounded-full bg-violet-500/20 text-violet-400 text-xs">{id}</span>
            )) : <span className="text-slate-500 text-sm">None selected</span>}
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => setShowTutorial(true)}>
              <HelpCircle className="w-4 h-4 mr-1" /> Help
            </Button>
            <Button size="sm" variant="outline" onClick={() => setActiveEffects([])}>
              <RefreshCw className="w-4 h-4 mr-1" /> Reset
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Panel - Mood & Effects */}
          <div className="lg:col-span-4 space-y-4">
            {/* AI Generation */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-violet-500/10 to-cyan-500/10 border border-violet-500/30">
              <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                <Bot className="w-4 h-4 text-violet-400" /> AI Effect Generator
              </h3>
              <Textarea
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="Describe your effect... e.g., 'a glitchy VHS effect with purple hues and floating particles'"
                className="bg-slate-900 border-slate-700 text-white text-sm mb-3 min-h-[80px]"
              />
              <Button
                onClick={generateWithAI}
                disabled={isAiGenerating || !aiPrompt.trim()}
                className="w-full bg-gradient-to-r from-violet-500 to-cyan-500"
              >
                {isAiGenerating ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating...</>
                ) : (
                  <><Wand2 className="w-4 h-4 mr-2" /> Generate with AI</>
                )}
              </Button>
              {aiResult?.explanation && (
                <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-3 text-xs text-cyan-400 bg-cyan-500/10 p-2 rounded-lg">
                  {aiResult.explanation}
                </motion.p>
              )}
            </div>

            {/* Mood Presets */}
            <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800">
              <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-violet-400" /> Quick Moods
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(moodPresets).map(([id, preset]) => (
                  <motion.button
                    key={id}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => applyMood(id)}
                    className={`p-3 rounded-xl text-left transition-all ${selectedMood === id ? "bg-gradient-to-r from-violet-500/30 to-cyan-500/30 border border-violet-500" : "bg-slate-800/50 border border-slate-700 hover:border-slate-600"}`}
                  >
                    <p className={`font-medium text-sm ${selectedMood === id ? "text-white" : "text-slate-300"}`}>{id}</p>
                    <p className="text-xs text-slate-500">{preset.desc}</p>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Effect Toggles by Category */}
            <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800">
              <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" /> Effects
              </h3>
              {Object.entries(effectCategories).map(([category, effects]) => (
                <div key={category} className="mb-2">
                  <button onClick={() => setExpandedCategory(expandedCategory === category ? null : category)} className="w-full flex items-center justify-between p-2 rounded-lg bg-slate-800/50 hover:bg-slate-800 mb-1">
                    <span className="text-slate-300 text-sm capitalize">{category}</span>
                    {expandedCategory === category ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
                  </button>
                  <AnimatePresence>
                    {expandedCategory === category && (
                      <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }} className="overflow-hidden">
                        <div className="space-y-2 py-2">
                          {effects.map(effect => (
                            <div key={effect.id} className="space-y-2">
                              <div className="flex items-center justify-between px-2">
                                <span className="text-slate-300 text-sm">{effect.icon} {effect.name}</span>
                                <ToggleSwitch checked={activeEffects.includes(effect.id)} onCheckedChange={() => toggleEffect(effect.id)} />
                              </div>
                              {activeEffects.includes(effect.id) && (
                                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="px-2 pb-2 space-y-2">
                                  {effect.id === "vhs" && (
                                    <div>
                                      <Label className="text-xs text-slate-500">Noise: {settings.vhs.noise}%</Label>
                                      <Slider value={[settings.vhs.noise]} onValueChange={([v]) => updateSetting("vhs", "noise", v)} max={100} />
                                    </div>
                                  )}
                                  {effect.id === "grain" && (
                                    <div>
                                      <Label className="text-xs text-slate-500">Intensity: {settings.grain.intensity}%</Label>
                                      <Slider value={[settings.grain.intensity]} onValueChange={([v]) => updateSetting("grain", "intensity", v)} max={100} />
                                    </div>
                                  )}
                                  {effect.id === "vignette" && (
                                    <div>
                                      <Label className="text-xs text-slate-500">Intensity: {settings.vignette.intensity}%</Label>
                                      <Slider value={[settings.vignette.intensity]} onValueChange={([v]) => updateSetting("vignette", "intensity", v)} max={100} />
                                    </div>
                                  )}
                                  {effect.id === "blur" && (
                                    <div>
                                      <Label className="text-xs text-slate-500">Amount: {settings.blur.amount}px</Label>
                                      <Slider value={[settings.blur.amount]} onValueChange={([v]) => updateSetting("blur", "amount", v)} max={20} />
                                    </div>
                                  )}
                                  {effect.id === "particles" && (
                                    <>
                                      <div>
                                        <Label className="text-xs text-slate-500">Count: {settings.particles.count}</Label>
                                        <Slider value={[settings.particles.count]} onValueChange={([v]) => updateSetting("particles", "count", v)} min={5} max={50} />
                                      </div>
                                      <div className="flex gap-1">
                                        <button onClick={() => updateSetting("particles", "type", "snow")} className={`px-2 py-1 rounded text-xs ${settings.particles.type === "snow" ? "bg-violet-500 text-white" : "bg-slate-700 text-slate-400"}`}>Snow</button>
                                        <button onClick={() => updateSetting("particles", "type", "fireflies")} className={`px-2 py-1 rounded text-xs ${settings.particles.type === "fireflies" ? "bg-violet-500 text-white" : "bg-slate-700 text-slate-400"}`}>Fireflies</button>
                                      </div>
                                    </>
                                  )}
                                  {effect.id === "glow" && (
                                    <div className="flex gap-1">
                                      {["#8b5cf6", "#06b6d4", "#ec4899", "#22c55e"].map(color => (
                                        <button key={color} onClick={() => updateSetting("glow", "color", color)} className={`w-6 h-6 rounded-full ${settings.glow.color === color ? "ring-2 ring-white" : ""}`} style={{ backgroundColor: color }} />
                                      ))}
                                    </div>
                                  )}
                                  {effect.id === "shake" && (
                                    <div>
                                      <Label className="text-xs text-slate-500">Intensity: {settings.shake.intensity}</Label>
                                      <Slider value={[settings.shake.intensity]} onValueChange={([v]) => updateSetting("shake", "intensity", v)} max={15} />
                                    </div>
                                  )}
                                  {effect.id === "gradient" && (
                                    <div>
                                      <Label className="text-xs text-slate-500">Speed: {settings.gradient.speed}s</Label>
                                      <Slider value={[settings.gradient.speed]} onValueChange={([v]) => updateSetting("gradient", "speed", v)} min={1} max={10} />
                                    </div>
                                  )}
                                </motion.div>
                              )}
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          </div>

          {/* Right Panel - Preview & Code */}
          <div className="lg:col-span-8 space-y-4">
            {/* Preview */}
            <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-semibold flex items-center gap-2">
                  <Eye className="w-4 h-4 text-cyan-400" /> Live Preview
                </h3>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => setIsPlaying(!isPlaying)}>
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
              {renderPreview()}
            </div>

            {/* Code Section */}
            <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <button onClick={() => setShowCode(!showCode)} className="flex items-center gap-2 text-white font-semibold">
                  <Code className="w-4 h-4 text-cyan-400" /> Generated Code
                  {showCode ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
                <div className="flex gap-2">
                  <motion.button onClick={copyCode} whileTap={{ scale: 0.95 }} className="h-8 px-3 rounded-lg border-2 border-cyan-500 text-cyan-400 text-xs font-medium flex items-center gap-1 hover:bg-cyan-500 hover:text-white transition-colors">
                    {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    {copied ? "Copied!" : "Copy"}
                  </motion.button>
                  <Button size="sm" variant="outline" onClick={() => { const blob = new Blob([generateCode()], { type: 'text/plain' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'effect.jsx'; a.click(); }}>
                    <Download className="w-3 h-3 mr-1" /> Download
                  </Button>
                </div>
              </div>
              <AnimatePresence>
                {showCode && (
                  <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }} className="overflow-hidden">
                    <pre className="p-4 rounded-lg bg-slate-950 border border-slate-800 overflow-x-auto text-xs text-slate-300 max-h-60 overflow-y-auto">
                      <code>{generateCode()}</code>
                    </pre>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}