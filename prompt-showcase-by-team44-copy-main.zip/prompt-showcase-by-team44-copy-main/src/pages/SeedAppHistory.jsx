import React, { useState } from "react";
import { motion } from "framer-motion";
import { History, Download, Copy, Check, Calendar, Code } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import CategoryHeader from "@/components/effects/CategoryHeader";
import { useQuery } from "@tanstack/react-query";

const seedHistory = [
  {
    version: "2.0.1",
    date: "2025-12-22",
    label: "Current Template",
    changes: [
      "Updated promo bar text and icons",
      "Fixed footer social links integration",
      "Added delete buttons for promo bar icons",
      "Updated sci-fi banner to Team44 branding",
      "Created version 2.0.1 with latest configurations"
    ],
    defaultSettings: {
      app_title: "UI Effects Playground",
      version: "2.0.1",
      promo_bar_enabled: true,
      promo_bar_text: "⚡850+ Effects • Copy & Paste Ready Prompts! ⚡",
      promo_bar_link_text: "Team44 apps on Base44 👀",
      social_links_filled: true,
      coffee_banner_enabled: true,
      footer_columns: 3,
      banner_text: "THE ULTIMATE UI LIBRARY"
    }
  },
  {
    version: "2.0.0",
    date: "2025-12-21",
    label: "Major Update",
    changes: [
      "Premium Effects & Page Templates disabled by default",
      "See It In Action section defaults to OFF",
      "Promo bar disabled by default",
      "Social links cleared by default",
      "Donation settings cleared by default",
      "Coffee banner disabled by default",
      "Walkthrough video disabled by default",
      "Footer updated to 4 columns: brand, stats, settings, install",
      "Added SEO Optimizer page",
      "Fixed toggle persistence issues"
    ],
    defaultSettings: {
      app_title: "UI Effects Playground",
      version: "2.0.0",
      promo_bar_enabled: false,
      see_it_in_action_enabled: false,
      coffee_banner_enabled: false,
      social_links_filled: false,
      donation_settings_filled: false,
      premium_effects_enabled: false,
      page_templates_enabled: false
    }
  },
  {
    version: "1.5.0",
    date: "2025-12-15",
    label: "Previous State",
    changes: [
      "All features enabled",
      "Promo bar with Team44 branding",
      "Social links pre-filled",
      "Coffee banner with Team44 images",
      "Walkthrough video enabled",
      "Footer with 3 columns"
    ],
    defaultSettings: {
      app_title: "UI Effects Playground",
      version: "1.5.0",
      promo_bar_enabled: true,
      see_it_in_action_enabled: false,
      coffee_banner_enabled: true,
      social_links_filled: true,
      donation_settings_filled: true,
      premium_effects_enabled: true,
      page_templates_enabled: true
    }
  }
];

export default function SeedAppHistory() {
  const [copiedVersion, setCopiedVersion] = useState(null);
  const [expandedVersion, setExpandedVersion] = useState("2.0.1");

  const copySettings = async (version) => {
    const versionData = seedHistory.find(v => v.version === version);
    const text = JSON.stringify(versionData.defaultSettings, null, 2);
    await navigator.clipboard.writeText(text);
    setCopiedVersion(version);
    setTimeout(() => setCopiedVersion(null), 2000);
  };

  return (
    <div className="min-h-screen pb-20">
      <CategoryHeader
        icon={History}
        title="seedApp History"
        description="Reference and restore previous default states"
        gradient="#8b5cf6, #06b6d4"
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Info Card */}
        <Card className="bg-gradient-to-r from-violet-500/10 to-cyan-500/10 border-violet-500/30 mb-8">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-xl bg-violet-500/20">
                <History className="w-6 h-6 text-violet-400" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">What is this page?</h3>
                <p className="text-slate-300 text-sm mb-3">
                  This page tracks the default configuration of the seedApp function over time. 
                  Use it to:
                </p>
                <ul className="text-slate-400 text-sm space-y-1">
                  <li>• Reference what the "clean template" looked like at different points</li>
                  <li>• Understand what changed between versions</li>
                  <li>• Copy previous default settings if needed</li>
                  <li>• See the evolution of the template</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Version Timeline */}
        <div className="space-y-6">
          {seedHistory.map((version, index) => (
            <motion.div
              key={version.version}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className={`bg-slate-900/50 ${index === 0 ? 'border-violet-500 shadow-lg shadow-violet-500/20' : 'border-slate-800'}`}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <CardTitle className="text-white">v{version.version}</CardTitle>
                        {index === 0 && (
                          <span className="px-2 py-1 rounded-full bg-violet-500 text-white text-xs font-medium">
                            Current
                          </span>
                        )}
                      </div>
                      <CardDescription className="flex items-center gap-2 text-slate-400">
                        <Calendar className="w-3 h-3" />
                        {new Date(version.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                        {version.label && ` • ${version.label}`}
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setExpandedVersion(expandedVersion === version.version ? null : version.version)}
                      >
                        {expandedVersion === version.version ? 'Hide' : 'Show'} Details
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copySettings(version.version)}
                      >
                        {copiedVersion === version.version ? (
                          <>
                            <Check className="w-3 h-3 mr-1" /> Copied
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3 mr-1" /> Copy
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </CardHeader>

                {expandedVersion === version.version && (
                  <CardContent className="border-t border-slate-800 pt-4 space-y-4">
                    {/* Changes */}
                    <div>
                      <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                        📋 Key Changes
                      </h4>
                      <div className="space-y-2">
                        {version.changes.map((change, i) => (
                          <div key={i} className="flex gap-2 text-sm">
                            <span className="text-cyan-400">•</span>
                            <span className="text-slate-300">{change}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Default Settings Preview */}
                    <div>
                      <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                        <Code className="w-4 h-4" /> Default Configuration
                      </h4>
                      <div className="grid grid-cols-2 gap-2">
                        {Object.entries(version.defaultSettings).map(([key, value]) => (
                          <div key={key} className="p-2 bg-slate-950 rounded border border-slate-800">
                            <p className="text-xs text-slate-500">{key}</p>
                            <p className="text-sm text-white font-mono">
                              {typeof value === 'boolean' ? (
                                <span className={value ? 'text-green-400' : 'text-red-400'}>
                                  {value ? '✓ enabled' : '✗ disabled'}
                                </span>
                              ) : (
                                value
                              )}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                )}
              </Card>
            </motion.div>
          ))}
        </div>

        {/* How to Use */}
        <Card className="bg-slate-900/50 border-slate-800 mt-8">
          <CardHeader>
            <CardTitle className="text-white">🔧 How to Use</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-slate-300 text-sm">
            <p>
              <strong className="text-violet-400">To reset to a specific version:</strong> Go to Admin Dashboard → Video tab → Click "Reset App to Template Defaults" button. This will apply the current version's defaults from seedApp.
            </p>
            <p>
              <strong className="text-cyan-400">To manually apply old settings:</strong> Click "Copy" on any version above, then paste the JSON into your code or contact support.
            </p>
            <p className="text-xs text-slate-500 pt-2 border-t border-slate-800">
              This page is for reference only. It does not modify your current app settings.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}