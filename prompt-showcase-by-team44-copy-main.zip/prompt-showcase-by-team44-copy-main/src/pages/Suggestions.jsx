import React, { useState } from "react";
import { motion } from "framer-motion";
import { 
  Lightbulb, Layout, Palette, MousePointer, Zap, Code, Users, 
  Sparkles, Settings, Database, Shield, Globe, Smartphone, Search,
  MessageCircle, BarChart3, Share2, BookOpen, Heart, Star, Eye, Download, Copy, Check
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import CategoryHeader from "@/components/effects/CategoryHeader";
import { useQuery } from "@tanstack/react-query";

const suggestions = [
  { id: 1, title: "Dark/Light Theme Toggle", category: "UI Design", priority: "High", description: "Global theme switching with smooth transitions", icon: Palette },
  { id: 2, title: "Keyboard Shortcuts", category: "UX", priority: "High", description: "Navigate the app and copy code with keyboard only", icon: Zap },
  { id: 3, title: "Effect Playground", category: "Features", priority: "High", description: "Real-time code editor with live preview", icon: Code },
  { id: 4, title: "Export to CodePen/Sandbox", category: "Features", priority: "High", description: "One-click export to online code editors", icon: Share2 },
  { id: 5, title: "TypeScript Definitions", category: "Developer", priority: "High", description: "Type definitions for all components", icon: Code },
  { id: 6, title: "Responsive Preview Modes", category: "Features", priority: "High", description: "Test effects on mobile, tablet, desktop", icon: Smartphone },
  { id: 7, title: "Performance Benchmarks", category: "Performance", priority: "High", description: "Show FPS and render time for each effect", icon: BarChart3 },
  { id: 8, title: "Favorites & Collections", category: "UX", priority: "High", description: "Organize effects into custom folders", icon: Heart },
  { id: 9, title: "Undo/Redo in Builder", category: "UX", priority: "High", description: "Step back through customizations", icon: RefreshCw },
  { id: 10, title: "Icon Badge Pack Browser", category: "Icons", priority: "High", description: "10+ themed icon packs to preview and use", icon: Eye },
  { id: 11, title: "Effect Comparison Mode", category: "UX", priority: "Medium", description: "View 2-4 effects side by side", icon: Layout },
  { id: 12, title: "Onboarding Tour", category: "UX", priority: "Medium", description: "Interactive walkthrough for new users", icon: BookOpen },
  { id: 13, title: "Animation Timeline Editor", category: "Features", priority: "Medium", description: "Visual keyframe editing", icon: Layers },
  { id: 14, title: "Copy as Different Frameworks", category: "Developer", priority: "Medium", description: "React, Vue, Svelte, vanilla JS exports", icon: Code },
  { id: 15, title: "Bundle Size Indicators", category: "Performance", priority: "Medium", description: "Display the size impact of each effect", icon: Database },
  { id: 16, title: "Share to Social Media", category: "Social", priority: "Medium", description: "Preview cards for Twitter, LinkedIn", icon: Share2 },
  { id: 17, title: "Micro-animation Library", category: "UI Design", priority: "Medium", description: "Pre-built hover, click, and focus states", icon: Sparkles },
  { id: 18, title: "Glass Morphism Components", category: "UI Design", priority: "Medium", description: "Frosted glass effect cards and modals", icon: Palette },
  { id: 19, title: "User Profiles", category: "Social", priority: "Medium", description: "Showcase your created/saved effects", icon: Users },
  { id: 20, title: "Effect Marketplace", category: "Features", priority: "Low", description: "Community-submitted effects", icon: Globe },
  { id: 21, title: "npm Package Generator", category: "Developer", priority: "Low", description: "Export effects as installable packages", icon: Download },
  { id: 22, title: "Custom Cursor Effects", category: "UI Design", priority: "Low", description: "Animated cursors that react to elements", icon: MousePointer },
  { id: 23, title: "Embed Widgets", category: "Social", priority: "Low", description: "Embed effects in external sites", icon: Code },
];

// Need to import RefreshCw and Layers
import { RefreshCw, Layers } from "lucide-react";

export default function Suggestions() {
  const [copiedId, setCopiedId] = useState(null);
  const highPriority = suggestions.filter(s => s.priority === "High");
  const mediumPriority = suggestions.filter(s => s.priority === "Medium");
  const lowPriority = suggestions.filter(s => s.priority === "Low");

  const copySuggestion = async (suggestion) => {
    const text = `Feature Request: ${suggestion.title}\nPriority: ${suggestion.priority}\nCategory: ${suggestion.category}\nDescription: ${suggestion.description}`;
    await navigator.clipboard.writeText(text);
    setCopiedId(suggestion.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const SuggestionCard = ({ suggestion, index }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.03 }}
      className="flex items-start gap-4 p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors border border-slate-700 group"
    >
      <div className={`p-2 rounded-lg ${
        suggestion.priority === "High" ? "bg-red-500/20" : 
        suggestion.priority === "Medium" ? "bg-amber-500/20" : "bg-slate-500/20"
      }`}>
        <suggestion.icon className={`w-5 h-5 ${
          suggestion.priority === "High" ? "text-red-400" : 
          suggestion.priority === "Medium" ? "text-amber-400" : "text-slate-400"
        }`} />
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-2 flex-wrap">
          <h4 className="text-white font-medium">{suggestion.title}</h4>
          <span className={`px-2 py-0.5 rounded text-xs font-medium ${
            suggestion.priority === "High" ? "bg-red-500/20 text-red-400" :
            suggestion.priority === "Medium" ? "bg-amber-500/20 text-amber-400" :
            "bg-slate-500/20 text-slate-400"
          }`}>
            {suggestion.priority}
          </span>
          <span className="px-2 py-0.5 rounded text-xs bg-violet-500/20 text-violet-400">
            {suggestion.category}
          </span>
        </div>
        <p className="text-sm text-slate-400 mt-1">{suggestion.description}</p>
      </div>
      <div className="flex items-center gap-2">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => copySuggestion(suggestion)}
          className={`p-2 rounded-lg transition-colors ${
            copiedId === suggestion.id 
              ? "bg-green-500/20 text-green-400" 
              : "opacity-0 group-hover:opacity-100 hover:bg-slate-700 text-slate-400 hover:text-white"
          }`}
          title="Click to copy"
        >
          {copiedId === suggestion.id ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
        </motion.button>
        <span className="text-xs text-slate-600 font-mono">#{suggestion.id}</span>
      </div>
    </motion.div>
  );

  return (
    <div>
      <CategoryHeader 
        icon={Lightbulb} 
        title="Top 23 Suggestions" 
        description="Prioritized improvements to enhance the B44 Effects Showcase" 
        gradient="#f59e0b" 
      />
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* Priority Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          {[
            { label: "High Priority", count: highPriority.length, color: "text-red-400 bg-red-500/10 border-red-500/20" },
            { label: "Medium Priority", count: mediumPriority.length, color: "text-amber-400 bg-amber-500/10 border-amber-500/20" },
            { label: "Low Priority", count: lowPriority.length, color: "text-slate-400 bg-slate-500/10 border-slate-500/20" },
          ].map((stat, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              className={`text-center p-4 rounded-xl border ${stat.color}`}
            >
              <div className={`text-3xl font-bold ${stat.color.split(' ')[0]}`}>{stat.count}</div>
              <div className="text-xs text-slate-400">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        {/* High Priority */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-red-500" />
            High Priority ({highPriority.length})
          </h3>
          <div className="space-y-3">
            {highPriority.map((s, i) => <SuggestionCard key={s.id} suggestion={s} index={i} />)}
          </div>
        </div>

        {/* Medium Priority */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-amber-500" />
            Medium Priority ({mediumPriority.length})
          </h3>
          <div className="space-y-3">
            {mediumPriority.map((s, i) => <SuggestionCard key={s.id} suggestion={s} index={i} />)}
          </div>
        </div>

        {/* Low Priority */}
        <div>
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-slate-500" />
            Low Priority ({lowPriority.length})
          </h3>
          <div className="space-y-3">
            {lowPriority.map((s, i) => <SuggestionCard key={s.id} suggestion={s} index={i} />)}
          </div>
        </div>
      </div>
    </div>
  );
}