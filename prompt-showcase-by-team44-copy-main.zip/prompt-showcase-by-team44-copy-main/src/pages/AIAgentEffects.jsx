import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Bot, Brain, Sparkles, Zap, MessageCircle, Copy, Check, Loader2, Settings, Cpu, Network, Gauge, Mic, Volume2, Eye, RefreshCw, Code, Lightbulb, Target, Layers } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import ToggleSwitch from "@/components/ui/toggle-switch";
import { Label } from "@/components/ui/label";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// AI Thinking Animation
function AIThinkingAnimation() {
  const [isThinking, setIsThinking] = useState(true);
  const nodes = Array.from({ length: 12 }, (_, i) => ({
    x: 50 + Math.cos((i / 12) * Math.PI * 2) * 35,
    y: 50 + Math.sin((i / 12) * Math.PI * 2) * 35
  }));

  return (
    <EffectCard title="AI Neural Network" description="Animated neural network visualization" whenToUse="Show AI processing state or explain how AI works." controls={
      <div className="flex items-center justify-between">
        <Label className="text-slate-300">Thinking</Label>
        <ToggleSwitch checked={isThinking} onCheckedChange={setIsThinking} />
      </div>
    }>
      <div className="relative w-full h-[200px] flex items-center justify-center">
        <svg viewBox="0 0 100 100" className="w-40 h-40">
          {isThinking && nodes.map((node, i) => nodes.slice(i + 1).map((target, j) => (
            <motion.line
              key={`${i}-${j}`}
              x1={node.x} y1={node.y} x2={target.x} y2={target.y}
              stroke="#8b5cf6" strokeWidth="0.5"
              initial={{ opacity: 0 }}
              animate={{ opacity: [0.1, 0.5, 0.1] }}
              transition={{ duration: 1.5, delay: (i + j) * 0.1, repeat: Infinity }}
            />
          )))}
          {nodes.map((node, i) => (
            <motion.circle
              key={i} cx={node.x} cy={node.y} r="3" fill="#8b5cf6"
              animate={isThinking ? { scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] } : {}}
              transition={{ duration: 1, delay: i * 0.1, repeat: Infinity }}
            />
          ))}
          <motion.circle cx="50" cy="50" r="8" fill="#06b6d4"
            animate={isThinking ? { scale: [1, 1.2, 1] } : {}}
            transition={{ duration: 0.8, repeat: Infinity }}
          />
        </svg>
      </div>
    </EffectCard>
  );
}

// Streaming Text Effect
function StreamingTextEffect() {
  const [text, setText] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const fullText = "Hello! I'm an AI assistant. I can help you build amazing applications with React, Tailwind CSS, and Framer Motion. Let me know what you'd like to create today!";

  const startStream = () => {
    setText("");
    setIsStreaming(true);
    let i = 0;
    const interval = setInterval(() => {
      setText(fullText.slice(0, i));
      i++;
      if (i > fullText.length) { clearInterval(interval); setIsStreaming(false); }
    }, 30);
  };

  return (
    <EffectCard title="Streaming Text" description="Character-by-character AI response" whenToUse="Display AI-generated content as it's being created." controls={
      <Button onClick={startStream} variant="outline" className="w-full" disabled={isStreaming}>
        {isStreaming ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
        {isStreaming ? "Generating..." : "Start Stream"}
      </Button>
    }>
      <div className="p-4 w-full">
        <div className="p-4 rounded-xl bg-slate-800 min-h-[80px]">
          <p className="text-slate-300 text-sm">
            {text}
            {isStreaming && <motion.span animate={{ opacity: [1, 0] }} transition={{ duration: 0.5, repeat: Infinity }} className="inline-block w-2 h-4 bg-cyan-400 ml-1" />}
          </p>
        </div>
      </div>
    </EffectCard>
  );
}

// AI Status Indicator
function AIStatusIndicator() {
  const [status, setStatus] = useState("idle");
  const statuses = {
    idle: { color: "bg-slate-500", text: "Idle", icon: Bot },
    thinking: { color: "bg-yellow-500", text: "Thinking...", icon: Brain },
    responding: { color: "bg-green-500", text: "Responding", icon: MessageCircle },
    error: { color: "bg-red-500", text: "Error", icon: Zap }
  };

  return (
    <EffectCard title="Agent Status" description="Visual status indicators" whenToUse="Show current AI state (idle, thinking, responding, error)." controls={
      <div className="flex gap-2 flex-wrap">
        {Object.keys(statuses).map(s => (
          <button key={s} onClick={() => setStatus(s)} className={`px-2 py-1 rounded text-xs ${status === s ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400"}`}>{s}</button>
        ))}
      </div>
    }>
      <div className="flex items-center gap-3 p-4">
        <motion.div animate={{ scale: status === "thinking" ? [1, 1.2, 1] : 1 }} transition={{ duration: 0.5, repeat: status === "thinking" ? Infinity : 0 }} className={`p-3 rounded-full ${statuses[status].color}`}>
          {React.createElement(statuses[status].icon, { className: "w-6 h-6 text-white" })}
        </motion.div>
        <div>
          <p className="text-white font-medium">{statuses[status].text}</p>
          <p className="text-slate-400 text-xs">AI Agent Status</p>
        </div>
      </div>
    </EffectCard>
  );
}

// Temperature Control
function TemperatureControl() {
  const [temp, setTemp] = useState([0.7]);
  const getLabel = () => temp[0] < 0.3 ? "Precise" : temp[0] < 0.7 ? "Balanced" : "Creative";

  return (
    <EffectCard title="Temperature Control" description="Creativity vs precision slider" whenToUse="Let users adjust AI creativity in content generation tools.">
      <div className="p-6 w-full space-y-4">
        <div className="flex justify-between text-sm">
          <span className="text-cyan-400">Precise</span>
          <span className="text-violet-400">Creative</span>
        </div>
        <Slider value={temp} onValueChange={setTemp} min={0} max={1} step={0.1} />
        <div className="text-center">
          <span className="text-2xl font-bold text-white">{temp[0].toFixed(1)}</span>
          <p className="text-slate-400 text-sm">{getLabel()}</p>
        </div>
      </div>
    </EffectCard>
  );
}

// Model Selection
function ModelSelection() {
  const [selected, setSelected] = useState("gpt-4");
  const models = [
    { id: "gpt-4", name: "GPT-4", desc: "Most capable", icon: Brain },
    { id: "gpt-3.5", name: "GPT-3.5", desc: "Fast & efficient", icon: Zap },
    { id: "claude", name: "Claude", desc: "Thoughtful", icon: MessageCircle }
  ];

  return (
    <EffectCard title="Model Selection" description="Choose AI model" whenToUse="Allow users to select different AI models based on needs.">
      <div className="p-4 w-full space-y-2">
        {models.map(model => (
          <button key={model.id} onClick={() => setSelected(model.id)} className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${selected === model.id ? "bg-violet-500/20 border border-violet-500" : "bg-slate-800 hover:bg-slate-700"}`}>
            <model.icon className={`w-5 h-5 ${selected === model.id ? "text-violet-400" : "text-slate-400"}`} />
            <div className="text-left">
              <p className={`font-medium ${selected === model.id ? "text-white" : "text-slate-300"}`}>{model.name}</p>
              <p className="text-xs text-slate-500">{model.desc}</p>
            </div>
          </button>
        ))}
      </div>
    </EffectCard>
  );
}

// Voice Input Animation
function VoiceInputAnimation() {
  const [isListening, setIsListening] = useState(false);

  return (
    <EffectCard title="Voice Input" description="Audio waveform visualization" controls={
      <div className="flex items-center justify-between">
        <Label className="text-slate-300">Listening</Label>
        <ToggleSwitch checked={isListening} onCheckedChange={setIsListening} />
      </div>
    }>
      <div className="flex items-center justify-center gap-1 h-20">
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            className="w-1 bg-gradient-to-t from-violet-500 to-cyan-400 rounded-full"
            animate={isListening ? { height: [10, 30 + Math.random() * 30, 10] } : { height: 10 }}
            transition={{ duration: 0.3 + Math.random() * 0.2, repeat: isListening ? Infinity : 0, delay: i * 0.05 }}
          />
        ))}
      </div>
    </EffectCard>
  );
}

// Token Counter
function TokenCounter() {
  const [tokens, setTokens] = useState(0);
  const maxTokens = 4096;

  useEffect(() => {
    const interval = setInterval(() => setTokens(t => t < maxTokens ? t + Math.floor(Math.random() * 50) : 0), 100);
    return () => clearInterval(interval);
  }, []);

  return (
    <EffectCard title="Token Counter" description="Real-time token usage" whenToUse="Monitor API usage and costs in AI applications.">
      <div className="p-6 w-full">
        <div className="relative h-4 bg-slate-800 rounded-full overflow-hidden">
          <motion.div className="absolute inset-y-0 left-0 bg-gradient-to-r from-green-500 via-yellow-500 to-red-500" style={{ width: `${(tokens / maxTokens) * 100}%` }} />
        </div>
        <div className="flex justify-between mt-2 text-sm">
          <span className="text-slate-400">{tokens.toLocaleString()} tokens</span>
          <span className="text-slate-400">{maxTokens.toLocaleString()} max</span>
        </div>
      </div>
    </EffectCard>
  );
}

// Confidence Meter
function ConfidenceMeter() {
  const [confidence, setConfidence] = useState(85);

  return (
    <EffectCard title="Confidence Meter" description="AI response confidence" controls={
      <Slider value={[confidence]} onValueChange={([v]) => setConfidence(v)} max={100} />
    }>
      <div className="flex flex-col items-center p-4">
        <div className="relative w-32 h-32">
          <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
            <circle cx="50" cy="50" r="40" fill="none" stroke="#1e293b" strokeWidth="8" />
            <motion.circle
              cx="50" cy="50" r="40" fill="none" stroke="url(#gradient)" strokeWidth="8" strokeLinecap="round"
              strokeDasharray={251.2} strokeDashoffset={251.2 - (confidence / 100) * 251.2}
            />
            <defs>
              <linearGradient id="gradient"><stop offset="0%" stopColor="#8b5cf6" /><stop offset="100%" stopColor="#06b6d4" /></linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-2xl font-bold text-white">{confidence}%</span>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Tool Call Animation
function ToolCallAnimation() {
  const [stage, setStage] = useState(0);
  const stages = ["Analyzing", "Calling Tool", "Processing", "Complete"];

  useEffect(() => {
    const interval = setInterval(() => setStage(s => (s + 1) % 4), 1500);
    return () => clearInterval(interval);
  }, []);

  return (
    <EffectCard title="Tool Execution" description="Function call visualization">
      <div className="p-4 w-full">
        <div className="flex items-center justify-between mb-4">
          {stages.map((s, i) => (
            <div key={i} className="flex flex-col items-center">
              <motion.div
                animate={{ scale: stage === i ? 1.2 : 1, backgroundColor: stage >= i ? "#8b5cf6" : "#334155" }}
                className="w-8 h-8 rounded-full flex items-center justify-center"
              >
                <span className="text-white text-xs">{i + 1}</span>
              </motion.div>
              <span className="text-xs text-slate-400 mt-1">{s}</span>
            </div>
          ))}
        </div>
        <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
          <motion.div className="h-full bg-violet-500" animate={{ width: `${((stage + 1) / 4) * 100}%` }} />
        </div>
      </div>
    </EffectCard>
  );
}

// Context Window Visualizer
function ContextWindowVisualizer() {
  const segments = [
    { label: "System", size: 15, color: "bg-violet-500" },
    { label: "History", size: 30, color: "bg-cyan-500" },
    { label: "Context", size: 25, color: "bg-pink-500" },
    { label: "Response", size: 30, color: "bg-green-500" }
  ];

  return (
    <EffectCard title="Context Window" description="Token distribution view">
      <div className="p-4 w-full space-y-3">
        <div className="flex h-8 rounded-lg overflow-hidden">
          {segments.map((seg, i) => (
            <motion.div key={i} initial={{ width: 0 }} animate={{ width: `${seg.size}%` }} transition={{ delay: i * 0.2 }} className={`${seg.color} flex items-center justify-center`}>
              <span className="text-white text-xs font-medium">{seg.size}%</span>
            </motion.div>
          ))}
        </div>
        <div className="flex justify-between text-xs">
          {segments.map((seg, i) => (
            <div key={i} className="flex items-center gap-1">
              <div className={`w-2 h-2 rounded-full ${seg.color}`} />
              <span className="text-slate-400">{seg.label}</span>
            </div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Prompt Builder UI
function PromptBuilderUI() {
  const [parts, setParts] = useState(["Define task", "Add context"]);

  return (
    <EffectCard title="Prompt Builder" description="Visual prompt construction">
      <div className="p-4 w-full space-y-2">
        {parts.map((part, i) => (
          <motion.div key={i} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }} className="flex items-center gap-2 p-2 rounded-lg bg-slate-800 border border-slate-700">
            <div className="w-6 h-6 rounded bg-violet-500/20 flex items-center justify-center text-violet-400 text-xs">{i + 1}</div>
            <span className="text-slate-300 text-sm flex-1">{part}</span>
          </motion.div>
        ))}
        <Button size="sm" variant="outline" onClick={() => setParts([...parts, "New section"])} className="w-full">+ Add Section</Button>
      </div>
    </EffectCard>
  );
}

// Agent Memory Banks
function AgentMemoryBanks() {
  const banks = [
    { name: "Short-term", usage: 65, color: "from-violet-500 to-violet-400" },
    { name: "Long-term", usage: 42, color: "from-cyan-500 to-cyan-400" },
    { name: "Working", usage: 88, color: "from-pink-500 to-pink-400" }
  ];

  return (
    <EffectCard title="Memory Banks" description="Agent memory visualization">
      <div className="p-4 w-full space-y-4">
        {banks.map((bank, i) => (
          <div key={i}>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-slate-300">{bank.name}</span>
              <span className="text-slate-400">{bank.usage}%</span>
            </div>
            <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${bank.usage}%` }}
                transition={{ delay: i * 0.2 }}
                className={`h-full bg-gradient-to-r ${bank.color}`}
              />
            </div>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Reasoning Steps
function ReasoningSteps() {
  const [step, setStep] = useState(0);
  const steps = ["Understanding query", "Gathering context", "Formulating response", "Validating output"];

  useEffect(() => {
    const interval = setInterval(() => setStep(s => (s + 1) % 4), 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <EffectCard title="Reasoning Chain" description="Step-by-step thought process">
      <div className="p-4 w-full space-y-2">
        {steps.map((s, i) => (
          <motion.div
            key={i}
            animate={{ opacity: i <= step ? 1 : 0.3, x: i <= step ? 0 : 10 }}
            className="flex items-center gap-3 p-2 rounded-lg bg-slate-800"
          >
            <motion.div
              animate={{ scale: i === step ? [1, 1.2, 1] : 1 }}
              transition={{ duration: 0.5, repeat: i === step ? Infinity : 0 }}
              className={`w-6 h-6 rounded-full flex items-center justify-center ${i <= step ? "bg-violet-500" : "bg-slate-700"}`}
            >
              {i < step ? <Check className="w-3 h-3 text-white" /> : <span className="text-white text-xs">{i + 1}</span>}
            </motion.div>
            <span className={`text-sm ${i <= step ? "text-white" : "text-slate-500"}`}>{s}</span>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Multi-Agent Orchestration
function MultiAgentOrchestration() {
  const agents = [
    { name: "Planner", status: "active" },
    { name: "Researcher", status: "waiting" },
    { name: "Writer", status: "idle" },
    { name: "Reviewer", status: "idle" }
  ];

  return (
    <EffectCard title="Multi-Agent System" description="Agent orchestration view">
      <div className="p-4 w-full">
        <div className="flex items-center justify-center gap-4">
          {agents.map((agent, i) => (
            <motion.div
              key={i}
              animate={{ scale: agent.status === "active" ? [1, 1.1, 1] : 1 }}
              transition={{ duration: 0.5, repeat: agent.status === "active" ? Infinity : 0 }}
              className="flex flex-col items-center"
            >
              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                agent.status === "active" ? "bg-green-500" : agent.status === "waiting" ? "bg-yellow-500" : "bg-slate-700"
              }`}>
                <Bot className="w-6 h-6 text-white" />
              </div>
              <span className="text-xs text-slate-400 mt-1">{agent.name}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Embedding Visualization
function EmbeddingVisualization() {
  const points = Array.from({ length: 20 }, () => ({
    x: Math.random() * 100,
    y: Math.random() * 100,
    cluster: Math.floor(Math.random() * 3)
  }));
  const colors = ["#8b5cf6", "#06b6d4", "#ec4899"];

  return (
    <EffectCard title="Embedding Space" description="Vector clustering visualization">
      <div className="relative w-full h-[180px] bg-slate-900 rounded-lg overflow-hidden">
        {points.map((point, i) => (
          <motion.div
            key={i}
            initial={{ scale: 0 }}
            animate={{ scale: 1, x: [0, Math.random() * 10 - 5], y: [0, Math.random() * 10 - 5] }}
            transition={{ delay: i * 0.05, duration: 2, repeat: Infinity, repeatType: "reverse" }}
            className="absolute w-3 h-3 rounded-full"
            style={{ left: `${point.x}%`, top: `${point.y}%`, backgroundColor: colors[point.cluster] }}
          />
        ))}
      </div>
    </EffectCard>
  );
}

// Attention Heatmap
function AttentionHeatmap() {
  const words = ["The", "quick", "brown", "fox", "jumps"];

  return (
    <EffectCard title="Attention Heatmap" description="Token attention weights">
      <div className="p-4 w-full">
        <div className="flex gap-2 justify-center">
          {words.map((word, i) => (
            <motion.div
              key={i}
              animate={{ backgroundColor: [`rgba(139, 92, 246, ${0.2 + Math.random() * 0.6})`, `rgba(139, 92, 246, ${0.2 + Math.random() * 0.6})`] }}
              transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
              className="px-3 py-2 rounded-lg"
            >
              <span className="text-white text-sm">{word}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Knowledge Graph Node
function KnowledgeGraphNode() {
  return (
    <EffectCard title="Knowledge Graph" description="Connected concepts visualization">
      <div className="relative w-full h-[180px] flex items-center justify-center">
        <svg viewBox="0 0 200 150" className="w-full h-full">
          {[[100, 75, 50, 50], [100, 75, 150, 50], [100, 75, 50, 110], [100, 75, 150, 110]].map(([x1, y1, x2, y2], i) => (
            <motion.line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#8b5cf6" strokeWidth="2"
              initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay: i * 0.2 }} />
          ))}
          <motion.circle cx="100" cy="75" r="20" fill="#8b5cf6" animate={{ scale: [1, 1.1, 1] }} transition={{ duration: 1, repeat: Infinity }} />
          {[[50, 50], [150, 50], [50, 110], [150, 110]].map(([cx, cy], i) => (
            <motion.circle key={i} cx={cx} cy={cy} r="12" fill="#06b6d4" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.5 + i * 0.1 }} />
          ))}
        </svg>
      </div>
    </EffectCard>
  );
}

export default function AIAgentEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <AIThinkingAnimation />, name: "Neural Network" },
    { component: <StreamingTextEffect />, name: "Streaming Text" },
    { component: <AIStatusIndicator />, name: "Agent Status" },
    { component: <TemperatureControl />, name: "Temperature" },
    { component: <ModelSelection />, name: "Model Selection" },
    { component: <VoiceInputAnimation />, name: "Voice Input" },
    { component: <TokenCounter />, name: "Token Counter" },
    { component: <ConfidenceMeter />, name: "Confidence Meter" },
    { component: <ToolCallAnimation />, name: "Tool Execution" },
    { component: <ContextWindowVisualizer />, name: "Context Window" },
    { component: <PromptBuilderUI />, name: "Prompt Builder" },
    { component: <AgentMemoryBanks />, name: "Memory Banks" },
    { component: <ReasoningSteps />, name: "Reasoning Chain" },
    { component: <MultiAgentOrchestration />, name: "Multi-Agent" },
    { component: <EmbeddingVisualization />, name: "Embeddings" },
    { component: <AttentionHeatmap />, name: "Attention Map" },
    { component: <KnowledgeGraphNode />, name: "Knowledge Graph" },
  ];

  const filtered = effects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={Bot} title="AI Agent Effects" description="17 AI interface components and visualizations" gradient="#8b5cf6" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((effect, i) => <div key={i}>{effect.component}</div>)}
        </div>
      </div>
    </div>
  );
}