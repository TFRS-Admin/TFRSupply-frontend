import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Video, Youtube, Play, Pause, Volume2, VolumeX, SkipForward, Maximize, Monitor, Grid, Share2, Heart, Award, Mic, Film, Layout, FileText, Loader, Minimize2, List, PieChart, Lock, Coins, Tag, Palette, MousePointerClick, Type, ShoppingBag, Layers, Sparkles } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import SearchFilterEnhanced from "@/components/effects/SearchFilterEnhanced";
import EffectCard from "@/components/effects/EffectCard";
import { useQuery } from "@tanstack/react-query";

export default function VideoPlayerCustomization() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const categories = [
    { id: "all", label: "All Effects", color: "bg-slate-500" },
    { id: "overlays", label: "Overlays & Thumbnails", color: "bg-violet-500" },
    { id: "controls", label: "Controls & UI", color: "bg-blue-500" },
    { id: "interactive", label: "Interactive", color: "bg-emerald-500" },
    { id: "layout", label: "Layout & Skins", color: "bg-amber-500" },
  ];

  const effects = [
    {
      id: "custom-play-glitch",
      title: "Glitch Play Overlay",
      description: "Custom thumbnail with CSS glitch effect on hover.",
      category: "overlays",
      icon: Play,
      whenToUse: "For high-energy, tech, or gaming video intros.",
      component: (
        <div className="relative w-full aspect-video bg-slate-900 rounded-lg overflow-hidden group cursor-pointer border border-slate-700">
           <img src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1000&auto=format&fit=crop" alt="Thumbnail" className="w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity" />
           <div className="absolute inset-0 flex items-center justify-center">
             <div className="w-16 h-16 bg-red-600/90 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg shadow-red-500/30">
               <Play className="w-8 h-8 text-white ml-1" fill="currentColor" />
             </div>
           </div>
           <div className="absolute inset-0 pointer-events-none mix-blend-color-dodge opacity-0 group-hover:opacity-100 transition-opacity" style={{background: 'repeating-linear-gradient(0deg, transparent, transparent 2px, #ff0000 2px, #ff0000 4px)'}}></div>
        </div>
      )
    },
    {
      id: "cinematic-letterbox",
      title: "Cinematic Letterbox",
      description: "Adds black bars for a movie-like widescreen experience.",
      category: "layout",
      icon: Film,
      whenToUse: "To give standard 16:9 videos a more dramatic, cinematic feel.",
      component: (
        <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden flex flex-col justify-center">
          <div className="w-full h-[80%] bg-slate-800 relative">
             <div className="absolute inset-0 flex items-center justify-center text-slate-500">Video Content</div>
          </div>
        </div>
      )
    },
    {
      id: "vhs-glitch-player",
      title: "VHS Glitch Player",
      description: "Retro VHS tracking lines and color distortion overlay.",
      category: "overlays",
      icon: Video,
      whenToUse: "For nostalgia, retro-themed content, or artistic showcases.",
      component: (
        <div className="relative w-full aspect-video bg-slate-800 rounded-lg overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/20 pointer-events-none" />
          <div className="absolute top-4 left-4 font-mono text-green-400 text-xs opacity-80">PLAY 00:00:12</div>
          <div className="absolute inset-0 pointer-events-none opacity-20" style={{background: 'linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.25) 50%), linear-gradient(90deg, rgba(255, 0, 0, 0.06), rgba(0, 255, 0, 0.02), rgba(0, 0, 255, 0.06))', backgroundSize: '100% 2px, 3px 100%'}}></div>
        </div>
      )
    },
    {
      id: "neon-border-player",
      title: "Neon Glowing Border",
      description: "Pulsing neon border that reacts to video state.",
      category: "layout",
      icon: Grid,
      whenToUse: "Cyberpunk themes or to make the video pop on dark backgrounds.",
      component: (
        <div className="p-1 rounded-xl bg-slate-900 shadow-[0_0_15px_rgba(139,92,246,0.6)] border border-violet-500">
           <div className="w-full aspect-video bg-slate-800 rounded-lg flex items-center justify-center text-violet-400">
             Video
           </div>
        </div>
      )
    },
    {
      id: "interactive-progress",
      title: "Interactive Progress",
      description: "Custom progress bar with hover previews and chapters.",
      category: "controls",
      icon: Monitor,
      whenToUse: "For long-form content requiring easy navigation.",
      component: (
        <div className="w-full aspect-[21/9] bg-slate-900 rounded-lg flex flex-col justify-end p-4 relative overflow-hidden">
          <div className="w-full h-1.5 bg-slate-700 rounded-full cursor-pointer group relative">
            <div className="absolute top-0 left-0 h-full w-1/3 bg-red-500 rounded-full"></div>
            <div className="absolute top-1/2 left-1/3 w-3 h-3 bg-red-500 rounded-full -translate-y-1/2 scale-0 group-hover:scale-100 transition-transform shadow"></div>
            <div className="absolute bottom-4 left-1/3 -translate-x-1/2 px-2 py-1 bg-black text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity">03:45</div>
          </div>
        </div>
      )
    },
    {
      id: "watch-next-preview",
      title: "Watch Next Preview",
      description: "Animated slide-in showing the next video in queue.",
      category: "interactive",
      icon: SkipForward,
      whenToUse: "To increase retention and binge-watching behavior.",
      component: (
         <div className="relative w-full aspect-video bg-slate-800 rounded-lg overflow-hidden">
           <div className="absolute bottom-4 right-4 bg-slate-900/90 p-2 rounded-lg border border-slate-700 w-40 flex gap-2 items-center shadow-xl">
              <div className="w-10 h-10 bg-slate-700 rounded flex-shrink-0"></div>
              <div className="flex flex-col">
                <span className="text-[10px] text-slate-400 uppercase">Up Next</span>
                <span className="text-xs text-white truncate w-20">Episode 2</span>
              </div>
           </div>
         </div>
      )
    },
    {
      id: "scroll-triggered",
      title: "Scroll Auto-Play",
      description: "Video starts playing when it enters the viewport.",
      category: "controls",
      icon: Play,
      whenToUse: "For landing pages to grab attention without user click.",
      component: (
        <div className="w-full aspect-video bg-slate-800 rounded-lg flex items-center justify-center border-2 border-green-500/30">
          <span className="text-xs text-green-400 bg-green-900/30 px-2 py-1 rounded">Viewport Active</span>
        </div>
      )
    },
    {
      id: "pip-toggle",
      title: "Picture-in-Picture",
      description: "Button to detach video and float it on screen.",
      category: "controls",
      icon: Minimize2,
      whenToUse: "Allowing users to browse while watching.",
      component: (
        <div className="w-full aspect-video bg-slate-800 rounded-lg relative group">
           <button className="absolute top-2 right-2 p-1.5 bg-black/60 rounded text-white hover:bg-white/20 transition-colors">
             <Minimize2 className="w-4 h-4" />
           </button>
        </div>
      )
    },
    {
      id: "animated-end-card",
      title: "Animated End Card",
      description: "Engaging overlay with Subscribe and Next Video CTAs.",
      category: "overlays",
      icon: Layout,
      whenToUse: "At the end of videos to drive actions.",
      component: (
        <div className="w-full aspect-video bg-black rounded-lg relative flex items-center justify-center gap-4">
           <div className="w-24 h-24 rounded-full border-4 border-white/10 flex items-center justify-center bg-slate-800">
             <span className="text-xs text-slate-400">Sub</span>
           </div>
           <div className="w-32 h-20 rounded bg-slate-800 border border-white/10 flex items-center justify-center">
              <span className="text-xs text-slate-400">Next</span>
           </div>
        </div>
      )
    },
    {
      id: "video-hotspots",
      title: "Interactive Hotspots",
      description: "Clickable areas within the video to show info.",
      category: "interactive",
      icon: MousePointerClick,
      whenToUse: "Shoppable videos or educational content.",
      component: (
        <div className="w-full aspect-video bg-slate-800 rounded-lg relative">
           <div className="absolute top-1/3 left-1/4 w-4 h-4 bg-white rounded-full animate-ping opacity-75"></div>
           <div className="absolute top-1/3 left-1/4 w-4 h-4 bg-white rounded-full border-2 border-violet-500 cursor-pointer hover:scale-125 transition-transform"></div>
        </div>
      )
    },
    {
      id: "synced-text",
      title: "Synced Captions",
      description: "Karaoke-style text overlays synced to video time.",
      category: "overlays",
      icon: Type,
      whenToUse: "Music videos or accessibility focused content.",
      component: (
        <div className="w-full aspect-video bg-slate-900 rounded-lg flex items-end justify-center pb-6">
           <p className="px-4 py-2 bg-black/50 rounded text-yellow-400 font-medium text-center">
             ♪ Never gonna give you up... ♪
           </p>
        </div>
      )
    },
    {
      id: "themed-skins",
      title: "Themed Player Skins",
      description: "Custom UI controls matching brand aesthetic.",
      category: "layout",
      icon: Palette,
      whenToUse: "To align the player with your website's design language.",
      component: (
        <div className="w-full aspect-video bg-slate-800 rounded-lg relative flex flex-col justify-end">
           <div className="h-10 bg-gradient-to-r from-pink-500 to-violet-500 flex items-center px-4 gap-4">
              <Play className="w-4 h-4 text-white fill-white" />
              <div className="h-1 flex-1 bg-white/30 rounded-full"><div className="w-1/3 h-full bg-white rounded-full"></div></div>
           </div>
        </div>
      )
    },
    {
      id: "custom-volume",
      title: "Custom Volume",
      description: "Vertical or radial volume sliders.",
      category: "controls",
      icon: Volume2,
      whenToUse: "For music apps or precise audio control.",
      component: (
        <div className="w-full aspect-video bg-slate-800 rounded-lg relative flex items-center justify-center">
           <div className="flex items-center gap-2 bg-black/50 p-2 rounded-lg">
             <Volume2 className="w-4 h-4 text-white" />
             <div className="w-16 h-1 bg-slate-600 rounded-full"><div className="w-3/4 h-full bg-cyan-400 rounded-full"></div></div>
           </div>
        </div>
      )
    },
    {
      id: "branded-spinner",
      title: "Branded Loader",
      description: "Custom animation while video buffers.",
      category: "overlays",
      icon: Loader,
      whenToUse: "To keep branding visible even during wait times.",
      component: (
        <div className="w-full aspect-video bg-black rounded-lg flex items-center justify-center">
           <div className="w-10 h-10 border-4 border-violet-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      )
    },
    {
      id: "popup-transcript",
      title: "Popup Transcript",
      description: "Scrollable transcript that follows video progress.",
      category: "interactive",
      icon: FileText,
      whenToUse: "Lectures, webinars, or SEO-heavy video pages.",
      component: (
        <div className="w-full aspect-video bg-slate-800 rounded-lg flex">
           <div className="w-2/3 h-full bg-black/20"></div>
           <div className="w-1/3 h-full bg-white/5 p-2 text-[8px] text-slate-400 font-mono overflow-hidden">
             00:01 Welcome back...<br/>
             <span className="text-white bg-white/10 block w-full">00:05 Today we will...</span><br/>
             00:10 Learn about...
           </div>
        </div>
      )
    },
    {
      id: "muted-autoplay",
      title: "Muted Autoplay",
      description: "Background loop that plays without sound initially.",
      category: "controls",
      icon: VolumeX,
      whenToUse: "Hero backgrounds or product showcase cards.",
      component: (
        <div className="w-full aspect-video bg-slate-700 rounded-lg relative flex items-center justify-center">
            <span className="text-4xl opacity-20">🎥</span>
            <div className="absolute bottom-2 right-2 p-1 bg-black/50 rounded-full">
              <VolumeX className="w-3 h-3 text-white" />
            </div>
        </div>
      )
    },
    {
      id: "fullscreen-header",
      title: "Fullscreen Header",
      description: "Video covers entire viewport behind content.",
      category: "layout",
      icon: Maximize,
      whenToUse: "Immersive landing pages.",
      component: (
        <div className="w-full aspect-video bg-slate-800 rounded-lg relative overflow-hidden">
           <div className="absolute inset-0 flex items-center justify-center bg-black/40">
             <h3 className="text-white font-bold">Hero Text</h3>
           </div>
        </div>
      )
    },
    {
      id: "theater-mode",
      title: "Theater Mode",
      description: "Dims page background and expands player.",
      category: "layout",
      icon: Maximize,
      whenToUse: "Focus mode for viewing content.",
      component: (
        <div className="w-full aspect-video bg-black rounded-lg shadow-[0_0_0_100px_rgba(0,0,0,0.5)] z-10 relative border border-slate-700">
           <div className="absolute top-2 right-2 text-white/50 text-[10px]">Theater Mode Active</div>
        </div>
      )
    },
    {
      id: "video-mosaic",
      title: "Video Mosaic",
      description: "Grid of multiple playing videos.",
      category: "layout",
      icon: Grid,
      whenToUse: "Event recaps or community highlights.",
      component: (
        <div className="w-full aspect-video grid grid-cols-2 grid-rows-2 gap-1 bg-slate-900 p-1 rounded-lg">
           <div className="bg-slate-700 rounded"></div>
           <div className="bg-slate-800 rounded"></div>
           <div className="bg-slate-800 rounded"></div>
           <div className="bg-slate-700 rounded"></div>
        </div>
      )
    },
    {
      id: "dynamic-cta",
      title: "Timed CTA Button",
      description: "Buy button appears at specific product mention.",
      category: "interactive",
      icon: ShoppingBag,
      whenToUse: "E-commerce videos and product demos.",
      component: (
        <div className="w-full aspect-video bg-slate-800 rounded-lg relative">
           <motion.div 
             animate={{ opacity: [0, 1, 0] }}
             transition={{ duration: 4, repeat: Infinity }}
             className="absolute bottom-4 left-4 bg-white text-black text-xs px-3 py-1.5 rounded-full font-bold shadow-lg flex items-center gap-1"
           >
             <ShoppingBag className="w-3 h-3" /> Buy Now $29
           </motion.div>
        </div>
      )
    },
    {
      id: "chapter-nav",
      title: "Chapter Navigation",
      description: "Sidebar or markers for video chapters.",
      category: "controls",
      icon: List,
      whenToUse: "Tutorials and long educational videos.",
      component: (
        <div className="w-full aspect-video bg-slate-800 rounded-lg flex flex-col justify-between p-4">
           <div className="w-full h-1 bg-slate-600 rounded-full relative">
              <div className="absolute top-0 left-0 w-[2px] h-2 bg-white -mt-0.5 left-1/4"></div>
              <div className="absolute top-0 left-0 w-[2px] h-2 bg-white -mt-0.5 left-1/2"></div>
              <div className="absolute top-0 left-0 w-[2px] h-2 bg-white -mt-0.5 left-3/4"></div>
           </div>
        </div>
      )
    },
    {
      id: "video-poll",
      title: "In-Video Poll",
      description: "Overlay asking viewers a question.",
      category: "interactive",
      icon: PieChart,
      whenToUse: "Engagement and gathering viewer feedback.",
      component: (
        <div className="w-full aspect-video bg-slate-800 rounded-lg relative flex items-center justify-end px-4">
           <div className="w-1/2 bg-white/10 backdrop-blur p-3 rounded-lg border border-white/20">
             <div className="text-[10px] text-white mb-2">Vote Now?</div>
             <div className="h-4 bg-white/20 rounded mb-1"></div>
             <div className="h-4 bg-white/20 rounded"></div>
           </div>
        </div>
      )
    },
    {
      id: "parallax-scroll",
      title: "Parallax Video",
      description: "Video scrolling at different speed than page.",
      category: "layout",
      icon: Layers,
      whenToUse: "Artistic background effects.",
      component: (
        <div className="w-full aspect-video bg-slate-900 rounded-lg overflow-hidden relative">
           <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?q=80&w=1000')] bg-cover bg-fixed opacity-50"></div>
        </div>
      )
    },
    {
      id: "3d-frame",
      title: "3D Frame Player",
      description: "Video player inside a 3D device mockup.",
      category: "layout",
      icon: Monitor,
      whenToUse: "App demos or showcasing digital products.",
      component: (
        <div className="w-full aspect-video bg-slate-900 rounded-lg flex items-center justify-center perspective-1000">
           <div className="w-3/4 h-3/4 bg-slate-800 border-4 border-slate-600 rounded-lg transform rotate-y-12 shadow-2xl"></div>
        </div>
      )
    },
    {
      id: "skip-intro",
      title: "Skip Intro Button",
      description: "Button to jump past opening sequences.",
      category: "controls",
      icon: SkipForward,
      whenToUse: "TV series style content.",
      component: (
        <div className="w-full aspect-video bg-slate-800 rounded-lg relative">
           <button className="absolute bottom-8 right-4 bg-white/10 hover:bg-white/20 text-white text-xs px-3 py-1.5 rounded border border-white/20 backdrop-blur">
             Skip Intro
           </button>
        </div>
      )
    },
    {
      id: "custom-reactions",
      title: "Custom Reactions",
      description: "Floating emojis when users react.",
      category: "interactive",
      icon: Heart,
      whenToUse: "Live streams or community content.",
      component: (
        <div className="w-full aspect-video bg-slate-800 rounded-lg relative overflow-hidden">
           <div className="absolute bottom-10 right-10 text-xl animate-bounce">❤️</div>
           <div className="absolute bottom-12 right-14 text-lg animate-pulse delay-75">🔥</div>
        </div>
      )
    },
    {
      id: "nft-gated",
      title: "NFT Gated Access",
      description: "Lock content behind wallet verification.",
      category: "interactive",
      icon: Lock,
      whenToUse: "Premium or exclusive content.",
      component: (
        <div className="w-full aspect-video bg-slate-900 rounded-lg flex flex-col items-center justify-center gap-2 border border-slate-700">
           <Lock className="w-6 h-6 text-slate-500" />
           <span className="text-[10px] text-slate-400">Connect Wallet to View</span>
        </div>
      )
    },
    {
      id: "crypto-tip",
      title: "Crypto Tipping",
      description: "Direct wallet tipping overlay.",
      category: "interactive",
      icon: Coins,
      whenToUse: "Creator economy and support.",
      component: (
        <div className="w-full aspect-video bg-slate-800 rounded-lg relative">
           <div className="absolute top-2 right-2 flex items-center gap-1 bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded-full border border-yellow-500/50 text-xs">
             <Coins className="w-3 h-3" /> Tip ETH
           </div>
        </div>
      )
    },
    {
      id: "affiliate-overlay",
      title: "Affiliate Products",
      description: "Carousel of products shown in video.",
      category: "overlays",
      icon: Tag,
      whenToUse: "Review videos and unboxings.",
      component: (
        <div className="w-full aspect-video bg-slate-800 rounded-lg relative">
           <div className="absolute bottom-4 left-4 right-4 h-12 bg-white/10 backdrop-blur rounded flex items-center gap-2 px-2">
              <div className="w-8 h-8 bg-white/20 rounded"></div>
              <div className="w-8 h-8 bg-white/20 rounded"></div>
           </div>
        </div>
      )
    },
    {
      id: "ai-summary",
      title: "AI Highlights",
      description: "Auto-generated key moments list.",
      category: "interactive",
      icon: Sparkles,
      whenToUse: "Long meeting recordings or podcasts.",
      component: (
        <div className="w-full aspect-video bg-slate-800 rounded-lg flex">
           <div className="flex-1"></div>
           <div className="w-1/3 border-l border-white/10 p-2 space-y-2">
              <div className="h-2 bg-violet-500/50 rounded w-3/4"></div>
              <div className="h-2 bg-violet-500/30 rounded w-1/2"></div>
           </div>
        </div>
      )
    }
  ];



  const filteredEffects = effects.filter(effect => {
    const matchesSearch = effect.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          effect.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === "all" || effect.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen">
      <CategoryHeader
        title="Video Player Customization"
        description="Advanced UI/UX effects, overlays, and interactions for YouTube videos."
        icon={Youtube}
        gradient="from-red-600 to-rose-600"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <SearchFilterEnhanced
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          activeCategory={activeCategory}
          setActiveCategory={setActiveCategory}
          categories={categories}
          resultCount={filteredEffects.length}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
          {filteredEffects.map((effect) => (
            <EffectCard
              key={effect.id}
              title={effect.title}
              description={effect.description}
              whenToUse={effect.whenToUse}
              icon={effect.icon}
            >
              {effect.component}
            </EffectCard>
          ))}
        </div>
      </div>
    </div>
  );
}