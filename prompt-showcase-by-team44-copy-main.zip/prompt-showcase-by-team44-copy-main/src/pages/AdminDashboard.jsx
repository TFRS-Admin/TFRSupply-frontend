import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Settings, Upload, Save, Image, Type, Hash, Loader2, AlertCircle, X, 
  Snowflake, Sparkles, Star, Heart, Flame, Zap, PartyPopper, Gift, Eye, EyeOff,
  Play, Code, Smartphone, Shield, Layers, BookOpen, Video, Wifi, ToggleLeft, Lock, Check,
  Megaphone, LayoutDashboard, BarChart3, Users, Activity, TrendingUp, Search
} from "lucide-react";
// Note: Some icons reused for multiple features
// RetroAdBanner removed (unused)
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import ToggleSwitch from "@/components/ui/toggle-switch";
import BannerConfigPanel from "@/components/admin/BannerConfigPanel";
import LibraryIngestionPanel from "@/components/admin/LibraryIngestionPanel";
// BannerGenerator removed (unused)



// Buy Me a Coffee Style Generator Component
const coffeeStyles = [
  { id: "classic", name: "Classic Coffee", gradient: "from-amber-500 to-orange-600", icon: "☕", text: "Buy Me a Coffee" },
  { id: "neon", name: "Neon Glow", gradient: "from-violet-500 to-fuchsia-600", icon: "✨", text: "Fuel the Magic" },
  { id: "cyber", name: "Cyberpunk", gradient: "from-cyan-400 to-blue-600", icon: "⚡", text: "Power Up" },
  { id: "retro", name: "Retro Wave", gradient: "from-pink-500 to-purple-600", icon: "🎮", text: "Support the Cause" },
  { id: "nature", name: "Nature", gradient: "from-green-500 to-emerald-600", icon: "🌱", text: "Help Us Grow" },
  { id: "fire", name: "Fire", gradient: "from-red-500 to-orange-600", icon: "🔥", text: "Keep the Fire Burning" },
  { id: "ocean", name: "Ocean", gradient: "from-blue-500 to-teal-600", icon: "🌊", text: "Make Waves" },
  { id: "galaxy", name: "Galaxy", gradient: "from-indigo-600 to-purple-800", icon: "🌌", text: "Reach for the Stars" },
  { id: "gold", name: "Gold", gradient: "from-yellow-500 to-amber-600", icon: "🏆", text: "Support Excellence" },
  { id: "minimal", name: "Minimal", gradient: "from-slate-600 to-slate-800", icon: "💎", text: "Support Us" },
];

function BuyMeCoffeeStyleGenerator({ currentStyle, onSave }) {
  const [selectedStyle, setSelectedStyle] = useState(currentStyle || coffeeStyles[0]);
  const [isRandomizing, setIsRandomizing] = useState(false);

  const randomizeStyle = () => {
    setIsRandomizing(true);
    let count = 0;
    const interval = setInterval(() => {
      setSelectedStyle(coffeeStyles[Math.floor(Math.random() * coffeeStyles.length)]);
      count++;
      if (count >= 10) {
        clearInterval(interval);
        setIsRandomizing(false);
        const finalStyle = coffeeStyles[Math.floor(Math.random() * coffeeStyles.length)];
        setSelectedStyle(finalStyle);
        onSave(finalStyle);
      }
    }, 100);
  };

  return (
    <Card className="bg-slate-900/50 border-slate-800">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <span className="text-xl">☕</span> Buy Me a Coffee CTA Style Generator
        </CardTitle>
        <CardDescription className="text-slate-400">Randomize or select a style for the donation CTA</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Preview */}
        <div className="p-6 rounded-xl bg-slate-950 border border-slate-800">
          <div className={`p-6 rounded-2xl bg-gradient-to-r ${selectedStyle.gradient} text-center transition-all duration-300`}>
            <motion.span 
              className="text-4xl inline-block"
              animate={isRandomizing ? { rotate: [0, 360] } : {}}
              transition={{ duration: 0.5, repeat: isRandomizing ? Infinity : 0 }}
            >
              {selectedStyle.icon}
            </motion.span>
            <h3 className="text-xl font-bold text-white mt-3">{selectedStyle.text}</h3>
            <p className="text-white/80 text-sm mt-1">Your support keeps us caffeinated!</p>
          </div>
        </div>

        {/* Style Grid */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
          {coffeeStyles.map(style => (
            <button
              key={style.id}
              onClick={() => { setSelectedStyle(style); onSave(style); }}
              className={`p-3 rounded-xl border-2 transition-all ${selectedStyle.id === style.id ? "border-white bg-white/10" : "border-slate-700 hover:border-slate-600"}`}
            >
              <span className="text-2xl">{style.icon}</span>
              <p className="text-xs text-slate-400 mt-1">{style.name}</p>
            </button>
          ))}
        </div>

        {/* Actions */}
        <div className="flex gap-3">
          <Button 
            onClick={randomizeStyle} 
            disabled={isRandomizing}
            className="flex-1 bg-gradient-to-r from-violet-600 to-purple-600"
          >
            {isRandomizing ? "🎰 Randomizing..." : "🎲 Randomize Style"}
          </Button>
          <Button 
            onClick={() => onSave(selectedStyle)} 
            variant="outline"
            className="flex-1"
          >
            💾 Save Selection
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

const holidayEffects = [
  { id: "snow", name: "❄️ Snow Fall", icon: Snowflake },
  { id: "sparkles", name: "✨ Sparkles", icon: Sparkles },
  { id: "hearts", name: "💕 Hearts", icon: Heart },
  { id: "stars", name: "⭐ Stars", icon: Star },
  { id: "fire", name: "🔥 Fire", icon: Flame },
  { id: "confetti", name: "🎉 Confetti", icon: PartyPopper },
  { id: "gifts", name: "🎁 Gifts", icon: Gift },
  { id: "neon", name: "💜 Neon Glow", icon: Zap },
];

const featureToggles = [
  // Pages
  { id: "effectBuilder", name: "Effect Builder", icon: Layers, desc: "Visual effect builder", category: "pages" },
  { id: "visualEffects", name: "Visual Effects Page", icon: Eye, desc: "Screen effects gallery", category: "pages" },
  { id: "audioEffects", name: "Audio Effects Page", icon: Video, desc: "Sound visualizations", category: "pages" },
  { id: "transitions", name: "Transitions Page", icon: Layers, desc: "Animation transitions", category: "pages" },
  { id: "navigationEffects", name: "Navigation Effects", icon: Layers, desc: "Nav animations", category: "pages" },
  { id: "buttonEffects", name: "Button Effects", icon: Play, desc: "Button interactions", category: "pages" },
  { id: "menuEffects", name: "Menu Effects", icon: Layers, desc: "Menu animations", category: "pages" },
  { id: "chatEffects", name: "Chat Effects", icon: Video, desc: "Chat UI components", category: "pages" },
  { id: "characterEffects", name: "Character Effects", icon: Sparkles, desc: "Animated characters", category: "pages" },
  { id: "aiAgentEffects", name: "AI Agent Effects", icon: Zap, desc: "AI interface components", category: "pages" },
  { id: "iconEffects", name: "Icon Effects", icon: Sparkles, desc: "Icon animations", category: "pages" },
  { id: "loadingSpinners", name: "Loading Spinners", icon: Play, desc: "Loader animations", category: "pages" },
  { id: "tutorials", name: "Tutorials Page", icon: BookOpen, desc: "Learning resources", category: "pages" },
  { id: "discover", name: "Discover Page", icon: Eye, desc: "Browse all effects", category: "pages" },
  { id: "myEffects", name: "My Effects Page", icon: Heart, desc: "Saved effects", category: "pages" },
  { id: "teachableMode", name: "Teachable Mode", icon: BookOpen, desc: "UI terminology", category: "pages" },
  { id: "suggestions", name: "Suggestions Page", icon: Sparkles, desc: "Feature requests", category: "pages" },
  { id: "gamingEffects", name: "Gaming Effects", icon: Play, desc: "Retro & modern game UI", category: "pages" },
  { id: "pixelAssets", name: "Pixel Assets / Game Art", icon: Layers, desc: "Sprites & icons", category: "pages" },
  { id: "premiumEffects", name: "Premium Effects", icon: Star, desc: "Premium store", category: "pages" },
  { id: "abstractAnimations", name: "Abstract Animations", icon: Sparkles, desc: "Mesmerizing visuals", category: "pages" },
  { id: "colorSchemes", name: "Color Schemes", icon: Eye, desc: "Color palettes", category: "pages" },
  { id: "adminLayouts", name: "Admin Layouts", icon: Layers, desc: "Dashboard layouts", category: "pages" },
  { id: "marketingEffects", name: "Marketing Effects", icon: Zap, desc: "CTAs & popups", category: "pages" },
  { id: "creativeEffects", name: "Creative Effects", icon: Sparkles, desc: "Design tools", category: "pages" },
  { id: "contentEffects", name: "Content Effects", icon: BookOpen, desc: "Blog & publishing", category: "pages" },
  { id: "communicationEffects", name: "Communication Effects", icon: Video, desc: "Email & chat", category: "pages" },
  { id: "socialEffects", name: "Social Effects", icon: Heart, desc: "Social media UI", category: "pages" },
  { id: "productivityEffects", name: "Productivity Effects", icon: Play, desc: "Tasks & timers", category: "pages" },
  { id: "ecommerceEffects", name: "E-commerce Effects", icon: Layers, desc: "Products & carts", category: "pages" },
  { id: "cartCheckout", name: "Cart & Checkout", icon: Layers, desc: "Shopping cart UI", category: "pages" },
  { id: "dividerEffects", name: "Divider Transitions", icon: Layers, desc: "Section dividers", category: "pages", defaultOn: true },
  { id: "pageTemplates", name: "Page Templates", icon: Layers, desc: "Reusable page templates", category: "pages" },
  // Features
  { id: "effectPlayground", name: "Effect Playground", icon: Play, desc: "Real-time code editor", category: "features" },
  { id: "exportCodeSandbox", name: "Export to CodeSandbox", icon: Code, desc: "One-click sandbox export", category: "features" },
  { id: "animationTimeline", name: "Animation Timeline", icon: Layers, desc: "Visual timeline editor", category: "features" },
  { id: "responsiveTesting", name: "Responsive Testing", icon: Smartphone, desc: "Device previews", category: "features" },
  { id: "accessibilityChecker", name: "Accessibility Checker", icon: Shield, desc: "A11y validation", category: "features" },
  { id: "effectVariants", name: "Effect Variants", icon: Layers, desc: "A/B testing", category: "features" },
  { id: "effectBundles", name: "Effect Bundles", icon: Gift, desc: "Curated collections", category: "features" },
  { id: "learningPaths", name: "Learning Paths", icon: BookOpen, desc: "Progressive tutorials", category: "features" },
  { id: "videoTutorials", name: "Video Tutorials", icon: Video, desc: "Embedded videos", category: "features" },
  { id: "offlineSupport", name: "Offline Support", icon: Wifi, desc: "PWA offline mode", category: "features" },
  { id: "retroAdBanner", name: "90s Retro Ad Banner", icon: Zap, desc: "Wild infomercial ad", category: "features" },
  { id: "glitchLoader", name: "Glitch Page Loader", icon: Zap, desc: "Page transition effect", category: "features" },
  { id: "responsivePreview", name: "Responsive Preview", icon: Smartphone, desc: "Device breakpoint testing", category: "features" },
];

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("branding");
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(u => setUser(u)).catch(() => {});
  }, []);
  
  const queryClient = useQueryClient();
  // Hero Style State
  const [heroStyle, setHeroStyle] = useState({ gradient_start: "#7c3aed", gradient_middle: "#8b5cf6", gradient_end: "#db2777", opacity: 0.6, effects: [] });
  // Video Section State
  const [modernVideo, setModernVideo] = useState({ enabled: false, youtube_url: "", title: "", description: "" });
  const [youtubeOverlayUrl, setYoutubeOverlayUrl] = useState("");
  const [walkthroughVideo, setWalkthroughVideo] = useState({ enabled: false, youtube_url: "", title: "", description: "", theme: "default" });
  const [seeItInActionEnabled, setSeeItInActionEnabled] = useState(false);
  
  // Announcements State
  const [announcementsEnabled, setAnnouncementsEnabled] = useState(false);
  const [activeAnnouncements, setActiveAnnouncements] = useState([]);
  const [showAnnouncementForm, setShowAnnouncementForm] = useState(false);
  const [newAnnouncement, setNewAnnouncement] = useState({ title: "", content: "", type: "banner", priority: "medium", action_url: "", action_text: "" });

  // Coffee Banner State - Simple
  const [coffeeBanner, setCoffeeBanner] = useState({ enabled: false, image_url: "", link: "", size: "medium", button_enabled: false, button_image: "", button_effect: "bounce", show_on_all_pages: false });
  const [uploadingBanner, setUploadingBanner] = useState(false);
  const [uploadingButton, setUploadingButton] = useState(false);
  // CTA Section State (Main Donation Section)
  const [ctaSection, setCtaSection] = useState({ enabled: true, visible_buttons: [] });
  // Footer Config State
  const [footerConfig, setFooterConfig] = useState({ columns: 4, column_widgets: ["brand", "stats", "settings", "install"], alignment: "left", style: "default" });
  // Global Search State
  const [globalSearchEnabled, setGlobalSearchEnabled] = useState(true);

  const [logoPreview, setLogoPreview] = useState("");
  const [appTitle, setAppTitle] = useState("");
  const [version, setVersion] = useState("1.0.0");
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState("");
  const [saveError, setSaveError] = useState("");
  const [isDragging, setIsDragging] = useState(false);
  const [logoFile, setLogoFile] = useState(null);
  const [logoPreview2, setLogoPreview2] = useState("");
  const [logoFile2, setLogoFile2] = useState(null);
  const [logoMorphEnabled, setLogoMorphEnabled] = useState(true);
  const [logoMorphSpeed, setLogoMorphSpeed] = useState(6);
  const [activeLogoEffects, setActiveLogoEffects] = useState([]);
  const [socialLinks, setSocialLinks] = useState({
    github: "",
    twitter: "",
    instagram: "",
    facebook: "",
    youtube: "",
    linkedin: ""
  });
  const [activeTitleEffects, setActiveTitleEffects] = useState([]);
  const [enabledFeatures, setEnabledFeatures] = useState([]);
  const [selectedBanner, setSelectedBanner] = useState("moviePoster2");
  const [bannerConfigs, setBannerConfigs] = useState({});
  const [logoGlitchEnabled, setLogoGlitchEnabled] = useState(false);
  const [logoGlitchInterval, setLogoGlitchInterval] = useState(20);
  const [logoOverlayEnabled, setLogoOverlayEnabled] = useState(true);
  const [donationSettings, setDonationSettings] = useState({});
  const [backToTopLogo, setBackToTopLogo] = useState("");
  const [backToTopFile, setBackToTopFile] = useState(null);
  const [bottomBannerUrl, setBottomBannerUrl] = useState("");
  const [bottomBannerLink, setBottomBannerLink] = useState("");
  const [footerEffect, setFooterEffect] = useState("none");
  const [footerWidgets, setFooterWidgets] = useState([]);
  const [coffeeCTAStyle, setCoffeeCTAStyle] = useState(null);
  const [promoBar, setPromoBar] = useState({ enabled: false, text: "", link_url: "", link_text: "", leftIconImage: "", rightIconImage: "", fontFamily: "Arial", textGlitch: false, override_template_link: false, custom_template_url: "" });
  const [featuredNavRandom, setFeaturedNavRandom] = useState(true);
  const [featuredNavPages, setFeaturedNavPages] = useState([]);

  const [templateShowcase, setTemplateShowcase] = useState({ enabled: false, poster_1_image: "", poster_1_link: "", poster_1_title: "", poster_2_image: "", poster_2_link: "", poster_2_title: "", poster_3_image: "", poster_3_link: "", poster_3_title: "" });
  const [donationBanner, setDonationBanner] = useState({ enabled: false });
  const [heroLayout, setHeroLayout] = useState("default");
  const [youtubeOverlayEnabled, setYoutubeOverlayEnabled] = useState(true);

  const { data: settings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || null;
    }
  });

  useEffect(() => {
    if (settings) {
      setAppTitle(settings.app_title || "Base44 Effects");
      setLogoPreview(settings.logo_url || "");
      setVersion(settings.version || "1.0.0");
      setActiveLogoEffects(settings.logo_effects || []);
      setActiveTitleEffects(settings.title_effects || []);
      setLogoPreview2(settings.logo_url_2 || "");
      setLogoMorphEnabled(settings.logo_morph_enabled !== false);
      setLogoMorphSpeed(settings.logo_morph_speed || 6);
      setLogoGlitchEnabled(settings.logo_glitch_enabled || false);
      setLogoGlitchInterval(settings.logo_glitch_interval || 20);
      setLogoOverlayEnabled(settings.logo_overlay_enabled !== false);
      // Set enabled features, with dividerEffects on by default if not set
      const savedFeatures = settings.enabled_features || [];
      if (!settings.enabled_features) {
        savedFeatures.push("dividerEffects");
      }
      setEnabledFeatures(savedFeatures);
      setSocialLinks(settings.social_links || {});
      setDonationSettings(settings.donation_settings || {});
      setBackToTopLogo(settings.back_to_top_logo || "");
      setBottomBannerUrl(settings.bottom_banner_url || "");
      setBottomBannerLink(settings.bottom_banner_link || "");
      setFooterEffect(settings.footer_effect || "none");
      setFooterWidgets(settings.footer_widgets || []);
      setSelectedBanner(settings.selected_banner || "moviePoster2");
      setBannerConfigs(settings.banner_configs || {});
      setCoffeeCTAStyle(settings.banner_configs?.coffeeCTAStyle || null);
      
      if (settings.hero_style) setHeroStyle(settings.hero_style);
      if (settings.modern_video) setModernVideo(settings.modern_video);
      setYoutubeOverlayUrl(settings.youtube_overlay_image_url || "");
      setYoutubeOverlayEnabled(settings.youtube_overlay_enabled !== false);
      if (settings.walkthrough_video) setWalkthroughVideo(settings.walkthrough_video);
      setSeeItInActionEnabled(settings.see_it_in_action_enabled === true);
      if (settings.coffee_banner) {
        setCoffeeBanner({
          enabled: settings.coffee_banner.enabled || false,
          image_url: settings.coffee_banner.image_url || "",
          link: settings.coffee_banner.link || "https://buymeacoffee.com/team44",
          size: settings.coffee_banner.size || "medium",
          button_enabled: settings.coffee_banner.button_enabled || false,
          button_image: settings.coffee_banner.button_image || "",
          button_effect: settings.coffee_banner.button_effect || "bounce",
          show_on_all_pages: settings.coffee_banner.show_on_all_pages || false
        });
      }
      if (settings.footer_config) setFooterConfig(settings.footer_config);
      if (settings.cta_section) setCtaSection(settings.cta_section);

      // Promo bar with all properties
      if (settings.promo_bar) {
        setPromoBar({
          enabled: settings.promo_bar.enabled || false,
          text: settings.promo_bar.text || "",
          link_url: settings.promo_bar.link_url || "",
          link_text: settings.promo_bar.link_text || "",
          gradient: settings.promo_bar.gradient || "from-violet-600 via-fuchsia-600 to-pink-600",
          sticky: settings.promo_bar.sticky !== false,
          shadow: settings.promo_bar.shadow || false,
          autoHide: settings.promo_bar.autoHide || false,
          watermark_url: settings.promo_bar.watermark_url || "",
          leftIconImage: settings.promo_bar.leftIconImage || "",
          rightIconImage: settings.promo_bar.rightIconImage || "",
          fontFamily: settings.promo_bar.fontFamily || "Arial",
          textGlitch: settings.promo_bar.textGlitch || false,
          override_template_link: settings.promo_bar.override_template_link || false,
          custom_template_url: settings.promo_bar.custom_template_url || ""
        });
      } else {
        setPromoBar({ enabled: false, text: "", link_url: "", link_text: "", gradient: "from-violet-600 via-fuchsia-600 to-pink-600", sticky: true, shadow: false, autoHide: false, watermark_url: "", leftIconImage: "", rightIconImage: "", fontFamily: "Arial", textGlitch: false, override_template_link: false, custom_template_url: "" });
      }



      // Template showcase
      if (settings.template_showcase) {
        setTemplateShowcase(settings.template_showcase);
      }

      // Donation banner
      if (settings.donation_banner) {
        setDonationBanner(settings.donation_banner);
      }

      // Hero layout
      if (settings.hero_layout) {
        setHeroLayout(settings.hero_layout);
      }

      setFeaturedNavRandom(settings.featured_nav_random !== false);
      setFeaturedNavPages((settings.featured_nav_pages || []).filter(p => p && typeof p === 'string'));
      
      setAnnouncementsEnabled(settings.announcements_enabled || false);
      setGlobalSearchEnabled(settings.global_search_enabled !== false);
    }
  }, [settings]);

  // Fetch announcements separately
  const { data: fetchedAnnouncements, refetch: refetchAnnouncements } = useQuery({
    queryKey: ['admin-announcements'],
    queryFn: async () => base44.entities.Announcement.list({ sort: { created_date: -1 } }),
    enabled: activeTab === 'announcements'
  });

  useEffect(() => {
    if (fetchedAnnouncements) {
      setActiveAnnouncements(fetchedAnnouncements);
    }
  }, [fetchedAnnouncements]);

  const handleCreateAnnouncement = async () => {
    try {
      await base44.entities.Announcement.create({
        ...newAnnouncement,
        status: "active",
        dismissible: true
      });
      setNewAnnouncement({ title: "", content: "", type: "banner", priority: "medium", action_url: "", action_text: "" });
      setShowAnnouncementForm(false);
      refetchAnnouncements();
      setSaveMessage("Announcement created successfully!");
      setTimeout(() => setSaveMessage(""), 3000);
    } catch (error) {
      console.error(error);
      setSaveError("Failed to create announcement.");
    }
  };

  const handleDeleteAnnouncement = async (id) => {
    if (!confirm("Are you sure?")) return;
    try {
      await base44.entities.Announcement.delete(id);
      refetchAnnouncements();
    } catch (error) {
      console.error(error);
    }
  };

  const handleDragOver = useCallback((e) => { e.preventDefault(); setIsDragging(true); }, []);
  const handleDragLeave = useCallback((e) => { e.preventDefault(); setIsDragging(false); }, []);
  const handleDrop = useCallback((e) => { e.preventDefault(); setIsDragging(false); const file = e.dataTransfer.files[0]; if (file) processFile(file); }, []);

  const processFile = (file) => {
    setSaveError("");
    if (file.size > 15 * 1024 * 1024) {
      setSaveError("File size must be less than 15MB");
      return;
    }
    setLogoFile(file);
    const reader = new FileReader();
    reader.onloadend = () => setLogoPreview(reader.result);
    reader.readAsDataURL(file);
  };

  const handleFileInput = (e) => { const file = e.target.files[0]; if (file) processFile(file); };
  const clearLogo = () => { setLogoFile(null); setLogoPreview(""); };

  const processFile2 = (file) => {
    setSaveError("");
    if (file.size > 15 * 1024 * 1024) {
      setSaveError("File size must be less than 15MB");
      return;
    }
    setLogoFile2(file);
    const reader = new FileReader();
    reader.onloadend = () => setLogoPreview2(reader.result);
    reader.readAsDataURL(file);
  };
  const handleFileInput2 = (e) => { const file = e.target.files[0]; if (file) processFile2(file); };
  const clearLogo2 = () => { setLogoFile2(null); setLogoPreview2(""); };

  const toggleLogoEffect = (id) => setActiveLogoEffects(prev => prev.includes(id) ? prev.filter(e => e !== id) : [...prev, id]);
  const toggleTitleEffect = (id) => setActiveTitleEffects(prev => prev.includes(id) ? prev.filter(e => e !== id) : [...prev, id]);
  const toggleFeature = (id) => setEnabledFeatures(prev => prev.includes(id) ? prev.filter(e => e !== id) : [...prev, id]);
  
  const toggleFeaturedPage = (page) => {
    if (!page || typeof page !== 'string') return;
    if (featuredNavPages.includes(page)) {
      setFeaturedNavPages(featuredNavPages.filter(p => p !== page));
    } else if (featuredNavPages.length < 4) {
      setFeaturedNavPages([...featuredNavPages, page]);
    }
  };

  const [showDeleteConfirm, setShowDeleteConfirm] = useState(0); // 0: none, 1: first confirm, 2: second confirm

  const handleDeleteAllBranding = async () => {
    setIsSaving(true);
    try {
      const genericData = {
        app_title: "Base44 Effects",
        logo_url: "",
        logo_url_2: "",
        logo_morph_enabled: true,
        logo_overlay_enabled: true,
        footer_config: { columns: 4, column_widgets: ["brand", "stats", "settings", "install"], alignment: "left", style: "default" },
        promo_bar: { enabled: false, text: "Welcome to Base44 Effects", link_url: "", link_text: "Learn More", gradient: "from-violet-600 via-fuchsia-600 to-pink-600", sticky: true },
        youtube_overlay_image_url: "",
        hero_style: { gradient_start: "#7c3aed", gradient_middle: "#8b5cf6", gradient_end: "#db2777", opacity: 0.6, effects: [] },
        // Keep functional settings, reset branding visuals
        version: "1.0.0"
      };
      
      if (settings?.id) {
        await base44.entities.AppSettings.update(settings.id, genericData);
      }
      
      await queryClient.invalidateQueries({ queryKey: ['appSettings'] });
      setSaveMessage("✓ All branding reset to defaults.");
      setTimeout(() => setSaveMessage(""), 4000);
      setShowDeleteConfirm(0);
      // Reload page to reflect changes cleanly
      window.location.reload();
    } catch (error) {
      console.error("Reset error:", error);
      setSaveError("Failed to reset branding.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveMessage("");
    setSaveError("");
    
    try {
      let logoUrl = logoPreview || "";
      
      // Only upload if we have a new file
      if (logoFile) {
        try {
          const result = await base44.integrations.Core.UploadFile({ file: logoFile });
          logoUrl = result.file_url;
        } catch (uploadError) {
          console.error("Upload error:", uploadError);
          // If upload fails, try to keep existing URL or use data URL
          if (settings?.logo_url) {
            logoUrl = settings.logo_url;
          } else if (logoPreview && logoPreview.startsWith('data:')) {
            // Store the data URL directly (for small images)
            logoUrl = logoPreview;
          }
        }
      } else if (!logoPreview) {
        logoUrl = "";
      } else if (logoPreview && !logoPreview.startsWith('http')) {
        // Keep existing URL if we have one
        logoUrl = settings?.logo_url || "";
      }

      // Handle logo 2 upload
      let logoUrl2 = logoPreview2 || "";
      if (logoFile2) {
        try {
          const result2 = await base44.integrations.Core.UploadFile({ file: logoFile2 });
          logoUrl2 = result2.file_url;
        } catch (e) {
          if (settings?.logo_url_2) logoUrl2 = settings.logo_url_2;
        }
      } else if (!logoPreview2) {
        logoUrl2 = "";
      } else if (logoPreview2 && !logoPreview2.startsWith('http')) {
        logoUrl2 = settings?.logo_url_2 || "";
      }

      // Keep existing icon images if already uploaded
      const leftIcon = promoBar.leftIconImage || settings?.promo_bar?.leftIconImage || "";
      const rightIcon = promoBar.rightIconImage || settings?.promo_bar?.rightIconImage || "";

      // Handle back to top logo upload
      let backToTopUrl = backToTopLogo || "";
      if (backToTopFile) {
        try {
          const result = await base44.integrations.Core.UploadFile({ file: backToTopFile });
          backToTopUrl = result.file_url;
        } catch (e) { console.error("Back to top upload failed"); }
      }

      const data = {
        app_title: appTitle || "Base44 Effects",
        logo_url: logoUrl,
        logo_url_2: logoUrl2,
        logo_morph_enabled: logoMorphEnabled,
        logo_morph_speed: logoMorphSpeed,
        logo_glitch_enabled: logoGlitchEnabled,
        logo_glitch_interval: logoGlitchInterval,
        logo_overlay_enabled: logoOverlayEnabled,
        back_to_top_logo: backToTopUrl,
        bottom_banner_url: bottomBannerUrl,
        bottom_banner_link: bottomBannerLink,
        footer_effect: footerEffect,
        footer_widgets: footerWidgets,
        version: version || "1.0.0",
        logo_effects: activeLogoEffects,
        title_effects: activeTitleEffects,
        enabled_features: enabledFeatures,
        selected_banner: selectedBanner,
        banner_configs: bannerConfigs,
        social_links: socialLinks,
        donation_settings: donationSettings,
        promo_bar: {
          enabled: promoBar.enabled,
          text: promoBar.text,
          link_url: promoBar.link_url,
          link_text: promoBar.link_text,
          gradient: promoBar.gradient || "from-violet-600 via-fuchsia-600 to-pink-600",
          sticky: promoBar.sticky !== false,
          shadow: promoBar.shadow || false,
          autoHide: promoBar.autoHide || false,
          watermark_url: promoBar.watermark_url || "",
          leftIconImage: leftIcon,
          rightIconImage: rightIcon,
          fontFamily: promoBar.fontFamily || "Arial",
          textGlitch: promoBar.textGlitch || false,
          override_template_link: promoBar.override_template_link || false,
          custom_template_url: promoBar.custom_template_url || ""
        },
        hero_style: heroStyle,
        modern_video: modernVideo,
        walkthrough_video: walkthroughVideo,
        see_it_in_action_enabled: seeItInActionEnabled,
        coffee_banner: coffeeBanner,
        footer_config: footerConfig,
        cta_section: ctaSection,
        featured_nav_random: featuredNavRandom,
        featured_nav_pages: featuredNavPages,
        template_showcase: templateShowcase,
        donation_banner: donationBanner,
        hero_layout: heroLayout,
        youtube_overlay_image_url: youtubeOverlayUrl,
        youtube_overlay_enabled: youtubeOverlayEnabled,
        announcements_enabled: announcementsEnabled,
        global_search_enabled: globalSearchEnabled
      };

      if (settings?.id) {
        await base44.entities.AppSettings.update(settings.id, data);
      } else {
        await base44.entities.AppSettings.create(data);
      }

      await queryClient.invalidateQueries({ queryKey: ['appSettings'] });
      setSaveMessage("✓ Settings saved successfully! Refresh to see changes.");
      setLogoFile(null);
      setBackToTopFile(null);
      setTimeout(() => setSaveMessage(""), 4000);
    } catch (error) {
      console.error("Save error:", error);
      setSaveError(`Save failed: ${error.message || "Unknown error"}. Settings without logo were saved.`);
      
      // Try saving without logo
      try {
        const dataWithoutLogo = {
          app_title: appTitle || "Base44 Effects",
          logo_url: settings?.logo_url || "",
          version: version || "1.0.0",
          logo_effects: activeLogoEffects,
              title_effects: activeTitleEffects,
              enabled_features: enabledFeatures,
              selected_banner: selectedBanner,
              banner_configs: bannerConfigs
            };
        if (settings?.id) {
          await base44.entities.AppSettings.update(settings.id, dataWithoutLogo);
        } else {
          await base44.entities.AppSettings.create(dataWithoutLogo);
        }
        queryClient.invalidateQueries({ queryKey: ['appSettings'] });
        setSaveMessage("Title and settings saved (logo upload failed).");
      } catch (e) {
        console.error("Fallback save also failed:", e);
      }
    } finally {
      setIsSaving(false);
    }
  };



  const tabs = [
    { id: "branding", label: "Branding", icon: Image },
    { id: "features", label: "Features", icon: Zap },
    { id: "monetization", label: "Monetization", icon: Heart },
    { id: "customization", label: "Customization", icon: Sparkles },
    { id: "video", label: "Video Showcase", icon: Video },
    { id: "announcements", label: "Announcements", icon: Megaphone },
    { id: "analytics", label: "Analytics", icon: LayoutDashboard },
    { id: "library", label: "Library", icon: Code },
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-6xl mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          <div className="flex items-center gap-4 mb-8" data-tour="admin-header">
            <motion.div animate={{ rotate: 360 }} transition={{ duration: 20, repeat: Infinity, ease: "linear" }}>
              {settings?.logo_url ? (
                <img src={settings.logo_url} alt="Logo" className="w-16 h-16 object-contain" />
              ) : (
                <Settings className="w-16 h-16 text-white" />
              )}
            </motion.div>
            <div>
              <h1 className="text-3xl font-bold text-white">Master Admin Dashboard</h1>
              <p className="text-slate-400">Customize your app experience</p>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 border-b border-slate-800 mb-6 overflow-x-auto" data-tour="admin-tabs">
            {tabs.map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors whitespace-nowrap ${activeTab === tab.id ? "border-violet-500 text-white" : "border-transparent text-slate-400 hover:text-white"}`}>
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>

          {activeTab === "branding" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Logo Card */}
            <Card className="bg-slate-900/50 border-slate-800" data-tour="branding-section">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-white flex items-center gap-2"><Image className="w-5 h-5" /> App Logos (Logo Effects)</CardTitle>
                    <CardDescription className="text-slate-400">Upload logos and configure visual effects</CardDescription>
                  </div>
                  <div className="flex flex-col gap-2">
                    {showDeleteConfirm === 0 ? (
                      <Button variant="destructive" size="sm" onClick={() => setShowDeleteConfirm(1)} className="bg-red-900/50 hover:bg-red-800 text-red-200 border border-red-800">
                        <AlertCircle className="w-3 h-3 mr-1" />
                        Delete Branding
                      </Button>
                    ) : showDeleteConfirm === 1 ? (
                      <Button variant="destructive" size="sm" onClick={() => setShowDeleteConfirm(2)} className="bg-red-600 hover:bg-red-700 animate-pulse">
                        Sure? Click again
                      </Button>
                    ) : (
                      <div className="flex flex-col gap-1">
                        <Button size="sm" variant="outline" onClick={() => setShowDeleteConfirm(0)}>Cancel</Button>
                        <Button size="sm" variant="destructive" onClick={handleDeleteAllBranding} className="bg-red-600 hover:bg-red-700 font-bold text-xs">
                          YES, DELETE ALL
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  {/* Logo 1 */}
                  <div>
                    <Label className="text-slate-400 text-xs mb-2 block">Primary Logo</Label>
                    <div onDragOver={handleDragOver} onDragLeave={handleDragLeave} onDrop={handleDrop} className={`relative border-2 border-dashed rounded-xl p-4 text-center transition-all cursor-pointer ${isDragging ? 'border-violet-500 bg-violet-500/10' : 'border-slate-700 hover:border-slate-600'}`}>
                      {logoPreview ? (
                        <div className="relative inline-block">
                          <img src={logoPreview} alt="Logo" className="w-20 h-20 rounded-xl object-contain mx-auto bg-slate-800" />
                          <button onClick={(e) => { e.stopPropagation(); clearLogo(); }} className="absolute -top-2 -right-2 p-1 bg-red-500 rounded-full text-white hover:bg-red-600"><X className="w-3 h-3" /></button>
                        </div>
                      ) : (
                        <div className="py-4">
                          <Upload className="w-8 h-8 text-slate-500 mx-auto mb-2" />
                          <p className="text-slate-400 text-xs">Logo 1</p>
                        </div>
                      )}
                      <input type="file" accept="image/png,image/jpeg,image/svg+xml,image/webp,image/gif" onChange={handleFileInput} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                    </div>
                  </div>
                  {/* Logo 2 */}
                  <div>
                    <Label className="text-slate-400 text-xs mb-2 block">Secondary Logo</Label>
                    <div className={`relative border-2 border-dashed rounded-xl p-4 text-center transition-all cursor-pointer border-slate-700 hover:border-cyan-500`}>
                      {logoPreview2 ? (
                        <div className="relative inline-block">
                          <img src={logoPreview2} alt="Logo 2" className="w-20 h-20 rounded-xl object-contain mx-auto bg-slate-800" />
                          <button onClick={(e) => { e.stopPropagation(); clearLogo2(); }} className="absolute -top-2 -right-2 p-1 bg-red-500 rounded-full text-white hover:bg-red-600"><X className="w-3 h-3" /></button>
                        </div>
                      ) : (
                        <div className="py-4">
                          <Upload className="w-8 h-8 text-slate-500 mx-auto mb-2" />
                          <p className="text-slate-400 text-xs">Logo 2</p>
                        </div>
                      )}
                      <input type="file" accept="image/png,image/jpeg,image/svg+xml,image/webp,image/gif" onChange={handleFileInput2} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                    </div>
                  </div>
                </div>
                <div className="space-y-3 pt-2 border-t border-slate-700">
                  <div className="flex items-center justify-between">
                    <Label className="text-slate-400 text-xs">Enable Morphing</Label>
                    <ToggleSwitch checked={logoMorphEnabled && !logoGlitchEnabled} onCheckedChange={(v) => { setLogoMorphEnabled(v); if(v) setLogoGlitchEnabled(false); }} />
                  </div>
                  {logoMorphEnabled && !logoGlitchEnabled && (
                    <div>
                      <Label className="text-slate-400 text-xs">Morph Speed: {logoMorphSpeed}s</Label>
                      <input type="range" min="2" max="15" value={logoMorphSpeed} onChange={(e) => setLogoMorphSpeed(Number(e.target.value))} className="w-full accent-violet-500" />
                    </div>
                  )}
                  <div className="flex items-center justify-between">
                    <Label className="text-slate-400 text-xs">Enable Glitch Effect</Label>
                    <ToggleSwitch checked={logoGlitchEnabled} onCheckedChange={(v) => { setLogoGlitchEnabled(v); if(v) setLogoMorphEnabled(false); }} />
                  </div>
                  {logoGlitchEnabled && (
                    <div>
                      <Label className="text-slate-400 text-xs">Trigger Every: {logoGlitchInterval}s</Label>
                      <input type="range" min="5" max="60" value={logoGlitchInterval} onChange={(e) => setLogoGlitchInterval(Number(e.target.value))} className="w-full accent-violet-500" />
                    </div>
                  )}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-700">
                    <div>
                      <Label className="text-slate-400 text-xs">Overlay Both Logos</Label>
                      <p className="text-[10px] text-slate-600">When checked, both logos display together</p>
                    </div>
                    <ToggleSwitch checked={logoOverlayEnabled} onCheckedChange={setLogoOverlayEnabled} />
                  </div>
                  <p className="text-xs text-slate-500 text-center">{logoGlitchEnabled ? "Glitch effect active" : logoMorphEnabled ? "Logos morph between each other" : "Only primary logo shown"}</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2"><Type className="w-5 h-5" /> App Title & Version</CardTitle>
                <CardDescription className="text-slate-400">Customize the navigation title appearance</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-slate-400 text-xs mb-2 block">App Title Text</Label>
                  <Input value={appTitle} onChange={(e) => setAppTitle(e.target.value)} placeholder="Base44 Effects" className="bg-slate-800 border-slate-700 text-white text-lg h-12" />
                </div>
                
                <p className="text-xs text-slate-500 mb-2">Title colors saved with main settings button</p>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                  <Label className="text-slate-400 text-xs mb-3 block">Live Preview</Label>
                  <div className="text-center">
                    <span className="text-2xl font-bold text-white">{appTitle || "Base44 Effects"}</span>
                  </div>
                </div>
                
                <div>
                  <Label className="text-white text-sm mb-2 block flex items-center gap-2"><Hash className="w-4 h-4" /> Version Number</Label>
                  <Input value={version} onChange={(e) => setVersion(e.target.value)} placeholder="1.0.0" className="bg-slate-800 border-slate-700 text-white" />
                </div>
              </CardContent>
            </Card>
            </div>
          )}

          {activeTab === "branding" && (
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2"><Sparkles className="w-5 h-5" /> 🎬 Marketing Description Generator</CardTitle>
              <CardDescription className="text-slate-400">Copy-ready descriptions for the Base44 Template Store</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                  <h4 className="text-violet-400 font-medium mb-2">🚀 Short & Punchy</h4>
                  <p className="text-slate-300 text-sm">"UI Effects Playground — 200+ animated components, copy-paste code, and AI prompts. Build like a pro, for free!"</p>
                </div>
                <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                  <h4 className="text-cyan-400 font-medium mb-2">😎 Fun & Playful</h4>
                  <p className="text-slate-300 text-sm">"Why code from scratch when you can copy-paste greatness? 200+ effects that'll make your users go 'WHOA!' No wizardry required."</p>
                </div>
                <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                  <h4 className="text-pink-400 font-medium mb-2">📋 Detailed</h4>
                  <p className="text-slate-300 text-sm">"A comprehensive UI effects library featuring visual effects, animations, buttons, admin layouts, marketing components, social features, e-commerce elements, and more. Each effect includes live demos, copy-ready code, and AI prompts for customization."</p>
                </div>
                <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                  <h4 className="text-amber-400 font-medium mb-2">🏆 Feature Focus</h4>
                  <p className="text-slate-300 text-sm">"• 200+ Ready Effects • Copy Code Instantly • AI Prompt Generator • 20+ Categories • Mobile Responsive • Dark Theme • PWA Ready • Free Forever"</p>
                </div>
              </div>
              <div className="p-4 rounded-xl bg-gradient-to-r from-violet-500/10 to-cyan-500/10 border border-violet-500/30">
                <h4 className="text-white font-medium mb-2">✨ Our Favorite (Use This One!)</h4>
                <p className="text-slate-200">"Stop reinventing the wheel! 🎡 UI Effects Playground is your secret weapon for building stunning interfaces. Browse 200+ animated components, click to copy code, grab AI prompts for customization, and ship features your users will actually love. It's like having a senior developer's component library... except it's free and you don't have to share your snacks. 🍕"</p>
              </div>
            </CardContent>
          </Card>

          )}

          {activeTab === "customization" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-6">
                <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">🎨 Hero Layout & Video</CardTitle>
                    <CardDescription className="text-slate-400">Hero section layout and video configuration</CardDescription>
                  </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => setHeroLayout("split")}
                    className={`p-4 rounded-lg border-2 transition-all ${
                      heroLayout === "split"
                        ? "border-violet-500 bg-violet-500/20"
                        : "border-slate-700 bg-slate-800/50 hover:border-slate-600"
                    }`}
                  >
                    <div className="text-2xl mb-1">📺</div>
                    <div className="font-bold text-white text-sm">Split + Video</div>
                    <div className="text-[10px] text-slate-400">Content & video</div>
                  </button>
                  <button
                    onClick={() => setHeroLayout("default")}
                    className={`p-4 rounded-lg border-2 transition-all ${
                      heroLayout === "default"
                        ? "border-violet-500 bg-violet-500/20"
                        : "border-slate-700 bg-slate-800/50 hover:border-slate-600"
                    }`}
                  >
                    <div className="text-2xl mb-1">📱</div>
                    <div className="font-bold text-white text-sm">Centered</div>
                    <div className="text-[10px] text-slate-400">Solo layout</div>
                  </button>
                </div>
                
                {heroLayout === "split" && (
                  <div className="pt-3 border-t border-slate-700">
                    <Label className="text-slate-400 text-xs mb-2 block">Hero Video URL (YouTube)</Label>
                    <Input
                      value={walkthroughVideo.youtube_url}
                      onChange={(e) => setWalkthroughVideo(p => ({ ...p, youtube_url: e.target.value }))}
                      placeholder="https://youtube.com/watch?v=..."
                      className="bg-slate-800 border-slate-700 text-white text-sm"
                    />
                  </div>
                )}
                </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">📺 "See It In Action" Section</CardTitle>
                    <CardDescription className="text-slate-400">Full walkthrough video section below hero</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-slate-950 rounded-lg border border-slate-800">
                      <div>
                        <Label className="text-white text-sm">Enable Section</Label>
                        <p className="text-[10px] text-slate-500">Show "See It In Action" video section</p>
                      </div>
                      <ToggleSwitch checked={seeItInActionEnabled} onCheckedChange={setSeeItInActionEnabled} />
                    </div>
                  </CardContent>
                </Card>
                </div>

                <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">🎯 Featured Navigation</CardTitle>
                  <CardDescription className="text-slate-400">Top nav featured pages (4 slots)</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <div>
                    <Label className="text-white text-sm">Random Discovery</Label>
                    <p className="text-[10px] text-slate-500">Randomize featured pages</p>
                  </div>
                  <ToggleSwitch checked={featuredNavRandom} onCheckedChange={setFeaturedNavRandom} />
                </div>
                
                {!featuredNavRandom && (
                  <div className="space-y-2 pt-2 border-t border-slate-700">
                    <Label className="text-slate-400 text-xs">Select 4 Pages</Label>
                    <div className="grid grid-cols-6 gap-1">
                      {["VisualEffects", "AudioEffects", "Transitions", "ButtonEffects", "ColorSchemes", "IconEffects", "MenuEffects", "NavigationEffects", "ChatEffects", "AIAgentEffects", "AdminLayouts", "MarketingEffects", "EcommerceEffects", "GamingEffects", "VideoEffects", "DonationComponents", "CreativeEffects", "ContentEffects", "CommunicationEffects", "SocialEffects", "ProductivityEffects", "CartCheckout", "AbstractAnimations", "PixelAssets", "DividerEffects", "LoadingSpinners", "TextEffects", "CharacterEffects"].map(page => (
                        <button
                          key={page}
                          onClick={() => toggleFeaturedPage(page)}
                          className={`px-1 py-1.5 rounded text-[11px] transition-all ${
                            featuredNavPages.includes(page)
                              ? "bg-violet-500 text-white"
                              : featuredNavPages.length >= 4
                                ? "bg-slate-800 text-slate-600 cursor-not-allowed"
                                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                          }`}
                          disabled={featuredNavPages.length >= 4 && !featuredNavPages.includes(page)}
                        >
                          {page.replace(/([A-Z])/g, ' $1').trim()}
                        </button>
                      ))}
                    </div>
                    <p className="text-[10px] text-slate-500">
                      Selected: {featuredNavPages.length}/4
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
            </div>
          )}

          {activeTab === "customization" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2"><Star className="w-4 h-4" /> Promo Bar</CardTitle>
                <CardDescription className="text-slate-400">Top notification bar</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <Label className="text-white text-sm">Enable Promo Bar</Label>
                  <ToggleSwitch checked={promoBar.enabled} onCheckedChange={(v) => setPromoBar(p => ({ ...p, enabled: v }))} />
                </div>

                <div className="grid md:grid-cols-2 gap-3">
                  <div>
                    <Label className="text-slate-400 text-xs mb-1">Message</Label>
                    <Input 
                      value={promoBar.text} 
                      onChange={(e) => setPromoBar(p => ({ ...p, text: e.target.value }))} 
                      placeholder="Your announcement..." 
                      className="bg-slate-800 border-slate-700 text-white text-sm" 
                    />
                  </div>
                  <div>
                    <Label className="text-slate-400 text-xs mb-1">Link Text</Label>
                    <Input 
                      value={promoBar.link_text} 
                      onChange={(e) => setPromoBar(p => ({ ...p, link_text: e.target.value }))} 
                      placeholder="Learn More →" 
                      className="bg-slate-800 border-slate-700 text-white text-sm" 
                    />
                  </div>
                </div>

                <div>
                  <Label className="text-slate-400 text-xs mb-1">Link URL</Label>
                  <Input 
                    value={promoBar.link_url} 
                    onChange={(e) => setPromoBar(p => ({ ...p, link_url: e.target.value }))} 
                    placeholder="https://..." 
                    className="bg-slate-800 border-slate-700 text-white text-sm" 
                  />
                </div>

                <div className="pt-3 border-t border-slate-700 space-y-3">
                  <div className="flex items-center justify-between p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <div>
                      <Label className="text-white text-sm">Override with "Get This Template"</Label>
                      <p className="text-[10px] text-slate-500">Show template CTA instead of custom text</p>
                    </div>
                    <ToggleSwitch checked={promoBar.override_template_link} onCheckedChange={(v) => setPromoBar(p => ({ ...p, override_template_link: v }))} />
                  </div>
                  
                  {promoBar.override_template_link && (
                    <div>
                      <Label className="text-slate-400 text-xs mb-1">Template URL</Label>
                      <Input 
                        value={promoBar.custom_template_url} 
                        onChange={(e) => setPromoBar(p => ({ ...p, custom_template_url: e.target.value }))} 
                        placeholder="https://base44.com/u/team44" 
                        className="bg-slate-800 border-slate-700 text-white text-sm" 
                      />
                      <p className="text-xs text-slate-500 mt-1">Where users go when clicking "Get This Template"</p>
                    </div>
                  )}
                </div>

                <div className="grid md:grid-cols-2 gap-3 pt-3 border-t border-slate-700">
                  <div>
                    <Label className="text-slate-400 text-xs mb-2 block">Gradient</Label>
                    <div className="grid grid-cols-3 gap-1 mb-2">
                      {[
                        { name: "Sunset", value: "from-violet-600 via-fuchsia-600 to-pink-600" },
                        { name: "Royal", value: "from-indigo-900 via-purple-900 to-slate-900" },
                        { name: "Ocean", value: "from-blue-600 via-cyan-600 to-teal-600" },
                        { name: "Fire", value: "from-red-600 via-orange-600 to-amber-600" },
                        { name: "Neon", value: "from-pink-500 via-purple-500 to-cyan-500" },
                        { name: "Midnight", value: "from-slate-900 via-slate-800 to-slate-900" }
                      ].map(grad => (
                        <button
                          key={grad.name}
                          onClick={() => setPromoBar(p => ({ ...p, gradient: grad.value }))}
                          className={`h-8 rounded border ${(promoBar.gradient || "from-violet-600 via-fuchsia-600 to-pink-600") === grad.value ? "border-white" : "border-transparent"}`}
                          title={grad.name}
                        >
                          <div className={`h-full w-full rounded bg-gradient-to-r ${grad.value}`} />
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label className="text-slate-400 text-xs mb-2 block">Font</Label>
                    <select
                      value={promoBar.fontFamily || "Arial"}
                      onChange={(e) => setPromoBar(p => ({ ...p, fontFamily: e.target.value }))}
                      className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg p-2 text-xs"
                    >
                      <option value="Arial">Arial</option>
                      <option value="Inter">Inter</option>
                      <option value="Poppins">Poppins</option>
                      <option value="Orbitron">Orbitron</option>
                      <option value="Press Start 2P">Press Start 2P</option>
                    </select>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-3 pt-3 border-t border-slate-700">
                  <div>
                    <Label className="text-slate-400 text-xs mb-2 block">Left Icon</Label>
                    <label className="cursor-pointer block">
                      <div className="p-2 border border-dashed border-slate-700 rounded hover:border-violet-500 text-center relative">
                        {promoBar.leftIconImage ? (
                          <>
                            <img src={promoBar.leftIconImage} alt="Left" className="w-6 h-6 mx-auto" />
                            <button 
                              onClick={(e) => { e.preventDefault(); e.stopPropagation(); setPromoBar(p => ({ ...p, leftIconImage: '' })); }}
                              className="absolute -top-1 -right-1 p-0.5 bg-red-500 rounded-full text-white hover:bg-red-600"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </>
                        ) : (
                          <Upload className="w-5 h-5 mx-auto text-slate-600" />
                        )}
                      </div>
                      <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                        const file = e.target.files[0];
                        if (file) {
                          try {
                            const result = await base44.integrations.Core.UploadFile({ file });
                            setPromoBar(p => ({ ...p, leftIconImage: result.file_url }));
                          } catch (err) { console.error(err); }
                        }
                      }} />
                    </label>
                  </div>
                  <div>
                    <Label className="text-slate-400 text-xs mb-2 block">Right Icon</Label>
                    <label className="cursor-pointer block">
                      <div className="p-2 border border-dashed border-slate-700 rounded hover:border-cyan-500 text-center relative">
                        {promoBar.rightIconImage ? (
                          <>
                            <img src={promoBar.rightIconImage} alt="Right" className="w-6 h-6 mx-auto" />
                            <button 
                              onClick={(e) => { e.preventDefault(); e.stopPropagation(); setPromoBar(p => ({ ...p, rightIconImage: '' })); }}
                              className="absolute -top-1 -right-1 p-0.5 bg-red-500 rounded-full text-white hover:bg-red-600"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </>
                        ) : (
                          <Upload className="w-5 h-5 mx-auto text-slate-600" />
                        )}
                      </div>
                      <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                        const file = e.target.files[0];
                        if (file) {
                          try {
                            const result = await base44.integrations.Core.UploadFile({ file });
                            setPromoBar(p => ({ ...p, rightIconImage: result.file_url }));
                          } catch (err) { console.error(err); }
                        }
                      }} />
                    </label>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-3 pt-3 border-t border-slate-700">
                  <div className="flex items-center justify-between p-2 bg-slate-950 rounded border border-slate-800">
                    <Label className="text-slate-400 text-xs">Sticky</Label>
                    <ToggleSwitch checked={promoBar.sticky !== false} onCheckedChange={(v) => setPromoBar(p => ({ ...p, sticky: v }))} />
                  </div>
                  <div className="flex items-center justify-between p-2 bg-slate-950 rounded border border-slate-800">
                    <Label className="text-slate-400 text-xs">Text Glitch</Label>
                    <ToggleSwitch checked={promoBar.textGlitch} onCheckedChange={(v) => setPromoBar(p => ({ ...p, textGlitch: v }))} />
                  </div>
                </div>

                <div>
                  <Label className="text-slate-400 text-xs mb-2 block">Watermark Background</Label>
                  <div className="flex gap-2">
                    <Input 
                      value={promoBar.watermark_url || ""} 
                      onChange={(e) => setPromoBar(p => ({ ...p, watermark_url: e.target.value }))} 
                      placeholder="PNG overlay URL" 
                      className="bg-slate-800 border-slate-700 text-white text-xs flex-1" 
                    />
                    <label className="px-3 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded cursor-pointer">
                      <Upload className="w-4 h-4" />
                      <input type="file" accept="image/png" className="hidden" onChange={async (e) => {
                        const file = e.target.files[0];
                        if (file) {
                          try {
                            const result = await base44.integrations.Core.UploadFile({ file });
                            setPromoBar(p => ({ ...p, watermark_url: result.file_url }));
                          } catch (err) { console.error(err); }
                        }
                      }} />
                    </label>
                  </div>
                </div>
              </CardContent>
            </Card>

              <div className="space-y-6">
                <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2"><Sparkles className="w-5 h-5" /> Social Media Links</CardTitle>
                    <CardDescription className="text-slate-400">Configure footer social media links</CardDescription>
                  </CardHeader>
                  <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  { key: "github", label: "GitHub", placeholder: "https://github.com/..." },
                  { key: "twitter", label: "X (Twitter)", placeholder: "https://x.com/..." },
                  { key: "instagram", label: "Instagram", placeholder: "https://instagram.com/..." },
                  { key: "facebook", label: "Facebook", placeholder: "https://facebook.com/..." },
                  { key: "youtube", label: "YouTube", placeholder: "https://youtube.com/..." },
                  { key: "linkedin", label: "LinkedIn", placeholder: "https://linkedin.com/..." },
                ].map(social => (
                  <div key={social.key}>
                    <Label className="text-slate-400 text-xs mb-1 block">{social.label}</Label>
                    <Input
                      value={socialLinks[social.key] || ""}
                      onChange={(e) => setSocialLinks(prev => ({ ...prev, [social.key]: e.target.value }))}
                      placeholder={social.placeholder}
                      className="bg-slate-800 border-slate-700 text-white text-sm"
                    />
                  </div>
                ))}
                  </div>
                </CardContent>
                </Card>

                <BannerConfigPanel
                  selectedBanner={selectedBanner}
                  setSelectedBanner={setSelectedBanner}
                  bannerConfigs={bannerConfigs}
                  setBannerConfigs={setBannerConfigs}
                />
              </div>
            </div>
          )}

          {activeTab === "features" && (
            <div className="space-y-6">
            {/* Global Search Toggle Card */}
            <Card className="bg-slate-900/50 border-slate-800 border-l-4 border-l-violet-500">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Search className="w-5 h-5" /> Global Search Bar
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Enable/disable the global search bar in the header
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between p-4 bg-slate-950 rounded-xl border border-slate-800">
                  <div>
                    <Label className="text-white text-sm">Show Global Search</Label>
                    <p className="text-xs text-slate-500">Display search bar in header navigation</p>
                  </div>
                  <ToggleSwitch checked={globalSearchEnabled} onCheckedChange={setGlobalSearchEnabled} />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-white flex items-center gap-2"><ToggleLeft className="w-4 h-4" /> Features</CardTitle>
                    <CardDescription className="text-slate-400 text-sm">Enable/disable pages</CardDescription>
                  </div>
                  <div className="flex gap-2 text-[10px]">
                    <span className="px-2 py-1 rounded bg-green-500/20 text-green-400 border border-green-500/30">{enabledFeatures.length} ON</span>
                    <span className="px-2 py-1 rounded bg-slate-700/50 text-slate-500">{featureToggles.length - enabledFeatures.length} OFF</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="text-xs font-semibold text-violet-400 mb-2">Pages</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {featureToggles.filter(f => f.category === "pages").map(feature => (
                      <div key={feature.id} className={`p-2 rounded-lg border transition-all ${enabledFeatures.includes(feature.id) ? "bg-green-500/10 border-green-500/50" : "bg-slate-800/50 border-slate-700"}`}>
                        <div className="flex items-center justify-between gap-1">
                          <div className="flex items-center gap-1 min-w-0">
                            <feature.icon className={`w-3 h-3 flex-shrink-0 ${enabledFeatures.includes(feature.id) ? "text-green-400" : "text-slate-500"}`} />
                            <p className={`text-[10px] font-medium truncate ${enabledFeatures.includes(feature.id) ? "text-white" : "text-slate-400"}`}>{feature.name}</p>
                          </div>
                          <ToggleSwitch checked={enabledFeatures.includes(feature.id)} onCheckedChange={() => toggleFeature(feature.id)} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="pt-3 border-t border-slate-700">
                  <h4 className="text-xs font-semibold text-cyan-400 mb-2">Features</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {featureToggles.filter(f => f.category === "features").map(feature => (
                      <div key={feature.id} className={`p-2 rounded-lg border transition-all ${enabledFeatures.includes(feature.id) ? "bg-green-500/10 border-green-500/50" : "bg-slate-800/50 border-slate-700"}`}>
                        <div className="flex items-center justify-between gap-1">
                          <div className="flex items-center gap-1 min-w-0">
                            <feature.icon className={`w-3 h-3 flex-shrink-0 ${enabledFeatures.includes(feature.id) ? "text-green-400" : "text-slate-500"}`} />
                            <p className={`text-[10px] font-medium truncate ${enabledFeatures.includes(feature.id) ? "text-white" : "text-slate-400"}`}>{feature.name}</p>
                          </div>
                          <ToggleSwitch checked={enabledFeatures.includes(feature.id)} onCheckedChange={() => toggleFeature(feature.id)} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
            </div>
          )}



          {activeTab === "customization" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">👣 Footer Customizer</CardTitle>
                  <CardDescription className="text-slate-400">Configure footer layout, widgets, and styling</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                <div>
                  <Label className="text-white mb-2 block">Number of Columns</Label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4].map(num => (
                      <button
                        key={num}
                        onClick={() => setFooterConfig(p => ({ ...p, columns: num, column_widgets: p.column_widgets.slice(0, num) }))}
                        className={`flex-1 py-2 rounded-lg border ${footerConfig.columns === num ? "bg-violet-600 border-violet-500 text-white" : "bg-slate-800 border-slate-700 text-slate-400"}`}
                      >
                        {num} Column{num > 1 ? 's' : ''}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-white mb-2 block">Footer Alignment</Label>
                  <div className="flex gap-2">
                    {[
                      { id: "left", label: "Left" },
                      { id: "center", label: "Center" },
                      { id: "justify", label: "Justify" }
                    ].map(align => (
                      <button
                        key={align.id}
                        onClick={() => setFooterConfig(p => ({ ...p, alignment: align.id }))}
                        className={`flex-1 py-2 rounded-lg border ${footerConfig.alignment === align.id ? "bg-violet-600 border-violet-500 text-white" : "bg-slate-800 border-slate-700 text-slate-400"}`}
                      >
                        {align.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-white mb-2 block">Footer Style</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: "default", label: "Default", desc: "Standard dark" },
                      { id: "glass", label: "Glassmorphism", desc: "Frosted glass" },
                      { id: "gradient", label: "Gradient", desc: "Color fade" },
                      { id: "minimal", label: "Minimal", desc: "Clean & simple" }
                    ].map(style => (
                      <button
                        key={style.id}
                        onClick={() => setFooterConfig(p => ({ ...p, style: style.id }))}
                        className={`p-3 rounded-lg border text-left ${footerConfig.style === style.id ? "bg-violet-600 border-violet-500 text-white" : "bg-slate-800 border-slate-700 text-slate-400"}`}
                      >
                        <div className="font-medium text-sm">{style.label}</div>
                        <div className="text-xs opacity-70">{style.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(${footerConfig.columns}, 1fr)` }}>
                  {Array.from({ length: footerConfig.columns }).map((_, idx) => (
                    <div key={idx} className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                      <Label className="text-xs text-slate-500 mb-2 block">Column {idx + 1}</Label>
                      <select 
                        className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg p-2 text-sm"
                        value={footerConfig.column_widgets?.[idx] || "brand"}
                        onChange={(e) => {
                          const newWidgets = [...(footerConfig.column_widgets || [])];
                          newWidgets[idx] = e.target.value;
                          setFooterConfig(p => ({ ...p, column_widgets: newWidgets }));
                        }}
                      >
                        <option value="none">⚪ None (Empty Space)</option>
                        <option value="brand">🎨 Brand & Bio</option>
                        <option value="links_social">🔗 Social Links</option>
                        <option value="stats">🔢 Component Counter</option>
                        <option value="settings">⚙️ Theme Settings</option>
                        <option value="install">📱 Install App (QR)</option>
                        <option value="newsletter">📧 Newsletter</option>
                        <option value="contact">📞 Contact Info</option>
                        <option value="links_legal">⚖️ Legal Links</option>
                        <option value="links_quick">⚡ Quick Links</option>
                        <option value="map">🗺️ Location Map</option>
                        <option value="gallery">🖼️ Mini Gallery</option>
                        <option value="testimonial">💬 Testimonial</option>
                        <option value="pricing">💰 Pricing Card</option>
                        <option value="features">✨ Features List</option>
                        <option value="faq">❓ FAQ Section</option>
                        <option value="awards">🏆 Awards & Badges</option>
                        <option value="team">👥 Team Members</option>
                        <option value="events">📅 Events Calendar</option>
                        <option value="blog">📝 Recent Posts</option>
                        <option value="partners">🤝 Partner Logos</option>
                        <option value="custom_image">🖼️ Custom Image</option>
                        <option value="custom_video">📺 YouTube Video</option>
                      </select>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

              <div className="space-y-6">
                <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2"><Image className="w-5 h-5" /> Back to Top Button Logo</CardTitle>
                    <CardDescription className="text-slate-400">Custom logo for the scroll-to-top button</CardDescription>
                  </CardHeader>
                  <CardContent>
                <div className="flex items-center gap-4">
                  <div className="relative border-2 border-dashed border-slate-700 rounded-xl p-4 w-24 h-24 flex items-center justify-center cursor-pointer hover:border-violet-500">
                    {backToTopLogo ? (
                      <img src={backToTopLogo} alt="Back to top" className="w-16 h-16 object-contain" />
                    ) : (
                      <Upload className="w-8 h-8 text-slate-500" />
                    )}
                    <input type="file" accept="image/*" onChange={(e) => {
                      const file = e.target.files[0];
                      if (file) {
                        setBackToTopFile(file);
                        const reader = new FileReader();
                        reader.onloadend = () => setBackToTopLogo(reader.result);
                        reader.readAsDataURL(file);
                      }
                    }} className="absolute inset-0 opacity-0 cursor-pointer" />
                  </div>
                  <p className="text-xs text-slate-500">Upload a custom image for the back-to-top button (PNG recommended)</p>
                  </div>
                </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2"><Image className="w-5 h-5" /> Bottom Banner (Above Footer)</CardTitle>
                    <CardDescription className="text-slate-400">Promotional banner displayed above the footer</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                <div>
                  <Label className="text-slate-400 text-xs mb-1">Banner Image URL</Label>
                  <Input value={bottomBannerUrl} onChange={(e) => setBottomBannerUrl(e.target.value)} placeholder="https://..." className="bg-slate-800 border-slate-700 text-white" />
                </div>
                <div>
                  <Label className="text-slate-400 text-xs mb-1">Banner Link URL</Label>
                  <Input value={bottomBannerLink} onChange={(e) => setBottomBannerLink(e.target.value)} placeholder="https://..." className="bg-slate-800 border-slate-700 text-white" />
                </div>
                  {bottomBannerUrl && <img src={bottomBannerUrl} alt="Preview" className="w-full h-32 object-cover rounded-lg" />}
                </CardContent>
                </Card>
              </div>
            </div>
          )}



          {activeTab === "announcements" && (
            <div className="space-y-6">
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Megaphone className="w-5 h-5" /> Announcement Manager
                      </CardTitle>
                      <CardDescription className="text-slate-400">
                        Manage site-wide alerts, banners, and popups
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
                        <Label className="text-xs text-white whitespace-nowrap">Master Switch</Label>
                        <ToggleSwitch checked={announcementsEnabled} onCheckedChange={setAnnouncementsEnabled} />
                      </div>
                      <Button onClick={() => setShowAnnouncementForm(!showAnnouncementForm)} className="bg-violet-600 hover:bg-violet-700">
                        {showAnnouncementForm ? "Cancel" : "Create New"}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Create Form */}
                  <AnimatePresence>
                    {showAnnouncementForm && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }} 
                        animate={{ height: "auto", opacity: 1 }} 
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-4 mb-6">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label className="text-slate-400 text-xs mb-1">Title (Internal/Header)</Label>
                              <Input 
                                value={newAnnouncement.title} 
                                onChange={(e) => setNewAnnouncement({...newAnnouncement, title: e.target.value})}
                                className="bg-slate-900 border-slate-700 text-white"
                                placeholder="e.g. System Maintenance"
                              />
                            </div>
                            <div>
                              <Label className="text-slate-400 text-xs mb-1">Type</Label>
                              <select 
                                value={newAnnouncement.type}
                                onChange={(e) => setNewAnnouncement({...newAnnouncement, type: e.target.value})}
                                className="w-full bg-slate-900 border border-slate-700 text-white rounded-md h-10 px-3 text-sm"
                              >
                                <option value="banner">Top Banner</option>
                                <option value="toast">Toast Notification</option>
                                <option value="modal">Center Modal</option>
                              </select>
                            </div>
                          </div>
                          <div>
                            <Label className="text-slate-400 text-xs mb-1">Content Message</Label>
                            <Input 
                              value={newAnnouncement.content} 
                              onChange={(e) => setNewAnnouncement({...newAnnouncement, content: e.target.value})}
                              className="bg-slate-900 border-slate-700 text-white"
                              placeholder="The actual message users will see..."
                            />
                          </div>
                          <div className="grid grid-cols-3 gap-4">
                            <div>
                              <Label className="text-slate-400 text-xs mb-1">Priority</Label>
                              <select 
                                value={newAnnouncement.priority}
                                onChange={(e) => setNewAnnouncement({...newAnnouncement, priority: e.target.value})}
                                className="w-full bg-slate-900 border border-slate-700 text-white rounded-md h-10 px-3 text-sm"
                              >
                                <option value="low">Low (Blue)</option>
                                <option value="medium">Medium (Purple)</option>
                                <option value="high">High (Red)</option>
                              </select>
                            </div>
                            <div>
                              <Label className="text-slate-400 text-xs mb-1">Action Text (Optional)</Label>
                              <Input 
                                value={newAnnouncement.action_text} 
                                onChange={(e) => setNewAnnouncement({...newAnnouncement, action_text: e.target.value})}
                                className="bg-slate-900 border-slate-700 text-white"
                                placeholder="Learn More"
                              />
                            </div>
                            <div>
                              <Label className="text-slate-400 text-xs mb-1">Action URL (Optional)</Label>
                              <Input 
                                value={newAnnouncement.action_url} 
                                onChange={(e) => setNewAnnouncement({...newAnnouncement, action_url: e.target.value})}
                                className="bg-slate-900 border-slate-700 text-white"
                                placeholder="https://..."
                              />
                            </div>
                          </div>
                          <div className="flex justify-end pt-2">
                            <Button onClick={handleCreateAnnouncement} className="bg-green-600 hover:bg-green-700">
                              <Save className="w-4 h-4 mr-2" /> Save Announcement
                            </Button>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* List */}
                  <div className="space-y-3">
                    <h3 className="text-sm font-medium text-slate-400 uppercase tracking-wider">Active Announcements</h3>
                    {activeAnnouncements.length === 0 ? (
                      <div className="text-center py-8 text-slate-500 border border-dashed border-slate-800 rounded-xl">
                        No active announcements found. Create one to get started.
                      </div>
                    ) : (
                      activeAnnouncements.map(ann => (
                        <div key={ann.id} className="flex items-center justify-between p-4 bg-slate-900/50 border border-slate-800 rounded-xl group hover:border-slate-700 transition-colors">
                          <div className="flex items-center gap-4">
                            <div className={`w-2 h-12 rounded-full ${
                              ann.priority === 'high' ? 'bg-red-500' : 
                              ann.priority === 'low' ? 'bg-blue-500' : 'bg-violet-500'
                            }`} />
                            <div>
                              <h4 className="text-white font-medium flex items-center gap-2">
                                {ann.title}
                                <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700 uppercase">
                                  {ann.type}
                                </span>
                              </h4>
                              <p className="text-slate-400 text-sm truncate max-w-md">{ann.content}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 opacity-50 group-hover:opacity-100 transition-opacity">
                            <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => handleDeleteAnnouncement(ann.id)} className="text-red-400 hover:text-red-300 hover:bg-red-900/20">
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "analytics" && (
            <div className="space-y-6">
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" /> App Analytics
                  </CardTitle>
                  <CardDescription className="text-slate-400">
                    Real-time stats from your app
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Stats Grid */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-4 rounded-xl bg-violet-500/10 border border-violet-500/20">
                      <div className="flex items-center gap-2 mb-2">
                        <Users className="w-4 h-4 text-violet-400" />
                        <span className="text-xs text-violet-300 uppercase font-bold">Total Users</span>
                      </div>
                      <p className="text-2xl font-bold text-white">
                        {/* Placeholder for real user count if available */}
                        0
                      </p>
                      <p className="text-xs text-slate-400 mt-1">Registered accounts</p>
                    </div>
                    <div className="p-4 rounded-xl bg-cyan-500/10 border border-cyan-500/20">
                      <div className="flex items-center gap-2 mb-2">
                        <Activity className="w-4 h-4 text-cyan-400" />
                        <span className="text-xs text-cyan-300 uppercase font-bold">Active Now</span>
                      </div>
                      <p className="text-2xl font-bold text-white">1</p>
                      <p className="text-xs text-slate-400 mt-1">You are here!</p>
                    </div>
                    <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                      <div className="flex items-center gap-2 mb-2">
                        <Sparkles className="w-4 h-4 text-emerald-400" />
                        <span className="text-xs text-emerald-300 uppercase font-bold">Effects Copied</span>
                      </div>
                      <p className="text-2xl font-bold text-white">
                        {JSON.parse(localStorage.getItem('appStats') || '{"copied":0}').copied || 0}
                      </p>
                      <p className="text-xs text-slate-400 mt-1">Local session</p>
                    </div>
                    <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
                      <div className="flex items-center gap-2 mb-2">
                        <Star className="w-4 h-4 text-amber-400" />
                        <span className="text-xs text-amber-300 uppercase font-bold">Page Views</span>
                      </div>
                      <p className="text-2xl font-bold text-white">
                        {JSON.parse(localStorage.getItem('appStats') || '{"viewed":0}').viewed || 0}
                      </p>
                      <p className="text-xs text-slate-400 mt-1">Local session</p>
                    </div>
                  </div>

                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-center">
                    <p className="text-slate-400 text-sm">
                      <span className="block mb-2 text-2xl">📉</span>
                      Connect Google Analytics or Plausible for detailed historical data.
                      <br/>
                      <span className="text-xs opacity-50">Current stats reflect local browser session or basic DB counts.</span>
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "video" && (
            <div className="space-y-6">
              {/* Seed / Reset Button */}
              <Card className="bg-slate-900/50 border-slate-800 border-l-4 border-l-red-500">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">⚠️ Template Reset / Initialize</CardTitle>
                  <CardDescription className="text-slate-400">Reset all app settings to the default "Clonable Template" state. Use this to fix missing settings or prepare for distribution.</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    variant="destructive" 
                    onClick={async () => {
                      if (confirm("Are you sure? This will RESET all app settings to defaults.")) {
                        try {
                          await base44.functions.invoke('seedApp', {});
                          window.location.reload();
                        } catch (e) {
                          alert("Failed to reset: " + e.message);
                        }
                      }
                    }}
                    className="w-full sm:w-auto"
                  >
                    Reset App to Template Defaults
                  </Button>
                </CardContent>
              </Card>
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2"><Video className="w-5 h-5" /> ✨ Modern Video Showcase</CardTitle>
                  <CardDescription className="text-slate-400">Trending, high-conversion video section style</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between p-4 bg-slate-950 rounded-xl border border-slate-800">
                    <div>
                      <Label className="text-white">Enable Modern Showcase</Label>
                      <p className="text-xs text-slate-500">Displays a floating glassmorphism card with video</p>
                    </div>
                    <ToggleSwitch checked={modernVideo.enabled} onCheckedChange={(v) => setModernVideo(p => ({ ...p, enabled: v }))} />
                  </div>

                  <div>
                    <Label className="text-slate-400 text-xs mb-1">YouTube URL</Label>
                    <Input 
                      value={modernVideo.youtube_url} 
                      onChange={(e) => setModernVideo(p => ({ ...p, youtube_url: e.target.value }))} 
                      placeholder="https://youtube.com/watch?v=..." 
                      className="bg-slate-800 border-slate-700 text-white" 
                    />
                  </div>
                  <div>
                    <Label className="text-slate-400 text-xs mb-1">Headline Title</Label>
                    <Input 
                      value={modernVideo.title} 
                      onChange={(e) => setModernVideo(p => ({ ...p, title: e.target.value }))} 
                      placeholder="Experience the Future" 
                      className="bg-slate-800 border-slate-700 text-white" 
                    />
                  </div>
                  <div>
                    <Label className="text-slate-400 text-xs mb-1">Description</Label>
                    <Input 
                      value={modernVideo.description} 
                      onChange={(e) => setModernVideo(p => ({ ...p, description: e.target.value }))} 
                      placeholder="Watch our latest showcase..." 
                      className="bg-slate-800 border-slate-700 text-white" 
                    />
                  </div>

                  <div className="pt-4 border-t border-slate-800">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <Label className="text-white mb-1 block">YouTube Overlay Image</Label>
                        <p className="text-xs text-slate-500">Custom image to show before the video plays</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Label className="text-slate-400 text-xs">Enable Overlay</Label>
                        <ToggleSwitch checked={youtubeOverlayEnabled} onCheckedChange={setYoutubeOverlayEnabled} />
                      </div>
                    </div>
                    {youtubeOverlayEnabled && (
                      <>
                        <div className="flex gap-2">
                          <Input 
                            value={youtubeOverlayUrl} 
                            onChange={(e) => setYoutubeOverlayUrl(e.target.value)} 
                            placeholder="https://..." 
                            className="bg-slate-800 border-slate-700 text-white flex-1" 
                          />
                          <label className="px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded cursor-pointer flex items-center gap-2 whitespace-nowrap">
                            <Upload className="w-4 h-4" />
                            Upload
                            <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                              const file = e.target.files[0];
                              if (file) {
                                try {
                                  const result = await base44.integrations.Core.UploadFile({ file });
                                  setYoutubeOverlayUrl(result.file_url);
                                } catch (err) { console.error(err); }
                              }
                            }} />
                          </label>
                        </div>
                        {youtubeOverlayUrl && <img src={youtubeOverlayUrl} className="w-32 h-20 object-cover rounded mt-2 border border-slate-700" alt="Overlay Preview" />}
                      </>
                    )}
                    {!youtubeOverlayEnabled && (
                      <p className="text-xs text-cyan-400 bg-cyan-500/10 border border-cyan-500/30 rounded px-3 py-2 mt-2">
                        ▶️ Video will autoplay when modal opens (no overlay)
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "monetization" && (
            <div className="space-y-6">
              {/* Top Row: Coffee Banner (Left) + Template Showcase (Right) */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">☕ Coffee Banner</CardTitle>
                    <CardDescription className="text-slate-400">Simple donation banner above footer</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                {/* Enable Banner + Show on All Pages - Side by Side */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <div>
                      <Label className="text-white text-sm">Enable Banner</Label>
                      <p className="text-[10px] text-slate-500">Show banner</p>
                    </div>
                    <ToggleSwitch checked={coffeeBanner.enabled} onCheckedChange={(v) => setCoffeeBanner(p => ({ ...p, enabled: v }))} />
                  </div>

                  {coffeeBanner.enabled && (
                    <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
                      <div>
                        <Label className="text-white text-sm">Show on All Pages</Label>
                        <p className="text-[10px] text-slate-500">Every page</p>
                      </div>
                      <ToggleSwitch checked={coffeeBanner.show_on_all_pages} onCheckedChange={(v) => setCoffeeBanner(p => ({ ...p, show_on_all_pages: v }))} />
                    </div>
                  )}
                </div>

                {coffeeBanner.enabled && (
                  <div className="space-y-4">
                    {/* Banner Size - Smaller Buttons */}
                    <div>
                      <Label className="text-slate-400 text-xs mb-2 block">Banner Size</Label>
                      <div className="flex gap-1.5">
                        {[
                          { id: 'small', label: 'S' },
                          { id: 'medium', label: 'M' },
                          { id: 'large', label: 'L' },
                          { id: 'xl', label: 'XL' },
                          { id: 'xxl', label: '2XL' },
                          { id: 'jumbo', label: 'XXL' }
                        ].map(size => (
                          <button
                            key={size.id}
                            onClick={() => setCoffeeBanner(p => ({ ...p, size: size.id }))}
                            className={`flex-1 py-2 px-1 rounded border-2 text-center transition-all ${
                              coffeeBanner.size === size.id
                                ? 'border-violet-500 bg-violet-500/20 text-white'
                                : 'border-slate-700 bg-slate-800 text-slate-400 hover:border-slate-600'
                            }`}
                          >
                            <div className="text-[11px] font-medium">{size.label}</div>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <Label className="text-slate-400 text-xs mb-2 block">Upload Banner Image</Label>
                      <div className="flex gap-2">
                        <Input 
                          value={coffeeBanner.image_url} 
                          onChange={(e) => setCoffeeBanner(p => ({ ...p, image_url: e.target.value }))} 
                          placeholder="Or paste image URL..." 
                          className="bg-slate-800 border-slate-700 text-white flex-1" 
                        />
                        <label className={`px-4 py-2 ${uploadingBanner ? 'bg-violet-700' : 'bg-violet-600 hover:bg-violet-700'} text-white rounded cursor-pointer flex items-center gap-2 whitespace-nowrap`}>
                          {uploadingBanner ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                          {uploadingBanner ? 'Uploading...' : 'Upload'}
                          <input 
                            type="file" 
                            accept="image/*" 
                            disabled={uploadingBanner}
                            className="hidden" 
                            onChange={async (e) => {
                              const file = e.target.files[0];
                              if (file) {
                                setUploadingBanner(true);
                                try {
                                  const result = await base44.integrations.Core.UploadFile({ file });
                                  setCoffeeBanner(p => ({ ...p, image_url: result.file_url }));
                                  setSaveMessage("✓ Image uploaded! Click Save Changes to keep it.");
                                  setTimeout(() => setSaveMessage(""), 3000);
                                } catch (err) {
                                  setSaveError("Upload failed. Please try again.");
                                } finally {
                                  setUploadingBanner(false);
                                }
                              }
                            }} 
                          />
                        </label>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">💡 Recommended sizes: 1200x200px (medium), 1200x300px (large), 1200x400px (XL)</p>
                      </div>

                      <div>
                      <Label className="text-slate-400 text-xs mb-1">Link URL</Label>
                      <Input 
                        value={coffeeBanner.link} 
                        onChange={(e) => setCoffeeBanner(p => ({ ...p, link: e.target.value }))} 
                        placeholder="https://buymeacoffee.com/team44" 
                        className="bg-slate-800 border-slate-700 text-white" 
                      />
                      <p className="text-xs text-slate-500 mt-1">Where users go when they click the banner</p>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-slate-950 rounded-xl border border-slate-800">
                      <div>
                        <Label className="text-white">Enable CTA Button</Label>
                        <p className="text-xs text-slate-500">Show clickable button in center of banner</p>
                      </div>
                      <ToggleSwitch checked={coffeeBanner.button_enabled} onCheckedChange={(v) => setCoffeeBanner(p => ({ ...p, button_enabled: v }))} />
                    </div>

                    {coffeeBanner.button_enabled && (
                      <>
                        <div>
                          <Label className="text-slate-400 text-xs mb-2 block">Button Image</Label>
                          <div className="flex gap-2">
                            <Input 
                              value={coffeeBanner.button_image} 
                              onChange={(e) => setCoffeeBanner(p => ({ ...p, button_image: e.target.value }))} 
                              placeholder="Or paste button image URL..." 
                              className="bg-slate-800 border-slate-700 text-white flex-1" 
                            />
                            <label className={`px-4 py-2 ${uploadingButton ? 'bg-cyan-700' : 'bg-cyan-600 hover:bg-cyan-700'} text-white rounded cursor-pointer flex items-center gap-2 whitespace-nowrap`}>
                              {uploadingButton ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                              {uploadingButton ? 'Uploading...' : 'Upload'}
                              <input 
                                type="file" 
                                accept="image/*" 
                                disabled={uploadingButton}
                                className="hidden" 
                                onChange={async (e) => {
                                  const file = e.target.files[0];
                                  if (file) {
                                    setUploadingButton(true);
                                    try {
                                      const result = await base44.integrations.Core.UploadFile({ file });
                                      setCoffeeBanner(p => ({ ...p, button_image: result.file_url }));
                                      setSaveMessage("✓ Button uploaded! Click Save Changes to keep it.");
                                      setTimeout(() => setSaveMessage(""), 3000);
                                    } catch (err) {
                                      setSaveError("Upload failed. Please try again.");
                                    } finally {
                                      setUploadingButton(false);
                                    }
                                  }
                                }} 
                              />
                            </label>
                          </div>
                        </div>

                        <div>
                          <Label className="text-slate-400 text-xs mb-2 block">Button Effect</Label>
                          <div className="flex gap-1.5">
                            {[
                              { id: 'bounce', label: 'Bounce', icon: '🎾' },
                              { id: 'shimmer', label: 'Shimmer', icon: '✨' },
                              { id: 'glow', label: 'Glow', icon: '💫' },
                              { id: 'pulse', label: 'Pulse', icon: '💓' },
                              { id: 'shadow', label: 'Shadow', icon: '🌑' }
                            ].map(effect => (
                              <button
                                key={effect.id}
                                onClick={() => setCoffeeBanner(p => ({ ...p, button_effect: effect.id }))}
                                className={`flex-1 py-1.5 px-2 rounded border-2 text-center transition-all ${
                                  coffeeBanner.button_effect === effect.id
                                    ? 'border-cyan-500 bg-cyan-500/20 text-white'
                                    : 'border-slate-700 bg-slate-800 text-slate-400 hover:border-slate-600'
                                }`}
                              >
                                <div className="text-sm">{effect.icon}</div>
                                <div className="text-[10px]">{effect.label}</div>
                              </button>
                            ))}
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                  )}
                  </CardContent>
                  </Card>

                  <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">🎬 Template Showcase Section</CardTitle>
                  <CardDescription className="text-slate-400">Movie poster-style section to showcase your Base44 templates</CardDescription>
                </CardHeader>
                    <CardContent className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-slate-950 rounded-xl border border-slate-800">
                  <Label className="text-white">Enable Template Showcase</Label>
                  <ToggleSwitch checked={templateShowcase.enabled} onCheckedChange={(v) => setTemplateShowcase(p => ({ ...p, enabled: v }))} />
                </div>

                {templateShowcase.enabled && (
                  <div className="space-y-6">
                    {/* Style Selector */}
                    <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                      <Label className="text-white font-semibold mb-3 block">🎨 Choose Display Style</Label>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {[
                          { id: "style1", name: "Full Posters", emoji: "🎬", desc: "Feastables vibrant" },
                          { id: "style2", name: "Compact Cards", emoji: "📱", desc: "Half height cards" },
                          { id: "style3", name: "Netflix Scroll", emoji: "📺", desc: "Horizontal scroll" },
                          { id: "style4", name: "Blockbuster", emoji: "📼", desc: "VHS tape style" },
                          { id: "style5", name: "Minimal Grid", emoji: "◻️", desc: "Clean & simple" },
                          { id: "style6", name: "Candy Store", emoji: "🍬", desc: "Feastables small" },
                          { id: "style7", name: "Dark Neon", emoji: "💜", desc: "Cyberpunk vibes" },
                          { id: "style8", name: "Banner Style", emoji: "🎪", desc: "Carousel banner" }
                        ].map(style => (
                          <button
                            key={style.id}
                            onClick={() => setTemplateShowcase(p => ({ ...p, style_id: style.id }))}
                            className={`p-3 rounded-lg border-2 transition-all text-left ${
                              (templateShowcase.style_id || "style1") === style.id
                                ? "border-violet-500 bg-violet-500/20"
                                : "border-slate-700 bg-slate-800/50 hover:border-slate-600"
                            }`}
                          >
                            <div className="text-2xl mb-1">{style.emoji}</div>
                            <div className="text-xs font-bold text-white">{style.name}</div>
                            <div className="text-[10px] text-slate-500">{style.desc}</div>
                          </button>
                        ))}
                      </div>
                    </div>
                    {/* Poster 1 */}
                    <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                      <Label className="text-violet-400 font-semibold mb-3 block">📼 Poster 1</Label>
                      <div className="grid gap-3">
                        <div>
                          <Label className="text-slate-400 text-xs mb-1">Upload Image or URL</Label>
                          <div className="flex gap-2">
                            <Input value={templateShowcase.poster_1_image} onChange={(e) => setTemplateShowcase(p => ({ ...p, poster_1_image: e.target.value }))} placeholder="https://..." className="bg-slate-800 border-slate-700 text-white flex-1" />
                            <label className="px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded cursor-pointer flex items-center gap-2 whitespace-nowrap">
                              <Upload className="w-4 h-4" />
                              Upload
                              <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                                const file = e.target.files[0];
                                if (file) {
                                  try {
                                    const result = await base44.integrations.Core.UploadFile({ file });
                                    setTemplateShowcase(p => ({ ...p, poster_1_image: result.file_url }));
                                  } catch (err) { console.error(err); }
                                }
                              }} />
                            </label>
                          </div>
                          {templateShowcase.poster_1_image && <img src={templateShowcase.poster_1_image} className="w-32 h-40 object-cover rounded mt-2 border border-slate-700" />}
                        </div>
                        <div>
                          <Label className="text-slate-400 text-xs mb-1">Template Link</Label>
                          <Input value={templateShowcase.poster_1_link} onChange={(e) => setTemplateShowcase(p => ({ ...p, poster_1_link: e.target.value }))} placeholder="https://base44templates.com/..." className="bg-slate-800 border-slate-700 text-white" />
                        </div>
                        <div>
                          <Label className="text-slate-400 text-xs mb-1">Title</Label>
                          <Input value={templateShowcase.poster_1_title} onChange={(e) => setTemplateShowcase(p => ({ ...p, poster_1_title: e.target.value }))} placeholder="Template Name" className="bg-slate-800 border-slate-700 text-white" />
                        </div>
                      </div>
                    </div>

                    {/* Poster 2 */}
                    <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                      <Label className="text-cyan-400 font-semibold mb-3 block">📼 Poster 2</Label>
                      <div className="grid gap-3">
                        <div>
                          <Label className="text-slate-400 text-xs mb-1">Upload Image or URL</Label>
                          <div className="flex gap-2">
                            <Input value={templateShowcase.poster_2_image} onChange={(e) => setTemplateShowcase(p => ({ ...p, poster_2_image: e.target.value }))} placeholder="https://..." className="bg-slate-800 border-slate-700 text-white flex-1" />
                            <label className="px-4 py-2 bg-cyan-600 hover:bg-cyan-700 text-white rounded cursor-pointer flex items-center gap-2 whitespace-nowrap">
                              <Upload className="w-4 h-4" />
                              Upload
                              <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                                const file = e.target.files[0];
                                if (file) {
                                  try {
                                    const result = await base44.integrations.Core.UploadFile({ file });
                                    setTemplateShowcase(p => ({ ...p, poster_2_image: result.file_url }));
                                  } catch (err) { console.error(err); }
                                }
                              }} />
                            </label>
                          </div>
                          {templateShowcase.poster_2_image && <img src={templateShowcase.poster_2_image} className="w-32 h-40 object-cover rounded mt-2 border border-slate-700" />}
                        </div>
                        <div>
                          <Label className="text-slate-400 text-xs mb-1">Template Link</Label>
                          <Input value={templateShowcase.poster_2_link} onChange={(e) => setTemplateShowcase(p => ({ ...p, poster_2_link: e.target.value }))} placeholder="https://base44templates.com/..." className="bg-slate-800 border-slate-700 text-white" />
                        </div>
                        <div>
                          <Label className="text-slate-400 text-xs mb-1">Title</Label>
                          <Input value={templateShowcase.poster_2_title} onChange={(e) => setTemplateShowcase(p => ({ ...p, poster_2_title: e.target.value }))} placeholder="Template Name" className="bg-slate-800 border-slate-700 text-white" />
                        </div>
                      </div>
                    </div>

                    {/* Poster 3 */}
                    <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                      <Label className="text-pink-400 font-semibold mb-3 block">📼 Poster 3</Label>
                      <div className="grid gap-3">
                        <div>
                          <Label className="text-slate-400 text-xs mb-1">Upload Image or URL</Label>
                          <div className="flex gap-2">
                            <Input value={templateShowcase.poster_3_image} onChange={(e) => setTemplateShowcase(p => ({ ...p, poster_3_image: e.target.value }))} placeholder="https://..." className="bg-slate-800 border-slate-700 text-white flex-1" />
                            <label className="px-4 py-2 bg-pink-600 hover:bg-pink-700 text-white rounded cursor-pointer flex items-center gap-2 whitespace-nowrap">
                              <Upload className="w-4 h-4" />
                              Upload
                              <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                                const file = e.target.files[0];
                                if (file) {
                                  try {
                                    const result = await base44.integrations.Core.UploadFile({ file });
                                    setTemplateShowcase(p => ({ ...p, poster_3_image: result.file_url }));
                                  } catch (err) { console.error(err); }
                                }
                              }} />
                            </label>
                          </div>
                          {templateShowcase.poster_3_image && <img src={templateShowcase.poster_3_image} className="w-32 h-40 object-cover rounded mt-2 border border-slate-700" />}
                        </div>
                        <div>
                          <Label className="text-slate-400 text-xs mb-1">Template Link</Label>
                          <Input value={templateShowcase.poster_3_link} onChange={(e) => setTemplateShowcase(p => ({ ...p, poster_3_link: e.target.value }))} placeholder="https://base44templates.com/..." className="bg-slate-800 border-slate-700 text-white" />
                        </div>
                        <div>
                          <Label className="text-slate-400 text-xs mb-1">Title</Label>
                          <Input value={templateShowcase.poster_3_title} onChange={(e) => setTemplateShowcase(p => ({ ...p, poster_3_title: e.target.value }))} placeholder="Template Name" className="bg-slate-800 border-slate-700 text-white" />
                        </div>
                      </div>
                    </div>
                  </div>
                  )}
                  </CardContent>
                  </Card>
                  </div>

                  {/* Full-Width Preview - Above Donation Section */}
                  {coffeeBanner.enabled && coffeeBanner.image_url && (
                  <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                   <CardTitle className="text-white text-sm">🔍 Live Preview</CardTitle>
                   <CardDescription className="text-slate-400 text-xs">Full-width banner preview</CardDescription>
                  </CardHeader>
                  <CardContent>
                   <div 
                     className="relative overflow-hidden rounded-lg border border-slate-700 flex items-center justify-center w-full"
                     style={{ 
                       height: coffeeBanner.size === 'small' ? '120px' : 
                               coffeeBanner.size === 'large' ? '300px' : 
                               coffeeBanner.size === 'xl' ? '400px' :
                               coffeeBanner.size === 'xxl' ? '500px' :
                               coffeeBanner.size === 'jumbo' ? '600px' : '200px'
                     }}
                   >
                     <img 
                       src={coffeeBanner.image_url} 
                       alt="Banner preview" 
                       className="w-full h-full object-cover"
                     />
                     {coffeeBanner.button_enabled && coffeeBanner.button_image && (
                       <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                         <img 
                           src={coffeeBanner.button_image} 
                           alt="Button preview" 
                           className="max-w-[300px] max-h-[80px] object-contain"
                         />
                       </div>
                     )}
                   </div>
                  </CardContent>
                  </Card>
                  )}

                  {/* Donation Payment Gateways - Full Width */}
                  <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2"><Heart className="w-5 h-5" /> Donation Payment Gateways</CardTitle>
                  <CardDescription className="text-slate-400">Configure your payment links and addresses here</CardDescription>
                  </CardHeader>
                  <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                   {[
                     { key: "paypal_email", label: "PayPal Email", placeholder: "your@email.com", icon: "💳", desc: "Most popular, works in Canada" },
                     { key: "paypal_me", label: "PayPal.me Link", placeholder: "paypal.me/yourname", icon: "💰", desc: "Easy one-click donations" },
                     { key: "stripe_link", label: "Stripe Payment Link", placeholder: "https://buy.stripe.com/...", icon: "💎", desc: "Credit/debit cards, Canada friendly" },
                     { key: "etransfer_email", label: "Interac e-Transfer", placeholder: "email@bank.com", icon: "🇨🇦", desc: "Canada bank transfers" },
                     { key: "kofi_username", label: "Ko-fi Username", placeholder: "username", icon: "☕", desc: "No fees, great for Canadians" },
                     { key: "buymeacoffee_username", label: "Buy Me a Coffee", placeholder: "username", icon: "🍵", desc: "5% fee, popular choice" },
                     { key: "patreon_url", label: "Patreon URL", placeholder: "patreon.com/...", icon: "🎨", desc: "Recurring subscriptions" },
                     { key: "gofundme_url", label: "GoFundMe", placeholder: "gofundme.com/...", icon: "💚", desc: "One-time fundraising" },
                     { key: "bitcoin_address", label: "Bitcoin Address", placeholder: "bc1q...", icon: "₿", desc: "Crypto donations" },
                     { key: "ethereum_address", label: "Ethereum Address", placeholder: "0x...", icon: "Ξ", desc: "ETH & ERC-20 tokens" },
                     { key: "solana_address", label: "Solana Address", placeholder: "...", icon: "◎", desc: "Fast, low-fee crypto" },
                     { key: "venmo_username", label: "Venmo (US only)", placeholder: "@username", icon: "💙", desc: "US-based payments" },
                     { key: "cashapp_tag", label: "Cash App (US/UK)", placeholder: "$cashtag", icon: "💵", desc: "Popular mobile payments" },
                   ].map(gateway => (
                     <div key={gateway.key}>
                       <Label className="text-slate-400 text-xs mb-1 flex items-center gap-1"><span>{gateway.icon}</span> {gateway.label}</Label>
                       <Input
                         value={donationSettings[gateway.key] || ""}
                         onChange={(e) => setDonationSettings(prev => ({ ...prev, [gateway.key]: e.target.value }))}
                         placeholder={gateway.placeholder}
                         className="bg-slate-800 border-slate-700 text-white text-sm"
                       />
                       <p className="text-xs text-slate-600 mt-0.5">{gateway.desc}</p>
                     </div>
                   ))}
                  </div>
                  </CardContent>
                  </Card>
                  </div>
                  )}

          {activeTab === "library" && (
            <div className="space-y-6">
              <LibraryIngestionPanel />
            </div>
          )}

        </motion.div>
      </div>

      {/* Sticky Save Button */}
      <motion.div 
        initial={{ y: 100 }} 
        animate={{ y: 0 }} 
        className="fixed bottom-0 left-0 right-0 bg-slate-900/70 backdrop-blur-md border-t border-slate-800 p-4 z-50"
        data-tour="save-button"
      >
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
          <div className="flex-1">
            {saveError && <p className="text-sm text-red-400">{saveError}</p>}
            {saveMessage && <p className="text-sm text-green-400">{saveMessage}</p>}
          </div>
          <div className="relative">
            {isSaving && (
              <>
                <motion.div className="absolute inset-0 rounded-xl bg-green-500" animate={{ scale: [1, 1.3], opacity: [0.5, 0] }} transition={{ duration: 0.6 }} />
                <motion.div className="absolute inset-0 rounded-xl bg-green-500" animate={{ scale: [1, 1.5], opacity: [0.5, 0] }} transition={{ duration: 0.6, delay: 0.2 }} />
              </>
            )}
            <motion.button
              onClick={handleSave}
              disabled={isSaving}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`relative h-12 px-8 text-base font-semibold rounded-xl flex items-center gap-2 ${isSaving ? "bg-green-500" : "bg-gradient-to-r from-violet-600 to-purple-600"} text-white disabled:opacity-50 z-10`}
            >
              {isSaving ? <><Check className="w-5 h-5" /> Saved!</> : <><Save className="w-5 h-5" /> Save Changes</>}
            </motion.button>
          </div>
        </div>
      </motion.div>
      <div className="h-24" /> {/* Spacer for sticky button */}
    </div>
  );
}