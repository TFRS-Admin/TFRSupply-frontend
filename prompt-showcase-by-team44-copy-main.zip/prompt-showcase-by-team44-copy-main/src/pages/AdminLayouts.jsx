import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { LayoutDashboard, Users, Settings, BarChart3, Bell, Search, Menu, ChevronDown, Plus, Filter, Download, MoreVertical, Check, X, Edit, Trash2, Eye, ArrowUpDown, Calendar, FileText, Shield, Database, Activity } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// Stats Cards
function StatsCardsEffect() {
  return (
    <EffectCard title="Stats Cards" description="KPI metrics with trends" whenToUse="Dashboard overviews, analytics summaries, performance metrics.">
      <div className="grid grid-cols-2 gap-3 w-full px-4">
        {[
          { label: "Users", value: "12,847", trend: "+12%", up: true },
          { label: "Revenue", value: "$48.2K", trend: "+8%", up: true },
          { label: "Orders", value: "1,284", trend: "-3%", up: false },
          { label: "Growth", value: "24.5%", trend: "+15%", up: true }
        ].map((stat, i) => (
          <motion.div key={i} whileHover={{ y: -2 }} className="p-3 rounded-xl bg-slate-800 border border-slate-700">
            <p className="text-slate-400 text-xs mb-1">{stat.label}</p>
            <p className="text-white text-xl font-bold">{stat.value}</p>
            <span className={`text-xs ${stat.up ? "text-green-400" : "text-red-400"}`}>{stat.trend}</span>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Data Table
function DataTableEffect() {
  const [selected, setSelected] = useState([]);
  return (
    <EffectCard title="Data Table" description="Sortable rows with actions" whenToUse="User lists, order management, inventory, logs.">
      <div className="w-full text-xs">
        <div className="flex items-center gap-2 px-3 py-2 bg-slate-800 rounded-t-lg border-b border-slate-700">
          <input type="checkbox" className="rounded" />
          <span className="flex-1 text-slate-400">Name</span>
          <span className="w-16 text-slate-400">Status</span>
          <span className="w-12 text-slate-400">Actions</span>
        </div>
        {["Alice", "Bob", "Charlie"].map((name, i) => (
          <motion.div key={name} whileHover={{ backgroundColor: "rgba(139,92,246,0.1)" }} className="flex items-center gap-2 px-3 py-2 border-b border-slate-800">
            <input type="checkbox" className="rounded" />
            <span className="flex-1 text-white">{name}</span>
            <span className={`w-16 px-2 py-0.5 rounded text-center ${i === 0 ? "bg-green-500/20 text-green-400" : i === 1 ? "bg-amber-500/20 text-amber-400" : "bg-slate-700 text-slate-400"}`}>
              {i === 0 ? "Active" : i === 1 ? "Pending" : "Inactive"}
            </span>
            <div className="w-12 flex gap-1">
              <button className="p-1 hover:bg-slate-700 rounded"><Edit className="w-3 h-3 text-slate-400" /></button>
              <button className="p-1 hover:bg-slate-700 rounded"><Trash2 className="w-3 h-3 text-red-400" /></button>
            </div>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Admin Sidebar
function AdminSidebarEffect() {
  const [active, setActive] = useState(0);
  const [collapsed, setCollapsed] = useState(false);
  return (
    <EffectCard title="Admin Sidebar" description="Collapsible navigation menu" whenToUse="Admin panels, dashboards, settings pages.">
      <motion.div animate={{ width: collapsed ? 48 : 160 }} className="bg-slate-800 rounded-lg p-2 h-48">
        <button onClick={() => setCollapsed(!collapsed)} className="p-2 hover:bg-slate-700 rounded-lg mb-2 w-full flex justify-center">
          <Menu className="w-4 h-4 text-slate-400" />
        </button>
        {[
          { icon: LayoutDashboard, label: "Dashboard" },
          { icon: Users, label: "Users" },
          { icon: BarChart3, label: "Analytics" },
          { icon: Settings, label: "Settings" }
        ].map((item, i) => (
          <motion.button key={i} onClick={() => setActive(i)} className={`w-full p-2 rounded-lg flex items-center gap-2 mb-1 ${active === i ? "bg-violet-500/20 text-violet-400" : "text-slate-400 hover:bg-slate-700"}`}>
            <item.icon className="w-4 h-4 flex-shrink-0" />
            <AnimatePresence>
              {!collapsed && <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-xs">{item.label}</motion.span>}
            </AnimatePresence>
          </motion.button>
        ))}
      </motion.div>
    </EffectCard>
  );
}

// Admin Header
function AdminHeaderEffect() {
  return (
    <EffectCard title="Admin Header" description="Top bar with search and user" whenToUse="Admin dashboards, SaaS applications, management panels.">
      <div className="w-full px-4 py-2 flex items-center justify-between bg-slate-800 rounded-lg">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-violet-500 rounded-lg flex items-center justify-center font-bold text-white text-sm">A</div>
          <span className="text-white font-medium text-sm">Admin Panel</span>
        </div>
        <div className="flex-1 max-w-xs mx-4">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-900 rounded-lg">
            <Search className="w-4 h-4 text-slate-500" />
            <span className="text-slate-500 text-xs">Search...</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-slate-700 rounded-lg relative">
            <Bell className="w-4 h-4 text-slate-400" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
          </button>
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-pink-500" />
        </div>
      </div>
    </EffectCard>
  );
}

// Dropdown Menu
function DropdownMenuEffect() {
  const [open, setOpen] = useState(false);
  return (
    <EffectCard title="Dropdown Menu" description="Actions dropdown with icons" whenToUse="Table actions, context menus, more options.">
      <div className="relative">
        <button onClick={() => setOpen(!open)} className="flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-lg text-white text-sm">
          Actions <ChevronDown className={`w-4 h-4 transition-transform ${open ? "rotate-180" : ""}`} />
        </button>
        <AnimatePresence>
          {open && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="absolute top-full left-0 mt-2 w-40 bg-slate-800 rounded-lg shadow-xl border border-slate-700 overflow-hidden z-10">
              {[
                { icon: Eye, label: "View" },
                { icon: Edit, label: "Edit" },
                { icon: Download, label: "Export" },
                { icon: Trash2, label: "Delete", danger: true }
              ].map((item, i) => (
                <button key={i} className={`w-full flex items-center gap-2 px-3 py-2 text-xs hover:bg-slate-700 ${item.danger ? "text-red-400" : "text-slate-300"}`}>
                  <item.icon className="w-3 h-3" /> {item.label}
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Modal Dialog
function ModalDialogEffect() {
  const [open, setOpen] = useState(false);
  return (
    <EffectCard title="Modal Dialog" description="Confirmation and form dialogs" whenToUse="Delete confirmations, forms, alerts.">
      <button onClick={() => setOpen(true)} className="px-4 py-2 bg-violet-500 rounded-lg text-white text-sm">Open Modal</button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setOpen(false)}>
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }} onClick={e => e.stopPropagation()} className="bg-slate-800 rounded-xl p-6 w-80 border border-slate-700">
              <h3 className="text-white font-semibold mb-2">Confirm Action</h3>
              <p className="text-slate-400 text-sm mb-4">Are you sure you want to proceed?</p>
              <div className="flex gap-2 justify-end">
                <button onClick={() => setOpen(false)} className="px-3 py-1.5 bg-slate-700 rounded-lg text-sm text-white">Cancel</button>
                <button onClick={() => setOpen(false)} className="px-3 py-1.5 bg-violet-500 rounded-lg text-sm text-white">Confirm</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </EffectCard>
  );
}

// Pagination
function PaginationEffect() {
  const [page, setPage] = useState(1);
  return (
    <EffectCard title="Pagination" description="Page navigation controls" whenToUse="Data tables, lists, search results.">
      <div className="flex items-center gap-1">
        <button onClick={() => setPage(Math.max(1, page - 1))} className="px-2 py-1 bg-slate-800 rounded text-slate-400 text-sm">Prev</button>
        {[1, 2, 3, 4, 5].map(p => (
          <motion.button key={p} whileTap={{ scale: 0.9 }} onClick={() => setPage(p)} className={`w-8 h-8 rounded text-sm ${page === p ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400"}`}>{p}</motion.button>
        ))}
        <button onClick={() => setPage(Math.min(5, page + 1))} className="px-2 py-1 bg-slate-800 rounded text-slate-400 text-sm">Next</button>
      </div>
    </EffectCard>
  );
}

// Breadcrumbs
function BreadcrumbsEffect() {
  return (
    <EffectCard title="Breadcrumbs" description="Navigation path indicator" whenToUse="Nested pages, category navigation, file browsers.">
      <div className="flex items-center gap-2 text-sm">
        {["Home", "Users", "Settings", "Profile"].map((item, i, arr) => (
          <React.Fragment key={item}>
            <span className={i === arr.length - 1 ? "text-white" : "text-slate-400 hover:text-violet-400 cursor-pointer"}>{item}</span>
            {i < arr.length - 1 && <span className="text-slate-600">/</span>}
          </React.Fragment>
        ))}
      </div>
    </EffectCard>
  );
}

// Tabs
function TabsEffect() {
  const [tab, setTab] = useState(0);
  return (
    <EffectCard title="Tabs" description="Content section switcher" whenToUse="Settings pages, profile views, data sections.">
      <div className="w-full">
        <div className="flex gap-1 bg-slate-800 p-1 rounded-lg mb-3">
          {["General", "Security", "Billing"].map((t, i) => (
            <button key={t} onClick={() => setTab(i)} className={`flex-1 py-2 px-3 rounded-md text-xs font-medium transition-colors ${tab === i ? "bg-violet-500 text-white" : "text-slate-400 hover:text-white"}`}>{t}</button>
          ))}
        </div>
        <div className="p-4 bg-slate-800/50 rounded-lg">
          <p className="text-slate-400 text-sm">{["General settings content", "Security options content", "Billing information content"][tab]}</p>
        </div>
      </div>
    </EffectCard>
  );
}

// Toggle Switch
function ToggleSwitchEffect() {
  const [enabled, setEnabled] = useState(true);
  return (
    <EffectCard title="Toggle Switch" description="On/off setting control" whenToUse="Feature flags, notifications, preferences.">
      <div className="flex items-center gap-3">
        <motion.button onClick={() => setEnabled(!enabled)} className={`w-12 h-6 rounded-full p-1 ${enabled ? "bg-violet-500" : "bg-slate-700"}`}>
          <motion.div animate={{ x: enabled ? 24 : 0 }} className="w-4 h-4 bg-white rounded-full" />
        </motion.button>
        <span className="text-white text-sm">{enabled ? "Enabled" : "Disabled"}</span>
      </div>
    </EffectCard>
  );
}

// Search Bar with Filters
function SearchFilterBarEffect() {
  return (
    <EffectCard title="Search with Filters" description="Combined search and filter bar" whenToUse="Data tables, user lists, logs.">
      <div className="flex items-center gap-2 w-full">
        <div className="flex-1 flex items-center gap-2 px-3 py-2 bg-slate-800 rounded-lg">
          <Search className="w-4 h-4 text-slate-400" />
          <input type="text" placeholder="Search users..." className="bg-transparent text-white text-sm flex-1 outline-none" />
        </div>
        <button className="flex items-center gap-1 px-3 py-2 bg-slate-800 rounded-lg text-slate-400 text-sm">
          <Filter className="w-4 h-4" /> Filters
        </button>
        <button className="flex items-center gap-1 px-3 py-2 bg-violet-500 rounded-lg text-white text-sm">
          <Plus className="w-4 h-4" /> Add
        </button>
      </div>
    </EffectCard>
  );
}

// Activity Log
function ActivityLogEffect() {
  return (
    <EffectCard title="Activity Log" description="Timeline of actions" whenToUse="Audit logs, user activity, history.">
      <div className="space-y-3 text-xs w-full px-2">
        {[
          { action: "User created", user: "admin", time: "2m ago", color: "bg-green-500" },
          { action: "Settings updated", user: "john", time: "15m ago", color: "bg-blue-500" },
          { action: "File deleted", user: "alice", time: "1h ago", color: "bg-red-500" }
        ].map((log, i) => (
          <div key={i} className="flex items-start gap-3">
            <div className={`w-2 h-2 rounded-full mt-1.5 ${log.color}`} />
            <div className="flex-1">
              <p className="text-white">{log.action}</p>
              <p className="text-slate-500">by {log.user} • {log.time}</p>
            </div>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Badge/Tag
function BadgeTagEffect() {
  return (
    <EffectCard title="Badges & Tags" description="Status indicators and labels" whenToUse="User roles, statuses, categories.">
      <div className="flex flex-wrap gap-2">
        <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded-full text-xs">Active</span>
        <span className="px-2 py-1 bg-amber-500/20 text-amber-400 rounded-full text-xs">Pending</span>
        <span className="px-2 py-1 bg-red-500/20 text-red-400 rounded-full text-xs">Inactive</span>
        <span className="px-2 py-1 bg-violet-500/20 text-violet-400 rounded-full text-xs">Admin</span>
        <span className="px-2 py-1 bg-blue-500/20 text-blue-400 rounded-full text-xs">New</span>
      </div>
    </EffectCard>
  );
}

// Progress Bar
function ProgressBarEffect() {
  return (
    <EffectCard title="Progress Bars" description="Task and upload progress" whenToUse="File uploads, task completion, loading states.">
      <div className="w-full space-y-4 px-4">
        {[75, 45, 90].map((val, i) => (
          <div key={i}>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400">Task {i + 1}</span>
              <span className="text-white">{val}%</span>
            </div>
            <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
              <motion.div initial={{ width: 0 }} animate={{ width: `${val}%` }} transition={{ duration: 1, delay: i * 0.2 }} className={`h-full rounded-full ${i === 0 ? "bg-violet-500" : i === 1 ? "bg-cyan-500" : "bg-green-500"}`} />
            </div>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Notification Toast
function NotificationToastEffect() {
  const [show, setShow] = useState(false);
  return (
    <EffectCard title="Notification Toast" description="Pop-up notifications" whenToUse="Success messages, errors, alerts.">
      <div className="relative">
        <button onClick={() => { setShow(true); setTimeout(() => setShow(false), 2000); }} className="px-4 py-2 bg-violet-500 rounded-lg text-white text-sm">Show Toast</button>
        <AnimatePresence>
          {show && (
            <motion.div initial={{ opacity: 0, y: 20, x: "-50%" }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }} className="absolute top-full left-1/2 mt-4 flex items-center gap-2 px-4 py-2 bg-green-500 rounded-lg text-white text-sm">
              <Check className="w-4 h-4" /> Action completed!
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Avatar Group
function AvatarGroupEffect() {
  return (
    <EffectCard title="Avatar Group" description="Stacked user avatars" whenToUse="Team members, collaborators, assignees.">
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((_, i) => (
          <motion.div key={i} whileHover={{ scale: 1.2, zIndex: 10 }} className="w-10 h-10 rounded-full border-2 border-slate-900 -ml-2 first:ml-0" style={{ backgroundColor: ["#8b5cf6", "#06b6d4", "#f43f5e", "#22c55e", "#f59e0b"][i] }} />
        ))}
        <span className="ml-2 text-slate-400 text-sm">+12 more</span>
      </div>
    </EffectCard>
  );
}

// Empty State
function EmptyStateEffect() {
  return (
    <EffectCard title="Empty State" description="No data placeholder" whenToUse="Empty tables, no search results, first-time users.">
      <div className="text-center py-8">
        <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-slate-800 flex items-center justify-center">
          <FileText className="w-8 h-8 text-slate-600" />
        </div>
        <h3 className="text-white font-medium mb-1">No data found</h3>
        <p className="text-slate-500 text-sm mb-4">Get started by creating your first item</p>
        <button className="px-4 py-2 bg-violet-500 rounded-lg text-white text-sm">Create New</button>
      </div>
    </EffectCard>
  );
}

// Card with Actions
function CardActionsEffect() {
  return (
    <EffectCard title="Card with Actions" description="Content card with menu" whenToUse="Project cards, user cards, item previews.">
      <div className="w-full bg-slate-800 rounded-xl p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-violet-500 to-pink-500" />
            <div>
              <h4 className="text-white font-medium text-sm">Project Alpha</h4>
              <p className="text-slate-500 text-xs">Updated 2h ago</p>
            </div>
          </div>
          <button className="p-1 hover:bg-slate-700 rounded">
            <MoreVertical className="w-4 h-4 text-slate-400" />
          </button>
        </div>
        <p className="text-slate-400 text-sm mb-3">A brief description of this project and its current status.</p>
        <div className="flex gap-2">
          <span className="px-2 py-0.5 bg-violet-500/20 text-violet-400 rounded text-xs">Active</span>
          <span className="px-2 py-0.5 bg-slate-700 text-slate-400 rounded text-xs">3 members</span>
        </div>
      </div>
    </EffectCard>
  );
}

// Chart Placeholder
function ChartPlaceholderEffect() {
  return (
    <EffectCard title="Chart Widget" description="Analytics visualization" whenToUse="Dashboard stats, analytics, reports.">
      <div className="w-full bg-slate-800 rounded-xl p-4">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-white font-medium text-sm">Revenue Overview</h4>
          <select className="bg-slate-700 text-slate-300 text-xs rounded px-2 py-1">
            <option>Last 7 days</option>
            <option>Last 30 days</option>
          </select>
        </div>
        <div className="flex items-end gap-2 h-24">
          {[40, 65, 45, 80, 55, 70, 90].map((h, i) => (
            <motion.div key={i} initial={{ height: 0 }} animate={{ height: `${h}%` }} transition={{ delay: i * 0.1 }} className="flex-1 bg-gradient-to-t from-violet-500 to-cyan-500 rounded-t" />
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Form Input
function FormInputEffect() {
  return (
    <EffectCard title="Form Inputs" description="Styled form controls" whenToUse="User forms, settings, data entry.">
      <div className="w-full space-y-3 px-4">
        <div>
          <label className="text-slate-400 text-xs mb-1 block">Email</label>
          <input type="email" placeholder="user@example.com" className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:border-violet-500 focus:outline-none" />
        </div>
        <div>
          <label className="text-slate-400 text-xs mb-1 block">Role</label>
          <select className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:border-violet-500 focus:outline-none">
            <option>Admin</option>
            <option>User</option>
            <option>Guest</option>
          </select>
        </div>
      </div>
    </EffectCard>
  );
}

// Skeleton Loader
function SkeletonLoaderEffect() {
  return (
    <EffectCard title="Skeleton Loader" description="Content loading placeholder" whenToUse="Page loads, data fetching, lazy loading.">
      <div className="w-full space-y-3 px-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-slate-700 animate-pulse" />
          <div className="flex-1 space-y-2">
            <div className="h-3 w-24 bg-slate-700 rounded animate-pulse" />
            <div className="h-2 w-16 bg-slate-700 rounded animate-pulse" />
          </div>
        </div>
        <div className="h-3 w-full bg-slate-700 rounded animate-pulse" />
        <div className="h-3 w-3/4 bg-slate-700 rounded animate-pulse" />
      </div>
    </EffectCard>
  );
}

// Alert Box
function AlertBoxEffect() {
  return (
    <EffectCard title="Alert Boxes" description="Warning and info messages" whenToUse="Errors, warnings, success messages.">
      <div className="w-full space-y-2 px-4">
        <div className="flex items-center gap-2 p-3 bg-green-500/20 border border-green-500/30 rounded-lg">
          <Check className="w-4 h-4 text-green-400" />
          <span className="text-green-400 text-sm">Changes saved successfully</span>
        </div>
        <div className="flex items-center gap-2 p-3 bg-amber-500/20 border border-amber-500/30 rounded-lg">
          <Bell className="w-4 h-4 text-amber-400" />
          <span className="text-amber-400 text-sm">Your session expires soon</span>
        </div>
        <div className="flex items-center gap-2 p-3 bg-red-500/20 border border-red-500/30 rounded-lg">
          <X className="w-4 h-4 text-red-400" />
          <span className="text-red-400 text-sm">Failed to save changes</span>
        </div>
      </div>
    </EffectCard>
  );
}

// Toolbar
function ToolbarEffect() {
  return (
    <EffectCard title="Toolbar" description="Action buttons row" whenToUse="Document editors, table actions, bulk operations.">
      <div className="flex items-center gap-1 p-2 bg-slate-800 rounded-lg">
        <button className="p-2 hover:bg-slate-700 rounded"><Plus className="w-4 h-4 text-slate-400" /></button>
        <button className="p-2 hover:bg-slate-700 rounded"><Edit className="w-4 h-4 text-slate-400" /></button>
        <button className="p-2 hover:bg-slate-700 rounded"><Download className="w-4 h-4 text-slate-400" /></button>
        <div className="w-px h-6 bg-slate-700 mx-1" />
        <button className="p-2 hover:bg-slate-700 rounded"><ArrowUpDown className="w-4 h-4 text-slate-400" /></button>
        <button className="p-2 hover:bg-slate-700 rounded"><Filter className="w-4 h-4 text-slate-400" /></button>
        <div className="flex-1" />
        <button className="p-2 hover:bg-red-500/20 rounded"><Trash2 className="w-4 h-4 text-red-400" /></button>
      </div>
    </EffectCard>
  );
}

// Calendar Widget
function CalendarWidgetEffect() {
  return (
    <EffectCard title="Calendar Widget" description="Date picker mini calendar" whenToUse="Date selection, scheduling, event planning.">
      <div className="bg-slate-800 rounded-xl p-3">
        <div className="flex items-center justify-between mb-2">
          <span className="text-white text-sm font-medium">Dec 2024</span>
          <div className="flex gap-1">
            <button className="p-1 hover:bg-slate-700 rounded text-slate-400">‹</button>
            <button className="p-1 hover:bg-slate-700 rounded text-slate-400">›</button>
          </div>
        </div>
        <div className="grid grid-cols-7 gap-1 text-center text-xs">
          {["S", "M", "T", "W", "T", "F", "S"].map(d => <span key={d} className="text-slate-500 py-1">{d}</span>)}
          {[...Array(35)].map((_, i) => {
            const day = i - 2;
            const isToday = day === 15;
            return (
              <motion.button key={i} whileHover={{ scale: 1.1 }} className={`py-1 rounded ${isToday ? "bg-violet-500 text-white" : day > 0 && day <= 31 ? "text-slate-400 hover:bg-slate-700" : "text-slate-700"}`}>
                {day > 0 && day <= 31 ? day : ""}
              </motion.button>
            );
          })}
        </div>
      </div>
    </EffectCard>
  );
}

// User Profile Card
function UserProfileCardEffect() {
  return (
    <EffectCard title="User Profile Card" description="User info summary" whenToUse="User details, profiles, account views.">
      <div className="bg-slate-800 rounded-xl p-4 text-center">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-violet-500 to-pink-500 mx-auto mb-3" />
        <h4 className="text-white font-medium">John Doe</h4>
        <p className="text-slate-500 text-sm mb-3">Administrator</p>
        <div className="flex justify-center gap-4 text-center">
          <div><p className="text-white font-bold">128</p><p className="text-slate-500 text-xs">Posts</p></div>
          <div><p className="text-white font-bold">1.2K</p><p className="text-slate-500 text-xs">Following</p></div>
          <div><p className="text-white font-bold">4.5K</p><p className="text-slate-500 text-xs">Followers</p></div>
        </div>
      </div>
    </EffectCard>
  );
}

// Command Palette
function CommandPaletteEffect() {
  const [open, setOpen] = useState(false);
  return (
    <EffectCard title="Command Palette" description="Quick search & actions" whenToUse="Power user navigation, quick commands, search.">
      <div className="w-full">
        <button onClick={() => setOpen(true)} className="w-full flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-lg text-slate-400 text-sm">
          <Search className="w-4 h-4" /> <span className="flex-1 text-left">Search commands...</span> <kbd className="px-2 py-0.5 bg-slate-700 rounded text-xs">⌘K</kbd>
        </button>
        <AnimatePresence>
          {open && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-2 bg-slate-800 rounded-xl border border-slate-700 p-2">
              {["Go to Dashboard", "Create User", "Settings", "Logout"].map((cmd, i) => (
                <button key={i} onClick={() => setOpen(false)} className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-slate-300 hover:bg-slate-700">{cmd}</button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// File Upload Zone
function FileUploadZoneEffect() {
  const [isDragging, setIsDragging] = useState(false);
  return (
    <EffectCard title="File Upload Zone" description="Drag & drop file area" whenToUse="Document uploads, image imports, bulk file handling.">
      <motion.div animate={{ borderColor: isDragging ? "#8b5cf6" : "#334155" }} onDragOver={() => setIsDragging(true)} onDragLeave={() => setIsDragging(false)} className="w-full p-8 border-2 border-dashed rounded-xl text-center bg-slate-800/50">
        <Download className="w-8 h-8 text-slate-500 mx-auto mb-2" />
        <p className="text-white text-sm">Drop files here</p>
        <p className="text-slate-500 text-xs mt-1">or click to browse</p>
      </motion.div>
    </EffectCard>
  );
}

// Permission Matrix
function PermissionMatrixEffect() {
  return (
    <EffectCard title="Permission Matrix" description="Role access grid" whenToUse="Access control, role management, permissions settings.">
      <div className="w-full text-xs overflow-x-auto">
        <div className="grid grid-cols-4 gap-1 bg-slate-800 p-2 rounded-lg min-w-[200px]">
          <span className="text-slate-400">Role</span>
          <span className="text-center text-slate-400">Read</span>
          <span className="text-center text-slate-400">Write</span>
          <span className="text-center text-slate-400">Delete</span>
          {[{ role: "Admin", r: true, w: true, d: true }, { role: "Editor", r: true, w: true, d: false }, { role: "Viewer", r: true, w: false, d: false }].map((p, i) => (
            <React.Fragment key={i}>
              <span className="text-white">{p.role}</span>
              <span className="text-center">{p.r ? "✓" : "—"}</span>
              <span className="text-center">{p.w ? "✓" : "—"}</span>
              <span className="text-center">{p.d ? "✓" : "—"}</span>
            </React.Fragment>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Split Button
function SplitButtonEffect() {
  const [open, setOpen] = useState(false);
  return (
    <EffectCard title="Split Button" description="Primary + dropdown actions" whenToUse="Save with options, export formats, action variants.">
      <div className="flex">
        <button className="px-4 py-2 bg-violet-500 text-white text-sm rounded-l-lg">Save</button>
        <button onClick={() => setOpen(!open)} className="px-2 py-2 bg-violet-600 text-white rounded-r-lg border-l border-violet-400">
          <ChevronDown className="w-4 h-4" />
        </button>
      </div>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="absolute mt-1 bg-slate-800 rounded-lg shadow-xl border border-slate-700 overflow-hidden">
            {["Save as Draft", "Save & Publish", "Schedule"].map((opt, i) => (
              <button key={i} className="block w-full px-4 py-2 text-xs text-slate-300 hover:bg-slate-700 text-left">{opt}</button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </EffectCard>
  );
}

// Sortable List
function SortableListEffect() {
  return (
    <EffectCard title="Sortable List" description="Drag to reorder items" whenToUse="Priority ordering, menu builders, custom sorting.">
      <div className="w-full space-y-2 px-4">
        {["Priority 1", "Priority 2", "Priority 3"].map((item, i) => (
          <motion.div key={i} whileHover={{ x: 4 }} className="flex items-center gap-2 p-2 bg-slate-800 rounded-lg cursor-move">
            <Menu className="w-4 h-4 text-slate-500" />
            <span className="text-white text-sm flex-1">{item}</span>
            <span className="text-xs text-slate-500">#{i + 1}</span>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Timeline Vertical
function TimelineVerticalEffect() {
  return (
    <EffectCard title="Vertical Timeline" description="Event history display" whenToUse="User activity, changelog, order tracking.">
      <div className="relative pl-6 space-y-4">
        <div className="absolute left-2 top-0 bottom-0 w-0.5 bg-slate-700" />
        {[{ title: "Order Placed", time: "9:00 AM", done: true }, { title: "Processing", time: "10:30 AM", done: true }, { title: "Shipped", time: "Pending", done: false }].map((step, i) => (
          <div key={i} className="relative">
            <div className={`absolute -left-4 w-3 h-3 rounded-full ${step.done ? "bg-green-500" : "bg-slate-600"}`} />
            <p className="text-white text-sm">{step.title}</p>
            <p className="text-slate-500 text-xs">{step.time}</p>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Inline Edit
function InlineEditEffect() {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState("Click to edit");
  return (
    <EffectCard title="Inline Edit" description="Click to edit text" whenToUse="Quick updates, titles, descriptions.">
      {editing ? (
        <input value={value} onChange={(e) => setValue(e.target.value)} onBlur={() => setEditing(false)} autoFocus className="bg-slate-800 border border-violet-500 rounded px-2 py-1 text-white text-sm" />
      ) : (
        <span onClick={() => setEditing(true)} className="text-white text-sm cursor-pointer hover:text-violet-400">{value} <Edit className="w-3 h-3 inline ml-1 text-slate-500" /></span>
      )}
    </EffectCard>
  );
}

// Stepper Progress
function StepperProgressEffect() {
  const [step, setStep] = useState(1);
  return (
    <EffectCard title="Stepper Progress" description="Multi-step form indicator" whenToUse="Onboarding flows, checkout, wizards.">
      <div className="w-full">
        <div className="flex items-center justify-between mb-4">
          {[1, 2, 3, 4].map((s) => (
            <React.Fragment key={s}>
              <motion.div animate={{ backgroundColor: s <= step ? "#8b5cf6" : "#334155" }} className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs">{s}</motion.div>
              {s < 4 && <div className={`flex-1 h-1 mx-1 ${s < step ? "bg-violet-500" : "bg-slate-700"}`} />}
            </React.Fragment>
          ))}
        </div>
        <div className="flex gap-2 justify-center">
          <button onClick={() => setStep(Math.max(1, step - 1))} className="px-3 py-1 bg-slate-700 text-white text-xs rounded">Prev</button>
          <button onClick={() => setStep(Math.min(4, step + 1))} className="px-3 py-1 bg-violet-500 text-white text-xs rounded">Next</button>
        </div>
      </div>
    </EffectCard>
  );
}

// Notification Center
function NotificationCenterEffect() {
  const [open, setOpen] = useState(false);
  return (
    <EffectCard title="Notification Center" description="Bell icon with dropdown" whenToUse="App notifications, alerts, messages.">
      <div className="relative">
        <button onClick={() => setOpen(!open)} className="p-2 bg-slate-800 rounded-lg relative">
          <Bell className="w-5 h-5 text-white" />
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-white text-xs flex items-center justify-center">3</span>
        </button>
        <AnimatePresence>
          {open && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="absolute top-full left-0 mt-2 w-64 bg-slate-800 rounded-xl border border-slate-700 shadow-xl overflow-hidden z-10">
              <div className="p-3 border-b border-slate-700"><p className="text-white text-sm font-medium">Notifications</p></div>
              {["New user signed up", "Payment received", "Server alert"].map((n, i) => (
                <div key={i} className="px-3 py-2 text-xs text-slate-300 hover:bg-slate-700">{n}</div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Quick Stats Row
function QuickStatsRowEffect() {
  return (
    <EffectCard title="Quick Stats Row" description="Horizontal KPI strip" whenToUse="Dashboard headers, performance summaries.">
      <div className="flex items-center gap-4 px-4 py-3 bg-slate-800 rounded-lg w-full">
        {[{ label: "Users", value: "12K", icon: Users }, { label: "Revenue", value: "$48K", icon: BarChart3 }, { label: "Active", value: "89%", icon: Activity }].map((stat, i) => (
          <div key={i} className="flex items-center gap-2">
            <stat.icon className="w-4 h-4 text-violet-400" />
            <div><p className="text-white text-sm font-bold">{stat.value}</p><p className="text-slate-500 text-xs">{stat.label}</p></div>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Tree View
function TreeViewEffect() {
  const [expanded, setExpanded] = useState({ 0: true });
  const toggle = (i) => setExpanded(prev => ({ ...prev, [i]: !prev[i] }));
  return (
    <EffectCard title="Tree View" description="Hierarchical file/folder view" whenToUse="File browsers, category trees, org charts.">
      <div className="w-full text-xs space-y-1">
        <button onClick={() => toggle(0)} className="flex items-center gap-1 text-white">
          <ChevronDown className={`w-3 h-3 transition-transform ${expanded[0] ? "" : "-rotate-90"}`} /> 📁 Documents
        </button>
        {expanded[0] && (
          <div className="pl-4 space-y-1">
            <p className="text-slate-400">📄 Report.pdf</p>
            <p className="text-slate-400">📄 Notes.txt</p>
            <button onClick={() => toggle(1)} className="flex items-center gap-1 text-white">
              <ChevronDown className={`w-3 h-3 transition-transform ${expanded[1] ? "" : "-rotate-90"}`} /> 📁 Images
            </button>
            {expanded[1] && <div className="pl-4"><p className="text-slate-400">🖼️ Photo.jpg</p></div>}
          </div>
        )}
      </div>
    </EffectCard>
  );
}

// Filter Tags
function FilterTagsEffect() {
  const [tags, setTags] = useState(["Active", "Admin", "Verified"]);
  return (
    <EffectCard title="Filter Tags" description="Active filter chips" whenToUse="Search filters, applied filters display.">
      <div className="flex flex-wrap gap-2">
        {tags.map((tag, i) => (
          <motion.span key={i} layout className="flex items-center gap-1 px-2 py-1 bg-violet-500/20 text-violet-400 rounded-full text-xs">
            {tag} <button onClick={() => setTags(tags.filter((_, j) => j !== i))}><X className="w-3 h-3" /></button>
          </motion.span>
        ))}
        {tags.length > 0 && <button onClick={() => setTags([])} className="text-xs text-slate-400 hover:text-white">Clear all</button>}
      </div>
    </EffectCard>
  );
}

// Status Indicator
function StatusIndicatorEffect() {
  return (
    <EffectCard title="Status Indicator" description="Live system status" whenToUse="Service health, connection status, sync state.">
      <div className="space-y-2 w-full px-4">
        {[{ name: "API Server", status: "online" }, { name: "Database", status: "online" }, { name: "CDN", status: "warning" }].map((s, i) => (
          <div key={i} className="flex items-center justify-between p-2 bg-slate-800 rounded-lg">
            <span className="text-white text-sm">{s.name}</span>
            <span className={`flex items-center gap-1 text-xs ${s.status === "online" ? "text-green-400" : "text-amber-400"}`}>
              <span className={`w-2 h-2 rounded-full ${s.status === "online" ? "bg-green-400" : "bg-amber-400"} animate-pulse`} />
              {s.status}
            </span>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Data Cards Grid
function DataCardsGridEffect() {
  return (
    <EffectCard title="Data Cards Grid" description="Multi-card info display" whenToUse="Dashboard overviews, quick stats, summaries.">
      <div className="grid grid-cols-2 gap-2 w-full px-2">
        {[{ icon: Users, label: "Users", value: "1.2K", color: "text-violet-400" }, { icon: Database, label: "Storage", value: "45GB", color: "text-cyan-400" }, { icon: Activity, label: "Uptime", value: "99.9%", color: "text-green-400" }, { icon: Shield, label: "Security", value: "A+", color: "text-amber-400" }].map((card, i) => (
          <motion.div key={i} whileHover={{ y: -2 }} className="p-3 bg-slate-800 rounded-lg text-center">
            <card.icon className={`w-5 h-5 mx-auto mb-1 ${card.color}`} />
            <p className="text-white text-lg font-bold">{card.value}</p>
            <p className="text-slate-500 text-xs">{card.label}</p>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Date Range Picker
function DateRangePickerEffect() {
  return (
    <EffectCard title="Date Range Picker" description="Start/end date selector" whenToUse="Report filters, booking systems, analytics.">
      <div className="flex items-center gap-2 p-2 bg-slate-800 rounded-lg">
        <Calendar className="w-4 h-4 text-slate-400" />
        <input type="text" placeholder="Start date" className="bg-transparent text-white text-xs w-24 outline-none" defaultValue="Dec 1, 2024" />
        <span className="text-slate-500">→</span>
        <input type="text" placeholder="End date" className="bg-transparent text-white text-xs w-24 outline-none" defaultValue="Dec 31, 2024" />
      </div>
    </EffectCard>
  );
}

// Collapsible Section
function CollapsibleSectionEffect() {
  const [open, setOpen] = useState(true);
  return (
    <EffectCard title="Collapsible Section" description="Expandable content block" whenToUse="FAQ sections, settings groups, long forms.">
      <div className="w-full bg-slate-800 rounded-lg overflow-hidden">
        <button onClick={() => setOpen(!open)} className="w-full flex items-center justify-between p-3 text-left">
          <span className="text-white text-sm font-medium">Advanced Settings</span>
          <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${open ? "" : "-rotate-90"}`} />
        </button>
        <AnimatePresence>
          {open && (
            <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }} className="overflow-hidden">
              <div className="p-3 pt-0 text-xs text-slate-400">Hidden content revealed when expanded. Perfect for settings or details.</div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Action Footer Bar
function ActionFooterBarEffect() {
  return (
    <EffectCard title="Action Footer Bar" description="Fixed bottom action bar" whenToUse="Form submissions, bulk actions, save bars.">
      <div className="w-full flex items-center justify-between p-3 bg-slate-800 rounded-lg">
        <span className="text-slate-400 text-xs">3 items selected</span>
        <div className="flex gap-2">
          <button className="px-3 py-1.5 bg-slate-700 text-white text-xs rounded">Cancel</button>
          <button className="px-3 py-1.5 bg-red-500 text-white text-xs rounded">Delete</button>
          <button className="px-3 py-1.5 bg-violet-500 text-white text-xs rounded">Save Changes</button>
        </div>
      </div>
    </EffectCard>
  );
}

// Metric Sparkline
function MetricSparklineEffect() {
  const data = [30, 45, 28, 50, 42, 65, 55, 70];
  return (
    <EffectCard title="Metric Sparkline" description="Inline mini chart" whenToUse="Compact trends, table cells, quick metrics.">
      <div className="flex items-center gap-3 p-3 bg-slate-800 rounded-lg">
        <div>
          <p className="text-white text-xl font-bold">$12.4K</p>
          <p className="text-green-400 text-xs">+12.5%</p>
        </div>
        <div className="flex items-end gap-0.5 h-10">
          {data.map((h, i) => (
            <motion.div key={i} initial={{ height: 0 }} animate={{ height: `${h}%` }} transition={{ delay: i * 0.05 }} className="w-2 bg-gradient-to-t from-violet-500 to-cyan-400 rounded-t" />
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

export default function AdminLayouts() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <StatsCardsEffect />, name: "Stats Cards", category: "admin" },
    { component: <DataTableEffect />, name: "Data Table", category: "admin" },
    { component: <AdminSidebarEffect />, name: "Admin Sidebar", category: "admin" },
    { component: <AdminHeaderEffect />, name: "Admin Header", category: "admin" },
    { component: <DropdownMenuEffect />, name: "Dropdown Menu", category: "admin" },
    { component: <ModalDialogEffect />, name: "Modal Dialog", category: "admin" },
    { component: <PaginationEffect />, name: "Pagination", category: "admin" },
    { component: <BreadcrumbsEffect />, name: "Breadcrumbs", category: "admin" },
    { component: <TabsEffect />, name: "Tabs", category: "admin" },
    { component: <ToggleSwitchEffect />, name: "Toggle Switch", category: "admin" },
    { component: <SearchFilterBarEffect />, name: "Search with Filters", category: "admin" },
    { component: <ActivityLogEffect />, name: "Activity Log", category: "admin" },
    { component: <BadgeTagEffect />, name: "Badges & Tags", category: "admin" },
    { component: <ProgressBarEffect />, name: "Progress Bars", category: "admin" },
    { component: <NotificationToastEffect />, name: "Notification Toast", category: "admin" },
    { component: <AvatarGroupEffect />, name: "Avatar Group", category: "admin" },
    { component: <EmptyStateEffect />, name: "Empty State", category: "admin" },
    { component: <CardActionsEffect />, name: "Card with Actions", category: "admin" },
    { component: <ChartPlaceholderEffect />, name: "Chart Widget", category: "admin" },
    { component: <FormInputEffect />, name: "Form Inputs", category: "admin" },
    { component: <SkeletonLoaderEffect />, name: "Skeleton Loader", category: "admin" },
    { component: <AlertBoxEffect />, name: "Alert Boxes", category: "admin" },
    { component: <ToolbarEffect />, name: "Toolbar", category: "admin" },
    { component: <CalendarWidgetEffect />, name: "Calendar Widget", category: "admin" },
    { component: <UserProfileCardEffect />, name: "User Profile Card", category: "admin" },
    { component: <CommandPaletteEffect />, name: "Command Palette", category: "admin" },
    { component: <FileUploadZoneEffect />, name: "File Upload Zone", category: "admin" },
    { component: <PermissionMatrixEffect />, name: "Permission Matrix", category: "admin" },
    { component: <SplitButtonEffect />, name: "Split Button", category: "admin" },
    { component: <SortableListEffect />, name: "Sortable List", category: "admin" },
    { component: <TimelineVerticalEffect />, name: "Vertical Timeline", category: "admin" },
    { component: <InlineEditEffect />, name: "Inline Edit", category: "admin" },
    { component: <StepperProgressEffect />, name: "Stepper Progress", category: "admin" },
    { component: <NotificationCenterEffect />, name: "Notification Center", category: "admin" },
    { component: <QuickStatsRowEffect />, name: "Quick Stats Row", category: "admin" },
    { component: <TreeViewEffect />, name: "Tree View", category: "admin" },
    { component: <FilterTagsEffect />, name: "Filter Tags", category: "admin" },
    { component: <StatusIndicatorEffect />, name: "Status Indicator", category: "admin" },
    { component: <DataCardsGridEffect />, name: "Data Cards Grid", category: "admin" },
    { component: <DateRangePickerEffect />, name: "Date Range Picker", category: "admin" },
    { component: <CollapsibleSectionEffect />, name: "Collapsible Section", category: "admin" },
    { component: <ActionFooterBarEffect />, name: "Action Footer Bar", category: "admin" },
    { component: <MetricSparklineEffect />, name: "Metric Sparkline", category: "admin" },
  ];

  const filtered = effects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={LayoutDashboard} title="Admin & Dashboard Components" description="45 essential components for building admin panels, dashboards, and management interfaces" gradient="#8b5cf6, #06b6d4" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((effect, i) => (
            <motion.div key={effect.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>
              {effect.component}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}