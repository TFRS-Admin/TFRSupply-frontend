import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Layers, RefreshCw, Plus, Minus, Loader2, ArrowRight, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import ToggleSwitch from "@/components/ui/toggle-switch";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// Page Fade Transition
function PageFadeTransition() {
  const [currentPage, setCurrentPage] = useState(0);
  const pages = [
    { title: "Welcome", content: "First page", bg: "from-violet-500/20 to-purple-500/20" },
    { title: "Features", content: "Second page", bg: "from-cyan-500/20 to-blue-500/20" },
    { title: "Contact", content: "Third page", bg: "from-pink-500/20 to-rose-500/20" }
  ];

  return (
    <EffectCard title="Page Fade Transition" description="Smooth crossfade between pages" whenToUse="Use for multi-step flows, wizards, or content switching." controls={
      <div className="flex gap-2">{pages.map((_, i) => <button key={i} onClick={() => setCurrentPage(i)} className={`w-3 h-3 rounded-full transition-all ${currentPage === i ? "bg-violet-500 scale-110" : "bg-slate-600"}`} />)}</div>
    }>
      <div className="relative w-full h-[200px] overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div key={currentPage} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.3 }} className={`absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br ${pages[currentPage].bg} rounded-xl`}>
            <h3 className="text-2xl font-bold text-white mb-2">{pages[currentPage].title}</h3>
            <p className="text-slate-300">{pages[currentPage].content}</p>
          </motion.div>
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Staggered List
function StaggeredListEntry() {
  const [items, setItems] = useState([]);
  const [key, setKey] = useState(0);
  const sampleItems = ["📧 Check emails", "📝 Review docs", "📞 Call client", "🎯 Update status", "☕ Take break"];

  const reset = () => { setItems([]); setKey(k => k + 1); setTimeout(() => setItems(sampleItems), 100); };

  useEffect(() => { setItems(sampleItems); }, []);

  return (
    <EffectCard title="Staggered List" description="Items appear one by one" whenToUse="Perfect for task lists, feeds, or any sequential content." controls={<Button onClick={reset} variant="outline" className="w-full"><RefreshCw className="w-4 h-4 mr-2" /> Replay</Button>}>
      <div className="p-4 w-full" key={key}>
        <div className="space-y-2">
          {items.map((item, i) => (
            <motion.div key={i} initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }} className="p-3 rounded-lg bg-slate-800/50 border border-slate-700">
              <p className="text-sm text-slate-200">{item}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Counter
function CounterOdometer() {
  const [count, setCount] = useState(0);
  const [target, setTarget] = useState(1000);

  useEffect(() => {
    const timer = setInterval(() => {
      setCount(c => { if (c >= target) return target; return Math.min(c + Math.max(1, Math.floor((target - c) / 20)), target); });
    }, 30);
    return () => clearInterval(timer);
  }, [target]);

  const reset = () => { setCount(0); setTarget(Math.floor(Math.random() * 9000) + 1000); };

  return (
    <EffectCard title="Counter / Odometer" description="Animated counting" whenToUse="Great for stats, dashboards, or achievement displays." controls={<Button onClick={reset} variant="outline" className="w-full"><RefreshCw className="w-4 h-4 mr-2" /> New Target</Button>}>
      <div className="p-8 flex flex-col items-center gap-4">
        <div className="flex items-baseline gap-1">
          {count.toString().split('').map((digit, i) => (
            <motion.span key={`${i}-${digit}`} initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="text-5xl font-bold text-white">{digit}</motion.span>
          ))}
        </div>
        <p className="text-slate-400 text-sm">Target: {target.toLocaleString()}</p>
      </div>
    </EffectCard>
  );
}

// Loading Spinners
function LoadingSpinnerEffect() {
  const [variant, setVariant] = useState("spinner");
  const spinners = {
    spinner: <Loader2 className="w-12 h-12 text-violet-500 animate-spin" />,
    dots: <div className="flex gap-2">{[0, 1, 2].map(i => <motion.div key={i} className="w-4 h-4 rounded-full bg-cyan-500" animate={{ y: [0, -12, 0] }} transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.2 }} />)}</div>,
    pulse: <div className="relative"><motion.div className="w-16 h-16 rounded-full bg-pink-500" animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.2, 0.5] }} transition={{ duration: 1.5, repeat: Infinity }} /></div>,
    bars: <div className="flex gap-1">{[0, 1, 2, 3, 4].map(i => <motion.div key={i} className="w-2 bg-emerald-500 rounded-full" animate={{ height: [8, 32, 8] }} transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.1 }} />)}</div>
  };

  return (
    <EffectCard title="Loading Spinners" description="Various loading indicators" whenToUse="Use during async operations to show progress." controls={<div className="flex gap-2 flex-wrap">{Object.keys(spinners).map(v => <Button key={v} variant={variant === v ? "default" : "outline"} size="sm" onClick={() => setVariant(v)}>{v}</Button>)}</div>}>
      <div className="h-32 flex items-center justify-center">{spinners[variant]}</div>
    </EffectCard>
  );
}

// Pulse/Heartbeat
function PulseHeartbeatEffect() {
  const [isActive, setIsActive] = useState(true);
  const [speed, setSpeed] = useState([1]);

  return (
    <EffectCard title="Pulse / Heartbeat" description="Rhythmic pulsing" controls={
      <div className="space-y-4">
        <div className="flex items-center justify-between"><Label className="text-slate-300">Enable</Label><ToggleSwitch checked={isActive} onCheckedChange={setIsActive} /></div>
        <div className="space-y-2"><Label className="text-slate-300">Speed: {speed}x</Label><Slider value={speed} onValueChange={setSpeed} min={0.5} max={3} step={0.5} /></div>
      </div>
    }>
      <div className="p-8 flex items-center justify-center">
        <motion.div animate={isActive ? { scale: [1, 1.15, 1, 1.1, 1] } : { scale: 1 }} transition={{ duration: 0.8 / speed[0], repeat: isActive ? Infinity : 0, repeatDelay: 0.2 / speed[0] }} className="relative">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-red-500 to-pink-500 flex items-center justify-center shadow-lg shadow-red-500/30"><span className="text-4xl">❤️</span></div>
          {isActive && <motion.div className="absolute inset-0 rounded-full border-4 border-red-400" animate={{ scale: [1, 1.5], opacity: [0.6, 0] }} transition={{ duration: 0.8 / speed[0], repeat: Infinity, repeatDelay: 0.2 / speed[0] }} />}
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Expand/Collapse
function ExpandCollapseEffect() {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <EffectCard title="Expand / Collapse" description="Accordion transitions" controls={<Button onClick={() => setIsExpanded(!isExpanded)} variant="outline" className="w-full">{isExpanded ? <Minus className="w-4 h-4 mr-2" /> : <Plus className="w-4 h-4 mr-2" />}{isExpanded ? "Collapse" : "Expand"}</Button>}>
      <div className="p-4 w-full">
        <div className="rounded-xl border border-slate-700 overflow-hidden">
          <button onClick={() => setIsExpanded(!isExpanded)} className="w-full p-4 flex items-center justify-between bg-slate-800/50 hover:bg-slate-800 transition-colors">
            <span className="font-medium text-white">Click to expand</span>
            <motion.span animate={{ rotate: isExpanded ? 180 : 0 }}><ChevronDown className="w-5 h-5 text-slate-400" /></motion.span>
          </button>
          <AnimatePresence>
            {isExpanded && (
              <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}>
                <div className="p-4 bg-slate-900/50"><p className="text-slate-300 text-sm">Expanded content with smooth animation.</p></div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </EffectCard>
  );
}

// Flip Card
function FlipCardEffect() {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <EffectCard title="Flip Card" description="3D card flip" controls={<Button onClick={() => setIsFlipped(!isFlipped)} variant="outline" className="w-full"><RefreshCw className="w-4 h-4 mr-2" /> Flip</Button>}>
      <div className="p-8" style={{ perspective: "1000px" }}>
        <motion.div animate={{ rotateY: isFlipped ? 180 : 0 }} transition={{ duration: 0.6 }} style={{ transformStyle: "preserve-3d" }} onClick={() => setIsFlipped(!isFlipped)} className="relative w-48 h-32 cursor-pointer mx-auto">
          <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-lg" style={{ backfaceVisibility: "hidden" }}><span className="text-white font-bold text-lg">Front</span></div>
          <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg" style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}><span className="text-white font-bold text-lg">Back</span></div>
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Typewriter
function TypewriterEffect() {
  const [text, setText] = useState("");
  const [key, setKey] = useState(0);
  const fullText = "Welcome to Base44 Effects!";

  useEffect(() => {
    let i = 0; setText("");
    const timer = setInterval(() => { if (i < fullText.length) { setText(fullText.slice(0, i + 1)); i++; } else clearInterval(timer); }, 80);
    return () => clearInterval(timer);
  }, [key]);

  return (
    <EffectCard title="Typewriter" description="Letter by letter" controls={<Button onClick={() => setKey(k => k + 1)} variant="outline" className="w-full"><RefreshCw className="w-4 h-4 mr-2" /> Replay</Button>}>
      <div className="p-8 min-h-[100px] flex items-center justify-center">
        <p className="text-xl text-white font-mono">{text}<motion.span animate={{ opacity: [1, 0] }} transition={{ duration: 0.5, repeat: Infinity }} className="inline-block w-[2px] h-6 bg-violet-400 ml-1" /></p>
      </div>
    </EffectCard>
  );
}

// Progress Bar
function ProgressBarEffect() {
  const [progress, setProgress] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const start = () => {
    setProgress(0); setIsAnimating(true);
    const interval = setInterval(() => {
      setProgress(p => { if (p >= 100) { clearInterval(interval); setIsAnimating(false); return 100; } return p + 2; });
    }, 50);
  };

  return (
    <EffectCard title="Progress Bar" description="Animated progress" whenToUse="Ideal for uploads, downloads, or multi-step processes." controls={<Button onClick={start} disabled={isAnimating} variant="outline" className="w-full">{isAnimating ? "Loading..." : "Start Progress"}</Button>}>
      <div className="p-6 space-y-4 w-full">
        <div className="h-4 bg-slate-800 rounded-full overflow-hidden">
          <motion.div className="h-full bg-gradient-to-r from-violet-500 to-cyan-500 rounded-full" animate={{ width: `${progress}%` }} />
        </div>
        <div className="text-center"><span className="text-2xl font-bold text-white">{progress}%</span></div>
      </div>
    </EffectCard>
  );
}

// Slide Transitions
function SlideTransitions() {
  const [direction, setDirection] = useState("right");
  const [key, setKey] = useState(0);
  const directions = { left: { initial: { x: -100 }, animate: { x: 0 } }, right: { initial: { x: 100 }, animate: { x: 0 } }, up: { initial: { y: 100 }, animate: { y: 0 } }, down: { initial: { y: -100 }, animate: { y: 0 } } };

  return (
    <EffectCard title="Slide Transitions" description="Directional slides" controls={<div className="flex gap-2 flex-wrap">{Object.keys(directions).map(d => <Button key={d} variant={direction === d ? "default" : "outline"} size="sm" onClick={() => { setDirection(d); setKey(k => k + 1); }}>{d}</Button>)}</div>}>
      <div className="h-40 flex items-center justify-center overflow-hidden">
        <motion.div key={key} {...directions[direction]} className="w-32 h-32 bg-gradient-to-br from-violet-500 to-cyan-500 rounded-2xl flex items-center justify-center">
          <ArrowRight className="w-8 h-8 text-white" style={{ transform: direction === "left" ? "rotate(180deg)" : direction === "up" ? "rotate(-90deg)" : direction === "down" ? "rotate(90deg)" : "" }} />
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Scale Transition
function ScaleTransition() {
  const [isVisible, setIsVisible] = useState(true);

  return (
    <EffectCard title="Scale Transition" description="Zoom in/out" controls={<Button onClick={() => setIsVisible(!isVisible)} variant="outline" className="w-full">{isVisible ? "Hide" : "Show"}</Button>}>
      <div className="h-40 flex items-center justify-center">
        <AnimatePresence>
          {isVisible && (
            <motion.div initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0, opacity: 0 }} transition={{ type: "spring", bounce: 0.4 }} className="w-24 h-24 bg-gradient-to-br from-pink-500 to-rose-500 rounded-2xl flex items-center justify-center shadow-lg">
              <span className="text-3xl">✨</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Rotate Transition
function RotateTransition() {
  const [rotation, setRotation] = useState(0);

  return (
    <EffectCard title="Rotate Transition" description="Spin animation" controls={<Button onClick={() => setRotation(r => r + 360)} variant="outline" className="w-full">Rotate 360°</Button>}>
      <div className="h-40 flex items-center justify-center">
        <motion.div animate={{ rotate: rotation }} transition={{ type: "spring", stiffness: 100 }} className="w-24 h-24 bg-gradient-to-br from-amber-500 to-orange-500 rounded-2xl flex items-center justify-center shadow-lg">
          <span className="text-3xl">🔄</span>
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Morph Transition
function MorphTransition() {
  const [shape, setShape] = useState("square");
  const shapes = { square: "0%", rounded: "25%", circle: "50%" };

  return (
    <EffectCard title="Morph Transition" description="Shape morphing" controls={<div className="flex gap-2">{Object.keys(shapes).map(s => <Button key={s} variant={shape === s ? "default" : "outline"} size="sm" onClick={() => setShape(s)}>{s}</Button>)}</div>}>
      <div className="h-40 flex items-center justify-center">
        <motion.div animate={{ borderRadius: shapes[shape] }} transition={{ duration: 0.5 }} className="w-24 h-24 bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center shadow-lg">
          <span className="text-white font-bold">{shape}</span>
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Blur Transition
function BlurTransition() {
  const [isBlurred, setIsBlurred] = useState(false);

  return (
    <EffectCard title="Blur Transition" description="Focus/blur effect" controls={<Button onClick={() => setIsBlurred(!isBlurred)} variant="outline" className="w-full">{isBlurred ? "Focus" : "Blur"}</Button>}>
      <div className="h-40 flex items-center justify-center">
        <motion.div animate={{ filter: isBlurred ? "blur(10px)" : "blur(0px)" }} className="w-32 h-32 bg-gradient-to-br from-violet-500 to-cyan-500 rounded-2xl flex items-center justify-center">
          <span className="text-white font-bold text-lg">Content</span>
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Skeleton to Content
function SkeletonToContent() {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <EffectCard title="Skeleton → Content" description="Loading placeholder" controls={<Button onClick={() => setIsLoaded(!isLoaded)} variant="outline" className="w-full">{isLoaded ? "Show Skeleton" : "Load Content"}</Button>}>
      <div className="p-4 w-full">
        <AnimatePresence mode="wait">
          {!isLoaded ? (
            <motion.div key="skeleton" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-3">
              <div className="flex gap-3"><div className="w-12 h-12 rounded-full bg-slate-700 animate-pulse" /><div className="flex-1 space-y-2"><div className="h-4 bg-slate-700 rounded animate-pulse w-3/4" /><div className="h-3 bg-slate-700 rounded animate-pulse w-1/2" /></div></div>
            </motion.div>
          ) : (
            <motion.div key="content" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-3">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-violet-500 to-cyan-500" />
              <div><p className="font-medium text-white">John Doe</p><p className="text-sm text-slate-400">Developer</p></div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Parallax Layers
function ParallaxLayers() {
  const [scrollY, setScrollY] = useState(0);

  return (
    <EffectCard title="Parallax Layers" description="Multi-depth scrolling">
      <div className="h-48 overflow-hidden relative rounded-xl" onScroll={(e) => setScrollY(e.currentTarget.scrollTop)}>
        <div className="h-96 relative" onMouseMove={(e) => setScrollY(e.clientY / 3)}>
          <motion.div animate={{ y: -scrollY * 0.2 }} className="absolute inset-0 bg-slate-800" />
          <motion.div animate={{ y: -scrollY * 0.5 }} className="absolute top-20 left-10 w-20 h-20 bg-violet-500/30 rounded-full blur-xl" />
          <motion.div animate={{ y: -scrollY * 0.8 }} className="absolute top-40 right-10 w-16 h-16 bg-cyan-500/30 rounded-full blur-xl" />
          <motion.div animate={{ y: -scrollY * 1 }} className="absolute top-32 left-1/2 -translate-x-1/2"><span className="text-4xl">🚀</span></motion.div>
        </div>
        <p className="absolute bottom-2 left-0 right-0 text-center text-xs text-slate-500">Move mouse to see parallax</p>
      </div>
    </EffectCard>
  );
}

// Number Flip
function NumberFlip() {
  const [number, setNumber] = useState(0);

  return (
    <EffectCard title="Number Flip" description="Digit flip animation" controls={<Button onClick={() => setNumber(n => n + 1)} variant="outline" className="w-full">Increment</Button>}>
      <div className="h-32 flex items-center justify-center">
        <div className="flex gap-1">
          {number.toString().padStart(3, '0').split('').map((digit, i) => (
            <div key={i} className="w-12 h-16 bg-slate-800 rounded-lg overflow-hidden">
              <AnimatePresence mode="wait">
                <motion.div key={digit} initial={{ y: -64 }} animate={{ y: 0 }} exit={{ y: 64 }} className="h-full flex items-center justify-center">
                  <span className="text-3xl font-bold text-white">{digit}</span>
                </motion.div>
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

export default function Transitions() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <PageFadeTransition />, name: "Page Fade" },
    { component: <StaggeredListEntry />, name: "Staggered List" },
    { component: <CounterOdometer />, name: "Counter" },
    { component: <LoadingSpinnerEffect />, name: "Loading Spinners" },
    { component: <PulseHeartbeatEffect />, name: "Pulse" },
    { component: <ExpandCollapseEffect />, name: "Expand/Collapse" },
    { component: <FlipCardEffect />, name: "Flip Card" },
    { component: <TypewriterEffect />, name: "Typewriter" },
    { component: <ProgressBarEffect />, name: "Progress Bar" },
    { component: <SlideTransitions />, name: "Slide" },
    { component: <ScaleTransition />, name: "Scale" },
    { component: <RotateTransition />, name: "Rotate" },
    { component: <MorphTransition />, name: "Morph" },
    { component: <BlurTransition />, name: "Blur" },
    { component: <SkeletonToContent />, name: "Skeleton" },
    { component: <ParallaxLayers />, name: "Parallax" },
    { component: <NumberFlip />, name: "Number Flip" },
  ];

  const filtered = effects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={Layers} title="Transitions & Animations" description="Page transitions, list animations, and dynamic effects" gradient="#ec4899" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((effect, i) => <div key={i}>{effect.component}</div>)}
        </div>
      </div>
    </div>
  );
}