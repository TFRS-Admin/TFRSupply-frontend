import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BookOpen, Info, Sparkles, Eye, MousePointerClick, Layers, Layout, Zap, Menu, ArrowRight } from "lucide-react";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";
import { useQuery } from "@tanstack/react-query";

const terminology = [
  {
    id: 1,
    term: "Navigation Bar (Navbar)",
    definition: "The top bar of your app containing links, logo, and menu items. Usually fixed or sticky so it stays visible when scrolling.",
    icon: Menu,
    usage: "Every website needs one! It's how users get around your app.",
    example: "navbar",
    color: "from-purple-500 to-violet-600"
  },
  {
    id: 2,
    term: "Dropdown Menu",
    definition: "A menu that appears when you hover or click a button/link. Contains additional options hidden until triggered.",
    icon: ArrowRight,
    usage: "Great for organizing many links without cluttering your navbar.",
    example: "dropdown",
    color: "from-cyan-500 to-blue-600"
  },
  {
    id: 3,
    term: "Hover State",
    definition: "The visual change that happens when your mouse cursor is over an interactive element (button, link, etc).",
    icon: MousePointerClick,
    usage: "Essential for UX - tells users 'hey, you can click this!'",
    example: "hover",
    color: "from-violet-500 to-purple-600"
  },
  {
    id: 4,
    term: "Component",
    definition: "A reusable piece of UI code. Like a LEGO block you can use multiple times throughout your app.",
    icon: Layers,
    usage: "Build once, use everywhere. Saves time and keeps design consistent.",
    example: "component",
    color: "from-teal-500 to-cyan-600"
  },
  {
    id: 5,
    term: "Props",
    definition: "Short for 'properties'. Data you pass into a component to customize how it looks or behaves.",
    icon: Zap,
    usage: "Makes components flexible - same component, different content.",
    example: "props",
    color: "from-indigo-500 to-purple-600"
  },
  {
    id: 6,
    term: "State",
    definition: "Data that can change over time in your app. When state changes, the UI updates automatically.",
    icon: Sparkles,
    usage: "Powers interactive features like toggles, forms, counters, etc.",
    example: "state",
    color: "from-purple-500 to-pink-600"
  },
  {
    id: 7,
    term: "Layout",
    definition: "The overall structure/wrapper of your app. Usually contains navbar, footer, and wraps all pages.",
    icon: Layout,
    usage: "Define once, applies to every page. Consistent header/footer everywhere.",
    example: "layout",
    color: "from-slate-500 to-gray-600"
  },
  {
    id: 8,
    term: "Hero Section",
    definition: "The big, eye-catching section at the top of a page. Usually has a headline, subtitle, and call-to-action.",
    icon: Eye,
    usage: "First impression matters! This is what visitors see first.",
    example: "hero",
    color: "from-violet-500 to-fuchsia-600"
  },
  {
    id: 9,
    term: "Call-to-Action (CTA)",
    definition: "A button or link that prompts users to do something (Sign Up, Learn More, Buy Now, etc).",
    icon: MousePointerClick,
    usage: "Drives conversions. Tell users what action you want them to take!",
    example: "cta",
    color: "from-emerald-500 to-teal-600"
  },
  {
    id: 10,
    term: "Responsive Design",
    definition: "Design that adapts to different screen sizes (mobile, tablet, desktop). Looks good everywhere.",
    icon: Layout,
    usage: "50%+ of traffic is mobile. Your site must work on all devices.",
    example: "responsive",
    color: "from-blue-500 to-cyan-600"
  },
  {
    id: 11,
    term: "Grid Layout",
    definition: "A way to organize content in rows and columns. Think of it like a spreadsheet for your UI.",
    icon: Layers,
    usage: "Perfect for galleries, product listings, card layouts.",
    example: "grid",
    color: "from-purple-500 to-violet-600"
  },
  {
    id: 12,
    term: "Flexbox",
    definition: "A CSS layout method for arranging items in rows or columns with flexible spacing.",
    icon: Layers,
    usage: "Great for navigation bars, centering content, equal-height cards.",
    example: "flex",
    color: "from-cyan-500 to-teal-600"
  },
  {
    id: 13,
    term: "Modal / Dialog",
    definition: "A popup window that appears on top of the main content. Requires user action to dismiss.",
    icon: Eye,
    usage: "Use for confirmations, forms, alerts, or detailed info without leaving page.",
    example: "modal",
    color: "from-indigo-500 to-blue-600"
  },
  {
    id: 14,
    term: "Tooltip",
    definition: "Small popup text that appears when you hover over an element. Provides helpful hints.",
    icon: Info,
    usage: "Great for explaining icons, abbreviations, or extra context.",
    example: "tooltip",
    color: "from-slate-500 to-zinc-600"
  },
  {
    id: 15,
    term: "Card",
    definition: "A container with rounded corners and shadow, grouping related content together.",
    icon: Layers,
    usage: "Modern, clean way to display products, blog posts, team members, etc.",
    example: "card",
    color: "from-violet-500 to-purple-600"
  },
  {
    id: 16,
    term: "Gradient",
    definition: "A smooth transition between two or more colors. Adds depth and visual interest.",
    icon: Sparkles,
    usage: "Make backgrounds, buttons, and text pop with color blends.",
    example: "gradient",
    color: "from-pink-500 to-rose-600"
  },
  {
    id: 17,
    term: "Animation / Transition",
    definition: "Movement or change over time. Makes UI feel alive and guides user attention.",
    icon: Zap,
    usage: "Smooth page transitions, button clicks, loading states, etc.",
    example: "animation",
    color: "from-cyan-500 to-blue-600"
  },
  {
    id: 18,
    term: "Z-Index",
    definition: "Controls which elements appear on top of others. Higher number = more forward.",
    icon: Layers,
    usage: "Fix overlapping issues - modals over content, dropdowns over cards.",
    example: "zindex",
    color: "from-purple-500 to-violet-600"
  },
  {
    id: 19,
    term: "Padding",
    definition: "Space inside an element, between its content and its border.",
    icon: Layout,
    usage: "Gives content room to breathe. Makes text readable.",
    example: "padding",
    color: "from-teal-500 to-emerald-600"
  },
  {
    id: 20,
    term: "Margin",
    definition: "Space outside an element, between it and other elements.",
    icon: Layout,
    usage: "Creates separation between sections, cards, buttons.",
    example: "margin",
    color: "from-indigo-500 to-purple-600"
  },
  {
    id: 21,
    term: "Breakpoint",
    definition: "A screen width where your design changes (e.g., 768px for tablets, 1024px for desktop).",
    icon: Layout,
    usage: "Makes responsive design work - different layouts for different devices.",
    example: "breakpoint",
    color: "from-blue-500 to-cyan-600"
  },
  {
    id: 22,
    term: "API",
    definition: "Application Programming Interface - how your frontend talks to the backend/database.",
    icon: Zap,
    usage: "Fetch data, save forms, authenticate users - connects everything.",
    example: "api",
    color: "from-violet-500 to-fuchsia-600"
  },
  {
    id: 23,
    term: "Frontend vs Backend",
    definition: "Frontend = what users see (UI). Backend = server, database, logic behind the scenes.",
    icon: Layers,
    usage: "Frontend builds the experience. Backend powers the functionality.",
    example: "frontend",
    color: "from-purple-500 to-pink-600"
  },
  {
    id: 24,
    term: "UX (User Experience)",
    definition: "How easy, intuitive, and pleasant your app is to use. The overall feel.",
    icon: Eye,
    usage: "Good UX = happy users who stay longer and come back.",
    example: "ux",
    color: "from-emerald-500 to-teal-600"
  },
  {
    id: 25,
    term: "UI (User Interface)",
    definition: "The visual design - buttons, colors, typography, spacing. What users see and click.",
    icon: Sparkles,
    usage: "Good UI makes your app beautiful and professional.",
    example: "ui",
    color: "from-cyan-500 to-blue-600"
  }
];

function StateDemo() {
  const [count, setCount] = useState(0);
  return (
    <div className="bg-slate-800 rounded-lg p-3 border border-cyan-500/50 text-center">
      <div className="text-2xl font-bold text-cyan-400 mb-2">{count}</div>
      <button
        onClick={() => setCount(count + 1)}
        className="bg-cyan-500 text-white px-3 py-1 rounded text-xs hover:bg-cyan-600"
      >
        Click Me
      </button>
    </div>
  );
}

// Visual example components for each term
function ExamplePreview({ type }) {
  switch(type) {
    case "navbar":
      return (
        <div className="w-full bg-slate-800 rounded-lg p-2 border border-slate-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-gradient-to-br from-purple-500 to-cyan-500 rounded" />
              <div className="h-3 w-20 bg-slate-600 rounded" />
            </div>
            <div className="flex gap-2">
              <div className="h-3 w-12 bg-slate-600 rounded" />
              <div className="h-3 w-12 bg-slate-600 rounded" />
              <div className="h-3 w-12 bg-slate-600 rounded" />
            </div>
          </div>
        </div>
      );
    
    case "dropdown":
      return (
        <div className="space-y-2">
          <div className="bg-slate-800 rounded-lg p-2 border border-purple-500/50 inline-block">
            <div className="h-3 w-16 bg-purple-500 rounded" />
          </div>
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-slate-800 border border-slate-700 rounded-lg p-2 space-y-1"
          >
            <div className="h-2 w-24 bg-slate-600 rounded" />
            <div className="h-2 w-24 bg-slate-600 rounded" />
            <div className="h-2 w-24 bg-slate-600 rounded" />
          </motion.div>
        </div>
      );
    
    case "hover":
      return (
        <motion.div
          whileHover={{ scale: 1.05, boxShadow: "0 0 20px rgba(139, 92, 246, 0.5)" }}
          className="bg-gradient-to-r from-purple-500 to-cyan-500 rounded-lg p-3 cursor-pointer"
        >
          <div className="h-3 w-20 bg-white/90 rounded mx-auto" />
        </motion.div>
      );
    
    case "component":
      return (
        <div className="grid grid-cols-2 gap-2">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="bg-slate-800 border border-purple-500/30 rounded-lg p-2">
              <div className="h-2 w-full bg-purple-500/50 rounded mb-1" />
              <div className="h-2 w-3/4 bg-slate-600 rounded" />
            </div>
          ))}
        </div>
      );
    
    case "state":
      return <StateDemo />;
    
    case "hero":
      return (
        <div className="bg-gradient-to-br from-purple-900/50 to-cyan-900/50 rounded-lg p-4 text-center border border-purple-500/30">
          <div className="h-4 w-3/4 bg-white/90 rounded mx-auto mb-2" />
          <div className="h-2 w-1/2 bg-slate-400 rounded mx-auto mb-3" />
          <div className="h-6 w-24 bg-gradient-to-r from-purple-500 to-cyan-500 rounded mx-auto" />
        </div>
      );
    
    case "cta":
      return (
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-6 py-2 rounded-lg font-semibold shadow-lg"
        >
          Get Started →
        </motion.button>
      );
    
    case "responsive":
      return (
        <div className="flex gap-2 items-end">
          <div className="h-16 w-8 bg-slate-700 rounded border border-cyan-500" />
          <div className="h-20 w-12 bg-slate-700 rounded border border-cyan-500" />
          <div className="h-24 w-16 bg-slate-700 rounded border border-cyan-500" />
        </div>
      );
    
    case "grid":
      return (
        <div className="grid grid-cols-3 gap-1">
          {[1,2,3,4,5,6].map(i => (
            <div key={i} className="h-8 bg-purple-500/30 rounded border border-purple-500/50" />
          ))}
        </div>
      );
    
    case "modal":
      return (
        <div className="relative">
          <div className="absolute inset-0 bg-black/50 rounded-lg" />
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative bg-slate-800 border border-indigo-500 rounded-lg p-3 m-4"
          >
            <div className="h-3 w-20 bg-indigo-400 rounded mb-2" />
            <div className="h-2 w-full bg-slate-600 rounded" />
          </motion.div>
        </div>
      );
    
    case "card":
      return (
        <motion.div 
          whileHover={{ y: -4 }}
          className="bg-slate-800 rounded-xl p-3 shadow-lg border border-violet-500/30"
        >
          <div className="h-12 bg-gradient-to-br from-violet-500/30 to-purple-500/30 rounded-lg mb-2" />
          <div className="h-2 w-3/4 bg-slate-600 rounded mb-1" />
          <div className="h-2 w-1/2 bg-slate-600 rounded" />
        </motion.div>
      );
    
    case "gradient":
      return (
        <div className="h-20 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 rounded-lg" />
      );
    
    case "animation":
      return (
        <div className="flex justify-center items-center h-20">
          <motion.div
            animate={{ 
              rotate: 360,
              scale: [1, 1.2, 1]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              ease: "linear"
            }}
            className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-500 rounded-lg"
          />
        </div>
      );
    
    case "padding":
      return (
        <div className="bg-slate-800 rounded-lg border-2 border-teal-500">
          <div className="bg-teal-500/20 p-4">
            <div className="bg-slate-700 rounded p-2 text-center text-xs text-teal-400">
              Content
            </div>
          </div>
        </div>
      );
    
    case "margin":
      return (
        <div className="space-y-2">
          <div className="bg-slate-700 rounded p-2 border-2 border-indigo-500" />
          <div className="h-4 bg-indigo-500/30 rounded" />
          <div className="bg-slate-700 rounded p-2 border-2 border-indigo-500" />
        </div>
      );
    
    default:
      return (
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <Sparkles className="w-8 h-8 text-purple-400 mx-auto" />
        </div>
      );
  }
}

function TermCard({ term }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="group"
    >
      <HoverCard openDelay={300}>
        <HoverCardTrigger asChild>
          <div className="relative cursor-help">
            <div className="absolute -inset-0.5 bg-gradient-to-r opacity-0 group-hover:opacity-50 blur transition-opacity rounded-xl"
                 style={{ background: `linear-gradient(135deg, ${term.color.split(' ')[1]}, ${term.color.split(' ')[3]})` }} />
            
            <div className="relative bg-slate-900/80 border border-slate-800 rounded-xl p-6 hover:border-slate-700 transition-all">
              <div className="flex items-start gap-4">
                <motion.div 
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.6 }}
                  className={`w-12 h-12 rounded-lg bg-slate-900 border-2 ${term.color.replace('from-', 'border-').split(' ')[0]} flex items-center justify-center`}
                >
                  <term.icon className="w-6 h-6 text-white" />
                </motion.div>
                
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-white mb-2 flex items-center gap-2">
                    {term.term}
                    <Info className="w-4 h-4 text-slate-500 group-hover:text-purple-400 transition-colors" />
                  </h3>
                  <p className="text-sm text-slate-400 mb-3">
                    {term.definition}
                  </p>
                  <div className="inline-flex items-center gap-1 px-2 py-1 bg-slate-800 rounded-full text-xs text-slate-500">
                    <Zap className="w-3 h-3" />
                    Hover for preview
                  </div>
                </div>
              </div>
            </div>
          </div>
        </HoverCardTrigger>
        
        <HoverCardContent 
          side="top" 
          className="w-80 bg-slate-900/95 border-slate-700 p-4 backdrop-blur-xl"
        >
          <div className="space-y-3">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span className="text-sm font-semibold text-white">Live Preview</span>
            </div>
            
            <ExamplePreview type={term.example} />
            
            <div className="pt-3 border-t border-slate-800">
              <p className="text-xs text-slate-400">
                <span className="text-purple-400 font-semibold">💡 Pro Tip:</span> {term.usage}
              </p>
            </div>
          </div>
        </HoverCardContent>
      </HoverCard>
    </motion.div>
  );
}

export default function DesignTerminology() {
  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border border-purple-500/20 mb-6">
            <BookOpen className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-slate-300">Design Education</span>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="text-white">Design </span>
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-cyan-400">
              Terminology Guide
            </span>
          </h1>
          
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            Learn the essential terms and concepts every designer should know. 
            Hover over each card to see live examples and practical tips!
          </p>
        </motion.div>

        {/* Info Box */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border border-purple-500/20 rounded-xl p-6 mb-12"
        >
          <div className="flex items-start gap-4">
            <div className="p-2 bg-purple-500/20 rounded-lg">
              <Sparkles className="w-6 h-6 text-purple-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">
                How to Use This Guide
              </h3>
              <p className="text-sm text-slate-400">
                Each term includes a clear definition, practical usage tips, and an interactive preview. 
                Simply <span className="text-purple-400 font-semibold">hover over any card</span> to see 
                a live example of the concept in action. Perfect for beginners and a handy reference for pros!
              </p>
            </div>
          </div>
        </motion.div>

        {/* Terminology Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {terminology.map((term) => (
            <TermCard key={term.id} term={term} />
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <div className="inline-block bg-slate-900/50 border border-slate-800 rounded-2xl p-8">
            <BookOpen className="w-12 h-12 text-purple-400 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-white mb-2">
              Ready to Build?
            </h3>
            <p className="text-slate-400 mb-6 max-w-md">
              Now that you know the basics, explore our component library and start creating!
            </p>
            <a href="/Explore" className="explore-btn relative inline-flex items-center gap-2 px-8 py-3 rounded-xl font-semibold overflow-hidden">
              <div className="absolute inset-0 bg-slate-900/30 rounded-xl" />
              <div className="absolute inset-0 rounded-xl border-2 border-violet-500" />
              <span className="relative z-10 flex items-center gap-2 text-white explore-btn-content">
                <Sparkles className="w-5 h-5 text-violet-400" />
                <span>Explore Components</span>
                <ArrowRight className="w-5 h-5" />
              </span>
            </a>
            <style>{`
              .explore-btn:hover .explore-btn-content {
                animation: explore-glitch 0.3s ease-in-out infinite;
              }
              .explore-btn:hover {
                animation: btn-shake 0.3s ease-in-out infinite;
              }
              @keyframes explore-glitch {
                0%, 100% { text-shadow: none; filter: none; }
                20% { text-shadow: -2px 0 #ff00ff, 2px 0 #00ffff; filter: hue-rotate(10deg); }
                40% { text-shadow: 2px 0 #ff00ff, -2px 0 #00ffff; filter: hue-rotate(-10deg); }
                60% { text-shadow: -1px 0 #00ffff, 1px 0 #ff00ff; filter: hue-rotate(5deg); }
                80% { text-shadow: 1px 0 #00ffff, -1px 0 #ff00ff; filter: hue-rotate(-5deg); }
              }
              @keyframes btn-shake {
                0%, 100% { transform: translate(0) scale(1.02); }
                10% { transform: translate(-1px, 1px) scale(1.02); }
                20% { transform: translate(1px, -1px) scale(1.02); }
                30% { transform: translate(-1px, 0) scale(1.02); }
                40% { transform: translate(1px, 1px) scale(1.02); }
                50% { transform: translate(0, -1px) scale(1.02); }
              }
            `}</style>
          </div>
        </motion.div>
      </div>
    </div>
  );
}