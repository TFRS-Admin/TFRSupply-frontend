import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { FileText, Book, Quote, List, Image, Video, Link2, Hash, AlignLeft, AlignCenter, AlignRight, Bold, Italic, Underline, Heading1, Heading2, Code, ListOrdered, CheckSquare, Table, Calendar, Clock, User, Tag, Bookmark, Share2, ThumbsUp, MessageSquare, Eye } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// Blog Post Card
function BlogCardEffect() {
  return (
    <EffectCard title="Blog Post Card" description="Article preview with metadata" whenToUse="Blog listings, news feeds, content grids.">
      <motion.div whileHover={{ y: -4 }} className="bg-slate-800 rounded-xl overflow-hidden w-full">
        <div className="h-24 bg-gradient-to-br from-violet-500/30 to-cyan-500/30" />
        <div className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2 py-0.5 bg-violet-500/20 text-violet-400 rounded text-xs">Tutorial</span>
            <span className="text-slate-500 text-xs">5 min read</span>
          </div>
          <h3 className="text-white font-semibold mb-2">Getting Started with React</h3>
          <p className="text-slate-400 text-sm mb-3 line-clamp-2">Learn the fundamentals of React and build your first component...</p>
          <div className="flex items-center gap-3 text-xs text-slate-500">
            <span className="flex items-center gap-1"><Eye className="w-3 h-3" /> 1.2k</span>
            <span className="flex items-center gap-1"><ThumbsUp className="w-3 h-3" /> 89</span>
            <span className="flex items-center gap-1"><MessageSquare className="w-3 h-3" /> 12</span>
          </div>
        </div>
      </motion.div>
    </EffectCard>
  );
}

// Rich Text Editor
function RichTextEditorEffect() {
  return (
    <EffectCard title="Rich Text Editor" description="WYSIWYG toolbar and editor" whenToUse="Blog posts, documentation, content management.">
      <div className="w-full bg-slate-800 rounded-lg overflow-hidden">
        <div className="flex items-center gap-1 p-2 border-b border-slate-700 flex-wrap">
          {[Bold, Italic, Underline, null, Heading1, Heading2, null, AlignLeft, AlignCenter, AlignRight, null, List, ListOrdered, null, Link2, Image, Code].map((Icon, i) =>
            Icon ? (
              <button key={i} className="p-1.5 hover:bg-slate-700 rounded"><Icon className="w-4 h-4 text-slate-400" /></button>
            ) : (
              <div key={i} className="w-px h-5 bg-slate-700 mx-1" />
            )
          )}
        </div>
        <div className="p-3 min-h-[80px]">
          <p className="text-white text-sm">Start writing your content...</p>
        </div>
      </div>
    </EffectCard>
  );
}

// Quote Block
function QuoteBlockEffect() {
  return (
    <EffectCard title="Quote Block" description="Styled blockquote" whenToUse="Articles, testimonials, citations.">
      <div className="border-l-4 border-violet-500 pl-4 py-2">
        <Quote className="w-6 h-6 text-violet-400 mb-2" />
        <p className="text-white italic mb-2">"Design is not just what it looks like and feels like. Design is how it works."</p>
        <p className="text-slate-400 text-sm">— Steve Jobs</p>
      </div>
    </EffectCard>
  );
}

// Table of Contents
function TOCEffect() {
  const [active, setActive] = useState(1);
  const items = ["Introduction", "Getting Started", "Core Concepts", "Advanced Topics", "Conclusion"];
  return (
    <EffectCard title="Table of Contents" description="Article navigation sidebar" whenToUse="Documentation, long articles, guides.">
      <div className="w-full bg-slate-800/50 rounded-lg p-3">
        <h4 className="text-slate-400 text-xs uppercase mb-2">Contents</h4>
        <ul className="space-y-1">
          {items.map((item, i) => (
            <motion.li key={i} onClick={() => setActive(i)} whileHover={{ x: 4 }} className={`flex items-center gap-2 py-1 px-2 rounded cursor-pointer text-sm ${active === i ? "bg-violet-500/20 text-violet-400" : "text-slate-400 hover:text-white"}`}>
              <span className="w-5 h-5 rounded bg-slate-700 flex items-center justify-center text-xs">{i + 1}</span>
              {item}
            </motion.li>
          ))}
        </ul>
      </div>
    </EffectCard>
  );
}

// Author Card
function AuthorCardEffect() {
  return (
    <EffectCard title="Author Card" description="Writer bio and social links" whenToUse="Blog posts, articles, team pages.">
      <div className="flex items-start gap-4 bg-slate-800/50 rounded-xl p-4">
        <div className="w-14 h-14 rounded-full bg-gradient-to-br from-violet-500 to-pink-500 flex-shrink-0" />
        <div className="flex-1">
          <h4 className="text-white font-medium">Sarah Johnson</h4>
          <p className="text-slate-400 text-xs mb-2">Senior Developer • 128 articles</p>
          <p className="text-slate-500 text-sm">Passionate about building great user experiences and teaching others.</p>
        </div>
      </div>
    </EffectCard>
  );
}

// Tag Cloud
function TagCloudEffect() {
  const tags = ["React", "JavaScript", "CSS", "TypeScript", "Node.js", "Design", "UI/UX", "API"];
  return (
    <EffectCard title="Tag Cloud" description="Clickable category tags" whenToUse="Blog sidebars, filtering, categories.">
      <div className="flex flex-wrap gap-2">
        {tags.map((tag, i) => (
          <motion.button key={tag} whileHover={{ scale: 1.05 }} className="px-3 py-1.5 bg-slate-800 hover:bg-violet-500/20 rounded-lg text-sm text-slate-400 hover:text-violet-400 transition-colors">
            <Hash className="w-3 h-3 inline mr-1" />{tag}
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Reading Progress
function ReadingProgressEffect() {
  const [progress, setProgress] = useState(35);
  return (
    <EffectCard title="Reading Progress" description="Article scroll indicator" whenToUse="Long-form content, articles, documentation.">
      <div className="w-full">
        <div className="h-1 bg-slate-700 rounded-full overflow-hidden mb-3">
          <motion.div animate={{ width: `${progress}%` }} className="h-full bg-gradient-to-r from-violet-500 to-cyan-500" />
        </div>
        <div className="flex justify-between text-xs text-slate-400">
          <span>{progress}% complete</span>
          <span>~4 min remaining</span>
        </div>
        <input type="range" min="0" max="100" value={progress} onChange={e => setProgress(e.target.value)} className="w-full mt-2" />
      </div>
    </EffectCard>
  );
}

// Code Block
function CodeBlockEffect() {
  const [copied, setCopied] = useState(false);
  return (
    <EffectCard title="Code Block" description="Syntax highlighted code" whenToUse="Documentation, tutorials, technical content.">
      <div className="w-full bg-slate-900 rounded-lg overflow-hidden">
        <div className="flex items-center justify-between px-3 py-2 bg-slate-800">
          <span className="text-xs text-slate-400">JavaScript</span>
          <button onClick={() => { setCopied(true); setTimeout(() => setCopied(false), 1500); }} className="text-xs text-slate-400 hover:text-white">{copied ? "Copied!" : "Copy"}</button>
        </div>
        <pre className="p-3 text-sm overflow-x-auto">
          <code className="text-slate-300">
            <span className="text-violet-400">const</span> greeting = <span className="text-green-400">"Hello World"</span>;
            {"\n"}<span className="text-cyan-400">console</span>.log(greeting);
          </code>
        </pre>
      </div>
    </EffectCard>
  );
}

// Callout Box
function CalloutBoxEffect() {
  return (
    <EffectCard title="Callout Boxes" description="Highlighted info sections" whenToUse="Tips, warnings, notes in content.">
      <div className="space-y-2 w-full">
        <div className="flex gap-3 p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg">
          <span className="text-lg">💡</span>
          <p className="text-blue-400 text-sm">Pro tip: Use keyboard shortcuts to speed up your workflow.</p>
        </div>
        <div className="flex gap-3 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg">
          <span className="text-lg">⚠️</span>
          <p className="text-amber-400 text-sm">Warning: This action cannot be undone.</p>
        </div>
      </div>
    </EffectCard>
  );
}

// Related Posts
function RelatedPostsEffect() {
  return (
    <EffectCard title="Related Posts" description="Suggested articles section" whenToUse="Article footers, sidebars, recommendations.">
      <div className="space-y-3">
        <h4 className="text-white text-sm font-medium">Related Articles</h4>
        {[1, 2, 3].map(i => (
          <motion.div key={i} whileHover={{ x: 4 }} className="flex gap-3 cursor-pointer">
            <div className="w-16 h-12 rounded bg-slate-800 flex-shrink-0" />
            <div>
              <p className="text-white text-sm hover:text-violet-400">Article Title {i}</p>
              <p className="text-slate-500 text-xs">3 min read</p>
            </div>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Newsletter Widget
function NewsletterWidgetEffect() {
  return (
    <EffectCard title="Newsletter Widget" description="Email subscription box" whenToUse="Blog sidebars, footers, content pages.">
      <div className="bg-gradient-to-br from-violet-500/20 to-cyan-500/20 rounded-xl p-4 border border-violet-500/30">
        <Book className="w-8 h-8 text-violet-400 mb-2" />
        <h4 className="text-white font-medium mb-1">Subscribe to our newsletter</h4>
        <p className="text-slate-400 text-sm mb-3">Get the latest articles delivered to your inbox.</p>
        <div className="flex gap-2">
          <input type="email" placeholder="you@example.com" className="flex-1 px-3 py-2 bg-slate-800 rounded-lg text-white text-sm" />
          <button className="px-4 py-2 bg-violet-500 rounded-lg text-white text-sm">Subscribe</button>
        </div>
      </div>
    </EffectCard>
  );
}

// Share Buttons
function ShareButtonsEffect() {
  return (
    <EffectCard title="Share Buttons" description="Social sharing options" whenToUse="Article headers/footers, content sharing.">
      <div className="flex items-center gap-3">
        <span className="text-slate-400 text-sm">Share:</span>
        {["Twitter", "Facebook", "LinkedIn", "Copy"].map(p => (
          <motion.button key={p} whileHover={{ scale: 1.1 }} className="w-10 h-10 bg-slate-800 hover:bg-violet-500/20 rounded-lg flex items-center justify-center">
            <Share2 className="w-4 h-4 text-slate-400 hover:text-violet-400" />
          </motion.button>
        ))}
      </div>
    </EffectCard>
  );
}

// Bookmark Button
function BookmarkButtonEffect() {
  const [saved, setSaved] = useState(false);
  return (
    <EffectCard title="Bookmark Button" description="Save for later action" whenToUse="Articles, products, content saving.">
      <motion.button onClick={() => setSaved(!saved)} whileTap={{ scale: 0.9 }} className={`flex items-center gap-2 px-4 py-2 rounded-lg ${saved ? "bg-violet-500 text-white" : "bg-slate-800 text-slate-400"}`}>
        <Bookmark className={`w-4 h-4 ${saved ? "fill-current" : ""}`} />
        {saved ? "Saved" : "Save for later"}
      </motion.button>
    </EffectCard>
  );
}

// Date/Time Display
function DateTimeEffect() {
  return (
    <EffectCard title="Date & Time" description="Publication metadata" whenToUse="Articles, posts, content timestamps.">
      <div className="flex items-center gap-4 text-sm">
        <div className="flex items-center gap-2 text-slate-400">
          <Calendar className="w-4 h-4" />
          <span>Dec 2, 2024</span>
        </div>
        <div className="flex items-center gap-2 text-slate-400">
          <Clock className="w-4 h-4" />
          <span>5 min read</span>
        </div>
        <div className="flex items-center gap-2 text-slate-400">
          <User className="w-4 h-4" />
          <span>John Doe</span>
        </div>
      </div>
    </EffectCard>
  );
}

// Image Caption
function ImageCaptionEffect() {
  return (
    <EffectCard title="Image with Caption" description="Captioned figure" whenToUse="Articles, documentation, galleries.">
      <figure className="w-full">
        <div className="h-32 bg-gradient-to-br from-violet-500/30 to-pink-500/30 rounded-lg mb-2" />
        <figcaption className="text-slate-400 text-xs text-center italic">Figure 1: Example image with descriptive caption explaining the content.</figcaption>
      </figure>
    </EffectCard>
  );
}

// Accordion FAQ
function AccordionFAQEffect() {
  const [open, setOpen] = useState(0);
  const faqs = ["What is this?", "How does it work?", "Is it free?"];
  return (
    <EffectCard title="Accordion FAQ" description="Expandable questions" whenToUse="FAQs, documentation, help pages.">
      <div className="w-full space-y-2">
        {faqs.map((q, i) => (
          <div key={i} className="bg-slate-800 rounded-lg overflow-hidden">
            <button onClick={() => setOpen(open === i ? -1 : i)} className="w-full flex items-center justify-between p-3 text-left text-white text-sm">
              {q}
              <motion.div animate={{ rotate: open === i ? 180 : 0 }}><ChevronDown className="w-4 h-4 text-slate-400" /></motion.div>
            </button>
            <AnimatePresence>
              {open === i && (
                <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }} className="overflow-hidden">
                  <p className="px-3 pb-3 text-slate-400 text-sm">Answer to the question goes here with detailed explanation.</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

const ChevronDown = ({ className }) => <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m6 9 6 6 6-6"/></svg>;

// Step Guide
function StepGuideEffect() {
  return (
    <EffectCard title="Step Guide" description="Numbered instructions" whenToUse="Tutorials, guides, onboarding.">
      <div className="space-y-4">
        {["Create your account", "Set up your profile", "Start creating"].map((step, i) => (
          <div key={i} className="flex gap-4">
            <div className="w-8 h-8 rounded-full bg-violet-500 flex items-center justify-center text-white font-bold flex-shrink-0">{i + 1}</div>
            <div>
              <h4 className="text-white font-medium">{step}</h4>
              <p className="text-slate-400 text-sm">Brief description of this step.</p>
            </div>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Content Rating
function ContentRatingEffect() {
  const [helpful, setHelpful] = useState(null);
  return (
    <EffectCard title="Content Rating" description="Was this helpful feedback" whenToUse="Documentation, articles, help content.">
      <div className="text-center">
        <p className="text-slate-400 text-sm mb-3">Was this article helpful?</p>
        <div className="flex gap-3 justify-center">
          <motion.button onClick={() => setHelpful(true)} whileTap={{ scale: 0.9 }} className={`px-4 py-2 rounded-lg flex items-center gap-2 ${helpful === true ? "bg-green-500 text-white" : "bg-slate-800 text-slate-400"}`}>
            <ThumbsUp className="w-4 h-4" /> Yes
          </motion.button>
          <motion.button onClick={() => setHelpful(false)} whileTap={{ scale: 0.9 }} className={`px-4 py-2 rounded-lg flex items-center gap-2 ${helpful === false ? "bg-red-500 text-white" : "bg-slate-800 text-slate-400"}`}>
            <ThumbsUp className="w-4 h-4 rotate-180" /> No
          </motion.button>
        </div>
      </div>
    </EffectCard>
  );
}

// Comparison Table
function ComparisonTableEffect() {
  return (
    <EffectCard title="Comparison Table" description="Feature comparison grid" whenToUse="Product comparisons, plan features.">
      <div className="w-full overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="text-slate-400">
              <th className="text-left p-2">Feature</th>
              <th className="p-2">Basic</th>
              <th className="p-2">Pro</th>
            </tr>
          </thead>
          <tbody>
            {["Storage", "Users", "Support"].map(f => (
              <tr key={f} className="border-t border-slate-800">
                <td className="p-2 text-white">{f}</td>
                <td className="p-2 text-center text-slate-400">1GB</td>
                <td className="p-2 text-center text-violet-400">Unlimited</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </EffectCard>
  );
}

// Video Embed
function VideoEmbedEffect() {
  return (
    <EffectCard title="Video Embed" description="Embedded video player" whenToUse="Tutorials, content, media pages.">
      <div className="relative w-full h-32 bg-slate-800 rounded-lg overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-violet-500/20 to-cyan-500/20 flex items-center justify-center">
          <motion.div whileHover={{ scale: 1.1 }} className="w-12 h-12 bg-white/90 rounded-full flex items-center justify-center cursor-pointer">
            <div className="w-0 h-0 border-t-6 border-b-6 border-l-8 border-transparent border-l-violet-600 ml-1" style={{ borderTopWidth: 8, borderBottomWidth: 8, borderLeftWidth: 12 }} />
          </motion.div>
        </div>
        <div className="absolute bottom-2 left-2 right-2 flex items-center gap-2">
          <div className="flex-1 h-1 bg-slate-700 rounded-full"><div className="w-1/3 h-full bg-violet-500 rounded-full" /></div>
          <span className="text-white text-xs">2:45</span>
        </div>
      </div>
    </EffectCard>
  );
}

// Comment Thread
function CommentThreadEffect() {
  return (
    <EffectCard title="Comment Thread" description="Nested comment display" whenToUse="Blog posts, discussions, forums.">
      <div className="space-y-3">
        <div className="flex gap-3">
          <div className="w-8 h-8 rounded-full bg-violet-500 flex-shrink-0" />
          <div className="flex-1 bg-slate-800 rounded-lg p-3">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-white text-sm font-medium">John</span>
              <span className="text-slate-500 text-xs">2h ago</span>
            </div>
            <p className="text-slate-300 text-sm">Great article! Really helpful.</p>
            <div className="flex gap-3 mt-2 text-xs text-slate-500">
              <button className="hover:text-violet-400">Reply</button>
              <button className="hover:text-violet-400">Like</button>
            </div>
          </div>
        </div>
        <div className="flex gap-3 ml-8">
          <div className="w-6 h-6 rounded-full bg-pink-500 flex-shrink-0" />
          <div className="flex-1 bg-slate-800/50 rounded-lg p-2">
            <span className="text-white text-xs font-medium">Author</span>
            <p className="text-slate-400 text-xs">Thanks John!</p>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Checklist
function ChecklistEffect() {
  const [checked, setChecked] = useState([true, false, false]);
  const items = ["Read introduction", "Complete exercises", "Take the quiz"];
  return (
    <EffectCard title="Checklist" description="Interactive task list" whenToUse="Guides, checklists, progress tracking.">
      <div className="space-y-2">
        {items.map((item, i) => (
          <motion.div key={i} onClick={() => setChecked(c => c.map((v, j) => j === i ? !v : v))} whileHover={{ x: 4 }} className={`flex items-center gap-3 p-2 rounded-lg cursor-pointer ${checked[i] ? "bg-green-500/10" : "bg-slate-800"}`}>
            <CheckSquare className={`w-5 h-5 ${checked[i] ? "text-green-400" : "text-slate-600"}`} />
            <span className={`text-sm ${checked[i] ? "text-green-400 line-through" : "text-white"}`}>{item}</span>
          </motion.div>
        ))}
      </div>
    </EffectCard>
  );
}

// Footnotes
function FootnotesEffect() {
  return (
    <EffectCard title="Footnotes" description="Reference annotations" whenToUse="Academic content, citations, references.">
      <div>
        <p className="text-slate-300 text-sm mb-4">
          This is an example paragraph with a footnote reference<sup className="text-violet-400 cursor-pointer hover:underline">[1]</sup> that links to additional information below.
        </p>
        <div className="border-t border-slate-700 pt-3">
          <p className="text-slate-500 text-xs">
            <span className="text-violet-400">[1]</span> Additional reference information or citation goes here.
          </p>
        </div>
      </div>
    </EffectCard>
  );
}

export default function ContentEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <BlogCardEffect />, name: "Blog Post Card" },
    { component: <RichTextEditorEffect />, name: "Rich Text Editor" },
    { component: <QuoteBlockEffect />, name: "Quote Block" },
    { component: <TOCEffect />, name: "Table of Contents" },
    { component: <AuthorCardEffect />, name: "Author Card" },
    { component: <TagCloudEffect />, name: "Tag Cloud" },
    { component: <ReadingProgressEffect />, name: "Reading Progress" },
    { component: <CodeBlockEffect />, name: "Code Block" },
    { component: <CalloutBoxEffect />, name: "Callout Boxes" },
    { component: <RelatedPostsEffect />, name: "Related Posts" },
    { component: <NewsletterWidgetEffect />, name: "Newsletter Widget" },
    { component: <ShareButtonsEffect />, name: "Share Buttons" },
    { component: <BookmarkButtonEffect />, name: "Bookmark Button" },
    { component: <DateTimeEffect />, name: "Date & Time" },
    { component: <ImageCaptionEffect />, name: "Image Caption" },
    { component: <AccordionFAQEffect />, name: "Accordion FAQ" },
    { component: <StepGuideEffect />, name: "Step Guide" },
    { component: <ContentRatingEffect />, name: "Content Rating" },
    { component: <ComparisonTableEffect />, name: "Comparison Table" },
    { component: <VideoEmbedEffect />, name: "Video Embed" },
    { component: <CommentThreadEffect />, name: "Comment Thread" },
    { component: <ChecklistEffect />, name: "Checklist" },
    { component: <FootnotesEffect />, name: "Footnotes" },
  ];

  const filtered = effects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={FileText} title="Content & Publishing" description="25 components for blogs, documentation, and content-rich applications" gradient="#06b6d4, #22c55e" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((effect, i) => <motion.div key={effect.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>{effect.component}</motion.div>)}
        </div>
      </div>
    </div>
  );
}