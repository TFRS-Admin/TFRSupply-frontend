import React, { useState } from "react";
import { motion } from "framer-motion";
import { Search, Sparkles, TrendingUp, FileText, Lightbulb, Copy, Check, Loader2, AlertCircle, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import CategoryHeader from "@/components/effects/CategoryHeader";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

export default function SEOOptimizer() {
  const [activeTab, setActiveTab] = useState("meta");
  const [pageContent, setPageContent] = useState("");
  const [targetKeywords, setTargetKeywords] = useState("");
  const [targetAudience, setTargetAudience] = useState("");
  const [contentTopic, setContentTopic] = useState("");
  const [contentType, setContentType] = useState("landing");
  const [isGenerating, setIsGenerating] = useState(false);
  const [seoResults, setSeoResults] = useState(null);
  const [generatedContent, setGeneratedContent] = useState(null);
  const [keywordResults, setKeywordResults] = useState(null);
  const [competitorUrl, setCompetitorUrl] = useState("");
  const [competitorAnalysis, setCompetitorAnalysis] = useState(null);
  const [copiedField, setCopiedField] = useState(null);

  const generateSEO = async () => {
    if (!pageContent.trim()) {
      alert("Please enter some page content first");
      return;
    }

    setIsGenerating(true);
    setSeoResults(null);

    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an SEO expert. Analyze this page content and generate comprehensive SEO optimization recommendations.

Page Content:
${pageContent}

${targetKeywords ? `Target Keywords: ${targetKeywords}` : ''}

Provide:
1. Meta title (55-60 characters, compelling and keyword-rich)
2. Meta description (150-160 characters, actionable and enticing)
3. 10 relevant keywords for this content
4. SEO score (0-100) with detailed breakdown
5. Optimization tips (5 actionable improvements)
6. Content quality analysis

Return ONLY valid JSON.`,
        response_json_schema: {
          type: "object",
          properties: {
            meta_title: { type: "string" },
            meta_description: { type: "string" },
            keywords: { type: "array", items: { type: "string" } },
            seo_score: { type: "number" },
            score_breakdown: {
              type: "object",
              properties: {
                title_quality: { type: "number" },
                description_quality: { type: "number" },
                keyword_density: { type: "number" },
                readability: { type: "number" },
                structure: { type: "number" }
              }
            },
            optimization_tips: { type: "array", items: { type: "string" } },
            content_analysis: { type: "string" }
          }
        }
      });

      setSeoResults(result);
    } catch (error) {
      alert("SEO generation failed: " + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const generateContent = async () => {
    if (!contentTopic.trim()) {
      alert("Please enter a content topic");
      return;
    }

    setIsGenerating(true);
    setGeneratedContent(null);

    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert content writer and SEO specialist. Generate ${contentType} page content optimized for SEO.

Topic: ${contentTopic}
${targetKeywords ? `Target Keywords: ${targetKeywords}` : ''}
${targetAudience ? `Target Audience: ${targetAudience}` : ''}

Generate:
1. Engaging headline (H1)
2. Compelling subheadline
3. Full content (500-800 words) with natural keyword integration
4. 3-5 section headings (H2)
5. Call-to-action
6. Meta title and description

Make it conversion-focused, easy to read, and SEO-optimized. Return ONLY valid JSON.`,
        response_json_schema: {
          type: "object",
          properties: {
            headline: { type: "string" },
            subheadline: { type: "string" },
            full_content: { type: "string" },
            section_headings: { type: "array", items: { type: "string" } },
            call_to_action: { type: "string" },
            meta_title: { type: "string" },
            meta_description: { type: "string" }
          }
        }
      });

      setGeneratedContent(result);
    } catch (error) {
      alert("Content generation failed: " + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const researchKeywords = async () => {
    if (!targetKeywords.trim()) {
      alert("Please enter seed keywords");
      return;
    }

    setIsGenerating(true);
    setKeywordResults(null);

    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an SEO keyword research expert. Analyze these seed keywords and provide comprehensive keyword research.

Seed Keywords: ${targetKeywords}
${targetAudience ? `Target Audience: ${targetAudience}` : ''}

Provide:
1. 20 long-tail keyword variations
2. Search intent for each (informational, commercial, transactional, navigational)
3. Estimated difficulty (easy, medium, hard)
4. Related questions people ask
5. Content topic clusters

Return ONLY valid JSON.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            long_tail_keywords: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  keyword: { type: "string" },
                  intent: { type: "string" },
                  difficulty: { type: "string" },
                  monthly_searches: { type: "string" }
                }
              }
            },
            related_questions: { type: "array", items: { type: "string" } },
            topic_clusters: { type: "array", items: { type: "string" } }
          }
        }
      });

      setKeywordResults(result);
    } catch (error) {
      alert("Keyword research failed: " + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const analyzeCompetitor = async () => {
    if (!competitorUrl.trim()) {
      alert("Please enter a competitor URL");
      return;
    }

    setIsGenerating(true);
    setCompetitorAnalysis(null);

    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this competitor's SEO strategy: ${competitorUrl}

Research and provide:
1. Their top 10 ranking keywords
2. Content strategy insights
3. Backlink profile overview
4. Technical SEO observations
5. Actionable recommendations to outrank them

Return ONLY valid JSON.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            top_keywords: { type: "array", items: { type: "string" } },
            content_strategy: { type: "string" },
            backlink_insights: { type: "string" },
            technical_seo: { type: "string" },
            recommendations: { type: "array", items: { type: "string" } }
          }
        }
      });

      setCompetitorAnalysis(result);
    } catch (error) {
      alert("Competitor analysis failed: " + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = async (text, field) => {
    await navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const getScoreColor = (score) => {
    if (score >= 80) return "text-green-400";
    if (score >= 60) return "text-yellow-400";
    if (score >= 40) return "text-orange-400";
    return "text-red-400";
  };

  const getScoreBg = (score) => {
    if (score >= 80) return "bg-green-500/20 border-green-500/30";
    if (score >= 60) return "bg-yellow-500/20 border-yellow-500/30";
    if (score >= 40) return "bg-orange-500/20 border-orange-500/30";
    return "bg-red-500/20 border-red-500/30";
  };

  return (
    <div className="min-h-screen pb-20">
      <CategoryHeader
        icon={Search}
        title="AI SEO Optimizer"
        description="Generate meta titles, descriptions, keywords, and get optimization tips"
        gradient="#10b981, #06b6d4"
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Tabs */}
        <div className="flex gap-2 mb-8 border-b border-slate-800">
          {[
            { id: "meta", label: "Meta Tags", icon: FileText },
            { id: "content", label: "AI Content Writer", icon: Sparkles },
            { id: "keywords", label: "Keyword Research", icon: Search },
            { id: "competitor", label: "Competitor Analysis", icon: TrendingUp }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors ${
                activeTab === tab.id
                  ? "border-violet-500 text-white"
                  : "border-transparent text-slate-400 hover:text-white"
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Meta Tags Tab */}
        {activeTab === "meta" && (
          <>
        <Card className="bg-slate-900/50 border-slate-800 mb-8">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <FileText className="w-5 h-5" /> Page Content
            </CardTitle>
            <CardDescription className="text-slate-400">
              Paste your page content or describe what the page is about
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              value={pageContent}
              onChange={(e) => setPageContent(e.target.value)}
              placeholder="Enter your page content here... This could be your homepage copy, blog post, product description, etc."
              className="min-h-[200px] bg-slate-800 border-slate-700 text-white"
            />
            <div>
              <label className="text-slate-400 text-sm mb-2 block">Target Keywords (optional)</label>
              <Input
                value={targetKeywords}
                onChange={(e) => setTargetKeywords(e.target.value)}
                placeholder="e.g., React components, UI effects, web animations"
                className="bg-slate-800 border-slate-700 text-white"
              />
            </div>
            <Button
              onClick={generateSEO}
              disabled={isGenerating || !pageContent.trim()}
              className="w-full bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing with AI...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate SEO Recommendations
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results Section */}
        {seoResults && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* SEO Score */}
            <Card className={`border-2 ${getScoreBg(seoResults.seo_score)}`}>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-white font-bold text-lg mb-1">Overall SEO Score</h3>
                    <p className="text-slate-400 text-sm">Based on industry best practices</p>
                  </div>
                  <div className={`text-6xl font-black ${getScoreColor(seoResults.seo_score)}`}>
                    {seoResults.seo_score}
                  </div>
                </div>

                {/* Score Breakdown */}
                <div className="mt-6 grid grid-cols-2 md:grid-cols-5 gap-3">
                  {Object.entries(seoResults.score_breakdown || {}).map(([key, value]) => (
                    <div key={key} className="text-center p-3 bg-slate-900/50 rounded-lg">
                      <p className={`text-2xl font-bold ${getScoreColor(value)}`}>{value}</p>
                      <p className="text-xs text-slate-500 mt-1 capitalize">{key.replace(/_/g, ' ')}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Meta Tags */}
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2 text-base">
                    <FileText className="w-4 h-4" /> Meta Title
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-slate-950 rounded-lg border border-slate-700">
                    <p className="text-white">{seoResults.meta_title}</p>
                    <p className="text-xs text-slate-500 mt-2">
                      Length: {seoResults.meta_title.length} characters
                      {seoResults.meta_title.length > 60 && (
                        <span className="text-yellow-400 ml-2">⚠️ Too long (max 60)</span>
                      )}
                      {seoResults.meta_title.length < 50 && (
                        <span className="text-cyan-400 ml-2">💡 Could be longer</span>
                      )}
                    </p>
                  </div>
                  <Button
                    onClick={() => copyToClipboard(seoResults.meta_title, 'title')}
                    variant="outline"
                    className="w-full"
                  >
                    {copiedField === 'title' ? (
                      <>
                        <Check className="w-4 h-4 mr-2" /> Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 mr-2" /> Copy Title
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2 text-base">
                    <FileText className="w-4 h-4" /> Meta Description
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-slate-950 rounded-lg border border-slate-700">
                    <p className="text-white text-sm">{seoResults.meta_description}</p>
                    <p className="text-xs text-slate-500 mt-2">
                      Length: {seoResults.meta_description.length} characters
                      {seoResults.meta_description.length > 160 && (
                        <span className="text-yellow-400 ml-2">⚠️ Too long (max 160)</span>
                      )}
                      {seoResults.meta_description.length < 140 && (
                        <span className="text-cyan-400 ml-2">💡 Could be longer</span>
                      )}
                    </p>
                  </div>
                  <Button
                    onClick={() => copyToClipboard(seoResults.meta_description, 'description')}
                    variant="outline"
                    className="w-full"
                  >
                    {copiedField === 'description' ? (
                      <>
                        <Check className="w-4 h-4 mr-2" /> Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 mr-2" /> Copy Description
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Keywords */}
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Search className="w-5 h-5" /> Suggested Keywords
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2 mb-4">
                  {seoResults.keywords?.map((keyword, i) => (
                    <span
                      key={i}
                      className="px-3 py-1.5 rounded-full bg-violet-500/20 text-violet-400 border border-violet-500/30 text-sm"
                    >
                      {keyword}
                    </span>
                  ))}
                </div>
                <Button
                  onClick={() => copyToClipboard(seoResults.keywords.join(', '), 'keywords')}
                  variant="outline"
                  className="w-full"
                >
                  {copiedField === 'keywords' ? (
                    <>
                      <Check className="w-4 h-4 mr-2" /> Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-2" /> Copy All Keywords
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Optimization Tips */}
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-amber-400" /> Optimization Tips
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {seoResults.optimization_tips?.map((tip, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="flex gap-3 p-3 bg-slate-950 rounded-lg border border-slate-800"
                    >
                      <div className="w-6 h-6 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-amber-400 text-xs font-bold">{i + 1}</span>
                      </div>
                      <p className="text-slate-300 text-sm">{tip}</p>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Content Analysis */}
            {seoResults.content_analysis && (
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Eye className="w-5 h-5 text-cyan-400" /> Content Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-300 text-sm leading-relaxed">{seoResults.content_analysis}</p>
                </CardContent>
              </Card>
            )}

            {/* HTML Tags Preview */}
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <FileText className="w-5 h-5 text-violet-400" /> HTML Tags (Copy & Paste)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="p-4 bg-slate-950 border border-slate-700 rounded-lg overflow-x-auto text-xs text-slate-300">
                  <code>{`<title>${seoResults.meta_title}</title>
<meta name="description" content="${seoResults.meta_description}" />
<meta name="keywords" content="${seoResults.keywords?.join(', ')}" />

<!-- Open Graph / Social Media -->
<meta property="og:title" content="${seoResults.meta_title}" />
<meta property="og:description" content="${seoResults.meta_description}" />
<meta property="og:type" content="website" />

<!-- Twitter -->
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="${seoResults.meta_title}" />
<meta name="twitter:description" content="${seoResults.meta_description}" />`}</code>
                </pre>
                <Button
                  onClick={() => copyToClipboard(
                    `<title>${seoResults.meta_title}</title>\n<meta name="description" content="${seoResults.meta_description}" />\n<meta name="keywords" content="${seoResults.keywords?.join(', ')}" />`,
                    'html'
                  )}
                  variant="outline"
                  className="w-full mt-3"
                >
                  {copiedField === 'html' ? (
                    <>
                      <Check className="w-4 h-4 mr-2" /> Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-2" /> Copy HTML Tags
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}
        </>
        )}

        {/* AI Content Writer Tab */}
        {activeTab === "content" && (
          <>
            <Card className="bg-slate-900/50 border-slate-800 mb-8">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5" /> AI Content Writer
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Generate SEO-optimized content with AI
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-slate-400 text-sm mb-2 block">Content Topic</label>
                  <Input
                    value={contentTopic}
                    onChange={(e) => setContentTopic(e.target.value)}
                    placeholder="e.g., Best React UI component libraries 2025"
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-slate-400 text-sm mb-2 block">Target Keywords</label>
                    <Input
                      value={targetKeywords}
                      onChange={(e) => setTargetKeywords(e.target.value)}
                      placeholder="React components, UI library"
                      className="bg-slate-800 border-slate-700 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 text-sm mb-2 block">Target Audience</label>
                    <Input
                      value={targetAudience}
                      onChange={(e) => setTargetAudience(e.target.value)}
                      placeholder="Web developers, designers"
                      className="bg-slate-800 border-slate-700 text-white"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-slate-400 text-sm mb-2 block">Content Type</label>
                  <div className="grid grid-cols-4 gap-2">
                    {["landing", "blog", "product", "about"].map(type => (
                      <button
                        key={type}
                        onClick={() => setContentType(type)}
                        className={`px-4 py-2 rounded-lg text-sm capitalize ${
                          contentType === type
                            ? "bg-violet-500 text-white"
                            : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                </div>
                <Button
                  onClick={generateContent}
                  disabled={isGenerating || !contentTopic.trim()}
                  className="w-full bg-gradient-to-r from-violet-500 to-purple-500"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate Content
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {generatedContent && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                    <CardTitle className="text-white">Generated Content</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-xs text-violet-400 mb-2">Headline (H1)</p>
                      <p className="text-2xl font-bold text-white">{generatedContent.headline}</p>
                    </div>
                    <div>
                      <p className="text-xs text-cyan-400 mb-2">Subheadline</p>
                      <p className="text-lg text-slate-300">{generatedContent.subheadline}</p>
                    </div>
                    <div>
                      <p className="text-xs text-emerald-400 mb-2">Full Content</p>
                      <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 max-h-96 overflow-y-auto">
                        <p className="text-slate-300 text-sm leading-relaxed whitespace-pre-wrap">{generatedContent.full_content}</p>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs text-amber-400 mb-2">Call to Action</p>
                      <p className="text-white font-semibold">{generatedContent.call_to_action}</p>
                    </div>
                    <Button
                      onClick={() => copyToClipboard(generatedContent.full_content, 'content')}
                      variant="outline"
                      className="w-full"
                    >
                      {copiedField === 'content' ? (
                        <>
                          <Check className="w-4 h-4 mr-2" /> Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" /> Copy Full Content
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </>
        )}

        {/* Keyword Research Tab */}
        {activeTab === "keywords" && (
          <>
            <Card className="bg-slate-900/50 border-slate-800 mb-8">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Search className="w-5 h-5" /> Keyword Research
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Discover long-tail keywords and search trends
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-slate-400 text-sm mb-2 block">Seed Keywords</label>
                    <Input
                      value={targetKeywords}
                      onChange={(e) => setTargetKeywords(e.target.value)}
                      placeholder="UI components, web design"
                      className="bg-slate-800 border-slate-700 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 text-sm mb-2 block">Target Audience</label>
                    <Input
                      value={targetAudience}
                      onChange={(e) => setTargetAudience(e.target.value)}
                      placeholder="Developers, designers"
                      className="bg-slate-800 border-slate-700 text-white"
                    />
                  </div>
                </div>
                <Button
                  onClick={researchKeywords}
                  disabled={isGenerating || !targetKeywords.trim()}
                  className="w-full bg-gradient-to-r from-cyan-500 to-blue-500"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Researching...
                    </>
                  ) : (
                    <>
                      <Search className="w-4 h-4 mr-2" />
                      Research Keywords
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {keywordResults && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                    <CardTitle className="text-white">Long-Tail Keywords</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {keywordResults.long_tail_keywords?.map((kw, i) => (
                        <div key={i} className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
                          <div>
                            <p className="text-white font-medium">{kw.keyword}</p>
                            <div className="flex gap-3 mt-1">
                              <span className="text-xs text-slate-500">Intent: <span className="text-cyan-400">{kw.intent}</span></span>
                              <span className="text-xs text-slate-500">Difficulty: <span className={kw.difficulty === 'easy' ? 'text-green-400' : kw.difficulty === 'medium' ? 'text-yellow-400' : 'text-red-400'}>{kw.difficulty}</span></span>
                              <span className="text-xs text-slate-500">Est. Searches: <span className="text-violet-400">{kw.monthly_searches}</span></span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                    <CardTitle className="text-white">Related Questions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {keywordResults.related_questions?.map((q, i) => (
                        <div key={i} className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                          <p className="text-slate-300 text-sm">{q}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </>
        )}

        {/* Competitor Analysis Tab */}
        {activeTab === "competitor" && (
          <>
            <Card className="bg-slate-900/50 border-slate-800 mb-8">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" /> Competitor Analysis
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Analyze competitor SEO strategies
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-slate-400 text-sm mb-2 block">Competitor URL</label>
                  <Input
                    value={competitorUrl}
                    onChange={(e) => setCompetitorUrl(e.target.value)}
                    placeholder="https://competitor.com"
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                </div>
                <Button
                  onClick={analyzeCompetitor}
                  disabled={isGenerating || !competitorUrl.trim()}
                  className="w-full bg-gradient-to-r from-pink-500 to-rose-500"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <TrendingUp className="w-4 h-4 mr-2" />
                      Analyze Competitor
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {competitorAnalysis && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                    <CardTitle className="text-white">Top Keywords</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {competitorAnalysis.top_keywords?.map((kw, i) => (
                        <span key={i} className="px-3 py-1.5 rounded-full bg-pink-500/20 text-pink-400 border border-pink-500/30 text-sm">
                          {kw}
                        </span>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                    <CardTitle className="text-white">Strategy Insights</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-xs text-cyan-400 mb-2">Content Strategy</p>
                      <p className="text-slate-300 text-sm">{competitorAnalysis.content_strategy}</p>
                    </div>
                    <div>
                      <p className="text-xs text-violet-400 mb-2">Backlink Insights</p>
                      <p className="text-slate-300 text-sm">{competitorAnalysis.backlink_insights}</p>
                    </div>
                    <div>
                      <p className="text-xs text-emerald-400 mb-2">Technical SEO</p>
                      <p className="text-slate-300 text-sm">{competitorAnalysis.technical_seo}</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Lightbulb className="w-5 h-5 text-amber-400" /> Recommendations
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {competitorAnalysis.recommendations?.map((rec, i) => (
                        <div key={i} className="flex gap-3 p-3 bg-slate-950 rounded-lg border border-slate-800">
                          <div className="w-6 h-6 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                            <span className="text-amber-400 text-xs font-bold">{i + 1}</span>
                          </div>
                          <p className="text-slate-300 text-sm">{rec}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </>
        )}

        {/* Example Templates */}
        {activeTab === "meta" && !seoResults && !isGenerating && (
          <Card className="bg-gradient-to-r from-violet-500/10 to-cyan-500/10 border-violet-500/30">
            <CardHeader>
              <CardTitle className="text-white">💡 Example Content</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-slate-300 text-sm">
                Paste any of these content types for SEO analysis:
              </p>
              <div className="grid grid-cols-2 gap-2">
                {[
                  "Homepage hero section copy",
                  "Product description",
                  "Blog post content",
                  "Service offering details",
                  "About us page",
                  "Landing page copy"
                ].map((example, i) => (
                  <div key={i} className="px-3 py-2 bg-slate-900/50 rounded-lg text-slate-400 text-xs border border-slate-800">
                    • {example}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}