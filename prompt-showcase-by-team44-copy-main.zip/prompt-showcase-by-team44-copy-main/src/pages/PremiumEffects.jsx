import React from "react";
import { Crown } from "lucide-react";
import CategoryHeader from "@/components/effects/CategoryHeader";
import PremiumStore from "@/components/monetization/PremiumStore";
import { useQuery } from "@tanstack/react-query";

export default function PremiumEffects() {
  return (
    <div className="min-h-screen">
      <CategoryHeader
        icon={Crown}
        title="Premium Store"
        description="Unlock exclusive effects, packs, and features"
        gradient="#8b5cf6, #ec4899"
      />
      <div className="max-w-7xl mx-auto px-4 pb-20">
        <PremiumStore />
      </div>
    </div>
  );
}