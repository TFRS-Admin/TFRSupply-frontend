import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, Send, Bot, User, Mic, Paperclip, Smile, MoreVertical, Phone, Video, X, Minimize2, Maximize2, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import ToggleSwitch from "@/components/ui/toggle-switch";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import CategoryHeader from "@/components/effects/CategoryHeader";
import EffectCard from "@/components/effects/EffectCard";
import SearchFilter from "@/components/effects/SearchFilter";
import { useQuery } from "@tanstack/react-query";

// Chat Bubble Styles
function ChatBubbleStyles() {
  const [style, setStyle] = useState("modern");
  const styles = {
    modern: { user: "bg-violet-500 text-white rounded-2xl rounded-br-sm", bot: "bg-slate-700 text-white rounded-2xl rounded-bl-sm" },
    minimal: { user: "bg-slate-200 text-slate-900 rounded-lg", bot: "bg-slate-100 text-slate-900 rounded-lg" },
    gradient: { user: "bg-gradient-to-r from-violet-500 to-cyan-500 text-white rounded-2xl", bot: "bg-gradient-to-r from-slate-700 to-slate-600 text-white rounded-2xl" },
    bubble: { user: "bg-blue-500 text-white rounded-3xl", bot: "bg-gray-200 text-gray-900 rounded-3xl" }
  };

  return (
    <EffectCard title="Chat Bubble Styles" description="Different message bubble designs" whenToUse="Essential for any messaging interface or chat application." controls={
      <div className="flex gap-2 flex-wrap">
        {Object.keys(styles).map(s => <Button key={s} variant={style === s ? "default" : "outline"} size="sm" onClick={() => setStyle(s)}>{s}</Button>)}
      </div>
    }>
      <div className="w-full p-4 space-y-3">
        <div className="flex justify-end"><div className={`px-4 py-2 max-w-[80%] ${styles[style].user}`}>Hello! How can I help?</div></div>
        <div className="flex justify-start"><div className={`px-4 py-2 max-w-[80%] ${styles[style].bot}`}>Hi there! I'm your assistant.</div></div>
        <div className="flex justify-end"><div className={`px-4 py-2 max-w-[80%] ${styles[style].user}`}>Great, thanks!</div></div>
      </div>
    </EffectCard>
  );
}

// Typing Indicator
function TypingIndicator() {
  const [isTyping, setIsTyping] = useState(true);

  return (
    <EffectCard title="Typing Indicator" description="Animated typing dots" whenToUse="Show when someone is composing a message or AI is generating." controls={
      <div className="flex items-center justify-between">
        <Label className="text-slate-300">Show Typing</Label>
        <ToggleSwitch checked={isTyping} onCheckedChange={setIsTyping} />
      </div>
    }>
      <div className="p-6">
        <AnimatePresence>
          {isTyping && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }} className="flex items-center gap-2 px-4 py-3 bg-slate-700 rounded-2xl rounded-bl-sm w-fit">
              <span className="text-slate-400 text-sm">Assistant is typing</span>
              <div className="flex gap-1">
                {[0, 1, 2].map(i => (
                  <motion.div key={i} className="w-2 h-2 bg-slate-400 rounded-full" animate={{ y: [0, -5, 0] }} transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }} />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

// Message Animations
function MessageAnimations() {
  const [messages, setMessages] = useState([]);
  const [animationType, setAnimationType] = useState("slide");

  const addMessage = () => {
    setMessages(prev => [...prev, { id: Date.now(), text: `Message ${prev.length + 1}`, isUser: prev.length % 2 === 0 }]);
  };

  const animations = {
    slide: { initial: { opacity: 0, x: 50 }, animate: { opacity: 1, x: 0 } },
    scale: { initial: { opacity: 0, scale: 0.8 }, animate: { opacity: 1, scale: 1 } },
    fade: { initial: { opacity: 0 }, animate: { opacity: 1 } },
    bounce: { initial: { opacity: 0, y: 30 }, animate: { opacity: 1, y: 0 }, transition: { type: "spring", bounce: 0.5 } }
  };

  return (
    <EffectCard title="Message Animations" description="Different entry animations" controls={
      <div className="space-y-3">
        <div className="flex gap-2 flex-wrap">
          {Object.keys(animations).map(a => <Button key={a} variant={animationType === a ? "default" : "outline"} size="sm" onClick={() => setAnimationType(a)}>{a}</Button>)}
        </div>
        <Button onClick={addMessage} variant="outline" className="w-full">Add Message</Button>
      </div>
    }>
      <div className="w-full h-[200px] overflow-y-auto p-4 space-y-2">
        <AnimatePresence>
          {messages.map(msg => (
            <motion.div key={msg.id} {...animations[animationType]} className={`flex ${msg.isUser ? "justify-end" : "justify-start"}`}>
              <div className={`px-4 py-2 rounded-2xl max-w-[80%] ${msg.isUser ? "bg-violet-500 text-white" : "bg-slate-700 text-white"}`}>{msg.text}</div>
            </motion.div>
          ))}
        </AnimatePresence>
        {messages.length === 0 && <p className="text-slate-500 text-center text-sm">Click "Add Message" to see animation</p>}
      </div>
    </EffectCard>
  );
}

// Floating Chat Button
function FloatingChatButton() {
  const [isOpen, setIsOpen] = useState(false);
  const [hasNotification, setHasNotification] = useState(true);

  return (
    <EffectCard title="Floating Chat Button" description="FAB with notification badge" whenToUse="Add customer support or help chat to any website." controls={
      <div className="flex items-center justify-between">
        <Label className="text-slate-300">Notification Badge</Label>
        <ToggleSwitch checked={hasNotification} onCheckedChange={setHasNotification} />
      </div>
    }>
      <div className="relative h-[200px] w-full flex items-end justify-end p-6">
        <AnimatePresence>
          {isOpen && (
            <motion.div initial={{ opacity: 0, scale: 0.8, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.8, y: 20 }} className="absolute bottom-20 right-6 w-64 bg-slate-800 rounded-2xl shadow-2xl overflow-hidden">
              <div className="p-4 border-b border-slate-700 flex items-center justify-between">
                <span className="font-semibold text-white">Chat</span>
                <button onClick={() => setIsOpen(false)}><X className="w-4 h-4 text-slate-400" /></button>
              </div>
              <div className="p-4 h-32 flex items-center justify-center text-slate-400 text-sm">Start a conversation</div>
            </motion.div>
          )}
        </AnimatePresence>
        
        <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => { setIsOpen(!isOpen); setHasNotification(false); }} className="relative w-14 h-14 rounded-full bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center shadow-lg">
          <motion.div animate={{ rotate: isOpen ? 90 : 0 }}>
            {isOpen ? <X className="w-6 h-6 text-white" /> : <MessageCircle className="w-6 h-6 text-white" />}
          </motion.div>
          {hasNotification && !isOpen && (
            <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-white text-xs flex items-center justify-center">3</motion.span>
          )}
        </motion.button>
      </div>
    </EffectCard>
  );
}

// Chat Input Designs
function ChatInputDesigns() {
  const [design, setDesign] = useState("modern");
  const [message, setMessage] = useState("");

  const designs = {
    modern: (
      <div className="flex items-center gap-2 p-2 bg-slate-800 rounded-full">
        <button className="p-2 hover:bg-slate-700 rounded-full"><Paperclip className="w-5 h-5 text-slate-400" /></button>
        <Input value={message} onChange={e => setMessage(e.target.value)} placeholder="Type a message..." className="flex-1 bg-transparent border-0 focus-visible:ring-0 text-white" />
        <button className="p-2 hover:bg-slate-700 rounded-full"><Smile className="w-5 h-5 text-slate-400" /></button>
        <button className="p-2 bg-violet-500 hover:bg-violet-600 rounded-full"><Send className="w-5 h-5 text-white" /></button>
      </div>
    ),
    minimal: (
      <div className="flex items-center gap-2">
        <Input value={message} onChange={e => setMessage(e.target.value)} placeholder="Message..." className="flex-1 bg-slate-800 border-slate-700 text-white rounded-lg" />
        <Button size="icon" className="bg-violet-500"><Send className="w-4 h-4" /></Button>
      </div>
    ),
    expanded: (
      <div className="space-y-2">
        <div className="flex gap-2">
          <button className="p-2 bg-slate-800 rounded-lg hover:bg-slate-700"><Paperclip className="w-5 h-5 text-slate-400" /></button>
          <button className="p-2 bg-slate-800 rounded-lg hover:bg-slate-700"><Mic className="w-5 h-5 text-slate-400" /></button>
          <button className="p-2 bg-slate-800 rounded-lg hover:bg-slate-700"><Smile className="w-5 h-5 text-slate-400" /></button>
        </div>
        <div className="flex gap-2">
          <Input value={message} onChange={e => setMessage(e.target.value)} placeholder="Type here..." className="flex-1 bg-slate-800 border-slate-700 text-white" />
          <Button className="bg-gradient-to-r from-violet-500 to-cyan-500">Send</Button>
        </div>
      </div>
    )
  };

  return (
    <EffectCard title="Chat Input Designs" description="Various input field layouts" controls={
      <div className="flex gap-2 flex-wrap">
        {Object.keys(designs).map(d => <Button key={d} variant={design === d ? "default" : "outline"} size="sm" onClick={() => setDesign(d)}>{d}</Button>)}
      </div>
    }>
      <div className="w-full p-4">{designs[design]}</div>
    </EffectCard>
  );
}

// Avatar with Status
function AvatarWithStatus() {
  const [status, setStatus] = useState("online");
  const statusColors = { online: "bg-green-500", away: "bg-yellow-500", busy: "bg-red-500", offline: "bg-slate-500" };

  return (
    <EffectCard title="Avatar with Status" description="User presence indicators" whenToUse="Show online/offline status in team apps or social platforms." controls={
      <div className="flex gap-2 flex-wrap">
        {Object.keys(statusColors).map(s => <Button key={s} variant={status === s ? "default" : "outline"} size="sm" onClick={() => setStatus(s)}>{s}</Button>)}
      </div>
    }>
      <div className="flex gap-6 items-center p-6">
        {["sm", "md", "lg"].map((size, i) => (
          <div key={size} className="relative">
            <Avatar className={`${size === "sm" ? "w-10 h-10" : size === "md" ? "w-14 h-14" : "w-20 h-20"}`}>
              <AvatarImage src={`https://images.unsplash.com/photo-${1535713875002 + i}-d1d0cf377fde?w=100&h=100&fit=crop`} />
              <AvatarFallback>U{i+1}</AvatarFallback>
            </Avatar>
            <motion.span animate={{ scale: status === "online" ? [1, 1.2, 1] : 1 }} transition={{ duration: 2, repeat: Infinity }} className={`absolute bottom-0 right-0 ${size === "sm" ? "w-3 h-3" : size === "md" ? "w-4 h-4" : "w-5 h-5"} ${statusColors[status]} rounded-full border-2 border-slate-900`} />
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Chat Header
function ChatHeaderDesigns() {
  const [variant, setVariant] = useState("standard");

  const headers = {
    standard: (
      <div className="flex items-center justify-between p-4 bg-slate-800 border-b border-slate-700">
        <div className="flex items-center gap-3">
          <Avatar><AvatarImage src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100" /><AvatarFallback>AI</AvatarFallback></Avatar>
          <div>
            <p className="font-semibold text-white">AI Assistant</p>
            <p className="text-xs text-green-400">Online</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button className="p-2 hover:bg-slate-700 rounded-lg"><Phone className="w-5 h-5 text-slate-400" /></button>
          <button className="p-2 hover:bg-slate-700 rounded-lg"><Video className="w-5 h-5 text-slate-400" /></button>
          <button className="p-2 hover:bg-slate-700 rounded-lg"><MoreVertical className="w-5 h-5 text-slate-400" /></button>
        </div>
      </div>
    ),
    minimal: (
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center gap-2">
          <Bot className="w-6 h-6 text-violet-400" />
          <span className="font-medium text-white">Assistant</span>
        </div>
        <button className="p-1 hover:bg-slate-800 rounded"><X className="w-5 h-5 text-slate-400" /></button>
      </div>
    ),
    gradient: (
      <div className="flex items-center justify-between p-4 bg-gradient-to-r from-violet-600 to-cyan-600">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center"><Bot className="w-6 h-6 text-white" /></div>
          <div>
            <p className="font-semibold text-white">Support Bot</p>
            <p className="text-xs text-white/70">Always here to help</p>
          </div>
        </div>
        <div className="flex gap-1">
          <button className="p-2 hover:bg-white/10 rounded-lg"><Minimize2 className="w-5 h-5 text-white" /></button>
          <button className="p-2 hover:bg-white/10 rounded-lg"><X className="w-5 h-5 text-white" /></button>
        </div>
      </div>
    )
  };

  return (
    <EffectCard title="Chat Header Designs" description="Various header layouts" controls={
      <div className="flex gap-2 flex-wrap">
        {Object.keys(headers).map(h => <Button key={h} variant={variant === h ? "default" : "outline"} size="sm" onClick={() => setVariant(h)}>{h}</Button>)}
      </div>
    }>
      <div className="w-full">{headers[variant]}</div>
    </EffectCard>
  );
}

// Read Receipts
function ReadReceipts() {
  const [status, setStatus] = useState("read");
  const statuses = { sent: "✓", delivered: "✓✓", read: "✓✓" };
  const colors = { sent: "text-slate-400", delivered: "text-slate-400", read: "text-blue-400" };

  return (
    <EffectCard title="Read Receipts" description="Message delivery status" controls={
      <div className="flex gap-2">
        {Object.keys(statuses).map(s => <Button key={s} variant={status === s ? "default" : "outline"} size="sm" onClick={() => setStatus(s)}>{s}</Button>)}
      </div>
    }>
      <div className="w-full p-4 space-y-3">
        {["Hey!", "How's it going?", "Let me know!"].map((msg, i) => (
          <div key={i} className="flex justify-end">
            <div className="bg-violet-500 text-white px-4 py-2 rounded-2xl rounded-br-sm">
              <p>{msg}</p>
              <div className="flex items-center justify-end gap-1 mt-1">
                <span className="text-xs text-white/60">12:0{i}</span>
                <span className={`text-xs ${colors[status]}`}>{statuses[status]}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </EffectCard>
  );
}

// Quick Replies
function QuickReplies() {
  const suggestions = ["Yes, please!", "No thanks", "Tell me more", "Schedule a call", "Send docs"];

  return (
    <EffectCard title="Quick Replies" description="Suggested response chips" whenToUse="Speed up conversations in chatbots or customer support.">
      <div className="w-full p-4 space-y-4">
        <div className="flex justify-start">
          <div className="bg-slate-700 text-white px-4 py-2 rounded-2xl rounded-bl-sm">Would you like me to help with that?</div>
        </div>
        <div className="flex flex-wrap gap-2">
          {suggestions.map((s, i) => (
            <motion.button key={i} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="px-4 py-2 rounded-full border border-violet-500 text-violet-400 hover:bg-violet-500/20 text-sm transition-colors">{s}</motion.button>
          ))}
        </div>
      </div>
    </EffectCard>
  );
}

// Chat Window Positions
function ChatWindowPositions() {
  const [position, setPosition] = useState("bottom-right");
  const positions = { "bottom-right": "bottom-4 right-4", "bottom-left": "bottom-4 left-4", "center": "top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" };

  return (
    <EffectCard title="Window Positions" description="Chat widget placement" controls={
      <div className="flex gap-2 flex-wrap">
        {Object.keys(positions).map(p => <Button key={p} variant={position === p ? "default" : "outline"} size="sm" onClick={() => setPosition(p)}>{p.replace("-", " ")}</Button>)}
      </div>
    }>
      <div className="relative w-full h-[200px] bg-slate-800/50 rounded-xl">
        <motion.div layout className={`absolute ${positions[position]} w-48 h-32 bg-slate-900 rounded-xl border border-slate-700 shadow-xl overflow-hidden`}>
          <div className="p-2 border-b border-slate-700 bg-gradient-to-r from-violet-500 to-cyan-500">
            <span className="text-white text-sm font-medium">Chat</span>
          </div>
          <div className="p-2">
            <p className="text-slate-400 text-xs">Widget preview</p>
          </div>
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Message Reactions
function MessageReactions() {
  const [reactions, setReactions] = useState({});
  const emojis = ["👍", "❤️", "😂", "😮", "😢", "🎉"];

  const toggleReaction = (emoji) => {
    setReactions(prev => ({ ...prev, [emoji]: !prev[emoji] }));
  };

  return (
    <EffectCard title="Message Reactions" description="Emoji reaction buttons">
      <div className="w-full p-4 space-y-4">
        <div className="flex justify-start">
          <div className="relative">
            <div className="bg-slate-700 text-white px-4 py-2 rounded-2xl rounded-bl-sm">Check out this new feature!</div>
            <div className="flex gap-1 mt-2">
              {emojis.map(emoji => (
                <motion.button key={emoji} whileHover={{ scale: 1.2 }} whileTap={{ scale: 0.9 }} onClick={() => toggleReaction(emoji)} className={`w-8 h-8 rounded-full flex items-center justify-center text-sm transition-colors ${reactions[emoji] ? "bg-violet-500/30 ring-2 ring-violet-500" : "bg-slate-800 hover:bg-slate-700"}`}>{emoji}</motion.button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Voice Message UI
function VoiceMessageUI() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setProgress(p => { if (p >= 100) { setIsPlaying(false); return 0; } return p + 2; });
      }, 50);
      return () => clearInterval(interval);
    }
  }, [isPlaying]);

  return (
    <EffectCard title="Voice Message" description="Audio message player UI" whenToUse="For messaging apps that support voice notes.">
      <div className="w-full p-4">
        <div className="flex items-center gap-3 bg-slate-700 p-3 rounded-2xl rounded-bl-sm max-w-xs">
          <button onClick={() => setIsPlaying(!isPlaying)} className="w-10 h-10 rounded-full bg-violet-500 flex items-center justify-center">
            {isPlaying ? <div className="w-3 h-3 bg-white rounded-sm" /> : <div className="w-0 h-0 border-t-[6px] border-t-transparent border-l-[10px] border-l-white border-b-[6px] border-b-transparent ml-1" />}
          </button>
          <div className="flex-1">
            <div className="flex gap-[2px] items-center h-8">
              {Array.from({ length: 30 }).map((_, i) => (
                <motion.div key={i} className={`w-1 rounded-full ${i < (progress / 100) * 30 ? "bg-violet-400" : "bg-slate-500"}`} style={{ height: `${10 + Math.sin(i * 0.5) * 15 + Math.random() * 10}px` }} />
              ))}
            </div>
            <p className="text-xs text-slate-400 mt-1">0:{Math.floor(progress / 100 * 15).toString().padStart(2, '0')} / 0:15</p>
          </div>
        </div>
      </div>
    </EffectCard>
  );
}

// Chat Bot Welcome
function ChatBotWelcome() {
  return (
    <EffectCard title="Bot Welcome Screen" description="Initial chatbot greeting">
      <div className="w-full p-6 text-center">
        <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", bounce: 0.5 }} className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center">
          <Bot className="w-10 h-10 text-white" />
        </motion.div>
        <motion.h3 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="text-xl font-bold text-white mb-2">Hi there! 👋</motion.h3>
        <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="text-slate-400 mb-4">I'm your AI assistant. How can I help you today?</motion.p>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="flex flex-col gap-2">
          {["Ask a question", "Get support", "Learn more"].map((opt, i) => (
            <button key={i} className="px-4 py-2 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 transition-colors">{opt}</button>
          ))}
        </motion.div>
      </div>
    </EffectCard>
  );
}

// Minimized Chat
function MinimizedChat() {
  const [isMinimized, setIsMinimized] = useState(true);

  return (
    <EffectCard title="Minimized Chat" description="Collapsed chat state">
      <div className="relative h-[200px] w-full flex items-end justify-end p-4">
        <AnimatePresence mode="wait">
          {isMinimized ? (
            <motion.button key="minimized" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }} onClick={() => setIsMinimized(false)} className="flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-violet-500 to-cyan-500 rounded-full shadow-lg">
              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center"><Bot className="w-5 h-5 text-white" /></div>
              <span className="text-white font-medium">Chat with us</span>
              <ChevronDown className="w-5 h-5 text-white" />
            </motion.button>
          ) : (
            <motion.div key="expanded" initial={{ opacity: 0, y: 20, scale: 0.9 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 20, scale: 0.9 }} className="w-72 bg-slate-900 rounded-2xl shadow-2xl overflow-hidden border border-slate-700">
              <div className="p-4 border-b border-slate-700 flex items-center justify-between bg-gradient-to-r from-violet-500 to-cyan-500">
                <span className="font-semibold text-white">Support Chat</span>
                <button onClick={() => setIsMinimized(true)}><Minimize2 className="w-5 h-5 text-white" /></button>
              </div>
              <div className="h-24 p-4"><p className="text-slate-400 text-sm">Chat window content...</p></div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </EffectCard>
  );
}

export default function ChatEffects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const effects = [
    { component: <ChatBubbleStyles />, name: "Bubble Styles" },
    { component: <TypingIndicator />, name: "Typing Indicator" },
    { component: <MessageAnimations />, name: "Message Animations" },
    { component: <FloatingChatButton />, name: "Floating Button" },
    { component: <ChatInputDesigns />, name: "Input Designs" },
    { component: <AvatarWithStatus />, name: "Avatar Status" },
    { component: <ChatHeaderDesigns />, name: "Header Designs" },
    { component: <ReadReceipts />, name: "Read Receipts" },
    { component: <QuickReplies />, name: "Quick Replies" },
    { component: <ChatWindowPositions />, name: "Window Positions" },
    { component: <MessageReactions />, name: "Reactions" },
    { component: <VoiceMessageUI />, name: "Voice Message" },
    { component: <ChatBotWelcome />, name: "Bot Welcome" },
    { component: <MinimizedChat />, name: "Minimized Chat" },
  ];

  const filtered = effects.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen">
      <CategoryHeader icon={MessageCircle} title="Chat Components" description="Chat bubbles, bots, messaging UI elements and patterns" gradient="#3b82f6" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <SearchFilter searchQuery={searchQuery} setSearchQuery={setSearchQuery} activeCategory={activeCategory} setActiveCategory={setActiveCategory} resultCount={filtered.length} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((effect, i) => <div key={i}>{effect.component}</div>)}
        </div>
      </div>
    </div>
  );
}