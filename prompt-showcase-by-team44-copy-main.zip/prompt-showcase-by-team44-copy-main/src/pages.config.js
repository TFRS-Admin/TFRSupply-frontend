import AIAgentEffects from './pages/AIAgentEffects';
import AbstractAnimations from './pages/AbstractAnimations';
import AdminDashboard from './pages/AdminDashboard';
import AdminInitializerPreview from './pages/AdminInitializerPreview';
import AdminLayouts from './pages/AdminLayouts';
import AudioEffects from './pages/AudioEffects';
import ButtonEffects from './pages/ButtonEffects';
import ButtonShowcase from './pages/ButtonShowcase';
import CartCheckout from './pages/CartCheckout';
import CharacterEffects from './pages/CharacterEffects';
import ChatEffects from './pages/ChatEffects';
import ColorSchemes from './pages/ColorSchemes';
import CommunicationEffects from './pages/CommunicationEffects';
import ContentEffects from './pages/ContentEffects';
import CreativeEffects from './pages/CreativeEffects';
import DesignTerminology from './pages/DesignTerminology';
import Discover from './pages/Discover';
import DividerEffects from './pages/DividerEffects';
import DonationComponents from './pages/DonationComponents';
import DonationGateway from './pages/DonationGateway';
import EcommerceEffects from './pages/EcommerceEffects';
import EffectBuilder from './pages/EffectBuilder';
import Explore from './pages/Explore';
import Favorites from './pages/Favorites';
import GamingEffects from './pages/GamingEffects';
import Home from './pages/Home';
import IconEffects from './pages/IconEffects';
import LoadingSpinners from './pages/LoadingSpinners';
import MarketingEffects from './pages/MarketingEffects';
import MenuEffects from './pages/MenuEffects';
import MyEffects from './pages/MyEffects';
import NavigationEffects from './pages/NavigationEffects';
import PageLayouts from './pages/PageLayouts';
import PageTemplates from './pages/PageTemplates';
import PixelAssets from './pages/PixelAssets';
import PremiumEffects from './pages/PremiumEffects';
import ProductivityEffects from './pages/ProductivityEffects';
import SEOOptimizer from './pages/SEOOptimizer';
import SeedAppHistory from './pages/SeedAppHistory';
import SocialEffects from './pages/SocialEffects';
import Suggestions from './pages/Suggestions';
import TeachableMode from './pages/TeachableMode';
import TextEffects from './pages/TextEffects';
import Transitions from './pages/Transitions';
import Tutorials from './pages/Tutorials';
import VideoEffects from './pages/VideoEffects';
import VideoPlayerCustomization from './pages/VideoPlayerCustomization';
import VisualEffects from './pages/VisualEffects';
import __Layout from './Layout.jsx';


export const PAGES = {
    "AIAgentEffects": AIAgentEffects,
    "AbstractAnimations": AbstractAnimations,
    "AdminDashboard": AdminDashboard,
    "AdminInitializerPreview": AdminInitializerPreview,
    "AdminLayouts": AdminLayouts,
    "AudioEffects": AudioEffects,
    "ButtonEffects": ButtonEffects,
    "ButtonShowcase": ButtonShowcase,
    "CartCheckout": CartCheckout,
    "CharacterEffects": CharacterEffects,
    "ChatEffects": ChatEffects,
    "ColorSchemes": ColorSchemes,
    "CommunicationEffects": CommunicationEffects,
    "ContentEffects": ContentEffects,
    "CreativeEffects": CreativeEffects,
    "DesignTerminology": DesignTerminology,
    "Discover": Discover,
    "DividerEffects": DividerEffects,
    "DonationComponents": DonationComponents,
    "DonationGateway": DonationGateway,
    "EcommerceEffects": EcommerceEffects,
    "EffectBuilder": EffectBuilder,
    "Explore": Explore,
    "Favorites": Favorites,
    "GamingEffects": GamingEffects,
    "Home": Home,
    "IconEffects": IconEffects,
    "LoadingSpinners": LoadingSpinners,
    "MarketingEffects": MarketingEffects,
    "MenuEffects": MenuEffects,
    "MyEffects": MyEffects,
    "NavigationEffects": NavigationEffects,
    "PageLayouts": PageLayouts,
    "PageTemplates": PageTemplates,
    "PixelAssets": PixelAssets,
    "PremiumEffects": PremiumEffects,
    "ProductivityEffects": ProductivityEffects,
    "SEOOptimizer": SEOOptimizer,
    "SeedAppHistory": SeedAppHistory,
    "SocialEffects": SocialEffects,
    "Suggestions": Suggestions,
    "TeachableMode": TeachableMode,
    "TextEffects": TextEffects,
    "Transitions": Transitions,
    "Tutorials": Tutorials,
    "VideoEffects": VideoEffects,
    "VideoPlayerCustomization": VideoPlayerCustomization,
    "VisualEffects": VisualEffects,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};