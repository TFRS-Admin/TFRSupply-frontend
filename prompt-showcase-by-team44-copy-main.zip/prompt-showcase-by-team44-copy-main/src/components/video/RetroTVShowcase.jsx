import React, { useState } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

export default function RetroTVShowcase() {
  const [isPlaying, setIsPlaying] = useState(false);

  const { data: settings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || {};
    },
    initialData: {}
  });

  const videoConfig = settings?.infomercial_video || {};
  
  if (!videoConfig.enabled || !videoConfig.youtube_url) return null;

  // Extract YouTube video ID
  const getYouTubeId = (url) => {
    const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/);
    return match ? match[1] : null;
  };

  const videoId = getYouTubeId(videoConfig.youtube_url);
  if (!videoId) return null;

  return (
    <section className="relative py-16 overflow-hidden">
      {/* 90s Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(45deg, #ff00ff 0px, #ff00ff 10px, transparent 10px, transparent 20px, #00ffff 20px, #00ffff 30px, transparent 30px, transparent 40px)`,
          animation: 'scroll 20s linear infinite'
        }} />
      </div>

      <style>{`
        @keyframes scroll {
          from { background-position: 0 0; }
          to { background-position: 100px 100px; }
        }
        @keyframes flicker {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.95; }
        }
        @keyframes scanline {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100%); }
        }
        @keyframes vhsNoise {
          0%, 100% { opacity: 0.05; }
          50% { opacity: 0.15; }
        }
        @keyframes priceFlash {
          0%, 100% { transform: scale(1); color: #fbbf24; }
          50% { transform: scale(1.1); color: #ef4444; }
        }
      `}</style>

      <div className="relative max-w-6xl mx-auto px-4">
        {/* Title */}
        <motion.div 
          initial={{ y: -30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-center mb-8"
        >
          <h2 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-cyan-400 mb-3" style={{
            textShadow: '3px 3px 0 #000, -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000'
          }}>
            {videoConfig.title || "📺 SEE IT IN ACTION! 📺"}
          </h2>
          <div className="flex items-center justify-center gap-4">
            <div className="animate-bounce text-3xl">👈</div>
            <p className="text-xl text-yellow-300 font-bold animate-pulse">AS SEEN ON TV!</p>
            <div className="animate-bounce text-3xl">👉</div>
          </div>
        </motion.div>

        {/* Retro TV Container */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="relative mx-auto"
          style={{ maxWidth: '800px' }}
        >
          {/* TV Frame */}
          <div className="relative bg-gradient-to-br from-orange-900 via-amber-800 to-yellow-900 rounded-3xl p-8 shadow-2xl border-8 border-amber-950">
            {/* TV Antennas */}
            <div className="absolute -top-32 left-1/2 -translate-x-1/2 flex gap-4">
              <motion.div 
                animate={{ rotate: [-5, 5, -5] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="w-2 h-32 bg-gradient-to-t from-slate-600 to-slate-400 rounded-full origin-bottom"
                style={{ transform: 'rotate(-20deg)' }}
              />
              <motion.div 
                animate={{ rotate: [5, -5, 5] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="w-2 h-32 bg-gradient-to-t from-slate-600 to-slate-400 rounded-full origin-bottom"
                style={{ transform: 'rotate(20deg)' }}
              />
            </div>

            {/* TV Screen Bezel */}
            <div className="relative bg-black rounded-2xl p-4">
              {/* Screen Glass Reflection */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/20 via-transparent to-transparent pointer-events-none" />
              
              {/* Video Container */}
              <div className="relative aspect-video bg-black rounded-xl overflow-hidden">
                {/* VHS Noise Overlay */}
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/5 to-transparent animate-[vhsNoise_0.3s_infinite] pointer-events-none z-10" />
                
                {/* Scanlines */}
                <div className="absolute inset-0 pointer-events-none z-10" style={{
                  backgroundImage: 'repeating-linear-gradient(0deg, rgba(0,0,0,0.15) 0px, rgba(0,0,0,0.15) 1px, transparent 1px, transparent 2px)',
                  animation: 'flicker 0.2s infinite'
                }} />
                
                {/* Moving Scanline */}
                <div className="absolute inset-0 pointer-events-none z-10">
                  <div className="absolute w-full h-1 bg-white/10 blur-sm" style={{ animation: 'scanline 4s linear infinite' }} />
                </div>

                {/* YouTube Embed */}
                <iframe
                  className="absolute inset-0 w-full h-full"
                  src={`https://www.youtube.com/embed/${videoId}?autoplay=0&rel=0`}
                  title="Product Showcase"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />

                {/* CRT Curve Effect */}
                <div className="absolute inset-0 rounded-xl border-4 border-black/30 pointer-events-none z-10" style={{
                  boxShadow: 'inset 0 0 60px rgba(0,0,0,0.5)'
                }} />
              </div>
            </div>

            {/* TV Knobs */}
            <div className="absolute top-8 right-4 space-y-3">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-600 to-amber-800 border-4 border-amber-950 shadow-lg flex items-center justify-center">
                <div className="w-1 h-4 bg-white/50 rounded-full" />
              </div>
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-600 to-amber-800 border-4 border-amber-950 shadow-lg flex items-center justify-center">
                <div className="w-1 h-4 bg-white/50 rounded-full" />
              </div>
            </div>

            {/* Brand Badge */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-red-600 to-red-800 rounded-full border-2 border-yellow-400 shadow-xl">
              <p className="text-white font-bold text-sm tracking-wider">RETRO-VISION™</p>
            </div>
          </div>

          {/* Call to Action Starburst */}
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="absolute -top-8 -right-8 w-32 h-32 flex items-center justify-center"
          >
            <div className="relative">
              {[...Array(8)].map((_, i) => (
                <div
                  key={i}
                  className="absolute w-32 h-1 bg-gradient-to-r from-yellow-400 to-red-500"
                  style={{
                    transform: `rotate(${i * 45}deg)`,
                    transformOrigin: 'center'
                  }}
                />
              ))}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-red-600 rounded-full w-20 h-20 flex items-center justify-center border-4 border-yellow-400 shadow-2xl">
                  <p className="text-white font-black text-xs text-center leading-tight" style={{ animation: 'priceFlash 1s infinite' }}>
                    FREE!<br/>NOW!
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Bottom Testimonial Banner */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-6 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 rounded-xl p-4 text-center shadow-xl border-4 border-white"
          >
            <p className="text-white font-bold text-lg md:text-xl" style={{
              textShadow: '2px 2px 4px rgba(0,0,0,0.8)'
            }}>
              ⭐⭐⭐⭐⭐ "This Changed My Life!" - Actual User
            </p>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}