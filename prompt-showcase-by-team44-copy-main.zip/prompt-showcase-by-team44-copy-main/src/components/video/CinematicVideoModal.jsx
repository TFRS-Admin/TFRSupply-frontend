import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Volume2, VolumeX, Maximize2, Minimize2, Sparkles } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function CinematicVideoModal({ isOpen, onClose, videoUrl, logoUrl, customOverlayImageUrl, overlayEnabled = true }) {
  const [showIntro, setShowIntro] = useState(true);
  const [showVideo, setShowVideo] = useState(false);
  const [showOverlay, setShowOverlay] = useState(false);

  // Extract video ID
  const videoId = videoUrl ? (videoUrl.includes('v=') ? videoUrl.split('v=')[1]?.split('&')[0] : videoUrl.split('/').pop()) : '';

  useEffect(() => {
    if (isOpen) {
      setShowIntro(true);
      setShowVideo(false);
      // Show overlay only if enabled AND custom image exists
      setShowOverlay(overlayEnabled && !!customOverlayImageUrl);
      
      // Sequence: Intro -> Video (with or without overlay)
      const timer = setTimeout(() => {
        setShowIntro(false);
        setTimeout(() => {
          setShowVideo(true);
          // If overlay is disabled, skip directly to video
          if (!overlayEnabled || !customOverlayImageUrl) {
            setShowOverlay(false);
          }
        }, 500);
      }, 2500); // 2.5s intro duration

      return () => clearTimeout(timer);
    }
  }, [isOpen, customOverlayImageUrl, overlayEnabled]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-xl"
        >
          {/* Close Button */}
          <button 
            onClick={onClose}
            className="absolute top-6 right-6 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors z-[110] group"
          >
            <X className="w-6 h-6 group-hover:rotate-90 transition-transform" />
          </button>

          {/* Intro Sequence */}
          <AnimatePresence>
            {showIntro && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.5, filter: "blur(20px)" }}
                transition={{ duration: 0.8 }}
                className="absolute inset-0 flex flex-col items-center justify-center z-[105]"
              >
                {logoUrl ? (
                  <motion.img 
                    src={logoUrl} 
                    alt="Logo" 
                    className="w-32 h-32 md:w-48 md:h-48 object-contain mb-8 drop-shadow-[0_0_30px_rgba(139,92,246,0.5)]"
                    animate={{ 
                      filter: ["brightness(1)", "brightness(1.5)", "brightness(1)"],
                      scale: [1, 1.05, 1]
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                ) : (
                  <Sparkles className="w-32 h-32 text-violet-500 mb-8" />
                )}
                <motion.h2 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="text-2xl md:text-4xl font-bold text-white tracking-widest uppercase"
                >
                  Feature Presentation
                </motion.h2>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Video Player */}
          {showVideo && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative w-full max-w-6xl aspect-video mx-4 shadow-[0_0_100px_rgba(139,92,246,0.2)] rounded-2xl overflow-hidden border border-white/10 bg-black group/player"
            >
              {showOverlay && customOverlayImageUrl ? (
                <div 
                  className="absolute inset-0 z-20 cursor-pointer overflow-hidden bg-black"
                  onClick={() => setShowOverlay(false)}
                >
                  <style>{`
                    @keyframes glitch-anim-1 {
                      0% { clip-path: inset(20% 0 80% 0); transform: translate(-2px, 1px); }
                      20% { clip-path: inset(60% 0 10% 0); transform: translate(2px, -1px); }
                      40% { clip-path: inset(40% 0 50% 0); transform: translate(-2px, 2px); }
                      60% { clip-path: inset(80% 0 5% 0); transform: translate(2px, -2px); }
                      80% { clip-path: inset(10% 0 70% 0); transform: translate(-1px, 1px); }
                      100% { clip-path: inset(30% 0 50% 0); transform: translate(1px, -1px); }
                    }
                    @keyframes glitch-anim-2 {
                      0% { clip-path: inset(10% 0 60% 0); transform: translate(2px, -1px); }
                      20% { clip-path: inset(80% 0 5% 0); transform: translate(-2px, 2px); }
                      40% { clip-path: inset(30% 0 20% 0); transform: translate(2px, 1px); }
                      60% { clip-path: inset(10% 0 80% 0); transform: translate(-1px, -2px); }
                      80% { clip-path: inset(50% 0 30% 0); transform: translate(1px, 2px); }
                      100% { clip-path: inset(20% 0 70% 0); transform: translate(-2px, -1px); }
                    }
                    .glitch-overlay-img {
                      position: absolute;
                      top: 0;
                      left: 0;
                      width: 100%;
                      height: 100%;
                      object-fit: cover;
                    }
                    .glitch-layer {
                      position: absolute;
                      top: 0;
                      left: 0;
                      width: 100%;
                      height: 100%;
                      background-image: url('${customOverlayImageUrl}');
                      background-size: cover;
                      background-position: center;
                      opacity: 0.5;
                      mix-blend-mode: hard-light;
                    }
                    .group\\/player:hover .glitch-layer-1 {
                      animation: glitch-anim-1 2.5s infinite linear alternate-reverse;
                    }
                    .group\\/player:hover .glitch-layer-2 {
                      animation: glitch-anim-2 2s infinite linear alternate-reverse;
                    }
                    .play-button-pulse {
                      animation: pulse-ring 2s cubic-bezier(0.215, 0.61, 0.355, 1) infinite;
                    }
                    @keyframes pulse-ring {
                      0% { transform: scale(0.8); box-shadow: 0 0 0 0 rgba(255, 255, 255, 0.7); }
                      70% { transform: scale(1); box-shadow: 0 0 0 20px rgba(255, 255, 255, 0); }
                      100% { transform: scale(0.8); box-shadow: 0 0 0 0 rgba(255, 255, 255, 0); }
                    }
                  `}</style>
                  
                  {/* Base Image */}
                  <img src={customOverlayImageUrl} alt="Play" className="w-full h-full object-cover opacity-80 group-hover/player:opacity-40 transition-opacity duration-300" />
                  
                  {/* Glitch Layers (Visible on Hover) */}
                  <div className="glitch-layer glitch-layer-1 hidden group-hover/player:block text-cyan-500"></div>
                  <div className="glitch-layer glitch-layer-2 hidden group-hover/player:block text-rose-500"></div>
                  
                  {/* Play Button Icon */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-20 h-20 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/30 group-hover/player:bg-white/20 transition-all play-button-pulse">
                      <div className="w-0 h-0 border-t-[12px] border-t-transparent border-l-[24px] border-l-white border-b-[12px] border-b-transparent ml-2"></div>
                    </div>
                  </div>
                  
                  {/* Overlay Text */}
                  <div className="absolute bottom-8 left-0 right-0 text-center">
                     <p className="text-white font-mono text-sm tracking-widest uppercase opacity-70 group-hover/player:opacity-100 transition-opacity">Click to Start</p>
                  </div>
                </div>
              ) : (
                <iframe
                  width="100%"
                  height="100%"
                  src={`https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1&iv_load_policy=3`}
                  title="Cinematic Walkthrough"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="w-full h-full"
                />
              )}
              
              {/* Theater Mode Hint */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 3, duration: 1 }}
                className="absolute -bottom-16 left-0 right-0 text-center"
              >
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-md">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-violet-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-violet-500"></span>
                  </span>
                  <span className="text-xs text-slate-400 font-medium tracking-wide">
                    Psst... stay until the very end for a secret surprise 🤫
                  </span>
                </div>
              </motion.div>
            </motion.div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}