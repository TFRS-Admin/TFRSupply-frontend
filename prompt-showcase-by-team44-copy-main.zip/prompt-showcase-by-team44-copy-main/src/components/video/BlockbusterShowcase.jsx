import React, { useState } from "react";
import { motion } from "framer-motion";
import { Play, Star } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

export default function BlockbusterShowcase() {
  const [isPlaying, setIsPlaying] = useState(false);

  const { data: settings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || {};
    },
    initialData: {}
  });

  const blockbusterVideo = settings?.blockbuster_video || {};

  if (!blockbusterVideo?.enabled || !blockbusterVideo?.youtube_url) return null;

  const getVideoId = (url) => {
    if (!url) return "";
    if (url.includes('v=')) return url.split('v=')[1]?.split('&')[0];
    return url.split('/').pop();
  };

  return (
    <section className="relative py-16 overflow-hidden">
      {/* Blockbuster Blue & Gold Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900 via-blue-800 to-yellow-600 opacity-40">
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 35px, rgba(255,215,0,0.05) 35px, rgba(255,215,0,0.05) 70px)`
        }} />
      </div>

      {/* Film Strip Border */}
      <div className="absolute top-0 left-0 right-0 h-4 bg-black flex">
        {[...Array(30)].map((_, i) => (
          <div key={i} className="flex-1 border-r border-slate-800" />
        ))}
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-4 bg-black flex">
        {[...Array(30)].map((_, i) => (
          <div key={i} className="flex-1 border-r border-slate-800" />
        ))}
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          {/* Video Player - Left */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative rounded-xl overflow-hidden border-4 border-yellow-500 shadow-[0_0_30px_rgba(234,179,8,0.4)]">
              <div className="aspect-video bg-black relative">
                {!isPlaying && (
                  <motion.div
                    className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-blue-900/80 to-yellow-700/80 cursor-pointer z-10"
                    onClick={() => setIsPlaying(true)}
                    whileHover={{ backgroundColor: "rgba(30,58,138,0.6)" }}
                  >
                    <motion.div
                      whileHover={{ scale: 1.2 }}
                      className="w-20 h-20 rounded-full bg-yellow-500 flex items-center justify-center shadow-[0_0_20px_rgba(234,179,8,0.6)]"
                    >
                      <Play className="w-10 h-10 text-blue-900 ml-1" fill="currentColor" />
                    </motion.div>
                  </motion.div>
                )}
                
                <iframe
                  width="100%"
                  height="100%"
                  src={`https://www.youtube.com/embed/${getVideoId(blockbusterVideo.youtube_url)}?autoplay=${isPlaying ? 1 : 0}&rel=0`}
                  title={blockbusterVideo.title}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; gyroscope"
                  allowFullScreen
                  className="w-full h-full"
                />
              </div>
              
              {/* Ticket tear effect at bottom */}
              <div className="h-3 bg-yellow-500 flex">
                {[...Array(20)].map((_, i) => (
                  <div key={i} className="flex-1">
                    <svg viewBox="0 0 10 12" className="w-full h-full">
                      <path d="M0,0 L10,0 L10,12 L5,8 L0,12 Z" fill="#eab308" />
                    </svg>
                  </div>
                ))}
              </div>
            </div>

            {/* Floating rating stars */}
            <div className="absolute -top-4 -right-4 flex gap-1">
              {[...Array(5)].map((_, i) => (
                <motion.div
                  key={i}
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{ duration: 2, delay: i * 0.2, repeat: Infinity }}
                  className="w-6 h-6"
                >
                  <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full text-yellow-400">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                  </svg>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Content - Right */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            {/* Blockbuster-style badge */}
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="inline-block"
            >
              <div className="px-4 py-2 bg-yellow-500 text-blue-900 font-black italic text-sm rounded-lg shadow-lg border-2 border-yellow-600">
                NOW AVAILABLE • BE KIND REWIND
              </div>
            </motion.div>

            {/* Title */}
            <h2 className="text-4xl md:text-5xl font-black text-white leading-tight" style={{
              textShadow: "3px 3px 0 #1e3a8a, 6px 6px 0 #eab308"
            }}>
              {blockbusterVideo.title || "THE ULTIMATE APP EXPERIENCE"}
            </h2>

            {/* Description */}
            <p className="text-lg text-slate-200 leading-relaxed">
              {blockbusterVideo.description || "Get ready for the most EPIC walkthrough of your LIFE! This isn't just an app... it's a BLOCKBUSTER!"}
            </p>

            {/* Rental Info Card */}
            <div className="bg-blue-900/80 border-2 border-yellow-500 rounded-lg p-4 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-yellow-400 font-bold text-sm">FREE RENTAL</span>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3 text-yellow-400">
                      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                    </svg>
                  ))}
                </div>
              </div>
              <p className="text-white text-xs">
                🎬 Genre: <span className="text-yellow-400 font-semibold">Tech Thriller</span> | 
                ⏱️ Runtime: <span className="text-yellow-400 font-semibold">Action-Packed</span>
              </p>
              <p className="text-slate-300 text-xs mt-2 italic">
                "Two thumbs way up! A must-watch for developers!" - App Critics Weekly
              </p>
            </div>

            {/* CTA Button */}
            <motion.button
              onClick={() => setIsPlaying(true)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="w-full md:w-auto px-8 py-4 bg-yellow-500 text-blue-900 font-black text-lg rounded-lg shadow-xl hover:bg-yellow-400 transition-all border-4 border-yellow-600"
            >
              ▶️ WATCH NOW - NO LATE FEES!
            </motion.button>

            <p className="text-xs text-blue-200 italic">
              * While supplies last. Membership not required. Rewind before returning.
            </p>
          </motion.div>
        </div>
      </div>

      {/* Blockbuster Logo Watermark */}
      <div className="absolute bottom-8 right-8 opacity-20">
        <div className="text-6xl font-black italic text-yellow-500" style={{
          textShadow: "4px 4px 0 #1e3a8a",
          transform: "rotate(-5deg)"
        }}>
          BLOCKBUSTER
        </div>
      </div>
    </section>
  );
}