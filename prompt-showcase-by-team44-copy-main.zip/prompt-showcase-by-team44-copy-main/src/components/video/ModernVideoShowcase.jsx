import React from "react";
import { motion } from "framer-motion";
import { Play, Sparkles } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export default function ModernVideoShowcase() {
  const { data: settings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || {};
    },
    initialData: {}
  });

  const config = settings?.modern_video || { enabled: false };

  if (!config.enabled || !config.youtube_url) return null;

  // Extract video ID
  const videoId = config.youtube_url.includes('v=') 
    ? config.youtube_url.split('v=')[1]?.split('&')[0] 
    : config.youtube_url.split('/').pop();

  return (
    <section className="relative py-24 overflow-hidden">
      {/* Abstract Background Elements */}
      <div className="absolute inset-0 bg-slate-950 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-violet-500/10 rounded-full blur-[100px]" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-[100px]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content Side */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-left"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-500/10 border border-violet-500/20 text-violet-400 text-sm font-medium mb-6">
              <Sparkles className="w-4 h-4" />
              <span>Featured Content</span>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 leading-tight">
              {config.title || "Experience the Future"}
            </h2>
            
            <p className="text-lg text-slate-400 mb-8 leading-relaxed">
              {config.description || "Watch our latest showcase demonstrating next-level UI interactions and seamless user experiences."}
            </p>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="group relative inline-flex items-center gap-3 px-8 py-4 bg-white text-slate-950 rounded-xl font-bold overflow-hidden"
            >
              <span className="relative z-10">Watch Now</span>
              <Play className="w-4 h-4 fill-current relative z-10 group-hover:translate-x-1 transition-transform" />
              <div className="absolute inset-0 bg-gradient-to-r from-violet-200 to-cyan-200 opacity-0 group-hover:opacity-100 transition-opacity" />
            </motion.button>
          </motion.div>

          {/* Video Side */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, rotate: -2 }}
            whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            {/* Decorative Card Effect */}
            <div className="absolute -inset-4 bg-gradient-to-r from-violet-500 to-cyan-500 rounded-3xl blur-xl opacity-30 animate-pulse" />
            
            <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-slate-900/50 backdrop-blur-sm shadow-2xl">
              {/* Browser-like Header */}
              <div className="h-10 bg-slate-900/80 border-b border-white/5 flex items-center px-4 gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500/80" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                <div className="w-3 h-3 rounded-full bg-green-500/80" />
                <div className="ml-4 flex-1 h-5 bg-slate-800/50 rounded-full" />
              </div>
              
              {/* Video Player */}
              <div className="aspect-video w-full bg-slate-950 relative group">
                <iframe
                  width="100%"
                  height="100%"
                  src={`https://www.youtube.com/embed/${videoId}?rel=0&showinfo=0`}
                  title="Video Showcase"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="w-full h-full"
                />
              </div>
            </div>

            {/* Floating Badge */}
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="absolute -bottom-6 -right-6 bg-slate-900/90 backdrop-blur-md border border-slate-800 p-4 rounded-xl shadow-xl hidden md:block"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
                  <Play className="w-5 h-5 text-green-400 fill-current" />
                </div>
                <div>
                  <p className="text-white font-bold text-sm">Now Playing</p>
                  <p className="text-slate-400 text-xs">High Definition • 4K</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}