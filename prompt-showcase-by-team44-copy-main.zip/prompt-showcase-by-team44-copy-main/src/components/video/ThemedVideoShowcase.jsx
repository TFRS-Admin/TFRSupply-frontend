import React, { useState } from "react";
import { motion } from "framer-motion";
import { Play } from "lucide-react";

export default function ThemedVideoShowcase({ theme = "bttf", videoUrl, title, description }) {
  const [isPlaying, setIsPlaying] = useState(false);

  const getVideoId = (url) => {
    if (!url) return "";
    if (url.includes('v=')) return url.split('v=')[1]?.split('&')[0];
    return url.split('/').pop();
  };

  const themes = {
    bttf: {
      bg: "from-orange-600 via-yellow-500 to-red-600",
      accent: "from-cyan-400 to-blue-600",
      pattern: "⚡",
      font: "font-mono",
      title: "Great Scott!",
      glow: "shadow-[0_0_50px_rgba(251,191,36,0.5)]"
    },
    jurassic: {
      bg: "from-amber-700 via-green-700 to-emerald-900",
      accent: "from-red-600 to-orange-600",
      pattern: "🦖",
      font: "font-bold tracking-widest",
      title: "SYSTEMS ONLINE",
      glow: "shadow-[0_0_50px_rgba(34,197,94,0.4)]"
    },
    dbz: {
      bg: "from-orange-500 via-amber-400 to-yellow-300",
      accent: "from-blue-600 to-cyan-400",
      pattern: "⭐",
      font: "font-black italic",
      title: "POWER LEVEL: OVER 9000!",
      glow: "shadow-[0_0_60px_rgba(251,191,36,1)]"
    },
    eighties: {
      bg: "from-pink-500 via-purple-500 to-cyan-500",
      accent: "from-yellow-400 to-pink-500",
      pattern: "▲",
      font: "font-black",
      title: "TOTALLY RADICAL",
      glow: "shadow-[0_0_40px_rgba(236,72,153,0.6)]"
    },
    rocky: {
      bg: "from-slate-800 via-red-700 to-slate-900",
      accent: "from-yellow-500 to-red-600",
      pattern: "🥊",
      font: "font-black uppercase",
      title: "ADRIAN!",
      glow: "shadow-[0_0_30px_rgba(220,38,38,0.5)]"
    },
    furious: {
      bg: "from-slate-900 via-orange-600 to-black",
      accent: "from-orange-500 to-red-600",
      pattern: "🏁",
      font: "font-black italic",
      title: "I LIVE MY LIFE A QUARTER MILE AT A TIME",
      glow: "shadow-[0_0_50px_rgba(249,115,22,0.6)]"
    }
  };

  const currentTheme = themes[theme] || themes.bttf;

  return (
    <section className="relative py-20 overflow-hidden">
      {/* Themed Background */}
      <div className={`absolute inset-0 bg-gradient-to-br ${currentTheme.bg} opacity-30`}>
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 35px, rgba(255,255,255,0.03) 35px, rgba(255,255,255,0.03) 70px)`
        }} />
      </div>

      {/* Pattern Overlay */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 text-9xl pointer-events-none">
        {currentTheme.pattern}
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <motion.div
            initial={{ scale: 0.8 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            className={`inline-block px-6 py-2 rounded-full bg-gradient-to-r ${currentTheme.accent} text-white text-xs ${currentTheme.font} mb-6`}
          >
            {currentTheme.title}
          </motion.div>
          
          <h2 className={`text-4xl md:text-5xl font-bold text-white mb-4 ${currentTheme.font}`}>
            <span className={`bg-clip-text text-transparent bg-gradient-to-r ${currentTheme.accent}`}>
              {title || "Watch the Epic Walkthrough"}
            </span>
          </h2>
          
          <p className="text-slate-300 text-lg max-w-2xl mx-auto">
            {description || "Buckle up for an action-packed tour of our features!"}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className={`relative max-w-5xl mx-auto rounded-3xl overflow-hidden ${currentTheme.glow} border-4 ${currentTheme.accent.replace('from-', 'border-').split(' ')[0].replace('to-', '')}`}
        >
          {/* Decorative Corner Elements */}
          <div className="absolute top-0 left-0 w-20 h-20 border-t-4 border-l-4 border-white/20 z-20" />
          <div className="absolute top-0 right-0 w-20 h-20 border-t-4 border-r-4 border-white/20 z-20" />
          <div className="absolute bottom-0 left-0 w-20 h-20 border-b-4 border-l-4 border-white/20 z-20" />
          <div className="absolute bottom-0 right-0 w-20 h-20 border-b-4 border-r-4 border-white/20 z-20" />

          <div className={`aspect-video bg-gradient-to-br ${currentTheme.bg} relative`}>
            {!isPlaying && (
              <motion.div
                className="absolute inset-0 flex items-center justify-center bg-black/50 cursor-pointer z-10"
                onClick={() => setIsPlaying(true)}
                whileHover={{ backgroundColor: "rgba(0,0,0,0.3)" }}
              >
                <motion.div
                  whileHover={{ scale: 1.2 }}
                  className={`w-24 h-24 rounded-full bg-gradient-to-r ${currentTheme.accent} flex items-center justify-center`}
                >
                  <Play className="w-12 h-12 text-white ml-1" fill="white" />
                </motion.div>
              </motion.div>
            )}
            
            <iframe
              width="100%"
              height="100%"
              src={`https://www.youtube.com/embed/${getVideoId(videoUrl)}?autoplay=${isPlaying ? 1 : 0}&rel=0`}
              title={title}
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full"
            />
          </div>
        </motion.div>

        {/* Themed CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-8"
        >
          <p className={`text-slate-400 ${currentTheme.font}`}>
            {theme === "bttf" && "Where we're going, we don't need roads!"}
            {theme === "jurassic" && "Life, uh, finds a way..."}
            {theme === "dbz" && "This isn't even our final form!"}
            {theme === "eighties" && "Totally tubular features, dude!"}
            {theme === "rocky" && "It ain't about how hard you hit..."}
            {theme === "furious" && "Ride or die, remember?"}
          </p>
        </motion.div>
      </div>
    </section>
  );
}