import React from "react";
import { motion } from "framer-motion";
import { Coffee, Heart, Sparkles, ExternalLink, CreditCard, Zap } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

export default function BuyMeCoffeeCTA() {
  const { data: settings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || {};
    },
    initialData: {}
  });

  const donations = settings?.donation_settings || {};
  const ctaStyle = settings?.banner_configs?.coffeeCTAStyle || { 
    gradient: "from-amber-500 to-orange-600", 
    icon: "☕", 
    text: "Buy Me a Coffee" 
  };
  
  const ctaConfig = settings?.cta_section || { enabled: true, visible_buttons: [] };

  if (ctaConfig.enabled === false) return null;

  const allDonationLinks = [
    { key: "kofi_username", label: "Ko-fi", icon: "☕", color: "from-amber-500 to-orange-500", url: donations.kofi_username ? `https://ko-fi.com/${donations.kofi_username}` : null },
    { key: "buymeacoffee_username", label: "Buy Me a Coffee", icon: "🍵", color: "from-yellow-500 to-amber-500", url: "https://buymeacoffee.com/team44" },
    { key: "paypal_me", label: "PayPal", icon: "💳", color: "from-blue-500 to-indigo-500", url: donations.paypal_me ? `https://${donations.paypal_me}` : donations.paypal_email ? `https://paypal.me/${donations.paypal_email}` : null },
    { key: "patreon_url", label: "Patreon", icon: "🎨", color: "from-red-500 to-pink-500", url: donations.patreon_url || null },
    { key: "stripe_link", label: "Stripe", icon: "💎", color: "from-violet-500 to-purple-500", url: donations.stripe_link || null },
    { key: "gofundme_url", label: "GoFundMe", icon: "💚", color: "from-green-500 to-emerald-600", url: donations.gofundme_url || null },
    { key: "bitcoin_address", label: "Bitcoin", icon: "₿", color: "from-orange-500 to-yellow-500", url: donations.bitcoin_address ? `bitcoin:${donations.bitcoin_address}` : null },
    { key: "ethereum_address", label: "Ethereum", icon: "Ξ", color: "from-slate-500 to-slate-700", url: donations.ethereum_address ? `ethereum:${donations.ethereum_address}` : null },
    { key: "solana_address", label: "Solana", icon: "◎", color: "from-purple-500 to-indigo-500", url: donations.solana_address ? `solana:${donations.solana_address}` : null },
    { key: "etransfer_email", label: "e-Transfer", icon: "🇨🇦", color: "from-red-600 to-red-700", url: donations.etransfer_email ? `mailto:${donations.etransfer_email}?subject=Donation` : null },
    { key: "venmo_username", label: "Venmo", icon: "💙", color: "from-blue-400 to-blue-600", url: donations.venmo_username ? `https://venmo.com/${donations.venmo_username}` : null },
    { key: "cashapp_tag", label: "Cash App", icon: "💵", color: "from-green-500 to-green-700", url: donations.cashapp_tag ? `https://cash.app/${donations.cashapp_tag}` : null },
  ];

  // Filter by both existence of URL AND selection in config (if config is present/not empty)
  // If visible_buttons is empty or undefined, show first 5 available as fallback? Or show all? 
  // User asked to "select to use whichever ones I want". So if none selected, show none? Or show defaults?
  // Let's assume if array exists, use it. If not, use defaults.
  
  let displayLinks = [];
  if (ctaConfig.visible_buttons && ctaConfig.visible_buttons.length > 0) {
    displayLinks = allDonationLinks.filter(d => d.url && ctaConfig.visible_buttons.includes(d.key));
  } else {
    // Fallback to old behavior if no config
    displayLinks = allDonationLinks.filter(d => d.url).slice(0, 5);
  }

  if (displayLinks.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="relative my-12 mx-4"
    >
      <div className="max-w-4xl mx-auto">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-violet-950/50 to-slate-900 border border-violet-500/30 p-8 md:p-12">
          {/* Background effects */}
          <div className="absolute inset-0 overflow-hidden">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="absolute -top-1/2 -right-1/2 w-full h-full bg-gradient-to-br from-violet-500/10 to-transparent rounded-full blur-3xl"
            />
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 4, repeat: Infinity }}
              className="absolute -bottom-1/2 -left-1/2 w-full h-full bg-gradient-to-tr from-cyan-500/10 to-transparent rounded-full blur-3xl"
            />
          </div>

          {/* Floating coffee beans */}
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute text-2xl"
              style={{ left: `${10 + i * 15}%`, top: `${10 + (i % 3) * 30}%` }}
              animate={{
                y: [0, -20, 0],
                rotate: [0, 10, -10, 0],
                opacity: [0.3, 0.6, 0.3]
              }}
              transition={{ duration: 3 + i, repeat: Infinity, delay: i * 0.5 }}
            >
              ☕
            </motion.div>
          ))}

          <div className="relative z-10 text-center">
            {/* Icon */}
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className={`inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br ${ctaStyle.gradient} mb-6 shadow-lg`}
            >
              <span className="text-4xl">{ctaStyle.icon}</span>
            </motion.div>

            {/* Title */}
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-3">
              {ctaStyle.text || "Enjoying This App?"}
              <motion.span
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 1, repeat: Infinity }}
                className="inline-block ml-2"
              >
                ❤️
              </motion.span>
            </h2>

            <p className="text-slate-400 text-lg mb-8 max-w-xl mx-auto">
              Your support helps keep this project free and growing! Buy us a coffee to fuel more awesome effects.
            </p>

            {/* Donation buttons */}
            <div className="flex flex-wrap justify-center gap-3">
              {displayLinks.map((link, i) => (
                <motion.a
                  key={link.key}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  className={`inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r ${link.color} text-white font-semibold shadow-lg transition-all`}
                >
                  <span className="text-xl">{link.icon}</span>
                  <span>{link.label}</span>
                  <ExternalLink className="w-4 h-4 opacity-70" />
                </motion.a>
              ))}
            </div>

            {/* Stats */}
            <div className="flex justify-center gap-8 mt-8 pt-6 border-t border-slate-700/50">
              <div className="text-center">
                <Sparkles className="w-5 h-5 text-violet-400 mx-auto mb-1" />
                <p className="text-2xl font-bold text-white">300+</p>
                <p className="text-xs text-slate-500">Effects</p>
              </div>
              <div className="text-center">
                <Heart className="w-5 h-5 text-pink-400 mx-auto mb-1" />
                <p className="text-2xl font-bold text-white">Free</p>
                <p className="text-xs text-slate-500">Forever</p>
              </div>
              <div className="text-center">
                <Coffee className="w-5 h-5 text-amber-400 mx-auto mb-1" />
                <p className="text-2xl font-bold text-white">$3</p>
                <p className="text-xs text-slate-500">= A Coffee</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}