import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Sparkles } from "lucide-react";

// Contextual tooltip that appears on hover or first visit
export default function TutorialTooltip({ 
  id, 
  children, 
  content, 
  position = "top",
  showOnFirstVisit = true 
}) {
  const [isVisible, setIsVisible] = useState(false);
  const [hasBeenSeen, setHasBeenSeen] = useState(false);

  useEffect(() => {
    const seen = localStorage.getItem(`tooltip_${id}_seen`);
    if (!seen && showOnFirstVisit) {
      setIsVisible(true);
      setHasBeenSeen(false);
    } else {
      setHasBeenSeen(true);
    }
  }, [id, showOnFirstVisit]);

  const handleDismiss = () => {
    localStorage.setItem(`tooltip_${id}_seen`, 'true');
    setIsVisible(false);
    setHasBeenSeen(true);
  };

  const positionClasses = {
    top: "-top-2 left-1/2 -translate-x-1/2 -translate-y-full",
    bottom: "-bottom-2 left-1/2 -translate-x-1/2 translate-y-full",
    left: "-left-2 top-1/2 -translate-y-1/2 -translate-x-full",
    right: "-right-2 top-1/2 -translate-y-1/2 translate-x-full"
  };

  return (
    <div 
      className="relative inline-block"
      onMouseEnter={() => hasBeenSeen && setIsVisible(true)}
      onMouseLeave={() => hasBeenSeen && setIsVisible(false)}
    >
      {children}

      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className={`absolute z-50 ${positionClasses[position]} pointer-events-auto`}
          >
            <div className="relative bg-slate-900/95 border-2 border-cyan-500 rounded-lg p-3 shadow-xl shadow-cyan-500/20 max-w-xs">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-violet-500/20 rounded-lg" />
              
              <div className="relative z-10 flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-slate-200 flex-1">{content}</p>
                {!hasBeenSeen && (
                  <button
                    onClick={handleDismiss}
                    className="p-0.5 rounded hover:bg-slate-800 text-slate-400 hover:text-white transition-colors flex-shrink-0"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}