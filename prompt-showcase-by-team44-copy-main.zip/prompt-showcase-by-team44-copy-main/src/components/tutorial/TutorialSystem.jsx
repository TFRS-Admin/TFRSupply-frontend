import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ChevronRight, ChevronLeft, Check, Play, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

// Tutorial System Manager
export default function TutorialSystem({ tutorialId, steps, onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Check if tutorial has been completed
    const completed = localStorage.getItem(`tutorial_${tutorialId}_completed`);
    if (!completed) {
      setIsVisible(true);
    }
  }, [tutorialId]);

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = () => {
    localStorage.setItem(`tutorial_${tutorialId}_completed`, 'true');
    setIsVisible(false);
    if (onComplete) onComplete();
  };

  const handleSkip = () => {
    localStorage.setItem(`tutorial_${tutorialId}_completed`, 'true');
    setIsVisible(false);
  };

  if (!isVisible || !steps || steps.length === 0) return null;

  const step = steps[currentStep] || {};

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex items-center justify-center p-4"
      >
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-black/70 backdrop-blur-sm"
          onClick={handleSkip}
        />

        {/* Tutorial Card */}
        <motion.div
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          className="relative max-w-2xl w-full bg-slate-900/95 rounded-2xl border-2 border-violet-500 shadow-2xl shadow-violet-500/20 overflow-hidden"
        >
          {/* Glowing border animation */}
          <div className="absolute inset-0 rounded-2xl">
            <div className="absolute inset-0 bg-gradient-to-r from-violet-500 via-cyan-500 to-violet-500 opacity-50 blur-xl animate-pulse" />
          </div>

          <div className="relative z-10 p-6">
            {/* Header */}
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-3">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="p-2 rounded-lg bg-violet-500/20 border border-violet-500/50"
                >
                  <Sparkles className="w-5 h-5 text-violet-400" />
                </motion.div>
                <div>
                  <h3 className="text-xl font-bold text-white">{step.title}</h3>
                  <p className="text-xs text-slate-400">
                    Step {currentStep + 1} of {steps.length}
                  </p>
                </div>
              </div>
              <button
                onClick={handleSkip}
                className="p-2 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Progress Bar */}
            <div className="mb-6 h-1 bg-slate-800 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
                className="h-full bg-gradient-to-r from-violet-500 to-cyan-500"
              />
            </div>

            {/* Content */}
            <div className="mb-6">
              {step?.videoUrl && typeof step.videoUrl === 'string' && (
                <div className="mb-4 aspect-video rounded-lg overflow-hidden border border-slate-800">
                  <iframe
                    width="100%"
                    height="100%"
                    src={step.videoUrl}
                    title={step.title || "Tutorial Video"}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="w-full h-full"
                  />
                </div>
              )}

              {step?.image && typeof step.image === 'string' && (
                <div className="mb-4 rounded-lg overflow-hidden border border-slate-800">
                  <img src={step.image} alt={step.title || "Tutorial"} className="w-full" />
                </div>
              )}

              <p className="text-slate-300 leading-relaxed mb-4">{step?.description || ""}</p>

              {step?.tips && Array.isArray(step.tips) && step.tips.length > 0 && (
                <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                  <p className="text-xs font-semibold text-cyan-400 mb-2">💡 Pro Tips:</p>
                  <ul className="space-y-1">
                    {step.tips.map((tip, idx) => (
                      <li key={idx} className="text-sm text-slate-300 flex items-start gap-2">
                        <span className="text-cyan-400 mt-1">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between gap-4">
              <Button
                onClick={handlePrev}
                disabled={currentStep === 0}
                variant="outline"
                className="border-slate-700 hover:bg-slate-800 disabled:opacity-50"
              >
                <ChevronLeft className="w-4 h-4 mr-1" />
                Previous
              </Button>

              <div className="flex gap-2">
                <Button
                  onClick={handleSkip}
                  variant="ghost"
                  className="text-slate-400 hover:text-white"
                >
                  Skip Tutorial
                </Button>

                <motion.button
                  onClick={handleNext}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="relative px-6 py-2 rounded-lg font-semibold overflow-hidden group"
                >
                  <div className="absolute inset-0 bg-slate-900/30 rounded-lg" />
                  <div className="absolute inset-0 rounded-lg border-2 border-violet-500 group-hover:border-cyan-500 transition-colors" />
                  <span className="relative z-10 flex items-center gap-2 text-white">
                    {currentStep === steps.length - 1 ? (
                      <>
                        <Check className="w-4 h-4" />
                        Complete
                      </>
                    ) : (
                      <>
                        Next
                        <ChevronRight className="w-4 h-4" />
                      </>
                    )}
                  </span>
                </motion.button>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// Reset a specific tutorial (useful for testing)
export function resetTutorial(tutorialId) {
  localStorage.removeItem(`tutorial_${tutorialId}_completed`);
}

// Reset all tutorials
export function resetAllTutorials() {
  const keys = Object.keys(localStorage);
  keys.forEach(key => {
    if (key.startsWith('tutorial_') && key.endsWith('_completed')) {
      localStorage.removeItem(key);
    }
  });
}