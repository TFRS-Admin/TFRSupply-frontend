// Tutorial definitions for different sections

export const effectBuilderTutorial = {
  id: "effect-builder",
  steps: [
    {
      title: "Welcome to Effect Builder",
      description: "The Effect Builder is your creative playground for designing custom UI effects. You can combine animations, transitions, and styles to create unique components for your projects.",
      tips: [
        "Start with a simple effect and gradually add complexity",
        "Use the preview panel to test your effects in real-time",
        "Save your favorite effects for quick access later"
      ]
    },
    {
      title: "Choose Your Base Effect",
      description: "Begin by selecting a base animation type. You can choose from fade, slide, scale, rotate, and many more. Each base effect can be customized with timing, easing, and duration.",
      tips: [
        "Hover over effect types to see a quick preview",
        "Combine multiple effects for complex animations"
      ]
    },
    {
      title: "Customize Properties",
      description: "Adjust the effect properties using the control panel. You can modify timing functions, durations, delays, and more. See your changes live in the preview area.",
      tips: [
        "Use the preset easing functions for smooth animations",
        "Experiment with different duration values"
      ]
    },
    {
      title: "Copy Code or Prompt",
      description: "Once you're satisfied with your effect, you can copy the React code to use directly in your project, or copy the AI prompt to recreate it with your preferred AI tool.",
      tips: [
        "The code includes all necessary imports and dependencies",
        "The AI prompt is optimized for accurate recreation"
      ]
    },
    {
      title: "Save and Share",
      description: "Save your custom effects to your favorites collection. You can access them anytime from the 'My Effects' page and share them with your team.",
      tips: [
        "Name your effects descriptively for easy searching",
        "Export your effects collection for backup"
      ]
    }
  ]
};

export const designTerminologyTutorial = {
  id: "design-terminology",
  steps: [
    {
      title: "Master Design Language",
      description: "Understanding design terminology is crucial for communicating effectively with AI and team members. This section teaches you the vocabulary used in modern UI/UX design.",
      tips: [
        "Bookmark terms you use frequently",
        "Use the search to find specific concepts quickly"
      ]
    },
    {
      title: "Learn UI Patterns",
      description: "Explore common UI patterns and their names. From accordions to modals, knowing the right terminology helps you describe exactly what you want to build.",
      tips: [
        "Each term includes visual examples",
        "Check the 'When to Use' section for best practices"
      ]
    },
    {
      title: "Communicate with AI",
      description: "Use precise terminology in your AI prompts to get better results. For example, 'Create a glassmorphic modal with a backdrop blur' is more effective than 'Make a transparent popup'.",
      tips: [
        "Copy example prompts to see proper usage",
        "Combine terms to describe complex designs"
      ]
    }
  ]
};

export const gamingEffectsTutorial = {
  id: "gaming-effects",
  steps: [
    {
      title: "Explore Gaming UI Components",
      description: "Discover 250+ gaming-specific effects including health bars, particle systems, score displays, and more. These components are perfect for game interfaces and interactive experiences.",
      tips: [
        "Use filters to find specific game styles (Retro, Sci-Fi, RPG)",
        "Preview effects in full-screen mode for better visualization"
      ]
    },
    {
      title: "React GameKit",
      description: "Access over 150 pre-built game mechanics components. From sprite animation to collision detection, these components accelerate your game development.",
      tips: [
        "Components are fully customizable and production-ready",
        "Check the code examples for integration guidance"
      ]
    },
    {
      title: "Phaser Engine Integration",
      description: "Explore Phaser-powered game examples. These demos show how to integrate the Phaser game engine into React applications for advanced game features.",
      tips: [
        "Each demo includes complete source code",
        "Combine Phaser games with React UI components"
      ],
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
    }
  ]
};

export const phaserKitTutorial = {
  id: "phaser-kit",
  steps: [
    {
      title: "Getting Started with Phaser",
      description: "Phaser is a powerful HTML5 game framework. These examples demonstrate platformer mechanics, physics simulations, and interactive game elements.",
      tips: [
        "Use arrow keys and spacebar for most demos",
        "Click anywhere to interact with particle effects"
      ]
    },
    {
      title: "Understanding Game Physics",
      description: "Learn how physics systems work in games. Experiment with gravity, collision, and bounce effects in the interactive demos.",
      tips: [
        "Adjust physics properties to see how they affect gameplay",
        "Study the code to understand the underlying mechanics"
      ]
    },
    {
      title: "Building Your Own Game",
      description: "Use these examples as a foundation for your own games. Copy the code, customize it, and combine different mechanics to create unique gameplay.",
      tips: [
        "Start simple and gradually add features",
        "Test frequently to catch bugs early"
      ]
    }
  ]
};

export const navigationTutorial = {
  id: "navigation-effects",
  steps: [
    {
      title: "Modern Navigation Patterns",
      description: "Explore navigation components including headers, sidebars, breadcrumbs, and tab systems. Each component is fully responsive and accessible.",
      tips: [
        "Test navigation on mobile devices",
        "Combine effects for unique experiences"
      ]
    },
    {
      title: "Scroll-Based Effects",
      description: "Discover scroll-triggered animations and sticky navigation behaviors. These effects enhance user engagement and provide visual feedback.",
      tips: [
        "Use subtle animations to avoid overwhelming users",
        "Test scroll performance on different devices"
      ]
    }
  ]
};

export const buttonEffectsTutorial = {
  id: "button-effects",
  steps: [
    {
      title: "Interactive Button Collection",
      description: "Browse 35+ button variations with hover effects, loading states, and micro-interactions. Each button includes copy-paste code and AI prompts.",
      tips: [
        "Match button styles to your design system",
        "Consider accessibility when choosing effects"
      ]
    }
  ]
};

// Tooltip content for various sections
export const tooltipContent = {
  effectBuilder: "Create custom UI effects by combining animations and styles",
  designTerminology: "Learn design vocabulary to communicate better with AI",
  gamingEffects: "250+ game-specific UI components and effects",
  phaserKit: "Interactive Phaser game engine examples with full source code",
  reactGameKit: "150+ pre-built game mechanics components",
  buttonEffects: "35+ interactive button variations with hover effects",
  navigationEffects: "Modern navigation patterns and scroll-based effects",
  visualEffects: "VHS, glitch, particles, and advanced visual effects",
  audioEffects: "Background music, visualizers, and sound effects",
  textEffects: "50+ animated text and typography components",
  transitions: "Page transitions, staggered lists, and counter animations",
  chatEffects: "Chat bubbles, bots, and messaging UI components",
  aiAgents: "AI interface components and agent UIs",
  adminLayouts: "Dashboard tables, sidebars, stats, and modals",
  marketing: "CTAs, testimonials, pricing, and popups",
  ecommerce: "Product cards, ratings, wishlists, and filters",
  productivity: "Todo lists, timers, kanban boards, and habit trackers"
};