import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, Copy, Check, Code } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CodeSnippet({ code, prompt, title = "View Code" }) {
  const [isOpen, setIsOpen] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [activeTab, setActiveTab] = useState("code");

  const handleCopyCode = async () => {
    await navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyPrompt = async () => {
    await navigator.clipboard.writeText(prompt);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2000);
  };

  return (
    <div className="border-t border-slate-700 mt-4 pt-4">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 text-sm text-slate-400 hover:text-white transition-colors w-full"
      >
        <Code className="w-4 h-4" />
        <span>{title}</span>
        <motion.span
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.2 }}
          className="ml-auto"
        >
          <ChevronDown className="w-4 h-4" />
        </motion.span>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="mt-4 space-y-3">
              {/* Tabs */}
              <div className="flex gap-2">
                <button
                  onClick={() => setActiveTab("code")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    activeTab === "code"
                      ? "bg-violet-500/20 text-violet-400"
                      : "bg-slate-800 text-slate-400 hover:text-white"
                  }`}
                >
                  Code
                </button>
                <button
                  onClick={() => setActiveTab("prompt")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    activeTab === "prompt"
                      ? "bg-cyan-500/20 text-cyan-400"
                      : "bg-slate-800 text-slate-400 hover:text-white"
                  }`}
                >
                  AI Prompt
                </button>
              </div>

              {activeTab === "code" && (
                <div className="relative">
                  <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 overflow-x-auto text-xs">
                    <code className="text-slate-300 whitespace-pre-wrap">{code}</code>
                  </pre>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={handleCopyCode}
                    className="absolute top-2 right-2 h-8 px-2"
                  >
                    {copiedCode ? (
                      <Check className="w-4 h-4 text-green-400" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              )}

              {activeTab === "prompt" && (
                <div className="relative">
                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300">
                    {prompt}
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={handleCopyPrompt}
                    className="absolute top-2 right-2 h-8 px-2"
                  >
                    {copiedPrompt ? (
                      <Check className="w-4 h-4 text-green-400" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}