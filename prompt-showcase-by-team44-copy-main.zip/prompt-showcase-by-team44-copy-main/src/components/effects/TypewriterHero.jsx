import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";

const messages = [
  "Welcome to Team44 Effects Showcase!",
  "Discover what you can do...",
  "Learn how You can do it!",
  "Build cool Apps, Sites, Tools, Games & more!",
  "Create fun and useful experiences:)",
  "Explore 850+ ready-to-use effects!"
];

export default function TypewriterHero() {
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);
  const [displayedText, setDisplayedText] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const currentMessage = messages[currentMessageIndex];

    const timeout = setTimeout(() => {
      if (!isDeleting) {
        if (displayedText.length < currentMessage.length) {
          setDisplayedText(currentMessage.slice(0, displayedText.length + 1));
        } else {
          setTimeout(() => setIsDeleting(true), 2000);
        }
      } else {
        if (displayedText.length > 0) {
          setDisplayedText(displayedText.slice(0, -1));
        } else {
          setIsDeleting(false);
          setCurrentMessageIndex((prev) => (prev + 1) % messages.length);
        }
      }
    }, isDeleting ? 30 : 80);

    return () => clearTimeout(timeout);
  }, [displayedText, isDeleting, currentMessageIndex]);

  // Pre-process message to split into segments (highlighted vs normal)
  const getSegments = (text) => {
    const highlights = ["Team44", "Discover", "Learn", "You can do it!...", "Build", "Create", "Explore"];
    const pattern = new RegExp(`(${highlights.join("|")})`, "g");
    const parts = text.split(pattern);
    
    return parts.map(part => ({
      text: part,
      isHighlight: highlights.includes(part)
    })).filter(segment => segment.text.length > 0);
  };

  const renderTypedText = () => {
    const currentMessage = messages[currentMessageIndex];
    const segments = getSegments(currentMessage);
    
    let charCount = 0;
    const renderedSegments = [];
    
    for (let i = 0; i < segments.length; i++) {
      const segment = segments[i];
      const segmentLength = segment.text.length;
      
      // If we haven't reached this segment yet in typing, stop
      if (displayedText.length <= charCount) break;
      
      // Calculate how much of this segment to show
      const charsToShow = Math.min(segmentLength, displayedText.length - charCount);
      const textPart = segment.text.slice(0, charsToShow);
      
      renderedSegments.push(
        <span key={i} className={segment.isHighlight ? "text-white" : "gradient-text"}>
          {textPart}
        </span>
      );
      
      charCount += segmentLength;
      
      // If we're in the middle of this segment, we're done
      if (charsToShow < segmentLength) break;
    }
    
    return renderedSegments;
  };

  return (
    <div className="w-full">
    <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold h-[180px] relative">  
        <div className="absolute inset-0 flex items-center justify-center">
        <span className="block text-center">
          {renderTypedText()}
          <motion.span
            animate={{ opacity: [1, 0] }}
            transition={{ duration: 0.5, repeat: Infinity }}
            className="inline-block w-[3px] h-[0.9em] bg-teal-400 ml-1 align-middle" />
        </span>  
        </div>  
      </h1>
    </div>
  );
}