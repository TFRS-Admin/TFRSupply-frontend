import React, { useState } from "react";
import { motion } from "framer-motion";

// Simple preview component that renders based on effect metadata
export default function DynamicEffectPreview({ effectData }) {
  if (!effectData || !effectData.preview) {
    return (
      <div className="flex items-center justify-center h-full text-slate-500 text-sm">
        Preview not available
      </div>
    );
  }

  const { type, props = {} } = effectData.preview;

  // Render different effect types
  switch (type) {
    case 'text':
      return <TextEffect {...props} />;
    case 'button':
      return <ButtonEffect {...props} />;
    case 'animation':
      return <AnimationEffect {...props} />;
    case 'gradient':
      return <GradientEffect {...props} />;
    case 'particle':
      return <ParticleEffect {...props} />;
    case 'glow':
      return <GlowEffect {...props} />;
    case 'ripple':
      return <RippleEffect {...props} />;
    default:
      return (
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <div className="text-6xl mb-4">✨</div>
            <div className="text-sm text-slate-400">{effectData.name}</div>
          </div>
        </div>
      );
  }
}

// Text Effect Preview
function TextEffect({ text = "Sample Text", animation = "fade", color = "violet" }) {
  const colorClasses = {
    violet: "text-violet-400",
    cyan: "text-cyan-400",
    pink: "text-pink-400",
    emerald: "text-emerald-400"
  };

  const animations = {
    fade: { initial: { opacity: 0 }, animate: { opacity: 1 }, transition: { repeat: Infinity, duration: 2, repeatType: "reverse" } },
    scale: { initial: { scale: 0.8 }, animate: { scale: 1.2 }, transition: { repeat: Infinity, duration: 1, repeatType: "reverse" } },
    slide: { initial: { x: -20 }, animate: { x: 20 }, transition: { repeat: Infinity, duration: 2, repeatType: "reverse" } },
    rotate: { animate: { rotate: 360 }, transition: { repeat: Infinity, duration: 2, ease: "linear" } }
  };

  return (
    <div className="flex items-center justify-center h-full">
      <motion.div 
        className={`text-2xl font-bold ${colorClasses[color] || colorClasses.violet}`}
        {...(animations[animation] || animations.fade)}
      >
        {text}
      </motion.div>
    </div>
  );
}

// Button Effect Preview
function ButtonEffect({ text = "Click Me", variant = "default" }) {
  const [clicked, setClicked] = useState(false);

  return (
    <div className="flex items-center justify-center h-full">
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setClicked(!clicked)}
        className={`px-6 py-3 rounded-lg font-medium transition-all ${
          clicked 
            ? "bg-emerald-500 text-white" 
            : variant === "gradient"
            ? "bg-gradient-to-r from-violet-500 to-cyan-500 text-white"
            : "bg-slate-800 text-white hover:bg-slate-700"
        }`}
      >
        {clicked ? "✓ Clicked!" : text}
      </motion.button>
    </div>
  );
}

// Animation Effect Preview
function AnimationEffect({ shape = "circle", color = "violet" }) {
  const colorClasses = {
    violet: "bg-violet-500",
    cyan: "bg-cyan-500",
    pink: "bg-pink-500",
    emerald: "bg-emerald-500"
  };

  return (
    <div className="flex items-center justify-center h-full">
      <motion.div
        className={`w-16 h-16 ${colorClasses[color]} ${shape === "circle" ? "rounded-full" : "rounded-lg"}`}
        animate={{ 
          scale: [1, 1.2, 1],
          rotate: [0, 180, 360]
        }}
        transition={{ 
          repeat: Infinity, 
          duration: 2,
          ease: "easeInOut"
        }}
      />
    </div>
  );
}

// Gradient Effect Preview
function GradientEffect({ from = "violet", to = "cyan" }) {
  const gradients = {
    'violet-cyan': 'from-violet-500 via-purple-500 to-cyan-500',
    'pink-violet': 'from-pink-500 via-purple-500 to-violet-500',
    'emerald-cyan': 'from-emerald-500 via-teal-500 to-cyan-500',
    'orange-pink': 'from-orange-500 via-rose-500 to-pink-500'
  };

  const gradientKey = `${from}-${to}`;
  
  return (
    <div className="flex items-center justify-center h-full p-8">
      <div className={`w-full h-full rounded-xl bg-gradient-to-r ${gradients[gradientKey] || gradients['violet-cyan']} animate-pulse`} />
    </div>
  );
}

// Particle Effect Preview
function ParticleEffect({ count = 20 }) {
  return (
    <div className="relative h-full overflow-hidden">
      {[...Array(count)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-violet-400 rounded-full"
          initial={{ 
            x: Math.random() * 300, 
            y: 300,
            opacity: 0 
          }}
          animate={{ 
            y: -20,
            opacity: [0, 1, 0]
          }}
          transition={{ 
            repeat: Infinity, 
            duration: 2 + Math.random() * 2,
            delay: Math.random() * 2,
            ease: "linear"
          }}
        />
      ))}
    </div>
  );
}

// Glow Effect Preview
function GlowEffect({ color = "violet", intensity = "medium" }) {
  const glows = {
    low: "shadow-lg",
    medium: "shadow-2xl",
    high: "shadow-[0_0_50px_rgba(139,92,246,0.8)]"
  };

  const colors = {
    violet: "bg-violet-500 shadow-violet-500/50",
    cyan: "bg-cyan-500 shadow-cyan-500/50",
    pink: "bg-pink-500 shadow-pink-500/50"
  };

  return (
    <div className="flex items-center justify-center h-full">
      <motion.div
        className={`w-24 h-24 rounded-full ${colors[color]} ${glows[intensity]}`}
        animate={{ 
          boxShadow: [
            '0 0 20px rgba(139,92,246,0.5)',
            '0 0 60px rgba(139,92,246,0.8)',
            '0 0 20px rgba(139,92,246,0.5)'
          ]
        }}
        transition={{ 
          repeat: Infinity, 
          duration: 2,
          ease: "easeInOut"
        }}
      />
    </div>
  );
}

// Ripple Effect Preview
function RippleEffect() {
  const [ripples, setRipples] = useState([]);

  const createRipple = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const newRipple = { x, y, id: Date.now() };
    setRipples([...ripples, newRipple]);
    setTimeout(() => {
      setRipples(r => r.filter(rip => rip.id !== newRipple.id));
    }, 600);
  };

  return (
    <div 
      className="relative h-full bg-slate-800 rounded-lg overflow-hidden cursor-pointer flex items-center justify-center"
      onClick={createRipple}
    >
      <span className="text-slate-400 text-sm">Click for ripple</span>
      {ripples.map(ripple => (
        <motion.span
          key={ripple.id}
          className="absolute w-5 h-5 rounded-full bg-violet-400/30 pointer-events-none"
          initial={{ scale: 0, opacity: 1 }}
          animate={{ scale: 20, opacity: 0 }}
          transition={{ duration: 0.6 }}
          style={{ left: ripple.x - 10, top: ripple.y - 10 }}
        />
      ))}
    </div>
  );
}