import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";

const wilsonImages = [
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d0e11f7107236669e8813/3aff6f6c2_wilson1.jpg",
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d0e11f7107236669e8813/5c3e602bf_wilson2.jpg",
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d0e11f7107236669e8813/d87bb9141_wilson3.jpg",
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d0e11f7107236669e8813/41b10b386_wilson4.jpg",
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d0e11f7107236669e8813/e5c69154b_wilson5.jpg",
];

// Wilson-style philosophical and neighborly wisdom
const wilsonWisdoms = [
  "Well, you know what they say: 'A journey of a thousand miles begins with a single step.' - Lao Tzu",
  "As the great philosopher Aristotle once said, 'We are what we repeatedly do. Excellence, then, is not an act, but a habit.'",
  "You know, there's an old saying: 'The only constant in life is change.' - Heraclitus",
  "Confucius once wrote, 'It does not matter how slowly you go as long as you do not stop.'",
  "As my neighbor across the fence might say, 'The best time to plant a tree was twenty years ago. The second best time is now.'",
  "Remember what Socrates said: 'The only true wisdom is in knowing you know nothing.'",
  "There's ancient wisdom that tells us: 'Fall seven times, stand up eight.' - Japanese proverb",
  "As the poets say, 'In the middle of difficulty lies opportunity.' - Albert Einstein",
  "You know, Marcus Aurelius wrote: 'Very little is needed to make a happy life; it is all within yourself.'",
  "The wise ones tell us: 'What we think, we become.' - Buddha",
  "There's a saying from ancient Rome: 'Fortune favors the bold.' - Virgil",
  "As grandmother used to say, 'A smooth sea never made a skilled sailor.'",
  "Remember the words: 'The mind is everything. What you think you become.' - Buddha",
  "There's wisdom in knowing that 'The greatest glory is not in never falling, but in rising every time we fall.'",
  "As they say over the fence, 'Patience is bitter, but its fruit is sweet.' - Aristotle"
];

// Glitching version text - 5 random glitches within 30 seconds
function GlitchingVersion({ version }) {
  const [isGlitching, setIsGlitching] = useState(false);

  useEffect(() => {
    const triggerRandomGlitches = () => {
      const glitchTimes = Array(5).fill(0).map(() => Math.random() * 30000);
      glitchTimes.forEach(time => {
        setTimeout(() => {
          setIsGlitching(true);
          setTimeout(() => setIsGlitching(false), 300);
        }, time);
      });
    };
    triggerRandomGlitches();
    const interval = setInterval(triggerRandomGlitches, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <style>{`
        @keyframes version-glitch {
          0%, 100% { text-shadow: none; transform: translate(0); }
          10% { text-shadow: -2px 0 #ff00ff, 2px 0 #00ffff; transform: translate(-1px, 1px); }
          20% { text-shadow: 2px 0 #ff00ff, -2px 0 #00ffff; transform: translate(1px, -1px); }
          30% { text-shadow: -1px 0 #00ffff, 1px 0 #ff00ff; transform: translate(-1px, 0); }
          40% { text-shadow: 1px 0 #00ffff, -1px 0 #ff00ff; transform: translate(1px, 1px); }
          50% { text-shadow: 0 -1px #ff00ff, 0 1px #00ffff; transform: translate(0, -1px); }
        }
        .version-glitch-active { animation: version-glitch 0.3s ease-in-out; }
      `}</style>
      <span className={`${isGlitching ? 'version-glitch-active' : ''}`}>v{version}</span>
    </>
  );
}

export default function WilsonQuote({ version = "1.0.0" }) {
  const [quote, setQuote] = useState("");
  const [imageIndex, setImageIndex] = useState(0);

  useEffect(() => {
    // Get a consistent quote AND image for each day - synced together
    const today = new Date();
    const dayOfYear = Math.floor((today - new Date(today.getFullYear(), 0, 0)) / (1000 * 60 * 60 * 24));
    const quoteIndex = dayOfYear % wilsonWisdoms.length;
    
    // Use a different offset for images to avoid same image on consecutive days
    // This ensures each quote gets a unique image and never repeats back-to-back
    const imageIdx = dayOfYear % wilsonImages.length;
    
    setQuote(wilsonWisdoms[quoteIndex]);
    setImageIndex(imageIdx);
  }, []);

  return (
    <HoverCard openDelay={50} closeDelay={100}>
      <HoverCardTrigger asChild>
        <button className="text-xs text-slate-500 hover:text-violet-400 transition-colors cursor-pointer">
          <GlitchingVersion version={version} />
        </button>
      </HoverCardTrigger>
      <HoverCardContent 
        side="top" 
        className="w-80 bg-slate-900 border-slate-700 text-white p-4"
      >
        <div className="flex gap-3">
          <div className="flex-shrink-0">
            <motion.img 
              key={imageIndex}
              src={wilsonImages[imageIndex]} 
              alt="Wilson" 
              className="w-14 h-14 rounded-lg object-cover border-2 border-violet-500/50"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            />
          </div>
          <div className="flex-1 space-y-2">
            <span className="font-semibold text-violet-400 text-sm">Wilson's Daily Wisdom</span>
            <p className="text-xs text-slate-300 italic leading-relaxed">
              "{quote}"
            </p>
            <p className="text-[10px] text-slate-500">
              *peeks over fence thoughtfully*
            </p>
          </div>
        </div>
      </HoverCardContent>
    </HoverCard>
  );
}