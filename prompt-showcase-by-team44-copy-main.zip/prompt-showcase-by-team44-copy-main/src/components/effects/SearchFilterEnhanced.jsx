import React, { useState, useEffect, useRef } from "react";
import { Search, Filter, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useQuery } from "@tanstack/react-query";

const categories = [
  { id: "all", label: "All", color: "violet" },
  { id: "visual", label: "Visual", color: "violet" },
  { id: "audio", label: "Audio", color: "cyan" },
  { id: "transition", label: "Transitions", color: "pink" },
  { id: "navigation", label: "Navigation", color: "amber" },
  { id: "button", label: "Buttons", color: "emerald" },
  { id: "chat", label: "Chat", color: "blue" },
  { id: "agent", label: "AI Agent", color: "purple" },
  { id: "admin", label: "Admin", color: "slate" },
  { id: "marketing", label: "Marketing", color: "rose" },
  { id: "creative", label: "Creative", color: "fuchsia" },
  { id: "ecommerce", label: "E-commerce", color: "orange" },
  { id: "content", label: "Content", color: "teal" },
  { id: "communication", label: "Comms", color: "indigo" },
  { id: "social", label: "Social", color: "pink" },
  { id: "productivity", label: "Productivity", color: "green" },
  { id: "gaming", label: "Gaming", color: "red" },
  { id: "youtube", label: "YouTube", color: "red" },
];

// Suggestions data for autocomplete
const allEffectSuggestions = [
  { name: "Wave Divider", page: "DividerEffects", category: "Dividers" },
  { name: "Glitch Effect", page: "VisualEffects", category: "Visual" },
  { name: "Neon Glow", page: "VisualEffects", category: "Visual" },
  { name: "Ripple Button", page: "ButtonEffects", category: "Buttons" },
  { name: "Chat Bubble", page: "ChatEffects", category: "Chat" },
  { name: "Particle System", page: "VisualEffects", category: "Visual" },
  { name: "Loading Spinner", page: "LoadingSpinners", category: "Loading" },
  { name: "Fade Transition", page: "Transitions", category: "Transitions" },
  { name: "VHS Effect", page: "VisualEffects", category: "Visual" },
  { name: "Frosted Glass", page: "VisualEffects", category: "Visual" },
  { name: "Custom Play Button", page: "VideoPlayerCustomization", category: "YouTube" },
  { name: "Glitch Player", page: "VideoPlayerCustomization", category: "YouTube" },
];

export default function SearchFilterEnhanced({ 
  searchQuery, 
  setSearchQuery, 
  activeCategory, 
  setActiveCategory,
  resultCount,
  suggestions = allEffectSuggestions
}) {
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [filteredSuggestions, setFilteredSuggestions] = useState([]);
  const searchRef = useRef(null);

  useEffect(() => {
    if (searchQuery.length > 0) {
      const filtered = suggestions.filter(s => 
        s.name.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 6);
      setFilteredSuggestions(filtered);
      setShowSuggestions(filtered.length > 0);
    } else {
      setShowSuggestions(false);
    }
  }, [searchQuery, suggestions]);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (searchRef.current && !searchRef.current.contains(e.target)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="space-y-4 mb-8">
      <style>{`
        .category-glitch:hover {
          animation: cat-glitch 0.3s ease-in-out;
        }
        @keyframes cat-glitch {
          0%, 100% { text-shadow: none; transform: translate(0); }
          20% { text-shadow: -1px 0 #ff00ff, 1px 0 #00ffff; transform: translate(-1px, 0); }
          40% { text-shadow: 1px 0 #ff00ff, -1px 0 #00ffff; transform: translate(1px, 0); }
          60% { text-shadow: -1px 0 #00ffff, 1px 0 #ff00ff; transform: translate(-1px, 0); }
          80% { text-shadow: 1px 0 #00ffff, -1px 0 #ff00ff; transform: translate(1px, 0); }
        }
      `}</style>
      
      {/* Search Bar with Suggestions */}
      <div className="relative" ref={searchRef}>
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 z-10" />
        <Input
          type="text"
          placeholder="Search effects by name or description..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onFocus={() => searchQuery && setShowSuggestions(filteredSuggestions.length > 0)}
          className="pl-12 pr-10 py-6 bg-slate-900/50 border-slate-700 text-white placeholder:text-slate-500 rounded-xl"
        />
        {searchQuery && (
          <button
            onClick={() => { setSearchQuery(""); setShowSuggestions(false); }}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-slate-700 text-slate-400 z-10"
          >
            <X className="w-4 h-4" />
          </button>
        )}
        
        {/* Suggestions Dropdown */}
        <AnimatePresence>
          {showSuggestions && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="absolute top-full left-0 right-0 mt-2 bg-slate-900/95 backdrop-blur-xl border border-slate-700 rounded-xl shadow-2xl overflow-hidden z-50"
            >
              {filteredSuggestions.map((suggestion, i) => (
                <Link
                  key={i}
                  to={createPageUrl(suggestion.page) + `#${suggestion.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')}`}
                  onClick={() => { setShowSuggestions(false); setSearchQuery(""); }}
                  className="flex items-center justify-between px-4 py-3 hover:bg-slate-800 transition-colors border-b border-slate-800 last:border-0"
                >
                  <div>
                    <p className="text-white text-sm font-medium">{suggestion.name}</p>
                    <p className="text-slate-500 text-xs">{suggestion.category}</p>
                  </div>
                  <span className="text-violet-400 text-xs">View →</span>
                </Link>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Category Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <Filter className="w-4 h-4 text-slate-400" />
        {categories.map((category) => (
          <motion.button
            key={category.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveCategory(category.id)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all category-glitch ${
              activeCategory === category.id
                ? `bg-black/70 border ${category.color.replace('bg-', 'border-')} text-white shadow-lg`
                : "bg-slate-800 text-slate-400 hover:text-white border border-transparent"
            }`}
            style={activeCategory === category.id ? { backdropFilter: "blur(2px)" } : {}}
          >
            {category.label}
          </motion.button>
        ))}
      </div>

      {/* Result Count */}
      <AnimatePresence>
        {(searchQuery || activeCategory !== "all") && (
          <motion.p
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="text-sm text-slate-400"
          >
            Found <span className="text-white font-semibold">{resultCount}</span> effects
            {searchQuery && <span> matching "{searchQuery}"</span>}
            {activeCategory !== "all" && (
              <span> in {categories.find(c => c.id === activeCategory)?.label}</span>
            )}
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}