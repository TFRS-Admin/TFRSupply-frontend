import React, { useState, useEffect } from "react";

const TEXTS = [
  { text: "Prompt Showcase", gradient: "from-cyan-400 via-cyan-500 to-cyan-500" },
  { text: "Copy Prompts", gradient: "from-purple-500 via-purple-500 to-purple-500" },
  { text: "Learn Prompts", gradient: "from-slate-400 via-slate-400 to-slate-400" },
  { text: "Build Better", gradient: "from-slate-400 via-slate-400 to-slate-400" },
  { text: "Built on Base44", gradient: "from-orange-400 via-orange-500 to-orange-500" }
];

export default function WordSlider() {
  const [index, setIndex] = useState(0);
  const [key, setKey] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setIndex(prev => (prev + 1) % TEXTS.length);
      setKey(prev => prev + 1); // Force re-render for animation
    }, 5000);
    return () => clearTimeout(intervalId);
  }, []);

  const currentText = TEXTS[index];

  return (
    <span className="flex items-center gap-2 font-bold text-lg">
      <style>{`
        .custom-glitch-anim {
          animation: custom-glitch 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94) both;
        }
        @keyframes custom-glitch {
          0% { transform: translate(0); text-shadow: none; opacity: 0; }
          20% { opacity: 1; transform: translate(-2px, 1px); text-shadow: 2px 0 #00ffff, -2px 0 #a855f7; }
          40% { transform: translate(2px, -1px); text-shadow: -2px 0 #ffffff, 2px 0 #00ffff; }
          60% { transform: translate(-1px, 2px); text-shadow: 2px 0 #a855f7, -2px 0 #ffffff; }
          80% { transform: translate(1px, -2px); text-shadow: -2px 0 #00ffff, 2px 0 #a855f7; }
          100% { transform: translate(0); text-shadow: none; opacity: 1; }
        }
      `}</style>
      <span className="text-white">Team44</span>
      <div className="w-[180px] flex items-center overflow-visible"> 
        <span 
          key={key} 
          className={`custom-glitch-anim bg-clip-text text-transparent bg-gradient-to-r ${currentText.gradient} whitespace-nowrap`}
        >
          {currentText.text}
        </span>
      </div>
    </span>
  );
}