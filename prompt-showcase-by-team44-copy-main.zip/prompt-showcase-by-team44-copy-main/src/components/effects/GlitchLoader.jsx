import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export default function GlitchLoader({ isVisible, onComplete }) {
  const [showLoader, setShowLoader] = useState(isVisible);
  
  const { data: settings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || {};
    },
    initialData: {}
  });

  useEffect(() => {
    if (isVisible) {
      setShowLoader(true);
      const timer = setTimeout(() => {
        setShowLoader(false);
        onComplete?.();
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onComplete]);

  return (
    <AnimatePresence>
      {showLoader && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 z-[100] bg-slate-950 flex items-center justify-center"
        >
          <style>{`
            @keyframes glitch-clip {
              0%, 100% { clip-path: inset(0 0 98% 0); }
              10% { clip-path: inset(25% 0 58% 0); }
              20% { clip-path: inset(82% 0 2% 0); }
              30% { clip-path: inset(58% 0 15% 0); }
              40% { clip-path: inset(10% 0 68% 0); }
              50% { clip-path: inset(42% 0 42% 0); }
              60% { clip-path: inset(88% 0 5% 0); }
              70% { clip-path: inset(35% 0 52% 0); }
              80% { clip-path: inset(72% 0 18% 0); }
              90% { clip-path: inset(5% 0 90% 0); }
            }
            @keyframes glitch-shift {
              0%, 100% { transform: translateX(0); }
              10% { transform: translateX(-2px); }
              20% { transform: translateX(2px); }
              30% { transform: translateX(-1px); }
              40% { transform: translateX(1px); }
              50% { transform: translateX(-2px); }
              60% { transform: translateX(2px); }
              70% { transform: translateX(-1px); }
              80% { transform: translateX(1px); }
              90% { transform: translateX(-2px); }
            }
            .glitch-loader-main { position: relative; }
            .glitch-loader-layer {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
            }
            .glitch-loader-red {
              animation: glitch-clip 0.3s infinite linear, glitch-shift 0.2s infinite linear;
              filter: drop-shadow(-2px 0 #ff0000);
            }
            .glitch-loader-cyan {
              animation: glitch-clip 0.3s infinite linear reverse, glitch-shift 0.2s infinite linear reverse;
              filter: drop-shadow(2px 0 #00ffff);
            }
            .glitch-loader-scanlines {
              background: repeating-linear-gradient(
                0deg,
                rgba(0,0,0,0.15) 0px,
                rgba(0,0,0,0.15) 1px,
                transparent 1px,
                transparent 2px
              );
            }
          `}</style>

          <div className="relative">
            {/* Glitch Layers */}
            <div className="glitch-loader-main">
              {/* Main Logo */}
              <motion.div
                animate={{ 
                  scale: [1, 1.02, 1, 0.98, 1],
                  filter: ["brightness(1)", "brightness(1.5)", "brightness(1)", "brightness(0.8)", "brightness(1)"]
                }}
                transition={{ duration: 0.3, repeat: Infinity }}
                className="relative z-10"
              >
                {settings?.logo_url ? (
                  <img 
                    src={settings.logo_url} 
                    alt="Loading" 
                    className="w-20 h-20 rounded-2xl object-contain"
                  />
                ) : (
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center">
                    <span className="text-white text-3xl font-bold">B44</span>
                  </div>
                )}
              </motion.div>

              {/* Red Glitch Layer */}
              <div className="glitch-loader-layer glitch-loader-red opacity-70">
                {settings?.logo_url ? (
                  <img 
                    src={settings.logo_url} 
                    alt="" 
                    className="w-20 h-20 rounded-2xl object-contain"
                  />
                ) : (
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center">
                    <span className="text-white text-3xl font-bold">B44</span>
                  </div>
                )}
              </div>

              {/* Cyan Glitch Layer */}
              <div className="glitch-loader-layer glitch-loader-cyan opacity-70">
                {settings?.logo_url ? (
                  <img 
                    src={settings.logo_url} 
                    alt="" 
                    className="w-20 h-20 rounded-2xl object-contain"
                  />
                ) : (
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center">
                    <span className="text-white text-3xl font-bold">B44</span>
                  </div>
                )}
              </div>
            </div>

            {/* Scanlines Overlay */}
            <div className="absolute inset-0 glitch-loader-scanlines pointer-events-none rounded-2xl" />

            {/* Loading Text */}
            <motion.p
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 0.5, repeat: Infinity }}
              className="text-center mt-6 text-slate-400 text-sm font-mono tracking-wider"
            >
              LOADING...
            </motion.p>

            {/* Glitch Lines */}
            {[...Array(3)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute left-1/2 -translate-x-1/2 h-px bg-cyan-400"
                style={{ top: `${30 + i * 20}%`, width: `${60 + Math.random() * 40}%` }}
                animate={{ 
                  opacity: [0, 1, 0],
                  scaleX: [0, 1, 0],
                  x: ["-50%", `${-50 + (Math.random() - 0.5) * 20}%`, "-50%"]
                }}
                transition={{ 
                  duration: 0.2, 
                  repeat: Infinity, 
                  delay: i * 0.1,
                  repeatDelay: Math.random() * 0.5
                }}
              />
            ))}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}