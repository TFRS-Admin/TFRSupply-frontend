import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Code, Copy, Check, Wand2, Heart, Maximize2, Minimize2, MousePointerClick } from "lucide-react";
import ResponsivePreview from "./ResponsivePreview";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "react-router-dom";
import html2canvas from "html2canvas";

// Add global styles for glitch hover on light buttons
const glitchStyles = `
  .glitch-hover-btn:hover {
    animation: btn-glitch 0.3s ease-in-out;
  }
  @keyframes btn-glitch {
    0%, 100% { transform: translate(0); }
    10% { transform: translate(-1px, 1px); }
    20% { transform: translate(1px, -1px); }
    30% { transform: translate(-1px, 0); }
    40% { transform: translate(1px, 1px); }
    50% { transform: translate(0, -1px); }
  }
`;

export default function EffectCard({ 
  title, 
  description, 
  children, 
  className,
  controls,
  code = "",
  prompt = "",
  whenToUse = "",
  previewType = null,
  previewProps = {},
  interactive = false
}) {
  const location = useLocation();
  const currentPage = location.pathname.split('/').pop() || 'Home';
  const previewRef = useRef(null);
  const { data: appSettings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || {};
    },
    initialData: {}
  });
  
  const isResponsiveEnabled = appSettings?.enabled_features?.includes("responsivePreview");
  const [showResponsive, setShowResponsive] = useState(false);
  const [showCode, setShowCode] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [saved, setSaved] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [codeProgress, setCodeProgress] = useState(0);
  const [promptProgress, setPromptProgress] = useState(0);

  const defaultCode = code || `// ${title} Effect
import { motion } from "framer-motion";

export default function ${title.replace(/\s+/g, '')}() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="your-styles-here"
    >
      {/* Effect content */}
    </motion.div>
  );
}`;

  const defaultPrompt = prompt || `Create a ${title} effect using React, Tailwind CSS, and Framer Motion. ${description}`;

  // Check if already saved on mount
  useEffect(() => {
    const checkSaved = async () => {
      try {
        const user = await base44.auth.me().catch(() => null);
        if (user) {
          // Check DB
          const dbEffects = await base44.entities.SavedEffect.list();
          const isSaved = dbEffects.some(e => e.name === title);
          setSaved(isSaved);
        } else {
          // Check LocalStorage
          const savedEffects = JSON.parse(localStorage.getItem('savedEffects') || '[]');
          const isSaved = savedEffects.some(e => e.name === title);
          setSaved(isSaved);
        }
      } catch (e) {
        console.error("Error checking saved status", e.message || "Unknown error");
      }
    };
    
    checkSaved();
    // Listen for updates from other components (like Favorites page)
    window.addEventListener('favoritesUpdated', checkSaved);
    return () => window.removeEventListener('favoritesUpdated', checkSaved);
  }, [title]);

  const incrementCopyStat = () => {
    const stored = localStorage.getItem('appStats');
    const stats = stored ? JSON.parse(stored) : { viewed: 0, copied: 0 };
    stats.copied += 1;
    localStorage.setItem('appStats', JSON.stringify(stats));
    window.dispatchEvent(new Event('statCopied'));
  };

  const handleCopyCode = async () => {
    setCodeProgress(0);
    incrementCopyStat();
    const interval = setInterval(() => {
      setCodeProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          return 100;
        }
        return p + 10;
      });
    }, 30);
    await navigator.clipboard.writeText(defaultCode);
    setTimeout(() => {
      setCopiedCode(true);
      setTimeout(() => { setCopiedCode(false); setCodeProgress(0); }, 2000);
    }, 300);
  };

  const handleCopyPrompt = async () => {
    setPromptProgress(0);
    incrementCopyStat();
    const interval = setInterval(() => {
      setPromptProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          return 100;
        }
        return p + 10;
      });
    }, 30);
    await navigator.clipboard.writeText(defaultPrompt);
    setTimeout(() => {
      setCopiedPrompt(true);
      setTimeout(() => { setCopiedPrompt(false); setPromptProgress(0); }, 2000);
    }, 300);
  };

  const handleSave = async () => {
    if (isSaving) return;
    setIsSaving(true);

    try {
      const user = await base44.auth.me().catch(() => null);

      if (user) {
        // DB Logic
        const dbEffects = await base44.entities.SavedEffect.list();
        const existingEffect = dbEffects.find(e => e.name === title);

        if (existingEffect) {
          // Remove
          await base44.entities.SavedEffect.delete(existingEffect.id);
          setSaved(false);
        } else {
          // Capture screenshot
          let screenshot = null;
          if (previewRef.current) {
            try {
              const canvas = await html2canvas(previewRef.current, {
                backgroundColor: '#020617',
                scale: 2,
                logging: false,
                useCORS: true,
                ignoreElements: (element) => {
                  // Ignore potentially problematic SVG elements during capture if needed
                  return element.tagName === 'symbol' || element.tagName === 'defs';
                }
              });
              screenshot = canvas.toDataURL('image/png');
            } catch (error) {
              // Log only the message to avoid DataCloneError with DOM nodes in error objects
              console.error('Screenshot failed:', error.message);
            }
          }

          // Save
          await base44.entities.SavedEffect.create({
            name: title,
            description,
            code: defaultCode,
            prompt: defaultPrompt,
            savedAt: new Date().toISOString(),
            sourcePage: currentPage,
            anchor: title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
            preview: previewType ? { type: previewType, props: previewProps } : null,
            screenshot
          });
          setSaved(true);
        }
      } else {
        // LocalStorage Logic
        const savedEffects = JSON.parse(localStorage.getItem('savedEffects') || '[]');
        const existingIndex = savedEffects.findIndex(e => e.name === title);
        
        if (existingIndex >= 0) {
          savedEffects.splice(existingIndex, 1);
          setSaved(false);
          localStorage.setItem('savedEffects', JSON.stringify(savedEffects));
        } else {
          // Capture screenshot
          let screenshot = null;
          if (previewRef.current) {
            try {
              const canvas = await html2canvas(previewRef.current, {
                backgroundColor: '#020617',
                scale: 2,
                logging: false
              });
              screenshot = canvas.toDataURL('image/png');
            } catch (error) {
              console.error('Screenshot failed:', error);
            }
          }

          savedEffects.push({
            id: Date.now(),
            name: title,
            description,
            code: defaultCode,
            prompt: defaultPrompt,
            savedAt: new Date().toISOString(),
            sourcePage: currentPage,
            anchor: title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
            preview: previewType ? { type: previewType, props: previewProps } : null,
            screenshot
          });
          setSaved(true);
          localStorage.setItem('savedEffects', JSON.stringify(savedEffects));
        }
      }
      
      window.dispatchEvent(new Event('favoritesUpdated'));
    } catch (error) {
      // Avoid logging full error object if it contains DOM nodes (causes DataCloneError in some environments)
      console.error("Error saving effect:", error.message || "Unknown error");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      id={title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')}
      >
      <style>{glitchStyles}</style>
      <Card className={cn("bg-slate-900/75 border-slate-800 overflow-hidden group hover:border-slate-700 transition-colors", className)}>
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <CardTitle className="text-lg text-white truncate">{title}</CardTitle>
              <CardDescription className="text-slate-400">{description}</CardDescription>
              {whenToUse && (
                <div className="mt-2 flex items-start gap-2">
                  <span className="px-2 py-0.5 text-xs rounded bg-teal-500/20 text-teal-400 whitespace-nowrap">When to use</span>
                  <span className="text-xs text-slate-500 leading-relaxed">{whenToUse}</span>
                </div>
              )}
            </div>
            <div className="flex gap-1 flex-shrink-0">
              <button 
                onClick={handleSave} 
                disabled={isSaving}
                className={`p-2 rounded-lg transition-all duration-300 ${
                  saved 
                    ? "bg-red-500/20 text-red-500 hover:bg-red-500/30" 
                    : "text-slate-300 hover:bg-red-500 hover:text-white"
                }`} 
                title={saved ? "Remove from favorites" : "Save to favorites"}
              >
                {isSaving ? (
                  <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Heart className={`w-5 h-5 ${saved ? "fill-current" : ""}`} />
                )}
              </button>
              {isResponsiveEnabled && (
                <button onClick={() => setShowResponsive(!showResponsive)} className="p-2 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white transition-colors" title="Responsive">
                  {showResponsive ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {showResponsive ? (
            <ResponsivePreview>
              <div className="min-h-[300px] flex items-center justify-center p-6">{children}</div>
            </ResponsivePreview>
          ) : (
            <div ref={previewRef} className="relative min-h-[300px] rounded-xl bg-slate-950 border border-slate-800 overflow-hidden flex items-center justify-center p-6 group/preview">
              {children}
              {interactive && (
                <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-slate-900/80 border border-white/10 text-[10px] text-slate-400 opacity-0 group-hover/preview:opacity-100 transition-opacity duration-300 pointer-events-none select-none backdrop-blur-sm">
                  <MousePointerClick className="w-3 h-3" />
                  <span>Click to Interact</span>
                </div>
              )}
            </div>
          )}
          
          {controls && <div className="pt-2 border-t border-slate-800">{controls}</div>}

          {/* Action Buttons with Fill Animation */}
          <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
            {/* Copy Code Button - Cyan with dark text */}
            <motion.button
              onClick={handleCopyCode}
              className="relative flex-1 h-10 rounded-lg border-2 border-cyan-500 overflow-hidden group/btn glitch-hover-btn"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <motion.div
                className="absolute inset-0 bg-cyan-500"
                initial={{ width: "0%" }}
                animate={{ width: copiedCode ? "100%" : `${codeProgress}%` }}
                transition={{ duration: 0.1 }}
              />
              <span className={`relative z-10 flex items-center justify-center gap-1 text-xs font-medium transition-colors ${copiedCode || codeProgress > 50 ? "text-slate-900" : "text-cyan-400"}`}>
                {copiedCode ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copiedCode ? "Copied!" : "Copy Code"}
              </span>
            </motion.button>

            {/* Copy Prompt Button - Purple with dark text */}
            <motion.button
              onClick={handleCopyPrompt}
              className="relative flex-1 h-10 rounded-lg border-2 border-purple-500 overflow-hidden group/btn glitch-hover-btn"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <motion.div
                className="absolute inset-0 bg-purple-500"
                initial={{ width: "0%" }}
                animate={{ width: copiedPrompt ? "100%" : `${promptProgress}%` }}
                transition={{ duration: 0.1 }}
              />
              <span className={`relative z-10 flex items-center justify-center gap-1 text-xs font-medium transition-colors ${copiedPrompt || promptProgress > 50 ? "text-slate-900" : "text-purple-400"}`}>
                {copiedPrompt ? <Check className="w-3 h-3" /> : <Wand2 className="w-3 h-3" />}
                {copiedPrompt ? "Copied!" : "Copy Prompt"}
              </span>
            </motion.button>

            {/* View Code Button with dark text when active */}
            <motion.button
              onClick={() => setShowCode(!showCode)}
              className={`relative flex-1 h-10 rounded-lg border-2 overflow-hidden glitch-hover-btn ${showCode ? "border-slate-500 bg-slate-500" : "border-slate-600"}`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <span className={`flex items-center justify-center gap-1 text-xs font-medium ${showCode ? "text-slate-900" : "text-slate-300"}`}>
                <Code className="w-3 h-3" />
                {showCode ? "Hide" : "View Code"}
              </span>
            </motion.button>
          </div>

          <AnimatePresence>
            {showCode && (
              <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-cyan-400 mb-2">Code:</p>
                    <pre className="p-3 rounded-lg bg-slate-950 border border-slate-800 overflow-x-auto text-xs">
                      <code className="text-slate-300">{defaultCode}</code>
                    </pre>
                  </div>
                  <div>
                    <p className="text-xs text-purple-400 mb-2">AI Prompt:</p>
                    <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300">{defaultPrompt}</div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </motion.div>
  );
}