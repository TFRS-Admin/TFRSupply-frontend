import React, { useState } from "react";
import { motion } from "framer-motion";
import { Smartphone, Tablet, Monitor, Maximize2 } from "lucide-react";

const breakpoints = [
  { name: "Mobile", icon: Smartphone, width: 375 },
  { name: "Tablet", icon: Tablet, width: 768 },
  { name: "Desktop", icon: Monitor, width: 1024 },
  { name: "Full", icon: Maximize2, width: null }
];

export default function ResponsivePreview({ children }) {
  const [selectedBreakpoint, setSelectedBreakpoint] = useState(3);

  const currentBreakpoint = breakpoints[selectedBreakpoint];
  const displayWidth = currentBreakpoint.width || "100%";

  return (
    <div className="space-y-4">
      {/* Breakpoint Selector */}
      <div className="flex items-center gap-2 flex-wrap">
        {breakpoints.map((bp, index) => (
          <button
            key={bp.name}
            onClick={() => setSelectedBreakpoint(index)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
              selectedBreakpoint === index
                ? "bg-violet-500/20 text-violet-400 border border-violet-500/30"
                : "bg-slate-800 text-slate-400 hover:text-white border border-transparent"
            }`}
          >
            <bp.icon className="w-4 h-4" />
            <span>{bp.name}</span>
            {bp.width && (
              <span className="text-slate-500">({bp.width}px)</span>
            )}
          </button>
        ))}
      </div>

      {/* Preview Container */}
      <motion.div
        animate={{ width: displayWidth }}
        transition={{ type: "spring", bounce: 0, duration: 0.4 }}
        className="mx-auto border border-slate-700 rounded-xl overflow-hidden bg-slate-900"
        style={{ maxWidth: "100%" }}
      >
        {children}
      </motion.div>
    </div>
  );
}