import React from "react";
import { motion } from "framer-motion";

export default function GlitchButton({ children, className = "", onClick }) {
  return (
    <motion.button
      onClick={onClick}
      className={`relative overflow-hidden group ${className}`}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <style>{`
        @keyframes glitch-1 {
          0%, 100% { clip-path: inset(0 0 100% 0); transform: translate(0); }
          20% { clip-path: inset(20% 0 60% 0); transform: translate(-2px, 2px); }
          40% { clip-path: inset(40% 0 40% 0); transform: translate(2px, -2px); }
          60% { clip-path: inset(60% 0 20% 0); transform: translate(-2px, 2px); }
          80% { clip-path: inset(80% 0 0% 0); transform: translate(2px, -2px); }
        }
        @keyframes glitch-2 {
          0%, 100% { clip-path: inset(100% 0 0 0); transform: translate(0); }
          20% { clip-path: inset(60% 0 20% 0); transform: translate(2px, -2px); }
          40% { clip-path: inset(40% 0 40% 0); transform: translate(-2px, 2px); }
          60% { clip-path: inset(20% 0 60% 0); transform: translate(2px, -2px); }
          80% { clip-path: inset(0% 0 80% 0); transform: translate(-2px, 2px); }
        }
        .glitch-btn:hover .glitch-layer-1 {
          animation: glitch-1 0.3s linear infinite;
        }
        .glitch-btn:hover .glitch-layer-2 {
          animation: glitch-2 0.3s linear infinite;
        }
        .glitch-btn:hover {
          animation: glitch-shake 0.3s linear infinite;
        }
        @keyframes glitch-shake {
          0%, 100% { transform: translate(0); }
          10% { transform: translate(-1px, 1px); }
          20% { transform: translate(1px, -1px); }
          30% { transform: translate(-1px, -1px); }
          40% { transform: translate(1px, 1px); }
          50% { transform: translate(-1px, 1px); }
          60% { transform: translate(1px, -1px); }
          70% { transform: translate(-1px, -1px); }
          80% { transform: translate(1px, 1px); }
          90% { transform: translate(-1px, 1px); }
        }
      `}</style>
      
      {/* Base layer */}
      <span className="relative z-10">{children}</span>
      
      {/* Glitch layers */}
      <span 
        className="glitch-layer-1 absolute inset-0 flex items-center justify-center text-cyan-400 opacity-0 group-hover:opacity-80 pointer-events-none"
        aria-hidden="true"
        style={{ mixBlendMode: "screen" }}
      >
        {children}
      </span>
      <span 
        className="glitch-layer-2 absolute inset-0 flex items-center justify-center text-pink-400 opacity-0 group-hover:opacity-80 pointer-events-none"
        aria-hidden="true"
        style={{ mixBlendMode: "screen" }}
      >
        {children}
      </span>
      
      {/* Scan line overlay on hover */}
      <motion.div
        className="absolute inset-0 pointer-events-none opacity-0 group-hover:opacity-30"
        style={{
          background: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.1) 2px, rgba(0,0,0,0.1) 4px)"
        }}
      />
    </motion.button>
  );
}