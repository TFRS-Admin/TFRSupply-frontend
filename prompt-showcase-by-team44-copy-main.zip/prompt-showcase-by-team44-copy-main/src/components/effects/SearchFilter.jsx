import React from "react";
import { Search, Filter, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery } from "@tanstack/react-query";

const categories = [
  { id: "all", label: "All", color: "violet" },
  { id: "visual", label: "Visual", color: "violet" },
  { id: "audio", label: "Audio", color: "cyan" },
  { id: "transition", label: "Transitions", color: "pink" },
  { id: "navigation", label: "Navigation", color: "amber" },
  { id: "button", label: "Buttons", color: "emerald" },
  { id: "chat", label: "Chat", color: "blue" },
  { id: "agent", label: "AI Agent", color: "purple" },
  { id: "admin", label: "Admin", color: "slate" },
  { id: "marketing", label: "Marketing", color: "rose" },
  { id: "creative", label: "Creative", color: "fuchsia" },
  { id: "ecommerce", label: "E-commerce", color: "orange" },
  { id: "content", label: "Content", color: "teal" },
  { id: "communication", label: "Comms", color: "indigo" },
  { id: "social", label: "Social", color: "pink" },
  { id: "productivity", label: "Productivity", color: "green" },
  { id: "gaming", label: "Gaming", color: "red" },
];

export default function SearchFilter({ 
  searchQuery, 
  setSearchQuery, 
  activeCategory, 
  setActiveCategory,
  resultCount 
}) {
  return (
    <div className="space-y-4 mb-8">
      <style>{`
        .category-glitch:hover {
          animation: cat-glitch 0.3s ease-in-out;
        }
        @keyframes cat-glitch {
          0%, 100% { text-shadow: none; transform: translate(0); }
          20% { text-shadow: -1px 0 #ff00ff, 1px 0 #00ffff; transform: translate(-1px, 0); }
          40% { text-shadow: 1px 0 #ff00ff, -1px 0 #00ffff; transform: translate(1px, 0); }
          60% { text-shadow: -1px 0 #00ffff, 1px 0 #ff00ff; transform: translate(-1px, 0); }
          80% { text-shadow: 1px 0 #00ffff, -1px 0 #ff00ff; transform: translate(1px, 0); }
        }
      `}</style>
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <Input
          type="text"
          placeholder="Search effects by name or description..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-12 pr-10 py-6 bg-slate-900/50 border-slate-700 text-white placeholder:text-slate-500 rounded-xl"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery("")}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-slate-700 text-slate-400"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Category Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <Filter className="w-4 h-4 text-slate-400" />
        {categories.map((category) => (
          <motion.button
            key={category.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveCategory(category.id)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all category-glitch ${
              activeCategory === category.id
                ? `bg-black/70 border ${category.color.replace('bg-', 'border-')} text-white shadow-lg`
                : "bg-slate-800 text-slate-400 hover:text-white border border-transparent"
            }`}
            style={activeCategory === category.id ? { backdropFilter: "blur(2px)" } : {}}
          >
            {category.label}
          </motion.button>
        ))}
      </div>

      {/* Result Count */}
      <AnimatePresence>
        {(searchQuery || activeCategory !== "all") && (
          <motion.p
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="text-sm text-slate-400"
          >
            Found <span className="text-white font-semibold">{resultCount}</span> effects
            {searchQuery && <span> matching "{searchQuery}"</span>}
            {activeCategory !== "all" && (
              <span> in {categories.find(c => c.id === activeCategory)?.label}</span>
            )}
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}