import React, { useEffect, useRef, useState } from "react";
import Phaser from "phaser";

// Phaser Game 1: Simple Platformer
export function PhaserPlatformer() {
  const gameRef = useRef(null);
  const [game, setGame] = useState(null);

  useEffect(() => {
    if (!gameRef.current || game) return;

    const config = {
      type: Phaser.AUTO,
      width: 400,
      height: 300,
      parent: gameRef.current,
      backgroundColor: '#1e293b',
      physics: {
        default: 'arcade',
        arcade: { gravity: { y: 300 }, debug: false }
      },
      scene: {
        create: function() {
          // Ground
          const ground = this.add.rectangle(200, 280, 400, 40, 0x22c55e);
          this.physics.add.existing(ground, true);
          
          // Player
          const player = this.add.circle(50, 200, 20, 0x06b6d4);
          this.physics.add.existing(player);
          player.body.setBounce(0.2);
          player.body.setCollideWorldBounds(true);
          
          this.physics.add.collider(player, ground);
          
          // Movement
          this.input.keyboard.on('keydown-SPACE', () => {
            if (player.body.touching.down) player.body.setVelocityY(-250);
          });
          
          this.input.keyboard.on('keydown-LEFT', () => player.body.setVelocityX(-160));
          this.input.keyboard.on('keydown-RIGHT', () => player.body.setVelocityX(160));
          this.input.keyboard.on('keyup-LEFT', () => player.body.setVelocityX(0));
          this.input.keyboard.on('keyup-RIGHT', () => player.body.setVelocityX(0));
        }
      }
    };

    const newGame = new Phaser.Game(config);
    setGame(newGame);

    return () => {
      newGame.destroy(true);
    };
  }, []);

  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center bg-slate-950 rounded-lg p-4">
      <div ref={gameRef} className="rounded-lg overflow-hidden border-2 border-cyan-500/30" />
      <p className="text-xs text-cyan-400 mt-3">Use Arrow Keys + SPACE to play</p>
    </div>
  );
}

// Phaser Game 2: Particle System
export function PhaserParticles() {
  const gameRef = useRef(null);
  const [game, setGame] = useState(null);

  useEffect(() => {
    if (!gameRef.current || game) return;

    const config = {
      type: Phaser.AUTO,
      width: 400,
      height: 300,
      parent: gameRef.current,
      backgroundColor: '#0f172a',
      scene: {
        create: function() {
          // Create graphics object for particles
          const graphics = this.add.graphics();
          graphics.fillStyle(0xffffff);
          graphics.fillCircle(2, 2, 2);
          graphics.generateTexture('particle', 4, 4);
          graphics.destroy();
          
          // Create particle emitter with new API
          const emitter = this.add.particles(200, 150, 'particle', {
            speed: { min: -100, max: 100 },
            angle: { min: 0, max: 360 },
            scale: { start: 1, end: 0 },
            blendMode: 'ADD',
            lifespan: 1000,
            gravityY: -50,
            frequency: 50,
            tint: [0x8b5cf6, 0x06b6d4, 0x14b8a6]
          });
        }
      }
    };

    const newGame = new Phaser.Game(config);
    setGame(newGame);

    return () => {
      newGame.destroy(true);
    };
  }, []);

  return (
    <div className="w-full h-full min-h-[300px] flex items-center justify-center bg-slate-950 rounded-lg">
      <div ref={gameRef} className="rounded-lg overflow-hidden border-2 border-violet-500/30" />
    </div>
  );
}

// Phaser Game 3: Physics Simulation
export function PhaserPhysics() {
  const gameRef = useRef(null);
  const [game, setGame] = useState(null);

  useEffect(() => {
    if (!gameRef.current || game) return;

    const config = {
      type: Phaser.AUTO,
      width: 400,
      height: 300,
      parent: gameRef.current,
      backgroundColor: '#000000',
      physics: {
        default: 'arcade',
        arcade: { gravity: { y: 200 }, debug: false }
      },
      scene: {
        create: function() {
          const colors = [0xef4444, 0x3b82f6, 0x22c55e, 0xf59e0b, 0xa855f7];
          
          // Create falling balls on click
          this.input.on('pointerdown', (pointer) => {
            const ball = this.add.circle(pointer.x, pointer.y, 15, colors[Math.floor(Math.random() * colors.length)]);
            this.physics.add.existing(ball);
            ball.body.setBounce(0.7);
            ball.body.setCollideWorldBounds(true);
          });
        }
      }
    };

    const newGame = new Phaser.Game(config);
    setGame(newGame);

    return () => {
      newGame.destroy(true);
    };
  }, []);

  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center bg-slate-950 rounded-lg p-4">
      <div ref={gameRef} className="rounded-lg overflow-hidden border-2 border-emerald-500/30" />
      <p className="text-xs text-emerald-400 mt-3">Click to spawn physics balls</p>
    </div>
  );
}

// Phaser Game 4: Shooting Game
export function PhaserShooter() {
  const gameRef = useRef(null);
  const [game, setGame] = useState(null);

  useEffect(() => {
    if (!gameRef.current || game) return;

    const config = {
      type: Phaser.AUTO,
      width: 400,
      height: 300,
      parent: gameRef.current,
      backgroundColor: '#0a0a0f',
      physics: {
        default: 'arcade',
        arcade: { debug: false }
      },
      scene: {
        create: function() {
          // Player
          const player = this.add.circle(200, 250, 15, 0x06b6d4);
          this.physics.add.existing(player);
          player.body.setCollideWorldBounds(true);
          
          // Bullets group
          const bullets = this.physics.add.group();
          
          // Enemies group
          const enemies = this.physics.add.group();
          
          // Spawn enemies
          this.time.addEvent({
            delay: 1000,
            callback: () => {
              const enemy = this.add.circle(Math.random() * 360 + 20, 20, 12, 0xef4444);
              this.physics.add.existing(enemy);
              enemy.body.setVelocityY(50);
              enemies.add(enemy);
            },
            loop: true
          });
          
          // Shoot on click
          this.input.on('pointerdown', (pointer) => {
            const bullet = this.add.circle(player.x, player.y, 5, 0xfbbf24);
            this.physics.add.existing(bullet);
            bullet.body.setVelocityY(-400);
            bullets.add(bullet);
          });
          
          // Collision
          this.physics.add.overlap(bullets, enemies, (bullet, enemy) => {
            bullet.destroy();
            enemy.destroy();
          });
        }
      }
    };

    const newGame = new Phaser.Game(config);
    setGame(newGame);

    return () => {
      newGame.destroy(true);
    };
  }, []);

  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center bg-slate-950 rounded-lg p-4">
      <div ref={gameRef} className="rounded-lg overflow-hidden border-2 border-red-500/30" />
      <p className="text-xs text-red-400 mt-3">Click to shoot enemies</p>
    </div>
  );
}

// Phaser Game 5: Breakout
export function PhaserBreakout() {
  const gameRef = useRef(null);
  const [game, setGame] = useState(null);

  useEffect(() => {
    if (!gameRef.current || game) return;

    const config = {
      type: Phaser.AUTO,
      width: 400,
      height: 300,
      parent: gameRef.current,
      backgroundColor: '#1e293b',
      physics: {
        default: 'arcade',
        arcade: { debug: false }
      },
      scene: {
        create: function() {
          // Paddle
          const paddle = this.add.rectangle(200, 280, 80, 10, 0x06b6d4);
          this.physics.add.existing(paddle, true);
          
          // Ball
          const ball = this.add.circle(200, 200, 8, 0xfbbf24);
          this.physics.add.existing(ball);
          ball.body.setBounce(1);
          ball.body.setCollideWorldBounds(true);
          ball.body.setVelocity(150, -150);
          
          // Bricks
          const bricks = this.physics.add.staticGroup();
          for (let y = 0; y < 3; y++) {
            for (let x = 0; x < 8; x++) {
              const brick = this.add.rectangle(25 + x * 50, 40 + y * 25, 40, 20, 0x8b5cf6);
              bricks.add(brick);
            }
          }
          
          // Movement
          this.input.on('pointermove', (pointer) => {
            paddle.x = Phaser.Math.Clamp(pointer.x, 40, 360);
          });
          
          // Collisions
          this.physics.add.collider(ball, paddle);
          this.physics.add.collider(ball, bricks, (ball, brick) => {
            brick.destroy();
          });
        }
      }
    };

    const newGame = new Phaser.Game(config);
    setGame(newGame);

    return () => {
      newGame.destroy(true);
    };
  }, []);

  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center bg-slate-950 rounded-lg p-4">
      <div ref={gameRef} className="rounded-lg overflow-hidden border-2 border-purple-500/30" />
      <p className="text-xs text-purple-400 mt-3">Move mouse to control paddle</p>
    </div>
  );
}

// Phaser Game 6: Flappy Bird Clone
export function PhaserFlappy() {
  const gameRef = useRef(null);
  const [game, setGame] = useState(null);

  useEffect(() => {
    if (!gameRef.current || game) return;

    const config = {
      type: Phaser.AUTO,
      width: 400,
      height: 300,
      parent: gameRef.current,
      backgroundColor: '#0ea5e9',
      physics: {
        default: 'arcade',
        arcade: { gravity: { y: 600 }, debug: false }
      },
      scene: {
        create: function() {
          // Bird
          const bird = this.add.circle(100, 150, 15, 0xfbbf24);
          this.physics.add.existing(bird);
          bird.body.setCollideWorldBounds(true);
          
          // Flap on click
          this.input.on('pointerdown', () => {
            bird.body.setVelocityY(-250);
          });
          
          // Pipes
          const pipes = this.physics.add.group();
          
          this.time.addEvent({
            delay: 2000,
            callback: () => {
              const gap = 100;
              const gapY = Phaser.Math.Between(80, 200);
              
              const topPipe = this.add.rectangle(420, gapY - gap/2 - 100, 50, 200, 0x22c55e);
              const bottomPipe = this.add.rectangle(420, gapY + gap/2 + 100, 50, 200, 0x22c55e);
              
              pipes.add(topPipe);
              pipes.add(bottomPipe);
              
              this.physics.add.existing(topPipe, true);
              this.physics.add.existing(bottomPipe, true);
              
              topPipe.body.setVelocityX(-150);
              bottomPipe.body.setVelocityX(-150);
            },
            loop: true
          });
          
          this.physics.add.overlap(bird, pipes, () => {
            this.scene.restart();
          });
        }
      }
    };

    const newGame = new Phaser.Game(config);
    setGame(newGame);

    return () => {
      newGame.destroy(true);
    };
  }, []);

  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center bg-slate-950 rounded-lg p-4">
      <div ref={gameRef} className="rounded-lg overflow-hidden border-2 border-sky-500/30" />
      <p className="text-xs text-sky-400 mt-3">Click to flap</p>
    </div>
  );
}

// Phaser Game 7: Space Invaders
export function PhaserSpaceInvaders() {
  const gameRef = useRef(null);
  const [game, setGame] = useState(null);

  useEffect(() => {
    if (!gameRef.current || game) return;

    const config = {
      type: Phaser.AUTO,
      width: 400,
      height: 300,
      parent: gameRef.current,
      backgroundColor: '#000000',
      physics: {
        default: 'arcade',
        arcade: { debug: false }
      },
      scene: {
        create: function() {
          // Player ship
          const player = this.add.triangle(200, 270, 0, 20, 10, 0, 20, 20, 0x06b6d4);
          this.physics.add.existing(player);
          player.body.setCollideWorldBounds(true);
          
          // Enemies
          const enemies = this.physics.add.group();
          for (let row = 0; row < 3; row++) {
            for (let col = 0; col < 8; col++) {
              const enemy = this.add.rectangle(30 + col * 45, 30 + row * 35, 25, 20, 0xef4444);
              this.physics.add.existing(enemy);
              enemies.add(enemy);
            }
          }
          
          // Bullets
          const bullets = this.physics.add.group();
          
          // Movement
          this.input.on('pointermove', (pointer) => {
            player.x = pointer.x;
          });
          
          this.input.on('pointerdown', () => {
            const bullet = this.add.rectangle(player.x, player.y - 20, 3, 10, 0xfbbf24);
            this.physics.add.existing(bullet);
            bullet.body.setVelocityY(-300);
            bullets.add(bullet);
          });
          
          this.physics.add.overlap(bullets, enemies, (bullet, enemy) => {
            bullet.destroy();
            enemy.destroy();
          });
        }
      }
    };

    const newGame = new Phaser.Game(config);
    setGame(newGame);

    return () => {
      newGame.destroy(true);
    };
  }, []);

  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center bg-slate-950 rounded-lg p-4">
      <div ref={gameRef} className="rounded-lg overflow-hidden border-2 border-red-500/30" />
      <p className="text-xs text-red-400 mt-3">Move mouse & click to shoot</p>
    </div>
  );
}

// Phaser Game 8: Collision Demo
export function PhaserCollision() {
  const gameRef = useRef(null);
  const [game, setGame] = useState(null);

  useEffect(() => {
    if (!gameRef.current || game) return;

    const config = {
      type: Phaser.AUTO,
      width: 400,
      height: 300,
      parent: gameRef.current,
      backgroundColor: '#1e293b',
      physics: {
        default: 'arcade',
        arcade: { gravity: { y: 0 }, debug: false }
      },
      scene: {
        create: function() {
          const ball1 = this.add.circle(100, 150, 20, 0x8b5cf6);
          const ball2 = this.add.circle(300, 150, 20, 0x06b6d4);
          
          this.physics.add.existing(ball1);
          this.physics.add.existing(ball2);
          
          ball1.body.setVelocity(100, 50);
          ball2.body.setVelocity(-80, -30);
          
          ball1.body.setBounce(1);
          ball2.body.setBounce(1);
          
          ball1.body.setCollideWorldBounds(true);
          ball2.body.setCollideWorldBounds(true);
          
          this.physics.add.collider(ball1, ball2, () => {
            ball1.setFillStyle(0xfbbf24);
            ball2.setFillStyle(0xfbbf24);
            
            this.time.delayedCall(200, () => {
              ball1.setFillStyle(0x8b5cf6);
              ball2.setFillStyle(0x06b6d4);
            });
          });
        }
      }
    };

    const newGame = new Phaser.Game(config);
    setGame(newGame);

    return () => {
      newGame.destroy(true);
    };
  }, []);

  return (
    <div className="w-full h-full min-h-[300px] flex items-center justify-center bg-slate-950 rounded-lg">
      <div ref={gameRef} className="rounded-lg overflow-hidden border-2 border-violet-500/30" />
    </div>
  );
}

// Phaser Game 9: Sprite Movement
export function PhaserSpriteMove() {
  const gameRef = useRef(null);
  const [game, setGame] = useState(null);

  useEffect(() => {
    if (!gameRef.current || game) return;

    const config = {
      type: Phaser.AUTO,
      width: 400,
      height: 300,
      parent: gameRef.current,
      backgroundColor: '#334155',
      physics: {
        default: 'arcade',
        arcade: { debug: false }
      },
      scene: {
        create: function() {
          const sprite = this.add.rectangle(200, 150, 30, 30, 0x22c55e);
          this.physics.add.existing(sprite);
          
          const cursors = this.input.keyboard.createCursorKeys();
          
          this.events.on('update', () => {
            sprite.body.setVelocity(0);
            
            if (cursors.left.isDown) sprite.body.setVelocityX(-160);
            if (cursors.right.isDown) sprite.body.setVelocityX(160);
            if (cursors.up.isDown) sprite.body.setVelocityY(-160);
            if (cursors.down.isDown) sprite.body.setVelocityY(160);
          });
        }
      }
    };

    const newGame = new Phaser.Game(config);
    setGame(newGame);

    return () => {
      newGame.destroy(true);
    };
  }, []);

  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center bg-slate-950 rounded-lg p-4">
      <div ref={gameRef} className="rounded-lg overflow-hidden border-2 border-green-500/30" />
      <p className="text-xs text-green-400 mt-3">Use arrow keys to move</p>
    </div>
  );
}

// Phaser Game 10: Click & Explode
export function PhaserExplosion() {
  const gameRef = useRef(null);
  const [game, setGame] = useState(null);

  useEffect(() => {
    if (!gameRef.current || game) return;

    const config = {
      type: Phaser.AUTO,
      width: 400,
      height: 300,
      parent: gameRef.current,
      backgroundColor: '#0f172a',
      scene: {
        create: function() {
          // Create graphics object for particles
          const graphics = this.add.graphics();
          graphics.fillStyle(0xffffff);
          graphics.fillCircle(3, 3, 3);
          graphics.generateTexture('explosion', 6, 6);
          graphics.destroy();
          
          this.input.on('pointerdown', (pointer) => {
            // Create explosion particles with new API
            const emitter = this.add.particles(pointer.x, pointer.y, 'explosion', {
              speed: { min: 100, max: 300 },
              angle: { min: 0, max: 360 },
              scale: { start: 1, end: 0 },
              blendMode: 'ADD',
              lifespan: 800,
              tint: [0xef4444, 0xf97316, 0xfbbf24],
              emitting: false
            });
            
            emitter.explode(30);
          });
        }
      }
    };

    const newGame = new Phaser.Game(config);
    setGame(newGame);

    return () => {
      newGame.destroy(true);
    };
  }, []);

  return (
    <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center bg-slate-950 rounded-lg p-4">
      <div ref={gameRef} className="rounded-lg overflow-hidden border-2 border-orange-500/30" />
      <p className="text-xs text-orange-400 mt-3">Click anywhere to explode</p>
    </div>
  );
}