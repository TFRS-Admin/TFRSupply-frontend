import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

// ===== REACT GAMEKIT COMPONENTS (70 Components) =====

// 1. Sprite Animation
export function SpriteAnimation() {
  const [frame, setFrame] = useState(0);
  useEffect(() => { const i = setInterval(() => setFrame(f => (f + 1) % 4), 150); return () => clearInterval(i); }, []);
  const frames = ["🚶", "🏃", "🚶", "🏃"];
  return <div className="w-full h-full min-h-[300px] flex items-center justify-center bg-slate-900 rounded"><motion.span className="text-6xl" key={frame} initial={{ x: -10 }} animate={{ x: 10 }}>{frames[frame]}</motion.span></div>;
}

// 2. Jump Physics
export function JumpPhysics({ showcase }) {
  const [jumping, setJumping] = useState(false);
  const handleJump = () => { if (!jumping) { setJumping(true); setTimeout(() => setJumping(false), 800); } };
  useEffect(() => { if (showcase) { const i = setInterval(handleJump, 2000); return () => clearInterval(i); } }, [showcase, jumping]);
  return <div onClick={handleJump} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-end justify-center cursor-pointer relative overflow-hidden"><div className="absolute bottom-0 w-full h-8 bg-green-700" /><motion.div className="text-6xl mb-8" animate={jumping ? { y: [-20, -150, -20] } : {}} transition={{ duration: 0.8 }}>🏃</motion.div><p className="absolute top-4 left-4 text-xs text-white bg-black/50 px-2 py-1 rounded">Click to jump</p></div>;
}

// 3. Collision Detection
export function CollisionDetection() {
  const [pos, setPos] = useState(30);
  const [dir, setDir] = useState(1);
  const [hit, setHit] = useState(false);
  useEffect(() => {
    const i = setInterval(() => {
      setPos(p => {
        const newPos = p + dir * 2;
        if (newPos >= 70 || newPos <= 10) { setDir(d => -d); setHit(true); setTimeout(() => setHit(false), 100); return newPos >= 70 ? 70 : 10; }
        return newPos;
      });
    }, 30);
    return () => clearInterval(i);
  }, [dir]);
  return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative"><motion.div className="absolute top-1/2 -translate-y-1/2 text-5xl" animate={{ left: `${pos}%`, scale: hit ? 0.8 : 1 }}>🎯</motion.div><div className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-40 bg-red-500/30 border-2 border-red-500" /><div className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-40 bg-red-500/30 border-2 border-red-500" /></div>;
}

// 4. Gravity System
export function GravitySystem() {
  const [y, setY] = useState(0);
  const [velocity, setVelocity] = useState(0);
  useEffect(() => { const i = setInterval(() => { setVelocity(v => v + 0.5); setY(yPos => { const newY = yPos + velocity; return newY >= 80 ? (setVelocity(-velocity * 0.7), 80) : newY; }); }, 30); return () => clearInterval(i); }, [velocity]);
  return <div className="w-full h-full bg-slate-900 rounded relative overflow-hidden"><div className="absolute bottom-0 w-full h-2 bg-slate-700" /><motion.div className="absolute text-3xl" style={{ top: `${y}%`, left: "45%" }}>⚽</motion.div></div>;
}

// 5. Platformer Character
export function PlatformerCharacter() {
  const [x, setX] = useState(50);
  const [flipped, setFlipped] = useState(false);
  useEffect(() => { const handleKey = (e) => { if (e.key === "ArrowLeft") { setX(p => Math.max(5, p - 5)); setFlipped(true); } if (e.key === "ArrowRight") { setX(p => Math.min(95, p + 5)); setFlipped(false); } }; window.addEventListener("keydown", handleKey); return () => window.removeEventListener("keydown", handleKey); }, []);
  return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-blue-900 to-slate-900 rounded relative"><div className="absolute bottom-0 w-full h-8 bg-green-700" /><motion.div className="absolute bottom-8 text-6xl" animate={{ left: `${x}%` }} style={{ transform: flipped ? "scaleX(-1)" : "scaleX(1)" }}>🦸</motion.div><p className="absolute top-4 left-4 text-xs text-white bg-black/50 px-2 py-1 rounded">Use ← → keys</p></div>;
}

// 6. Item Spawner
export function ItemSpawner() {
  const [items, setItems] = useState([]);
  useEffect(() => { const i = setInterval(() => { const id = Date.now(); setItems(its => [...its, { id, x: Math.random() * 80 + 10, y: -10 }]); setTimeout(() => setItems(its => its.filter(it => it.id !== id)), 2000); }, 800); return () => clearInterval(i); }, []);
  return <div className="w-full h-full min-h-[300px] bg-slate-950 rounded relative overflow-hidden">{items.map(it => <motion.div key={it.id} className="absolute text-2xl" initial={{ x: `${it.x}%`, y: it.y }} animate={{ y: 130 }} transition={{ duration: 2 }}>💎</motion.div>)}</div>;
}

// 7. Parallax Background
export function ParallaxBackground() {
  const [scroll, setScroll] = useState(0);
  useEffect(() => { const i = setInterval(() => setScroll(s => (s + 0.5) % 100), 30); return () => clearInterval(i); }, []);
  return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative overflow-hidden"><motion.div className="absolute inset-0 opacity-40" style={{ backgroundImage: "repeating-linear-gradient(90deg, #334155 0px, #334155 40px, transparent 40px, transparent 80px)", backgroundPositionX: `-${scroll}%` }} /><motion.div className="absolute inset-0 opacity-20" style={{ backgroundImage: "repeating-linear-gradient(90deg, #475569 0px, #475569 60px, transparent 60px, transparent 120px)", backgroundPositionX: `-${scroll * 0.5}%` }} /></div>;
}

// 8. Enemy AI Patrol
export function EnemyAIPatrol() {
  const [x, setX] = useState(10);
  const [dir, setDir] = useState(1);
  useEffect(() => { const i = setInterval(() => setX(p => { if (p >= 85) setDir(-1); if (p <= 10) setDir(1); return p + dir * 1.5; }), 30); return () => clearInterval(i); }, [dir]);
  return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative"><motion.div className="absolute top-1/2 -translate-y-1/2 text-6xl" animate={{ left: `${x}%`, scaleX: dir === 1 ? 1 : -1 }}>👾</motion.div><p className="absolute top-4 left-4 text-xs text-red-400 bg-black/50 px-2 py-1 rounded">Auto patrolling</p></div>;
}

// 9. Projectile System
export function ProjectileSystem({ showcase }) {
  const [bullets, setBullets] = useState([]);
  const shoot = () => { const id = Date.now(); setBullets(b => [...b, { id, x: 10 }]); setTimeout(() => setBullets(b => b.filter(bu => bu.id !== id)), 1000); };
  useEffect(() => { if (showcase) { const i = setInterval(shoot, 800); return () => clearInterval(i); } }, [showcase]);
  return <div onClick={shoot} className="w-full h-full min-h-[300px] bg-slate-900 rounded cursor-pointer relative"><div className="absolute left-8 top-1/2 -translate-y-1/2 text-6xl">🔫</div>{bullets.map(b => <motion.div key={b.id} className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-yellow-400 rounded-full" style={{ boxShadow: "0 0 10px #facc15" }} initial={{ left: "15%" }} animate={{ left: "95%" }} transition={{ duration: 1 }} />)}<p className="absolute top-4 right-4 text-xs text-yellow-400 bg-black/50 px-2 py-1 rounded">Click to shoot</p></div>;
}

// 10. Double Jump
export function DoubleJump({ showcase }) {
  const [y, setY] = useState(80);
  const [jumps, setJumps] = useState(0);
  const handleJump = () => { if (jumps < 2) { setY(20); setJumps(j => j + 1); setTimeout(() => { setY(80); if (jumps === 1) setJumps(0); }, 500); } };
  useEffect(() => { if (showcase) { const i = setInterval(handleJump, 1000); return () => clearInterval(i); } }, [showcase, jumps]);
  return <div onClick={handleJump} className="w-full h-full min-h-[300px] bg-gradient-to-b from-sky-900 to-slate-900 rounded relative cursor-pointer"><motion.div className="absolute text-3xl" animate={{ left: "45%", top: `${y}%` }}>🤸</motion.div><div className="absolute bottom-0 w-full h-2 bg-slate-700" /><p className="absolute top-2 left-2 text-xs text-white">Jumps: {jumps}/2</p></div>;
}

// 11. Score Multiplier
export function ScoreMultiplier() {
  const [mult, setMult] = useState(1);
  const [score, setScore] = useState(0);
  useEffect(() => { const i = setInterval(() => { setScore(s => s + 10 * mult); setMult(m => m < 8 ? m + 0.5 : 1); }, 500); return () => clearInterval(i); }, [mult]);
  return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center"><motion.p className="text-5xl font-black text-yellow-400" key={Math.floor(score / 100)}>{score}</motion.p><p className="text-sm text-white mt-2">x{mult.toFixed(1)} Multiplier</p></div>;
}

// 12. Dash Attack
export function DashAttack({ showcase }) {
  const [dashing, setDashing] = useState(false);
  const [x, setX] = useState(20);
  const dash = () => { setDashing(true); setX(80); setTimeout(() => { setDashing(false); setX(20); }, 400); };
  useEffect(() => { if (showcase) { const i = setInterval(dash, 1500); return () => clearInterval(i); } }, [showcase]);
  return <div onClick={dash} className="w-full h-full min-h-[300px] bg-slate-900 rounded relative cursor-pointer">{dashing && <motion.div className="absolute inset-0 bg-cyan-500/30" initial={{ opacity: 0 }} animate={{ opacity: [0, 0.5, 0] }} transition={{ duration: 0.4 }} />}<motion.div className="absolute top-1/2 -translate-y-1/2 text-3xl" animate={{ left: `${x}%` }} transition={{ duration: dashing ? 0.3 : 0.5 }}>{dashing ? "💨" : "🏃"}</motion.div></div>;
}

// 13. Shield/Block System
export function ShieldBlock({ showcase }) {
  const [blocking, setBlocking] = useState(false);
  useEffect(() => { if (showcase) { const i = setInterval(() => { setBlocking(true); setTimeout(() => setBlocking(false), 1000); }, 2000); return () => clearInterval(i); } }, [showcase]);
  return <div onMouseDown={() => setBlocking(true)} onMouseUp={() => setBlocking(false)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative">{blocking && <motion.div className="absolute inset-0 border-4 border-blue-500 rounded" initial={{ scale: 0.8 }} animate={{ scale: 1.05 }} />}<span className="text-5xl">{blocking ? "🛡️" : "⚔️"}</span><p className="absolute bottom-2 text-xs text-slate-500">{blocking ? "BLOCKING!" : "Hold to block"}</p></div>;
}

// 14. Charge Attack
export function ChargeAttack({ showcase }) {
  const [charge, setCharge] = useState(0);
  const [charging, setCharging] = useState(false);
  useEffect(() => { if (charging && charge < 100) { const i = setInterval(() => setCharge(c => Math.min(100, c + 5)), 50); return () => clearInterval(i); } if (!charging && charge > 0) setCharge(0); }, [charging, charge]);
  useEffect(() => { if (showcase) { const i = setInterval(() => { setCharging(true); setTimeout(() => setCharging(false), 2000); }, 3000); return () => clearInterval(i); } }, [showcase]);
  return <div onMouseDown={() => setCharging(true)} onMouseUp={() => setCharging(false)} className="w-full h-full min-h-[300px] bg-black rounded flex flex-col items-center justify-center cursor-pointer gap-2"><span className="text-4xl">⚡</span><div className="w-48 h-3 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-gradient-to-r from-yellow-500 to-orange-500" animate={{ width: `${charge}%` }} style={{ boxShadow: charge > 50 ? "0 0 15px #f59e0b" : "none" }} /></div><p className="text-xs text-white">{charge === 100 ? "FULLY CHARGED!" : charging ? "Charging..." : "Hold to charge"}</p></div>;
}

// 15. Inventory Slot
export function InventorySlot() {
  const [item, setItem] = useState("🗡️");
  const items = ["🗡️", "🛡️", "🧪", "📜", "💎", "🔮"];
  const cycle = () => setItem(items[(items.indexOf(item) + 1) % items.length]);
  return <div onClick={cycle} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer"><motion.div className="w-20 h-20 border-2 border-amber-500 bg-amber-500/10 rounded-xl flex items-center justify-center" whileHover={{ scale: 1.1 }}><span className="text-4xl">{item}</span></motion.div></div>;
}

// 16. Quest Marker
export function QuestMarker() {
  const [active, setActive] = useState(true);
  return <div onClick={() => setActive(!active)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative">{active && <motion.div className="absolute" animate={{ y: [-10, 10, -10] }} transition={{ duration: 1.5, repeat: Infinity }}><span className="text-5xl">❗</span></motion.div>}<p className="absolute bottom-2 text-xs text-slate-500">{active ? "Active Quest" : "Completed"}</p></div>;
}

// 17. Waypoint Navigation
export function WaypointNavigation() {
  const [current, setCurrent] = useState(0);
  const points = [20, 40, 60, 80];
  useEffect(() => { const i = setInterval(() => setCurrent(c => (c + 1) % points.length), 1500); return () => clearInterval(i); }, []);
  return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative">{points.map((p, i) => <div key={i} className={`absolute top-1/2 -translate-y-1/2 w-4 h-4 rounded-full ${i === current ? "bg-cyan-400" : "bg-slate-600"}`} style={{ left: `${p}%` }} />)}<motion.div className="absolute top-1/2 -translate-y-1/2 text-2xl" animate={{ left: `${points[current]}%` }} transition={{ duration: 0.8 }}>🚶</motion.div></div>;
}

// 18. Minimap
export function Minimap() {
  const [playerPos, setPlayerPos] = useState({ x: 50, y: 50 });
  useEffect(() => { const i = setInterval(() => setPlayerPos({ x: 20 + Math.random() * 60, y: 20 + Math.random() * 60 }), 1000); return () => clearInterval(i); }, []);
  return <div className="w-full h-full min-h-[300px] flex items-center justify-center bg-black rounded"><div className="relative w-24 h-24 bg-slate-800 border-2 border-green-500"><div className="absolute inset-0 opacity-30" style={{ backgroundImage: "linear-gradient(#22c55e 1px, transparent 1px), linear-gradient(90deg, #22c55e 1px, transparent 1px)", backgroundSize: "12px 12px" }} /><motion.div className="absolute w-2 h-2 bg-blue-500 rounded-full" animate={{ left: `${playerPos.x}%`, top: `${playerPos.y}%` }} /></div></div>;
}

// 19. Resource Counter
export function ResourceCounter() {
  const [gold, setGold] = useState(0);
  useEffect(() => { const i = setInterval(() => setGold(g => g + Math.floor(Math.random() * 10)), 500); return () => clearInterval(i); }, []);
  return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center gap-3"><span className="text-4xl">🪙</span><motion.span className="text-4xl font-black text-yellow-400" key={Math.floor(gold / 50)}>{gold}</motion.span></div>;
}

// 20. Skill Cooldown
export function SkillCooldown() {
  const [cd, setCd] = useState(0);
  const use = () => { if (cd === 0) setCd(100); };
  useEffect(() => { if (cd > 0) { const i = setInterval(() => setCd(c => Math.max(0, c - 2)), 30); return () => clearInterval(i); } }, [cd]);
  return <div onClick={use} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative"><div className="relative w-20 h-20"><svg className="w-full h-full -rotate-90"><circle cx="40" cy="40" r="35" fill="none" stroke="#1e293b" strokeWidth="8" /><motion.circle cx="40" cy="40" r="35" fill="none" stroke="#8b5cf6" strokeWidth="8" strokeDasharray={220} animate={{ strokeDashoffset: 220 - (cd / 100) * 220 }} /></svg><span className="absolute inset-0 flex items-center justify-center text-2xl">🔥</span></div><p className="absolute bottom-2 text-xs text-white">{cd > 0 ? `${(cd / 10).toFixed(1)}s` : "Ready!"}</p></div>;
}

// 21-70: Additional components (condensed for brevity - each would have full implementation)
export function DamageFlash() { const [hit, setHit] = useState(false); useEffect(() => { const i = setInterval(() => { setHit(true); setTimeout(() => setHit(false), 100); }, 2000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative">{hit && <div className="absolute inset-0 bg-red-500/50" />}<span className="text-5xl relative z-10">🤺</span></div>; }
export function ComboChain() { const [combo, setCombo] = useState(0); const hit = () => setCombo(c => c + 1); useEffect(() => { if (combo > 0) { const t = setTimeout(() => setCombo(0), 2000); return () => clearTimeout(t); } }, [combo]); return <div onClick={hit} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer"><motion.p className="text-5xl font-black text-orange-400" key={combo} initial={{ scale: 1.5 }} animate={{ scale: 1 }}>{combo > 0 ? `${combo}x` : "TAP!"}</motion.p></div>; }
export function StealthMeter() { const [stealth, setStealth] = useState(0); useEffect(() => { const i = setInterval(() => setStealth(s => (s + 5) % 101), 200); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-4xl">{stealth > 70 ? "👁️" : "🥷"}</span><div className="w-48 h-3 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-gradient-to-r from-purple-600 to-indigo-600" animate={{ width: `${stealth}%` }} /></div><p className="text-xs text-white">{stealth > 70 ? "DETECTED!" : "Hidden"}</p></div>; }
export function QTEPrompt() { const [active, setActive] = useState(false); useEffect(() => { const i = setInterval(() => { setActive(true); setTimeout(() => setActive(false), 2000); }, 4000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center">{active && <motion.div initial={{ scale: 0 }} animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 0.5 }} className="px-6 py-3 bg-red-600 rounded-xl text-white font-bold text-xl border-4 border-white">PRESS E!</motion.div>}</div>; }
export function LevelUpBurst() { const [show, setShow] = useState(false); useEffect(() => { const i = setInterval(() => { setShow(true); setTimeout(() => setShow(false), 2000); }, 5000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center relative overflow-hidden">{show && <><motion.div className="absolute inset-0 bg-gradient-to-r from-yellow-500/50 via-transparent to-yellow-500/50" initial={{ x: "-100%" }} animate={{ x: "100%" }} transition={{ duration: 0.5 }} /><motion.p className="text-4xl font-black text-yellow-400" initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }}>LEVEL UP!</motion.p></>}</div>; }
export function BossIntro() { const [phase, setPhase] = useState(0); useEffect(() => { const seq = [0, 1000, 2000]; seq.forEach((t, i) => setTimeout(() => setPhase(i), t)); const reset = setTimeout(() => setPhase(0), 4000); return () => clearTimeout(reset); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center">{phase === 0 && <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-white text-xl">A challenger approaches...</motion.p>}{phase === 1 && <motion.span initial={{ scale: 3, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-6xl">👹</motion.span>}{phase === 2 && <motion.p initial={{ y: 50 }} animate={{ y: 0 }} className="text-red-500 text-2xl font-bold">DEMON LORD</motion.p>}</div>; }
export function CheckpointFlag() { const [saved, setSaved] = useState(false); return <div onClick={() => setSaved(true)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative"><motion.span className="text-5xl" animate={saved ? { rotate: [0, 10, -10, 0] } : {}} transition={{ duration: 0.3 }}>🚩</motion.span>{saved && <p className="absolute bottom-2 text-green-400 text-sm">✓ Checkpoint Saved!</p>}</div>; }
export function GameTimer() { const [time, setTime] = useState(60); useEffect(() => { if (time > 0) { const i = setInterval(() => setTime(t => t - 1), 1000); return () => clearInterval(i); } }, [time]); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center"><motion.p className={`text-5xl font-mono font-black ${time < 10 ? "text-red-500 animate-pulse" : "text-white"}`} key={Math.floor(time / 10)}>{time}s</motion.p></div>; }
export function WaveCounter() { const [wave, setWave] = useState(1); useEffect(() => { const i = setInterval(() => setWave(w => w + 1), 3000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-red-950 to-black rounded flex flex-col items-center justify-center gap-2"><motion.p key={wave} initial={{ scale: 2, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-5xl font-black text-red-400">WAVE {wave}</motion.p><p className="text-xs text-slate-500">Prepare for battle!</p></div>; }
export function ManaBar() { const [mana, setMana] = useState(100); useEffect(() => { const i = setInterval(() => setMana(m => m <= 0 ? 100 : m - 3), 100); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-3xl">🔮</span><div className="w-48 h-4 bg-slate-800 rounded-full overflow-hidden border border-blue-500"><motion.div className="h-full bg-gradient-to-r from-blue-500 to-purple-500" animate={{ width: `${mana}%` }} style={{ boxShadow: "0 0 10px #3b82f6" }} /></div><p className="text-xs text-blue-400">{mana}/100 MP</p></div>; }
export function CriticalHit() { const [crit, setCrit] = useState(false); useEffect(() => { const i = setInterval(() => { if (Math.random() > 0.7) { setCrit(true); setTimeout(() => setCrit(false), 500); } }, 1500); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative">{crit && <><motion.div className="absolute inset-0 bg-yellow-500/30" initial={{ scale: 0 }} animate={{ scale: 1.5, opacity: 0 }} /><motion.p className="text-6xl font-black text-yellow-400" initial={{ scale: 0, rotate: -45 }} animate={{ scale: 1, rotate: 0 }}>CRIT!</motion.p></>}</div>; }
export function DialogueBox() { const [text, setText] = useState(""); const msg = "Welcome, brave adventurer!"; useEffect(() => { let i = 0; const interval = setInterval(() => { if (i < msg.length) { setText(msg.slice(0, i + 1)); i++; } else { setTimeout(() => { setText(""); i = 0; }, 2000); } }, 100); return () => clearInterval(interval); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative"><div className="absolute bottom-3 left-3 right-3 bg-black/90 border-2 border-white p-3 rounded"><p className="text-white text-sm font-mono">{text}<span className="animate-pulse">▮</span></p></div></div>; }
export function BuffIcon() { const [buffs, setBuffs] = useState(["⚡", "🛡️", "🔥"]); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center gap-2">{buffs.map((b, i) => <motion.div key={i} initial={{ scale: 0 }} animate={{ scale: 1, y: [0, -5, 0] }} transition={{ delay: i * 0.2, y: { duration: 1, repeat: Infinity } }} className="w-12 h-12 bg-slate-800 border-2 border-violet-500 rounded-lg flex items-center justify-center text-2xl">{b}</motion.div>)}</div>; }
export function DebuffTimer() { const [time, setTime] = useState(10); useEffect(() => { if (time > 0) { const i = setInterval(() => setTime(t => t - 1), 1000); return () => clearInterval(i); } }, [time]); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center gap-3"><span className="text-4xl opacity-50">🤢</span><p className="text-2xl font-mono text-purple-400">{time}s</p></div>; }
export function RarityGlow() { const rarities = [{ name: "Common", glow: "#9ca3af" }, { name: "Rare", glow: "#3b82f6" }, { name: "Epic", glow: "#a855f7" }, { name: "Legendary", glow: "#f59e0b" }]; const [r, setR] = useState(0); useEffect(() => { const i = setInterval(() => setR(ri => (ri + 1) % rarities.length), 2000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex flex-col items-center justify-center gap-2"><motion.div key={r} initial={{ scale: 0 }} animate={{ scale: 1 }} className="w-16 h-16 rounded-xl border-2 flex items-center justify-center text-3xl" style={{ borderColor: rarities[r].glow, boxShadow: `0 0 20px ${rarities[r].glow}` }}>💎</motion.div><p className="text-sm" style={{ color: rarities[r].glow }}>{rarities[r].name}</p></div>; }
export function TreasureChest({ showcase }) { const [open, setOpen] = useState(false); useEffect(() => { if (showcase) { const i = setInterval(() => setOpen(o => !o), 2000); return () => clearInterval(i); } }, [showcase]); return <div onClick={() => setOpen(!open)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative"><motion.span className="text-5xl" animate={open ? { rotateY: 180 } : {}} transition={{ duration: 0.5 }}>{open ? "📬" : "📦"}</motion.span>{open && <motion.div initial={{ scale: 0, y: 0 }} animate={{ scale: 1, y: -20 }} className="absolute text-3xl">✨💎✨</motion.div>}</div>; }
export function WeaponSwitch() { const weapons = ["🗡️", "🏹", "🔫", "⚔️"]; const [w, setW] = useState(0); return <div onClick={() => setW((w + 1) % weapons.length)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer"><motion.span key={w} initial={{ rotateY: -90, scale: 0 }} animate={{ rotateY: 0, scale: 1 }} className="text-6xl">{weapons[w]}</motion.span></div>; }
export function StatusEffect() { const effects = [{ icon: "🔥", name: "Burning" }, { icon: "🧊", name: "Frozen" }, { icon: "⚡", name: "Shocked" }]; const [e, setE] = useState(0); useEffect(() => { const i = setInterval(() => setE(ei => (ei + 1) % effects.length), 2000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center gap-3"><motion.span className="text-5xl" key={e} initial={{ scale: 0 }} animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 0.5, repeat: Infinity }}>{effects[e].icon}</motion.span><p className="text-white font-bold">{effects[e].name}</p></div>; }
export function EnergyShield({ showcase }) { const [active, setActive] = useState(true); useEffect(() => { if (showcase) { const i = setInterval(() => setActive(a => !a), 2000); return () => clearInterval(i); } }, [showcase]); return <div onClick={() => setActive(!active)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer relative">{active && <motion.div className="absolute w-24 h-24 rounded-full border-4 border-cyan-400" animate={{ scale: [1, 1.1, 1], opacity: [0.5, 1, 0.5] }} transition={{ duration: 1.5, repeat: Infinity }} style={{ boxShadow: "0 0 30px #22d3ee" }} />}<span className="text-4xl relative z-10">🛡️</span></div>; }
export function RageMeter() { const [rage, setRage] = useState(0); useEffect(() => { const i = setInterval(() => setRage(r => (r + 5) % 101), 200); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-4xl">😡</span><div className="w-48 h-4 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-gradient-to-r from-orange-500 to-red-600" animate={{ width: `${rage}%` }} /></div></div>; }
export function TalentTree() { const [unlocked, setUnlocked] = useState([0]); const unlock = (i) => { if (!unlocked.includes(i)) setUnlocked([...unlocked, i]); }; return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center gap-2">{[0, 1, 2, 3].map(i => <div key={i} onClick={() => unlock(i)} className={`w-10 h-10 rounded-full border-2 ${unlocked.includes(i) ? "border-yellow-500 bg-yellow-500/20" : "border-slate-600 bg-slate-800"} flex items-center justify-center cursor-pointer text-xl`}>{unlocked.includes(i) ? "⭐" : "🔒"}</div>)}</div>; }
export function QuestLog() { const quests = ["Defeat 10 enemies", "Find the key", "Explore the cave"]; const [active, setActive] = useState(0); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded p-4"><p className="text-xs text-violet-400 mb-2">ACTIVE QUESTS</p>{quests.map((q, i) => <p key={i} className={`text-xs ${i === active ? "text-white" : "text-slate-600"} py-1`}>{i === active ? "▶" : "○"} {q}</p>)}</div>; }
export function MinimapPing() { const [ping, setPing] = useState(null); useEffect(() => { const i = setInterval(() => setPing({ x: Math.random() * 80 + 10, y: Math.random() * 80 + 10 }), 3000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center"><div className="relative w-24 h-24 bg-slate-800 border border-green-500">{ping && <motion.div className="absolute w-3 h-3 bg-yellow-400 rounded-full" style={{ left: `${ping.x}%`, top: `${ping.y}%` }} initial={{ scale: 0 }} animate={{ scale: [1, 2, 1], opacity: [1, 0, 1] }} transition={{ duration: 1, repeat: Infinity }} />}</div></div>; }
export function DodgeRoll({ showcase }) { const [rolling, setRolling] = useState(false); const roll = () => { setRolling(true); setTimeout(() => setRolling(false), 600); }; useEffect(() => { if (showcase) { const i = setInterval(roll, 1500); return () => clearInterval(i); } }, [showcase]); return <div onClick={roll} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer"><motion.span className="text-5xl" animate={rolling ? { rotate: 360, x: [0, 100, 0] } : {}} transition={{ duration: 0.6 }}>{rolling ? "💨" : "🤸"}</motion.span></div>; }
export function ParryCounter() { const [parry, setParry] = useState(false); useEffect(() => { const i = setInterval(() => { setParry(true); setTimeout(() => setParry(false), 300); }, 3000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center">{parry ? <motion.p initial={{ scale: 0 }} animate={{ scale: 1.5 }} className="text-4xl font-black text-cyan-400">PARRY!</motion.p> : <span className="text-4xl">⚔️</span>}</div>; }
export function RespawnPoint() { const [active, setActive] = useState(false); return <div onClick={() => setActive(!active)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative">{active && <motion.div className="absolute w-20 h-40 bg-cyan-500/20 border-2 border-cyan-400" animate={{ opacity: [0.3, 0.7, 0.3] }} transition={{ duration: 1, repeat: Infinity }} />}<span className="text-4xl relative z-10">🚁</span></div>; }
export function PickupItem() { const [picked, setPicked] = useState(false); return <div onClick={() => setPicked(true)} onAnimationEnd={() => setPicked(false)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer">{!picked ? <motion.span className="text-5xl" animate={{ y: [0, -10, 0] }} transition={{ duration: 1, repeat: Infinity }}>⭐</motion.span> : <motion.p initial={{ scale: 0 }} animate={{ scale: 1, y: -50, opacity: 0 }} transition={{ duration: 0.8 }} className="text-xl text-yellow-400">+1 Star!</motion.p>}</div>; }
export function ZoomScope() { const [zoomed, setZoomed] = useState(false); return <div onClick={() => setZoomed(!zoomed)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer relative overflow-hidden">{zoomed && <motion.div className="absolute inset-0 border-4 border-white rounded-full" initial={{ scale: 0 }} animate={{ scale: 1 }} />}<span className="text-4xl relative z-10">{zoomed ? "🔭" : "🎯"}</span></div>; }
export function GrenadeTimer() { const [time, setTime] = useState(5); useEffect(() => { if (time > 0) { const i = setInterval(() => setTime(t => t - 1), 1000); return () => clearInterval(i); } else { setTimeout(() => setTime(5), 500); } }, [time]); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center">{time > 0 ? <motion.div className="flex items-center gap-2" animate={time < 2 ? { scale: [1, 1.2, 1] } : {}} transition={{ duration: 0.3, repeat: Infinity }}><span className="text-4xl">💣</span><p className={`text-4xl font-mono font-black ${time < 2 ? "text-red-500" : "text-white"}`}>{time}</p></motion.div> : <motion.p initial={{ scale: 0 }} animate={{ scale: 2, opacity: 0 }} className="text-5xl">💥</motion.p>}</div>; }
export function TeamIndicator() { const teams = [{ name: "BLUE", color: "#3b82f6" }, { name: "RED", color: "#ef4444" }]; const [team, setTeam] = useState(0); return <div onClick={() => setTeam((team + 1) % 2)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer"><motion.div key={team} initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }} className="px-6 py-3 rounded-xl border-4 font-bold text-xl" style={{ borderColor: teams[team].color, color: teams[team].color }}>{teams[team].name} TEAM</motion.div></div>; }
export function KillStreak() { const [streak, setStreak] = useState(0); useEffect(() => { const i = setInterval(() => setStreak(s => s + 1), 1000); return () => clearInterval(i); }, []); const msg = streak >= 10 ? "UNSTOPPABLE!" : streak >= 7 ? "RAMPAGE!" : streak >= 5 ? "KILLING SPREE!" : ""; return <div className="w-full h-full min-h-[300px] bg-black rounded flex flex-col items-center justify-center gap-2"><p className="text-5xl font-black text-red-500">{streak}</p>{msg && <motion.p initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-sm text-yellow-400 font-bold">{msg}</motion.p>}</div>; }
export function Leaderboard() { const players = [{ name: "ProGamer", score: 9999 }, { name: "You", score: 7500 }, { name: "Noob123", score: 3200 }]; return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded p-3"><p className="text-xs text-yellow-400 mb-1 font-bold">🏆 LEADERBOARD</p>{players.map((p, i) => <div key={i} className={`flex justify-between text-xs py-1 ${i === 1 ? "text-cyan-400" : "text-slate-400"}`}><span>{i + 1}. {p.name}</span><span>{p.score}</span></div>)}</div>; }
export function MapMarker() { const [pinned, setPinned] = useState(false); return <div onClick={() => setPinned(!pinned)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative">{pinned && <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="absolute w-32 h-32 rounded-full border-2 border-red-500 opacity-30" />}<motion.span className="text-5xl" animate={pinned ? { y: [0, -10, 0] } : {}} transition={{ duration: 0.5, repeat: pinned ? Infinity : 0 }}>📍</motion.span></div>; }
export function SkillSlot() { const skills = ["🔥", "❄️", "⚡", "💨"]; const [active, setActive] = useState(0); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center gap-2">{skills.map((s, i) => <div key={i} onClick={() => setActive(i)} className={`w-12 h-12 rounded-lg border-2 ${i === active ? "border-violet-500 bg-violet-500/20" : "border-slate-700 bg-slate-800"} flex items-center justify-center cursor-pointer text-2xl`}>{s}</div>)}</div>; }
export function AreaTransition() { const [zone, setZone] = useState("Forest"); const zones = ["Forest", "Cave", "Desert"]; useEffect(() => { const i = setInterval(() => setZone(zones[(zones.indexOf(zone) + 1) % zones.length]), 3000); return () => clearInterval(i); }, [zone]); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center"><motion.p key={zone} initial={{ opacity: 0, scale: 2 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="text-3xl font-bold text-white">Entering {zone}...</motion.p></div>; }
export function CraftingSlot() { const [item, setItem] = useState(null); const materials = ["🪵", "⛏️", "🔧"]; return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center gap-4">{materials.map((m, i) => <div key={i} className="w-10 h-10 bg-slate-800 border border-amber-500 rounded flex items-center justify-center text-xl">{m}</div>)}<span className="text-2xl">→</span><div onClick={() => setItem("🗡️")} className="w-14 h-14 bg-slate-800 border-2 border-violet-500 rounded-xl flex items-center justify-center text-2xl cursor-pointer">{item || "?"}</div></div>; }
export function PingSystem() { const [pings, setPings] = useState([]); useEffect(() => { const i = setInterval(() => { const id = Date.now(); setPings(p => [...p, { id, x: Math.random() * 80 + 10, y: Math.random() * 60 + 20 }]); setTimeout(() => setPings(p => p.filter(pi => pi.id !== id)), 2000); }, 2000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative">{pings.map(p => <motion.div key={p.id} className="absolute" style={{ left: `${p.x}%`, top: `${p.y}%` }} initial={{ scale: 0 }} animate={{ scale: [1, 2], opacity: [1, 0] }} transition={{ duration: 1.5 }}><span className="text-2xl">📍</span></motion.div>)}</div>; }
export function HealthPickup() { const [visible, setVisible] = useState(true); return <div onClick={() => setVisible(false)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer">{visible ? <motion.span className="text-5xl" animate={{ y: [0, -10, 0], rotate: [0, 10, -10, 0] }} transition={{ duration: 1.5, repeat: Infinity }}>💊</motion.span> : <motion.p initial={{ scale: 2, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} onAnimationComplete={() => setTimeout(() => setVisible(true), 1000)} className="text-green-400">+50 HP</motion.p>}</div>; }
export function AmmoPack() { const [collected, setCollected] = useState(false); return <div onClick={() => setCollected(true)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer">{!collected ? <motion.span className="text-5xl" animate={{ scale: [1, 1.1, 1] }} transition={{ duration: 1, repeat: Infinity }}>📦</motion.span> : <motion.p initial={{ y: 0, opacity: 1 }} animate={{ y: -40, opacity: 0 }} onAnimationComplete={() => setTimeout(() => setCollected(false), 500)} className="text-yellow-400">+30 Ammo</motion.p>}</div>; }
export function EnvironmentHazard() { const [danger, setDanger] = useState(false); useEffect(() => { const i = setInterval(() => { setDanger(true); setTimeout(() => setDanger(false), 800); }, 2500); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative">{danger && <motion.div className="absolute inset-0 bg-red-500/40" animate={{ opacity: [0.2, 0.6, 0.2] }} transition={{ duration: 0.3, repeat: 3 }} />}<span className="text-5xl relative z-10">{danger ? "☠️" : "⚠️"}</span></div>; }
export function CoverSystem() { const [cover, setCover] = useState(false); return <div onClick={() => setCover(!cover)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative"><div className="absolute right-8 top-1/2 -translate-y-1/2 w-16 h-24 bg-slate-700 border-2 border-slate-600" /><motion.span className="text-4xl" animate={cover ? { x: 60 } : { x: 0 }}>{cover ? "🙇" : "🏃"}</motion.span><p className="absolute bottom-2 text-xs text-slate-500">{cover ? "IN COVER" : "Click for cover"}</p></div>; }
export function ObjectiveMarker() { const [dist, setDist] = useState(100); useEffect(() => { const i = setInterval(() => setDist(d => d > 0 ? d - 5 : 100), 200); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-4xl">🎯</span><p className="text-white font-mono">{dist}m</p><p className="text-xs text-slate-500">to objective</p></div>; }
export function InteractionPrompt() { const [show, setShow] = useState(false); useEffect(() => { const i = setInterval(() => { setShow(true); setTimeout(() => setShow(false), 2000); }, 4000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center">{show && <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="px-4 py-2 bg-white/10 rounded-lg border border-white text-white text-sm">Press [E] to interact</motion.div>}</div>; }
export function VehicleHUD() { const [speed, setSpeed] = useState(0); useEffect(() => { const i = setInterval(() => setSpeed(s => (s + 10) % 201), 100); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center gap-4"><span className="text-4xl">🏎️</span><div className="text-center"><p className="text-4xl font-mono font-black text-cyan-400">{speed}</p><p className="text-xs text-slate-500">KM/H</p></div></div>; }
export function TurretAim() { const [angle, setAngle] = useState(0); useEffect(() => { const i = setInterval(() => setAngle(a => (a + 5) % 360), 50); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative"><motion.div className="w-16 h-2 bg-red-500 origin-left absolute" style={{ rotate: angle }} /><div className="w-8 h-8 rounded-full bg-slate-700 border-2 border-red-500 z-10" /></div>; }
export function CapturePoint() { const [progress, setProgress] = useState(0); useEffect(() => { const i = setInterval(() => setProgress(p => (p + 2) % 101), 100); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-4xl">🚩</span><div className="w-48 h-3 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-blue-500" animate={{ width: `${progress}%` }} /></div><p className="text-xs text-white">{progress < 100 ? "Capturing..." : "Captured!"}</p></div>; }
export function WeaponDurability() { const [dur, setDur] = useState(100); useEffect(() => { const i = setInterval(() => setDur(d => d > 0 ? d - 1 : 100), 100); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-4xl">🗡️</span><div className="w-32 h-2 bg-slate-800 rounded-full overflow-hidden"><motion.div className={`h-full ${dur > 50 ? "bg-green-500" : dur > 20 ? "bg-yellow-500" : "bg-red-500"}`} animate={{ width: `${dur}%` }} /></div></div>; }
export function ArmorPlate() { const [plates, setPlates] = useState(3); useEffect(() => { const i = setInterval(() => setPlates(p => p > 0 ? p - 1 : 3), 1500); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center gap-2">{[...Array(3)].map((_, i) => <motion.div key={i} className={`w-8 h-10 rounded ${i < plates ? "bg-blue-500 border-blue-400" : "bg-slate-700 border-slate-600"} border-2`} animate={i < plates ? { opacity: [0.7, 1, 0.7] } : {}} transition={{ duration: 1, repeat: Infinity }} />)}</div>; }
export function GasZone() { const [damage, setDamage] = useState(0); useEffect(() => { const i = setInterval(() => setDamage(d => Math.min(100, d + 5)), 300); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-t from-green-900/50 to-black rounded flex flex-col items-center justify-center relative overflow-hidden"><motion.div className="absolute inset-0 bg-green-500/20" animate={{ opacity: [0.1, 0.3, 0.1] }} transition={{ duration: 1, repeat: Infinity }} /><p className="text-red-500 text-sm font-bold relative z-10">☠️ IN GAS ZONE</p><p className="text-white text-3xl font-mono relative z-10">-{damage} HP</p></div>; }
export function RevivePrompt() { const [reviving, setReviving] = useState(false); const [progress, setProgress] = useState(0); useEffect(() => { if (reviving && progress < 100) { const i = setInterval(() => setProgress(p => Math.min(100, p + 5)), 100); return () => clearInterval(i); } if (!reviving) setProgress(0); }, [reviving, progress]); return <div onMouseDown={() => setReviving(true)} onMouseUp={() => setReviving(false)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2 cursor-pointer"><span className="text-4xl">🤕</span>{reviving && <div className="w-32 h-2 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-green-500" animate={{ width: `${progress}%` }} /></div>}<p className="text-xs text-white">{progress === 100 ? "Revived!" : reviving ? "Reviving..." : "Hold to revive"}</p></div>; }
export function SupplyDrop() { const [dropping, setDropping] = useState(false); useEffect(() => { const i = setInterval(() => { setDropping(true); setTimeout(() => setDropping(false), 2000); }, 5000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-blue-900 to-slate-900 rounded relative flex items-center justify-center">{dropping && <motion.div className="absolute text-4xl" initial={{ top: -20 }} animate={{ top: 90 }} transition={{ duration: 1.5 }}>🎁</motion.div>}<p className="text-white text-sm">{dropping ? "Incoming supply!" : "Awaiting drop..."}</p></div>; }
export function KillcamReplay() { const [replay, setReplay] = useState(false); useEffect(() => { const i = setInterval(() => { setReplay(true); setTimeout(() => setReplay(false), 2000); }, 5000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center">{replay ? <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center"><p className="text-red-500 text-sm font-bold mb-1">KILLCAM</p><p className="text-white text-xs">Replay: 3s</p></motion.div> : <p className="text-slate-600">Waiting...</p>}</div>; }
export function LoadoutCard() { const loadout = ["🔫", "💣", "🔪"]; return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center gap-3">{loadout.map((l, i) => <motion.div key={i} whileHover={{ scale: 1.1 }} className="w-14 h-14 bg-slate-800 border border-slate-600 rounded-lg flex items-center justify-center text-2xl cursor-pointer">{l}</motion.div>)}</div>; }
export function RankBadge() { const ranks = [{ name: "Bronze", color: "#cd7f32" }, { name: "Silver", color: "#c0c0c0" }, { name: "Gold", color: "#ffd700" }]; const [r, setR] = useState(0); useEffect(() => { const i = setInterval(() => setR(ri => (ri + 1) % ranks.length), 2000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><motion.div key={r} initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }} className="w-16 h-16 rounded-full border-4 flex items-center justify-center text-2xl" style={{ borderColor: ranks[r].color, backgroundColor: `${ranks[r].color}20` }}>🏅</motion.div><p className="font-bold" style={{ color: ranks[r].color }}>{ranks[r].name}</p></div>; }
export function PerkCard() { const perks = ["🏃 Speed", "💪 Strength", "🧠 Focus"]; const [selected, setSelected] = useState(null); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center gap-2">{perks.map((p, i) => <motion.div key={i} onClick={() => setSelected(i)} whileHover={{ y: -5 }} className={`px-3 py-2 rounded-lg border ${selected === i ? "border-violet-500 bg-violet-500/20" : "border-slate-700 bg-slate-800"} cursor-pointer text-xs`}>{p}</motion.div>)}</div>; }
export function MatchTimer() { const [time, setTime] = useState(300); useEffect(() => { if (time > 0) { const i = setInterval(() => setTime(t => t - 1), 1000); return () => clearInterval(i); } }, [time]); const mins = Math.floor(time / 60); const secs = time % 60; return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center"><p className={`text-5xl font-mono font-black ${time < 30 ? "text-red-500 animate-pulse" : "text-white"}`}>{mins}:{secs.toString().padStart(2, '0')}</p></div>; }
export function VoteKick() { const [votes, setVotes] = useState(0); return <div onClick={() => setVotes(v => v + 1)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2 cursor-pointer"><p className="text-white text-sm">Vote to Kick Player?</p><div className="flex gap-4"><button className="px-4 py-2 bg-green-600 rounded text-white text-xs">YES ({votes})</button><button className="px-4 py-2 bg-red-600 rounded text-white text-xs">NO (0)</button></div></div>; }
export function DropZoneIndicator() { const [inside, setInside] = useState(false); return <div onMouseEnter={() => setInside(true)} onMouseLeave={() => setInside(false)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative"><motion.div className={`w-24 h-24 rounded-full border-4 ${inside ? "border-green-500" : "border-blue-500 border-dashed"}`} animate={inside ? { scale: [1, 1.1, 1] } : { opacity: [0.5, 1, 0.5] }} transition={{ duration: 1, repeat: Infinity }} /><p className="absolute bottom-2 text-xs text-white">{inside ? "SAFE ZONE" : "Enter zone"}</p></div>; }
export function SpectatorMode() { const [player, setPlayer] = useState(1); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center gap-4"><button onClick={() => setPlayer(p => Math.max(1, p - 1))} className="text-white">←</button><div className="text-center"><p className="text-xs text-slate-500">Spectating</p><p className="text-white font-bold">Player {player}</p></div><button onClick={() => setPlayer(p => p + 1)} className="text-white">→</button></div>; }
export function BuildMode() { const [building, setBuilding] = useState(false); return <div onClick={() => setBuilding(!building)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative">{building && <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="absolute w-16 h-20 bg-amber-800 border-2 border-amber-600" />}<span className="text-4xl relative z-10">{building ? "🔨" : "🏗️"}</span></div>; }
export function HitMarker() { const [show, setShow] = useState(false); useEffect(() => { const i = setInterval(() => { setShow(true); setTimeout(() => setShow(false), 200); }, 1500); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center">{show && <motion.div initial={{ scale: 2, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ opacity: 0 }} className="text-red-500 text-6xl font-bold">+</motion.div>}</div>; }
export function KillConfirm() { const [show, setShow] = useState(false); useEffect(() => { const i = setInterval(() => { setShow(true); setTimeout(() => setShow(false), 1500); }, 4000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center">{show && <motion.p initial={{ scale: 0, rotate: -20 }} animate={{ scale: 1, rotate: 0 }} className="text-3xl font-black text-red-500">💀 ELIMINATED</motion.p>}</div>; }
export function SquadWipe() { const [wiped, setWiped] = useState(false); useEffect(() => { const i = setInterval(() => { setWiped(true); setTimeout(() => setWiped(false), 2000); }, 6000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center">{wiped && <motion.p initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-4xl font-black text-orange-500">SQUAD WIPED!</motion.p>}</div>; }
export function RoundStart() { const [count, setCount] = useState(3); useEffect(() => { if (count > 0) { const i = setInterval(() => setCount(c => c - 1), 1000); return () => clearInterval(i); } else { setTimeout(() => setCount(3), 2000); } }, [count]); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center">{count > 0 ? <motion.p key={count} initial={{ scale: 2, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-7xl font-black text-white">{count}</motion.p> : <motion.p initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-3xl text-green-400 font-bold">GO!</motion.p>}</div>; }
export function PauseMenu() { const [paused, setPaused] = useState(false); return <div onClick={() => setPaused(!paused)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer">{paused ? <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-black/90 p-4 rounded-xl border border-white/20"><p className="text-white font-bold mb-2">PAUSED</p><button className="px-3 py-1 bg-green-600 rounded text-white text-xs">Resume</button></motion.div> : <p className="text-slate-500">Click to pause</p>}</div>; }
export function OptionsMenu() { const [vol, setVol] = useState(70); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2 p-4"><p className="text-white text-sm">🔊 Volume</p><input type="range" min="0" max="100" value={vol} onChange={(e) => setVol(e.target.value)} className="w-full accent-violet-500" /><p className="text-xs text-slate-400">{vol}%</p></div>; }
export function SaveSlot() { const [saved, setSaved] = useState(false); return <div onClick={() => setSaved(true)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2 cursor-pointer p-4 border-2 border-slate-700 hover:border-violet-500 transition-colors"><p className="text-white text-sm">💾 Save Slot 1</p><p className="text-xs text-slate-500">{saved ? "Last saved: Now" : "Empty"}</p>{saved && <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-green-400 text-xs">✓ Game Saved!</motion.p>}</div>; }
export function AchievementProgress() { const [prog, setProg] = useState(0); useEffect(() => { const i = setInterval(() => setProg(p => (p + 1) % 101), 50); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2 p-4"><p className="text-white text-sm">🏆 Master Collector</p><div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-gradient-to-r from-violet-500 to-cyan-500" animate={{ width: `${prog}%` }} /></div><p className="text-xs text-slate-400">{prog}% Complete</p></div>; }
export function DailyChallenge() { return <div className="w-full h-full min-h-[300px] bg-gradient-to-br from-violet-900 to-slate-900 rounded flex flex-col items-center justify-center gap-2 p-4 border border-violet-500/30"><p className="text-violet-400 text-xs font-bold">⏰ DAILY CHALLENGE</p><p className="text-white text-sm">Defeat 50 enemies</p><div className="flex gap-2"><span className="text-xs text-slate-400">0/50</span><span className="text-xs text-yellow-400">+500 XP</span></div></div>; }
export function SeasonPass() { const [tier, setTier] = useState(1); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center gap-2">{[1, 2, 3, 4, 5].map(t => <div key={t} className={`w-10 h-10 rounded-full border-2 ${t <= tier ? "border-yellow-500 bg-yellow-500/20" : "border-slate-700 bg-slate-800"} flex items-center justify-center text-xs font-bold`} style={{ color: t <= tier ? "#fbbf24" : "#64748b" }}>{t}</div>)}</div>; }
export function BattlePass() { const [lvl, setLvl] = useState(1); const [xp, setXp] = useState(0); useEffect(() => { const i = setInterval(() => { setXp(x => { if (x >= 100) { setLvl(l => l + 1); return 0; } return x + 5; }); }, 200); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-r from-purple-900 to-pink-900 rounded flex flex-col items-center justify-center gap-2"><p className="text-white font-bold">Level {lvl}</p><div className="w-48 h-3 bg-black/50 rounded-full overflow-hidden"><motion.div className="h-full bg-gradient-to-r from-yellow-400 to-orange-500" animate={{ width: `${xp}%` }} /></div></div>; }
export function WeeklyReward() { return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2 p-4 border-2 border-amber-500/30"><p className="text-amber-400 text-xs font-bold">📆 WEEKLY REWARD</p><span className="text-4xl">🎁</span><p className="text-xs text-white">Unlock in 2 days</p></div>; }
export function MinigunSpinup() { const [spinning, setSpinning] = useState(false); const [speed, setSpeed] = useState(0); useEffect(() => { if (spinning && speed < 100) { const i = setInterval(() => setSpeed(s => Math.min(100, s + 10)), 100); return () => clearInterval(i); } if (!spinning && speed > 0) { const i = setInterval(() => setSpeed(s => Math.max(0, s - 20)), 100); return () => clearInterval(i); } }, [spinning, speed]); return <div onMouseDown={() => setSpinning(true)} onMouseUp={() => setSpinning(false)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2 cursor-pointer"><motion.span className="text-5xl" animate={{ rotate: speed > 0 ? 360 : 0, scaleX: -1 }} transition={{ duration: speed > 50 ? 0.1 : 1, repeat: speed > 0 ? Infinity : 0, ease: "linear" }}>🔫</motion.span><div className="w-32 h-2 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-red-500" animate={{ width: `${speed}%` }} /></div><p className="text-xs text-white">{speed === 100 ? "FIRING!" : "Hold to spin"}</p></div>; }
export function ZombieHorde() { const [zombies, setZombies] = useState([]); useEffect(() => { const i = setInterval(() => { const id = Date.now(); setZombies(z => [...z.slice(-5), { id, x: Math.random() * 80 + 10 }]); setTimeout(() => setZombies(z => z.filter(zz => zz.id !== id)), 3000); }, 800); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-green-950 to-black rounded relative overflow-hidden">{zombies.map(z => <motion.div key={z.id} className="absolute text-3xl" initial={{ left: `${z.x}%`, top: -20 }} animate={{ top: 110 }} transition={{ duration: 3 }}>🧟</motion.div>)}<p className="absolute top-2 left-2 text-xs text-green-400 bg-black/50 px-2 py-1 rounded">Incoming: {zombies.length}</p></div>; }
export function NightVision() { const [on, setOn] = useState(false); return <div onClick={() => setOn(!on)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer relative overflow-hidden">{on && <div className="absolute inset-0 bg-green-500/20 border-4 border-green-500/50" />}<span className="text-5xl relative z-10">{on ? "👁️" : "🌙"}</span><p className="absolute bottom-2 text-xs text-white">{on ? "Night Vision ON" : "Click to enable"}</p></div>; }
export function ThermalVision() { const [thermal, setThermal] = useState(false); return <div onClick={() => setThermal(!thermal)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer relative">{thermal && <><div className="absolute inset-0 bg-gradient-to-br from-red-900 to-orange-900 opacity-60" /><div className="absolute w-12 h-16 bg-yellow-400 rounded opacity-80" style={{ filter: "blur(8px)" }} /></>}<span className="text-4xl relative z-10">🌡️</span></div>; }
export function DroneView() { const [x, setX] = useState(50); const [y, setY] = useState(50); useEffect(() => { const i = setInterval(() => { setX(Math.random() * 80 + 10); setY(Math.random() * 60 + 20); }, 2000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative"><motion.div className="absolute border-2 border-cyan-400 w-16 h-16" animate={{ left: `${x}%`, top: `${y}%` }} style={{ transform: "translate(-50%, -50%)" }}><div className="absolute inset-0 flex items-center justify-center"><div className="w-1 h-full bg-cyan-400" /><div className="h-1 w-full bg-cyan-400 absolute" /></div></motion.div><p className="absolute top-2 left-2 text-xs text-cyan-400 bg-black/50 px-2 py-1 rounded">📡 DRONE ACTIVE</p></div>; }
export function EmoteWheel() { const emotes = ["👋", "👍", "😂", "😢", "😡", "😎", "❤️", "💀"]; const [selected, setSelected] = useState(null); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative"><div className="relative w-24 h-24">{emotes.map((e, i) => { const angle = (i / emotes.length) * 360; const x = 50 + Math.cos((angle * Math.PI) / 180) * 40; const y = 50 + Math.sin((angle * Math.PI) / 180) * 40; return <div key={i} onClick={() => setSelected(i)} className="absolute w-8 h-8 flex items-center justify-center text-xl cursor-pointer" style={{ left: `${x}%`, top: `${y}%`, transform: "translate(-50%, -50%)" }}>{e}</div>; })}{selected !== null && <motion.div initial={{ scale: 0 }} animate={{ scale: 1.5 }} className="absolute inset-0 flex items-center justify-center text-3xl">{emotes[selected]}</motion.div>}</div></div>; }
export function PingLocation() { const [pings, setPings] = useState([]); const ping = () => { const id = Date.now(); setPings(p => [...p, { id, x: Math.random() * 80 + 10, y: Math.random() * 60 + 20 }]); setTimeout(() => setPings(p => p.filter(pi => pi.id !== id)), 3000); }; return <div onClick={ping} className="w-full h-full min-h-[300px] bg-slate-900 rounded relative cursor-pointer">{pings.map(p => <motion.div key={p.id} className="absolute" style={{ left: `${p.x}%`, top: `${p.y}%` }} initial={{ scale: 0 }} animate={{ scale: [1, 2], opacity: [1, 0] }} transition={{ duration: 2 }}><span className="text-3xl">📍</span></motion.div>)}<p className="absolute bottom-2 left-2 text-xs text-white">Click to ping</p></div>; }
export function MarkerSystem() { const colors = ["🔴", "🟢", "🔵", "🟡"]; const [marker, setMarker] = useState(0); return <div onClick={() => setMarker((marker + 1) % colors.length)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer"><motion.span key={marker} initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-6xl">{colors[marker]}</motion.span></div>; }
export function CompasHUD() { const [dir, setDir] = useState(0); useEffect(() => { const i = setInterval(() => setDir(d => (d + 5) % 360), 100); return () => clearInterval(i); }, []); const dirs = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]; const current = dirs[Math.floor(dir / 45)]; return <div className="w-full h-full min-h-[300px] bg-black rounded flex flex-col items-center justify-center gap-2"><div className="relative w-48 h-8 bg-slate-800 rounded overflow-hidden"><motion.div className="absolute inset-0 flex items-center justify-center font-mono text-white text-xs" style={{ x: `${-dir * 2}px` }}>{dirs.map((d, i) => <span key={i} className="inline-block w-16 text-center">{d}</span>)}</motion.div></div><p className="text-cyan-400 font-bold">{current} {dir}°</p></div>; }
export function AltitudeMeter() { const [alt, setAlt] = useState(1000); useEffect(() => { const i = setInterval(() => setAlt(a => Math.max(0, a - 50)), 200); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-sky-900 to-slate-900 rounded flex flex-col items-center justify-center gap-1"><span className="text-4xl">✈️</span><p className="text-white text-2xl font-mono">{alt}m</p><p className="text-xs text-slate-500">altitude</p></div>; }
export function SpeedBoost({ showcase }) { const [boosting, setBoosting] = useState(false); useEffect(() => { if (showcase) { const i = setInterval(() => { setBoosting(true); setTimeout(() => setBoosting(false), 1000); }, 2000); return () => clearInterval(i); } }, [showcase]); return <div onClick={() => setBoosting(!boosting)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative">{boosting && <><motion.div className="absolute inset-0 bg-cyan-500/30" animate={{ opacity: [0, 0.5, 0] }} transition={{ duration: 0.3, repeat: Infinity }} /><motion.div className="absolute right-0 top-1/2 -translate-y-1/2 w-full h-1 bg-cyan-400" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ duration: 0.2 }} /></>}<span className="text-5xl relative z-10">{boosting ? "💨" : "🏎️"}</span></div>; }
export function SloMoEffect({ showcase }) { const [slow, setSlow] = useState(false); useEffect(() => { if (showcase) { const i = setInterval(() => { setSlow(true); setTimeout(() => setSlow(false), 2000); }, 4000); return () => clearInterval(i); } }, [showcase]); return <div onClick={() => setSlow(!slow)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer relative">{slow && <motion.div className="absolute inset-0 bg-blue-500/10" animate={{ opacity: [0.1, 0.3, 0.1] }} transition={{ duration: 2 }} />}<motion.span className="text-5xl" animate={slow ? { scale: [1, 1.05, 1] } : {}} transition={{ duration: slow ? 2 : 0.5 }}>⏱️</motion.span><p className="absolute bottom-2 text-xs text-white">{slow ? "SLO-MO ACTIVE" : "Click to slow"}</p></div>; }
export function BulletTime() { const [active, setActive] = useState(false); return <div onClick={() => setActive(!active)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer relative overflow-hidden">{active && <><motion.div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent" animate={{ x: ["-100%", "100%"] }} transition={{ duration: 1.5, repeat: Infinity }} /><motion.p className="text-white text-sm font-mono absolute top-2 left-2">Time: 0.25x</motion.p></>}<span className="text-5xl">🎯</span></div>; }
export function GlideMode() { const [gliding, setGliding] = useState(false); return <div onClick={() => setGliding(!gliding)} className="w-full h-full min-h-[300px] bg-gradient-to-b from-sky-700 to-slate-900 rounded flex items-center justify-center cursor-pointer relative">{gliding && [...Array(6)].map((_, i) => <motion.div key={i} className="absolute w-8 h-1 bg-white/30" initial={{ x: 0 }} animate={{ x: -200 }} transition={{ duration: 1, delay: i * 0.1, repeat: Infinity }} style={{ top: `${30 + i * 10}%` }} />)}<motion.span className="text-5xl" animate={gliding ? { x: [-20, 20, -20] } : {}} transition={{ duration: 2, repeat: gliding ? Infinity : 0 }}>🪂</motion.span></div>; }
export function ClimbLedge() { const [climbing, setClimbing] = useState(false); return <div onClick={() => setClimbing(!climbing)} className="w-full h-full min-h-[300px] bg-slate-900 rounded relative flex items-center justify-center cursor-pointer"><div className="absolute right-4 top-0 bottom-0 w-2 bg-slate-600" /><motion.span className="text-4xl" animate={climbing ? { x: 40, y: -20 } : {}} transition={{ duration: 0.5 }}>🧗</motion.span></div>; }
export function SwimMeter() { const [air, setAir] = useState(100); useEffect(() => { const i = setInterval(() => setAir(a => a > 0 ? a - 2 : 100), 100); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-blue-900 to-blue-950 rounded flex flex-col items-center justify-center gap-2"><span className="text-4xl">🏊</span><div className="w-32 h-3 bg-blue-950 rounded-full overflow-hidden border border-cyan-500"><motion.div className={`h-full ${air > 30 ? "bg-cyan-400" : "bg-red-500 animate-pulse"}`} animate={{ width: `${air}%` }} /></div><p className="text-xs text-cyan-400">O₂: {air}%</p></div>; }
export function MountedUnit() { const [mounted, setMounted] = useState(false); return <div onClick={() => setMounted(!mounted)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer"><motion.span className="text-5xl" animate={mounted ? { scale: 1.3 } : {}}>{mounted ? "🐴" : "🚶"}</motion.span><p className="absolute bottom-2 text-xs text-white">{mounted ? "Mounted" : "On foot"}</p></div>; }
export function TeleportBeacon() { const [charging, setCharging] = useState(false); const [charge, setCharge] = useState(0); useEffect(() => { if (charging) { const i = setInterval(() => setCharge(c => { if (c >= 100) { setCharging(false); setTimeout(() => setCharge(0), 1000); return 100; } return c + 5; }), 50); return () => clearInterval(i); } }, [charging, charge]); return <div onClick={() => !charging && setCharging(true)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2 cursor-pointer">{charge === 100 ? <motion.p initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-3xl">💫 TELEPORTED!</motion.p> : <><span className="text-4xl">🌀</span><div className="w-32 h-2 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-purple-500" animate={{ width: `${charge}%` }} /></div></>}</div>; }
export function HackingMiniGame() { const [progress, setProgress] = useState(0); const [hacking, setHacking] = useState(false); useEffect(() => { if (hacking) { const i = setInterval(() => setProgress(p => { if (p >= 100) { setHacking(false); setTimeout(() => setProgress(0), 1000); return 100; } return p + 3; }), 50); return () => clearInterval(i); } }, [hacking]); return <div onClick={() => !hacking && setHacking(true)} className="w-full h-full min-h-[300px] bg-black rounded flex flex-col items-center justify-center gap-2 cursor-pointer">{progress === 100 ? <motion.p initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-green-400 font-bold">✓ ACCESS GRANTED</motion.p> : <><span className="text-4xl">🔓</span><div className="w-40 h-2 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-gradient-to-r from-green-500 to-cyan-500" animate={{ width: `${progress}%` }} /></div><p className="text-xs text-white">{hacking ? "Hacking..." : "Click to hack"}</p></>}</div>; }
export function LockpickProgress() { const [picks, setPicks] = useState(0); const pick = () => { if (picks < 3) setPicks(p => p + 1); else { setPicks(0); } }; return <div onClick={pick} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2 cursor-pointer"><span className="text-4xl">🔐</span><div className="flex gap-1">{[...Array(3)].map((_, i) => <div key={i} className={`w-3 h-8 rounded ${i < picks ? "bg-green-500" : "bg-slate-700"}`} />)}</div><p className="text-xs text-white">{picks === 3 ? "Unlocked!" : `${picks}/3 pins`}</p></div>; }
export function TrapDetector() { const [trap, setTrap] = useState(null); useEffect(() => { const i = setInterval(() => { setTrap({ x: Math.random() * 80 + 10, y: Math.random() * 60 + 20 }); setTimeout(() => setTrap(null), 2000); }, 4000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative">{trap && <motion.div className="absolute" style={{ left: `${trap.x}%`, top: `${trap.y}%` }} initial={{ scale: 0 }} animate={{ scale: [1, 1.3, 1], opacity: [1, 0.5, 1] }} transition={{ duration: 0.8, repeat: Infinity }}><span className="text-3xl">⚠️</span></motion.div>}</div>; }
export function StealthKill() { const [executing, setExecuting] = useState(false); return <div onClick={() => setExecuting(true)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer">{executing ? <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} onAnimationComplete={() => setTimeout(() => setExecuting(false), 1000)} className="text-center"><p className="text-red-500 text-3xl font-black">STEALTH KILL</p><p className="text-white text-xs mt-1">+200 XP</p></motion.div> : <span className="text-4xl">🥷</span>}</div>; }
export function GrappleHook() { const [grappling, setGrappling] = useState(false); return <div onClick={() => setGrappling(!grappling)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative"><div className="absolute top-4 right-4 w-4 h-4 bg-amber-500 rounded-full" />{grappling && <motion.div className="absolute top-4 left-1/2 w-1 bg-amber-500" initial={{ height: 0 }} animate={{ height: "60%", rotate: 45 }} transition={{ duration: 0.3 }} />}<motion.span className="text-4xl" animate={grappling ? { y: -40 } : {}} transition={{ duration: 0.5 }}>🪝</motion.span></div>; }
export function WallRun() { const [running, setRunning] = useState(false); return <div onClick={() => setRunning(!running)} className="w-full h-full min-h-[300px] bg-slate-900 rounded relative flex items-center justify-center cursor-pointer"><div className="absolute right-0 top-0 bottom-0 w-4 bg-slate-700" /><motion.span className="text-4xl" animate={running ? { x: 40, rotate: 90 } : {}} transition={{ duration: 0.5 }}>{running ? "🏃" : "🧍"}</motion.span></div>; }
export function SlideAction() { const [sliding, setSliding] = useState(false); const slide = () => { setSliding(true); setTimeout(() => setSliding(false), 600); }; return <div onClick={slide} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative"><motion.span className="text-5xl" animate={sliding ? { x: [0, 80, 0], rotateZ: [0, -90, 0] } : {}} transition={{ duration: 0.6 }}>{sliding ? "💨" : "🏃"}</motion.span></div>; }
export function VaultObstacle() { const [vaulting, setVaulting] = useState(false); return <div onClick={() => setVaulting(true)} className="w-full h-full min-h-[300px] bg-slate-900 rounded relative flex items-center justify-center cursor-pointer"><div className="absolute left-1/2 -translate-x-1/2 bottom-8 w-24 h-8 bg-slate-700 border-2 border-slate-600" /><motion.span className="text-4xl" animate={vaulting ? { y: [-20, -60, -20], x: [-40, 40, -40] } : {}} transition={{ duration: 1.2 }} onAnimationComplete={() => setVaulting(false)}>🤸</motion.span></div>; }
export function CrouchMode() { const [crouching, setCrouching] = useState(false); return <div onClick={() => setCrouching(!crouching)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer"><motion.span className="text-5xl" animate={crouching ? { y: 15, scaleY: 0.7 } : {}}>{crouching ? "🙇" : "🧍"}</motion.span><p className="absolute bottom-2 text-xs text-white">{crouching ? "Crouching" : "Standing"}</p></div>; }
export function PronePosition() { const [prone, setProne] = useState(false); return <div onClick={() => setProne(!prone)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer"><motion.span className="text-5xl" animate={prone ? { rotate: 90, scaleY: 0.5 } : {}} transition={{ duration: 0.4 }}>{prone ? "🏃" : "🧍"}</motion.span></div>; }
export function AimDownSights() { const [ads, setAds] = useState(false); return <div onMouseDown={() => setAds(true)} onMouseUp={() => setAds(false)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer relative">{ads && <><motion.div className="absolute w-48 h-0.5 bg-red-500" /><motion.div className="absolute h-48 w-0.5 bg-red-500" /><motion.div className="absolute w-32 h-32 rounded-full border-2 border-red-500" initial={{ scale: 2, opacity: 0 }} animate={{ scale: 1, opacity: 0.5 }} /></>}<span className="text-4xl relative z-10">🎯</span></div>; }
export function RecoilPattern() { const [firing, setFiring] = useState(false); const [kicks, setKicks] = useState([]); useEffect(() => { if (firing) { const i = setInterval(() => { setKicks(k => [...k.slice(-10), { id: Date.now(), x: (Math.random() - 0.5) * 40, y: -Math.random() * 20 }]); }, 80); return () => clearInterval(i); } else { setKicks([]); } }, [firing]); return <div onMouseDown={() => setFiring(true)} onMouseUp={() => setFiring(false)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer relative">{kicks.map(k => <motion.div key={k.id} className="absolute w-1 h-1 bg-yellow-400 rounded-full" initial={{ x: 0, y: 0, opacity: 1 }} animate={{ x: k.x, y: k.y, opacity: 0 }} transition={{ duration: 0.3 }} style={{ left: "50%", top: "50%" }} />)}<span className="text-4xl" style={{ transform: "scaleX(-1)" }}>🔫</span></div>; }
export function GrenadeArc({ showcase }) { const [throwing, setThrowing] = useState(false); useEffect(() => { if (showcase) { const i = setInterval(() => setThrowing(true), 2000); return () => clearInterval(i); } }, [showcase]); return <div onClick={() => setThrowing(true)} className="w-full h-full min-h-[300px] bg-slate-900 rounded relative flex items-center justify-center cursor-pointer">{throwing && <motion.div className="absolute text-3xl" initial={{ left: "20%", top: "70%" }} animate={{ left: "80%", top: ["70%", "20%", "70%"] }} transition={{ duration: 1.5 }} onAnimationComplete={() => setThrowing(false)}>💣</motion.div>}<span className="text-4xl">🤾</span></div>; }
export function MeleeSwing({ showcase }) { const [swinging, setSwinging] = useState(false); useEffect(() => { if (showcase) { const i = setInterval(() => setSwinging(true), 1000); return () => clearInterval(i); } }, [showcase]); return <div onClick={() => setSwinging(true)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer"><motion.span className="text-6xl" animate={swinging ? { rotate: [0, -90, 0] } : {}} transition={{ duration: 0.4 }} onAnimationComplete={() => setSwinging(false)}>⚔️</motion.span></div>; }
export function ThrowableItem() { const [thrown, setThrown] = useState(false); return <div onClick={() => setThrown(true)} className="w-full h-full min-h-[300px] bg-slate-900 rounded relative flex items-center justify-center cursor-pointer">{thrown && <motion.div className="absolute text-3xl" initial={{ left: "30%", top: "60%", rotate: 0 }} animate={{ left: "70%", top: "20%", rotate: 720 }} transition={{ duration: 0.8 }} onAnimationComplete={() => setThrown(false)}>🪃</motion.div>}<span className="text-4xl">🤾</span></div>; }
export function ReloadAnimation({ showcase }) { const [reloading, setReloading] = useState(false); useEffect(() => { if (showcase) { const i = setInterval(() => setReloading(true), 2500); return () => clearInterval(i); } }, [showcase]); return <div onClick={() => setReloading(true)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer"><motion.div animate={reloading ? { rotateY: [0, 180, 360] } : { scaleX: -1 }} transition={{ duration: 1 }} onAnimationComplete={() => setReloading(false)}><span className="text-5xl">🔫</span></motion.div>{reloading && <motion.p className="absolute bottom-2 text-xs text-yellow-400">Reloading...</motion.p>}</div>; }
export function WeaponInspect({ showcase }) { const [inspecting, setInspecting] = useState(false); useEffect(() => { if (showcase) { setInspecting(true); } else { setInspecting(false); } }, [showcase]); return <div onClick={() => setInspecting(!inspecting)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer"><motion.span className="text-6xl" animate={inspecting ? { rotateY: 360, rotateX: 20 } : {}} transition={{ duration: 2, repeat: inspecting ? Infinity : 0 }}>🗡️</motion.span></div>; }
export function MuzzleFlash() { 
  const [flash, setFlash] = useState(false); 
  useEffect(() => { 
    const i = setInterval(() => { 
      setFlash(true); 
      setTimeout(() => setFlash(false), 150); 
    }, 1500); 
    return () => clearInterval(i); 
  }, []); 
  return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center relative">{flash && <motion.div className="absolute w-40 h-40 bg-yellow-400 rounded-full" initial={{ scale: 0, opacity: 1 }} animate={{ scale: 3, opacity: 0 }} transition={{ duration: 0.2 }} style={{ boxShadow: "0 0 60px #facc15" }} />}<span className="text-7xl relative z-10" style={{ transform: "scaleX(-1)" }}>🔫</span><p className="absolute bottom-4 left-4 text-xs text-yellow-400 bg-black/50 px-2 py-1 rounded">Auto firing</p></div>; 
}
export function ShellEjection() { const [shells, setShells] = useState([]); useEffect(() => { const i = setInterval(() => { const id = Date.now(); setShells(s => [...s.slice(-3), { id }]); setTimeout(() => setShells(s => s.filter(sh => sh.id !== id)), 1000); }, 600); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative flex items-center justify-center"><div className="absolute left-4 text-4xl" style={{ transform: "scaleX(-1)" }}>🔫</div>{shells.map(sh => <motion.div key={sh.id} className="absolute left-1/4 top-1/2 w-2 h-4 bg-yellow-600 rounded" initial={{ x: 0, y: 0, rotate: 0 }} animate={{ x: 30, y: -40, rotate: 720, opacity: 0 }} transition={{ duration: 0.8 }} />)}</div>; }
export function BloodSplatter() { const [splat, setSplat] = useState(false); useEffect(() => { const i = setInterval(() => { setSplat(true); setTimeout(() => setSplat(false), 800); }, 3000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center relative">{splat && <motion.div className="absolute" initial={{ scale: 0, opacity: 1 }} animate={{ scale: 3, opacity: 0 }} transition={{ duration: 0.6 }}><span className="text-6xl">💥</span></motion.div>}</div>; }
export function FootstepIndicator() { const [steps, setSteps] = useState([]); useEffect(() => { const i = setInterval(() => { const id = Date.now(); const angle = Math.random() * 360; setSteps(s => [...s.slice(-4), { id, angle }]); setTimeout(() => setSteps(s => s.filter(st => st.id !== id)), 2000); }, 800); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative flex items-center justify-center">{steps.map(st => <motion.div key={st.id} className="absolute text-2xl" style={{ left: `${50 + Math.cos((st.angle * Math.PI) / 180) * 30}%`, top: `${50 + Math.sin((st.angle * Math.PI) / 180) * 30}%` }} initial={{ opacity: 1, scale: 1 }} animate={{ opacity: 0, scale: 0.5 }} transition={{ duration: 1.5 }}>👣</motion.div>)}<div className="w-6 h-6 bg-blue-500 rounded-full" /></div>; }
export function BreathingPattern() { const [intensity, setIntensity] = useState(0); useEffect(() => { const i = setInterval(() => setIntensity(val => (val + 10) % 101), 200); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center"><motion.div className="w-20 h-20 rounded-full border-4 border-cyan-400 flex items-center justify-center" animate={{ scale: [1, 1 + intensity / 100, 1] }} transition={{ duration: 2, repeat: Infinity }}><span className="text-3xl">💨</span></motion.div></div>; }
export function InjuryIndicator() { const areas = ["Head", "Body", "Legs"]; const [hit, setHit] = useState(null); useEffect(() => { const i = setInterval(() => { setHit(areas[Math.floor(Math.random() * areas.length)]); setTimeout(() => setHit(null), 1500); }, 3000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center"><div className="relative w-16 h-24 border-2 border-slate-600 rounded-full flex flex-col items-center justify-around"><div className={`w-4 h-4 rounded-full ${hit === "Head" ? "bg-red-500 animate-pulse" : "bg-slate-700"}`} /><div className={`w-8 h-8 rounded ${hit === "Body" ? "bg-red-500 animate-pulse" : "bg-slate-700"}`} /><div className={`w-6 h-10 rounded ${hit === "Legs" ? "bg-red-500 animate-pulse" : "bg-slate-700"}`} /></div>{hit && <p className="absolute bottom-2 text-xs text-red-400">Hit: {hit}</p>}</div>; }
export function WeaponSway() { const [sway, setSway] = useState({ x: 0, y: 0 }); useEffect(() => { const i = setInterval(() => setSway({ x: Math.sin(Date.now() / 500) * 10, y: Math.cos(Date.now() / 700) * 5 }), 30); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center"><motion.span className="text-6xl" animate={{ x: sway.x, y: sway.y, scaleX: -1 }}>🔫</motion.span></div>; }
export function ScopeGlint() { const [glint, setGlint] = useState(false); useEffect(() => { const i = setInterval(() => { setGlint(true); setTimeout(() => setGlint(false), 200); }, 3000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center relative"><span className="text-5xl">🔭</span>{glint && <motion.div className="absolute w-4 h-4 bg-white rounded-full" initial={{ scale: 0, opacity: 1 }} animate={{ scale: 3, opacity: 0 }} transition={{ duration: 0.3 }} />}</div>; }
export function LaserSight() { const [on, setOn] = useState(true); return <div onClick={() => setOn(!on)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer relative"><span className="text-4xl" style={{ transform: "scaleX(-1)" }}>🔫</span>{on && <div className="absolute left-1/2 top-1/2 w-full h-0.5 bg-red-500" style={{ boxShadow: "0 0 10px #ef4444" }} />}</div>; }
export function FlashlightBeam() { const [angle, setAngle] = useState(0); useEffect(() => { const i = setInterval(() => setAngle(a => (a + 2) % 360), 30); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded relative overflow-hidden"><motion.div className="absolute left-1/2 top-1/2 w-32 h-64 bg-gradient-to-t from-yellow-400/50 to-transparent origin-bottom" style={{ rotate: angle, filter: "blur(8px)" }} /><div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-yellow-500 rounded-full" /></div>; }
export function RadiationMeter() { const [rads, setRads] = useState(0); useEffect(() => { const i = setInterval(() => setRads(r => (r + 5) % 101), 200); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-4xl">☢️</span><div className="w-32 h-3 bg-slate-800 rounded-full overflow-hidden"><motion.div className={`h-full ${rads > 70 ? "bg-red-500" : rads > 40 ? "bg-yellow-500" : "bg-green-500"}`} animate={{ width: `${rads}%` }} /></div><p className={`text-xs ${rads > 70 ? "text-red-400" : "text-green-400"}`}>{rads} RAD</p></div>; }
export function OxygenTank() { const [o2, setO2] = useState(100); useEffect(() => { const i = setInterval(() => setO2(o => o > 0 ? o - 1 : 100), 100); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-blue-950 to-black rounded flex flex-col items-center justify-center gap-2"><span className="text-4xl">🤿</span><div className="w-32 h-3 bg-blue-950 rounded-full overflow-hidden border border-cyan-500"><motion.div className={`h-full ${o2 > 30 ? "bg-cyan-400" : "bg-red-500 animate-pulse"}`} animate={{ width: `${o2}%` }} /></div><p className="text-xs text-cyan-400">O₂: {o2}%</p></div>; }
export function TemperatureGauge() { const [temp, setTemp] = useState(20); useEffect(() => { const i = setInterval(() => setTemp(t => -20 + (t + 5) % 121), 200); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-4xl">🌡️</span><p className={`text-3xl font-mono font-black ${temp > 40 ? "text-red-500" : temp < 0 ? "text-cyan-400" : "text-white"}`}>{temp}°C</p></div>; }
export function FallDamage() { const [falling, setFalling] = useState(false); const [damage, setDamage] = useState(0); const fall = () => { setFalling(true); setTimeout(() => { setDamage(Math.floor(Math.random() * 50)); setFalling(false); setTimeout(() => setDamage(0), 1000); }, 1500); }; return <div onClick={fall} className="w-full h-full min-h-[300px] bg-gradient-to-b from-sky-800 to-slate-900 rounded flex items-center justify-center cursor-pointer">{falling ? <motion.span className="text-5xl" animate={{ y: [0, 100] }} transition={{ duration: 1.5 }}>🤸</motion.span> : damage > 0 ? <motion.p initial={{ scale: 2 }} animate={{ scale: 1 }} className="text-red-500 text-3xl font-black">-{damage} HP</motion.p> : <p className="text-slate-500">Click to fall</p>}</div>; }
export function DrownWarning() { const [drowning, setDrowning] = useState(false); useEffect(() => { const i = setInterval(() => { setDrowning(true); setTimeout(() => setDrowning(false), 2000); }, 5000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-blue-900 to-blue-950 rounded flex items-center justify-center">{drowning && <motion.div initial={{ opacity: 0 }} animate={{ opacity: [0, 1, 0] }} transition={{ duration: 0.5, repeat: 3 }} className="absolute inset-0 border-4 border-red-500" />}<span className="text-5xl">🏊</span>{drowning && <p className="absolute bottom-2 text-red-500 text-sm font-bold animate-pulse">⚠️ DROWNING!</p>}</div>; }
export function BurnEffect() { const [burning, setBurning] = useState(false); const [dmg, setDmg] = useState(0); useEffect(() => { const i = setInterval(() => { setBurning(true); setDmg(d => d + 5); setTimeout(() => setBurning(false), 1000); }, 2000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative">{burning && <motion.div className="absolute inset-0 bg-orange-500/30" animate={{ opacity: [0.2, 0.5, 0.2] }} transition={{ duration: 0.3, repeat: 3 }} />}<span className="text-5xl">🔥</span><p className="absolute bottom-2 text-orange-400 text-sm">-{dmg} HP (fire)</p></div>; }
export function FreezeEffect() { const [frozen, setFrozen] = useState(false); return <div onClick={() => setFrozen(!frozen)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative">{frozen && <><motion.div className="absolute inset-0 bg-cyan-500/20" /><motion.div className="absolute inset-0 border-4 border-cyan-400" animate={{ scale: [1, 1.05, 1] }} transition={{ duration: 0.5, repeat: Infinity }} /></>}<span className="text-5xl">{frozen ? "🧊" : "🏃"}</span></div>; }
export function PoisonTick() { const [stacks, setStacks] = useState(0); useEffect(() => { const i = setInterval(() => setStacks(s => (s + 1) % 6), 1000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-4xl">🤢</span><div className="flex gap-1">{[...Array(5)].map((_, i) => <div key={i} className={`w-2 h-6 rounded ${i < stacks ? "bg-green-500" : "bg-slate-700"}`} />)}</div><p className="text-xs text-green-400">-{stacks * 5} HP/s</p></div>; }
export function StunIndicator() { const [stunned, setStunned] = useState(false); useEffect(() => { const i = setInterval(() => { setStunned(true); setTimeout(() => setStunned(false), 2000); }, 5000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative">{stunned && <><motion.div className="absolute inset-0 bg-yellow-500/20" animate={{ opacity: [0.2, 0.4, 0.2] }} transition={{ duration: 0.3, repeat: Infinity }} /><motion.div className="absolute top-4 left-1/2 -translate-x-1/2" animate={{ rotate: [0, 10, -10, 0] }} transition={{ duration: 0.3, repeat: Infinity }}><span className="text-4xl">⭐</span></motion.div></>}<span className="text-5xl">😵</span></div>; }
export function BleedEffect() { const [bleeding, setBleeding] = useState(0); useEffect(() => { const i = setInterval(() => setBleeding(b => (b + 1) % 6), 1000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-4xl">🩸</span><p className="text-red-400 text-sm font-mono">-{bleeding * 10} HP</p><p className="text-xs text-slate-500">Bleeding x{bleeding}</p></div>; }
export function HealOverTime() { const [healing, setHealing] = useState(0); useEffect(() => { const i = setInterval(() => setHealing(h => (h + 5) % 101), 200); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-4xl">💊</span><div className="w-32 h-3 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-green-500" animate={{ width: `${healing}%` }} style={{ boxShadow: "0 0 10px #22c55e" }} /></div><p className="text-xs text-green-400">+{healing} HP</p></div>; }
export function BuffDuration() { const [time, setTime] = useState(10); useEffect(() => { if (time > 0) { const i = setInterval(() => setTime(t => t - 1), 1000); return () => clearInterval(i); } else { setTimeout(() => setTime(10), 500); } }, [time]); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-4xl">⚡</span><div className="relative w-32 h-3 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-violet-500" animate={{ width: `${(time / 10) * 100}%` }} /><p className="absolute inset-0 flex items-center justify-center text-white text-xs font-mono">{time}s</p></div></div>; }
export function ReviveBar() { const [reviving, setReviving] = useState(false); const [prog, setProg] = useState(0); useEffect(() => { if (reviving) { const i = setInterval(() => setProg(p => { if (p >= 100) { setReviving(false); setTimeout(() => setProg(0), 1000); return 100; } return p + 5; }), 100); return () => clearInterval(i); } }, [reviving]); return <div onClick={() => !reviving && setReviving(true)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2 cursor-pointer">{prog === 100 ? <motion.p initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-green-400 font-bold text-xl">✓ REVIVED!</motion.p> : <><span className="text-4xl">💉</span><div className="w-40 h-3 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-green-500" animate={{ width: `${prog}%` }} /></div><p className="text-xs text-white">{reviving ? "Reviving..." : "Click to revive"}</p></>}</div>; }
export function KnockdownState() { const [down, setDown] = useState(false); return <div onClick={() => setDown(!down)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative">{down && <motion.div className="absolute inset-0 bg-red-500/20" animate={{ opacity: [0.1, 0.3, 0.1] }} transition={{ duration: 1, repeat: Infinity }} />}<motion.span className="text-5xl" animate={down ? { rotate: -90, y: 10 } : {}}>{down ? "🤕" : "🏃"}</motion.span>{down && <p className="absolute bottom-2 text-red-400 text-xs">NEED HELP!</p>}</div>; }
export function ExecutionPrompt() { const [available, setAvailable] = useState(false); useEffect(() => { const i = setInterval(() => { setAvailable(true); setTimeout(() => setAvailable(false), 2000); }, 5000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center">{available && <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-center"><p className="text-red-500 text-xl font-bold">☠️ EXECUTE</p><p className="text-xs text-white mt-1">Press [F] to finish</p></motion.div>}</div>; }
export function PickpocketPrompt() { const [stealing, setStealing] = useState(false); const [prog, setProg] = useState(0); useEffect(() => { if (stealing) { const i = setInterval(() => setProg(p => { if (p >= 100) { setStealing(false); setTimeout(() => setProg(0), 1000); return 100; } return p + 10; }), 100); return () => clearInterval(i); } }, [stealing]); return <div onClick={() => !stealing && setStealing(true)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2 cursor-pointer">{prog === 100 ? <motion.p initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-yellow-400">+50 Gold</motion.p> : <><span className="text-4xl">🤏</span>{stealing && <div className="w-32 h-2 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-yellow-500" animate={{ width: `${prog}%` }} /></div>}<p className="text-xs text-white">{stealing ? "Stealing..." : "Click to pickpocket"}</p></>}</div>; }
export function LockOnTarget() { const [locked, setLocked] = useState(false); return <div onClick={() => setLocked(!locked)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer relative"><motion.div className={`w-24 h-24 border-4 rounded-full ${locked ? "border-red-500" : "border-yellow-500"}`} animate={locked ? { scale: [1, 0.9, 1] } : { rotate: 360 }} transition={{ duration: locked ? 0.5 : 2, repeat: Infinity }} /><span className="text-3xl">{locked ? "🎯" : "⌖"}</span><p className="absolute bottom-2 text-xs" style={{ color: locked ? "#ef4444" : "#eab308" }}>{locked ? "LOCKED" : "Seeking..."}</p></div>; }
export function EnemyHealthTag() { const [hp, setHp] = useState(100); useEffect(() => { const i = setInterval(() => setHp(h => h > 0 ? h - 10 : 100), 500); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2 relative"><span className="text-4xl">👾</span><div className="w-32 h-2 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-red-500" animate={{ width: `${hp}%` }} /></div><p className="text-xs text-red-400">{hp} HP</p></div>; }
export function AllyHealthTag() { const [hp, setHp] = useState(80); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-4xl">🤝</span><div className="w-32 h-2 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-green-500" animate={{ width: `${hp}%` }} /></div><p className="text-xs text-green-400">Ally: {hp} HP</p></div>; }
export function WeaknessIndicator() { const parts = ["Head", "Body", "Legs"]; const [weak, setWeak] = useState(0); useEffect(() => { const i = setInterval(() => setWeak(w => (w + 1) % parts.length), 2000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center relative"><div className="relative w-16 h-24 border-2 border-slate-600 rounded-full flex flex-col items-center justify-around"><motion.div key={weak} className={`${weak === 0 ? "w-4 h-4 rounded-full" : weak === 1 ? "w-8 h-8 rounded" : "w-6 h-10 rounded"}`} initial={{ backgroundColor: "#1e293b" }} animate={{ backgroundColor: "#ef4444", boxShadow: "0 0 15px #ef4444" }} transition={{ duration: 0.5 }} /></div><p className="absolute bottom-2 text-xs text-red-400">Weak: {parts[weak]}</p></div>; }
export function BossPhase() { const [phase, setPhase] = useState(1); useEffect(() => { const i = setInterval(() => setPhase(p => p >= 3 ? 1 : p + 1), 4000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-red-950 to-black rounded flex flex-col items-center justify-center gap-2"><motion.p key={phase} initial={{ scale: 2, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-5xl font-black text-red-500">PHASE {phase}</motion.p><p className="text-xs text-white">Boss enters new phase!</p></div>; }
export function EnrageTimer() { const [time, setTime] = useState(30); useEffect(() => { if (time > 0) { const i = setInterval(() => setTime(t => t - 1), 1000); return () => clearInterval(i); } else { setTimeout(() => setTime(30), 1000); } }, [time]); return <div className="w-full h-full min-h-[300px] bg-black rounded flex flex-col items-center justify-center gap-2"><span className="text-4xl">😡</span><p className={`text-4xl font-mono font-black ${time < 10 ? "text-red-500 animate-pulse" : "text-white"}`}>{time}s</p><p className="text-xs text-red-400">Until Enrage</p></div>; }
export function MechanicWarning() { const [warning, setWarning] = useState(false); useEffect(() => { const i = setInterval(() => { setWarning(true); setTimeout(() => setWarning(false), 3000); }, 6000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center">{warning && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center"><p className="text-yellow-400 text-sm font-bold animate-pulse">⚠️ INCOMING ATTACK</p><p className="text-white text-xs mt-1">Dodge now!</p></motion.div>}</div>; }
export function InterruptCast() { const [casting, setCasting] = useState(false); const [prog, setProg] = useState(0); useEffect(() => { if (casting) { const i = setInterval(() => setProg(p => { if (p >= 100) { setCasting(false); setTimeout(() => setProg(0), 500); return 100; } return p + 5; }), 50); return () => clearInterval(i); } }, [casting]); return <div onClick={() => !casting && setCasting(true)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2 cursor-pointer"><span className="text-4xl">🧙</span>{casting && <div className="w-40 h-3 bg-slate-800 rounded-full overflow-hidden border border-purple-500"><motion.div className="h-full bg-purple-500" animate={{ width: `${prog}%` }} /></div>}<p className="text-xs text-white">{prog === 100 ? "SPELL CAST!" : casting ? "Casting..." : "Click to cast"}</p></div>; }
export function RaidMarker() { const markers = ["💀", "⭐", "🔵", "🟢", "🟡", "🔴", "🟣", "🟠"]; const [mark, setMark] = useState(0); return <div onClick={() => setMark((mark + 1) % markers.length)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer"><motion.span key={mark} initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1.5, rotate: 0 }} className="text-5xl">{markers[mark]}</motion.span></div>; }
export function ThreatMeter() { const [threat, setThreat] = useState(0); useEffect(() => { const i = setInterval(() => setThreat(t => (t + 5) % 101), 200); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-3xl">🎯</span><div className="w-40 h-3 bg-slate-800 rounded-full overflow-hidden"><motion.div className={`h-full ${threat > 70 ? "bg-red-500" : threat > 40 ? "bg-yellow-500" : "bg-green-500"}`} animate={{ width: `${threat}%` }} /></div><p className="text-xs text-white">Threat: {threat}%</p></div>; }
export function AggroIndicator() { const [aggro, setAggro] = useState(false); useEffect(() => { const i = setInterval(() => { setAggro(true); setTimeout(() => setAggro(false), 2000); }, 4000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center">{aggro && <motion.div className="flex items-center gap-2" initial={{ scale: 0 }} animate={{ scale: 1 }}><span className="text-4xl">👹</span><p className="text-red-500 font-bold">TARGETING YOU!</p></motion.div>}</div>; }
export function TauntEffect() { const [taunted, setTaunted] = useState(false); return <div onClick={() => setTaunted(true)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer">{taunted ? <motion.p initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} onAnimationComplete={() => setTimeout(() => setTaunted(false), 1500)} className="text-3xl">🤬 TAUNTED!</motion.p> : <span className="text-4xl">😏</span>}</div>; }
export function FearEffect() { const [feared, setFeared] = useState(false); return <div onClick={() => setFeared(!feared)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer"><motion.span className="text-5xl" animate={feared ? { x: [0, -20, 20, -10, 10, 0] } : {}} transition={{ duration: 1, repeat: feared ? Infinity : 0 }}>{feared ? "😱" : "🏃"}</motion.span></div>; }
export function CharmEffect() { const [charmed, setCharmed] = useState(false); return <div onClick={() => setCharmed(!charmed)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative">{charmed && <><motion.div className="absolute inset-0 bg-pink-500/20" />{[...Array(6)].map((_, i) => <motion.div key={i} className="absolute text-2xl" initial={{ scale: 0, x: 0, y: 0 }} animate={{ scale: 1, x: (Math.random() - 0.5) * 60, y: (Math.random() - 0.5) * 60, opacity: [1, 0] }} transition={{ duration: 1.5, delay: i * 0.2 }}>💕</motion.div>)}</>}<span className="text-5xl">😍</span></div>; }
export function SilenceEffect() { const [silenced, setSilenced] = useState(false); return <div onClick={() => setSilenced(!silenced)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative">{silenced && <motion.div className="absolute" initial={{ scale: 0 }} animate={{ scale: 1 }}><div className="absolute w-20 h-1 bg-red-500 rotate-45" /><div className="absolute w-20 h-1 bg-red-500 -rotate-45" /></motion.div>}<span className="text-5xl opacity-50">🔇</span></div>; }
export function RootEffect() { const [rooted, setRooted] = useState(false); return <div onClick={() => setRooted(!rooted)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative">{rooted && <motion.div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-16 h-20" initial={{ scaleY: 0 }} animate={{ scaleY: 1 }} transition={{ duration: 0.3 }}><span className="text-5xl">🌱</span></motion.div>}<span className="text-4xl">{rooted ? "🧍" : "🏃"}</span></div>; }
export function DisarmEffect() { const [disarmed, setDisarmed] = useState(false); return <div onClick={() => setDisarmed(!disarmed)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer">{disarmed ? <motion.div className="flex gap-8" initial={{ opacity: 0 }} animate={{ opacity: 1 }}><span className="text-4xl">🧍</span><motion.span className="text-3xl" animate={{ x: [0, 20], y: [0, -10], rotate: [0, 180] }} transition={{ duration: 0.5 }}>🗡️</motion.span></motion.div> : <span className="text-5xl">⚔️</span>}</div>; }
export function PolymorphEffect() { const forms = ["🐑", "🐸", "🐢", "🐛"]; const [form, setForm] = useState(null); useEffect(() => { const i = setInterval(() => { setForm(forms[Math.floor(Math.random() * forms.length)]); setTimeout(() => setForm(null), 3000); }, 6000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center">{form ? <motion.div initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }} className="flex flex-col items-center gap-2"><span className="text-5xl">{form}</span><p className="text-xs text-purple-400">Polymorphed!</p></motion.div> : <span className="text-5xl">🧙</span>}</div>; }
export function BerserkMode() { const [berserk, setBerserk] = useState(false); return <div onClick={() => setBerserk(!berserk)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer relative">{berserk && <><motion.div className="absolute inset-0 bg-red-500/40" animate={{ opacity: [0.2, 0.6, 0.2] }} transition={{ duration: 0.3, repeat: Infinity }} /><motion.div className="absolute inset-0 border-4 border-red-500" animate={{ scale: [1, 1.1, 1] }} transition={{ duration: 0.4, repeat: Infinity }} /></>}<span className="text-6xl">{berserk ? "😡" : "😐"}</span></div>; }
export function StealthIndicator() { const [detected, setDetected] = useState(false); useEffect(() => { const i = setInterval(() => { setDetected(true); setTimeout(() => setDetected(false), 1500); }, 4000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><motion.div animate={detected ? { scale: [1, 1.2, 1] } : { opacity: [0.5, 1, 0.5] }} transition={{ duration: 1, repeat: Infinity }} className={`w-16 h-16 rounded-full flex items-center justify-center ${detected ? "bg-red-500/30 border-2 border-red-500" : "bg-green-500/20 border border-green-500"}`}><span className="text-3xl">{detected ? "👁️" : "🥷"}</span></motion.div><p className={`text-xs font-bold ${detected ? "text-red-400" : "text-green-400"}`}>{detected ? "DETECTED!" : "Hidden"}</p></div>; }
export function NoiseIndicator() { const [volume, setVolume] = useState(0); useEffect(() => { const i = setInterval(() => { const spike = Math.random() > 0.7; setVolume(spike ? 80 + Math.random() * 20 : Math.random() * 30); }, 300); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-3xl">🔊</span><div className="w-40 h-3 bg-slate-800 rounded-full overflow-hidden"><motion.div className={`h-full ${volume > 50 ? "bg-red-500" : "bg-green-500"}`} animate={{ width: `${volume}%` }} transition={{ duration: 0.1 }} /></div><p className="text-xs text-white">Noise: {Math.round(volume)}%</p></div>; }
export function VisibilityMeter() { const [vis, setVis] = useState(0); useEffect(() => { const i = setInterval(() => setVis(v => (v + 10) % 101), 300); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2"><span className="text-3xl">{vis > 70 ? "👁️" : "🌑"}</span><div className="w-40 h-3 bg-slate-800 rounded-full overflow-hidden"><motion.div className={`h-full ${vis > 70 ? "bg-red-500" : "bg-green-500"}`} animate={{ width: `${vis}%` }} /></div><p className="text-xs text-white">Visibility: {vis}%</p></div>; }
export function ShadowBlend() { const [hidden, setHidden] = useState(false); return <div onClick={() => setHidden(!hidden)} className="w-full h-full min-h-[300px] bg-gradient-to-b from-slate-800 to-black rounded flex items-center justify-center cursor-pointer"><motion.span className="text-5xl" animate={hidden ? { opacity: [1, 0.2, 1] } : {}} transition={{ duration: 1, repeat: hidden ? Infinity : 0 }}>🥷</motion.span><p className="absolute bottom-2 text-xs text-white">{hidden ? "In shadows" : "Visible"}</p></div>; }
export function DistractionThrown() { const [thrown, setThrown] = useState(false); return <div onClick={() => setThrown(true)} className="w-full h-full min-h-[300px] bg-slate-900 rounded relative flex items-center justify-center cursor-pointer">{thrown && <motion.div className="absolute text-3xl" initial={{ left: "30%", top: "50%", rotate: 0 }} animate={{ left: "70%", top: "30%", rotate: 360 }} transition={{ duration: 0.6 }} onAnimationComplete={() => setThrown(false)}>💎</motion.div>}<span className="text-4xl">🤾</span></div>; }
export function GuardPattern() { const [alert, setAlert] = useState(false); useEffect(() => { const i = setInterval(() => { setAlert(true); setTimeout(() => setAlert(false), 1000); }, 3000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative"><motion.span className="text-5xl" animate={alert ? { rotate: [0, -30, 30, 0] } : {}} transition={{ duration: 0.5 }}>💂</motion.span>{alert && <motion.div className="absolute w-24 h-24 border-2 border-yellow-500 rounded-full" animate={{ scale: [1, 1.5], opacity: [0.5, 0] }} transition={{ duration: 1 }} />}</div>; }
export function EscapeRoute() { const [escape, setEscape] = useState(false); return <div onClick={() => setEscape(!escape)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer relative">{escape && <><motion.div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-1 bg-green-500" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ duration: 0.5 }} origin-left /><motion.div className="absolute left-0 top-1/2 text-2xl" animate={{ left: "90%" }} transition={{ duration: 2 }}>🏃💨</motion.div></>}<span className="text-4xl">🚪</span><p className="absolute bottom-2 text-xs text-green-400">{escape ? "Escaping!" : "Click to escape"}</p></div>; }

// ===== VEHICLES =====
export function SpeedLines() { 
  const [speed, setSpeed] = useState(0); 
  useEffect(() => { 
    const i = setInterval(() => setSpeed(s => (s + 5) % 101), 80); 
    return () => clearInterval(i); 
  }, []); 
  return <div className="w-full h-full min-h-[300px] bg-black rounded relative overflow-hidden">{[...Array(30)].map((_, i) => <motion.div key={i} className="absolute h-1 bg-cyan-400/70 rounded-full" style={{ top: `${(i * 100 / 30)}%`, left: 0 }} animate={{ width: `${speed}%` }} transition={{ duration: 0.1 }} />)}<p className="absolute bottom-4 right-4 text-xs text-cyan-400 bg-black/50 px-2 py-1 rounded">{speed}% speed</p></div>; 
}
export function DriftSmoke() { 
  const [particles, setParticles] = useState([]); 
  useEffect(() => { 
    const i = setInterval(() => { 
      const id = Date.now(); 
      setParticles(p => [...p.slice(-15), { id, y: 55 }]); 
      setTimeout(() => setParticles(p => p.filter(pp => pp.id !== id)), 1500); 
    }, 100); 
    return () => clearInterval(i); 
  }, []); 
  return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative overflow-hidden border border-slate-700"><span className="absolute left-1/2 top-1/2 -translate-y-1/2 -translate-x-1/2 text-7xl z-10" style={{ transform: "translate(-50%, -50%) scaleX(-1)" }}>🏎️</span>{particles.map(p => <motion.div key={p.id} className="absolute left-1/2 top-1/2 rounded-full bg-slate-500/60" style={{ width: 30, height: 30 }} initial={{ x: -60, y: 10, scale: 0.5, opacity: 0.9 }} animate={{ x: -200, y: 10 + (Math.random() - 0.5) * 40, scale: 4, opacity: 0 }} transition={{ duration: 1.2 }} />)}<p className="absolute bottom-4 left-4 text-xs text-slate-400 bg-black/50 px-2 py-1 rounded">Drifting smoke</p></div>; 
}
export function BoostFlames() { 
  const [boost, setBoost] = useState(false); 
  useEffect(() => { 
    const i = setInterval(() => { 
      setBoost(true); 
      setTimeout(() => setBoost(false), 1000); 
    }, 2000); 
    return () => clearInterval(i); 
  }, []); 
  return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative overflow-hidden"><span className="text-7xl z-10 relative" style={{ transform: "scaleX(-1)" }}>🏎️</span>{boost && <><motion.div className="absolute left-1/2 text-6xl" initial={{ x: -60, scale: 1, y: 0 }} animate={{ x: -250, scale: [1, 2.5, 0], opacity: [1, 0.6, 0] }} transition={{ duration: 0.8 }}>🔥</motion.div><motion.div className="absolute left-1/2 text-6xl" initial={{ x: -60, scale: 1, y: 0 }} animate={{ x: -250, scale: [1, 2.5, 0], opacity: [1, 0.6, 0] }} transition={{ duration: 0.8, delay: 0.1 }}>🔥</motion.div></>}<p className="absolute bottom-4 left-4 text-xs text-orange-400 bg-black/50 px-2 py-1 rounded">Auto boosting</p></div>; 
}
export function TireMarks() { 
  const [offset, setOffset] = useState(0); 
  useEffect(() => { 
    const i = setInterval(() => setOffset(o => (o + 5) % 100), 50); 
    return () => clearInterval(i); 
  }, []); 
  return <div className="w-full h-full min-h-[300px] bg-slate-800 rounded relative overflow-hidden border border-slate-700"><div className="absolute top-1/2 left-0 right-0 h-32 -translate-y-1/2 bg-slate-900/50" /><div className="absolute top-1/2 left-0 right-0 h-4 bg-black/40 -translate-y-8" style={{ background: `repeating-linear-gradient(90deg, transparent 0, transparent 20px, black 20px, black 40px)`, backgroundPositionX: `-${offset}%` }} /><div className="absolute top-1/2 left-0 right-0 h-4 bg-black/40 translate-y-8" style={{ background: `repeating-linear-gradient(90deg, transparent 0, transparent 20px, black 20px, black 40px)`, backgroundPositionX: `-${offset}%` }} /><span className="absolute left-1/2 top-1/2 text-7xl" style={{ transform: "translate(-50%, -50%) scaleX(-1)" }}>🏎️</span><p className="absolute bottom-4 left-4 text-xs text-slate-400 bg-black/50 px-2 py-1 rounded">Skid marks</p></div>; 
}
export function HelicopterRotor() { 
  return (
    <div className="w-full h-full min-h-[300px] bg-sky-900 rounded flex items-center justify-center relative overflow-hidden">
      <div className="relative">
        {/* Main Rotor */}
        <motion.div 
          className="absolute -top-8 left-1/2 -translate-x-1/2 w-48 h-2 bg-slate-300 blur-sm"
          animate={{ scaleX: [1, 0.1, 1] }}
          transition={{ duration: 0.1, repeat: Infinity }}
        />
        {/* Helicopter Body */}
        <div className="relative z-10">
          <div className="w-32 h-12 bg-slate-800 rounded-2xl relative">
            <div className="absolute right-0 top-0 w-12 h-12 bg-sky-400/50 rounded-r-2xl" /> {/* Cockpit */}
            <div className="absolute -left-12 top-4 w-16 h-4 bg-slate-800" /> {/* Tail boom */}
            <div className="absolute -left-14 top-0 w-4 h-12 bg-slate-300/50 blur-sm" /> {/* Tail rotor */}
            <div className="absolute top-12 left-8 w-16 h-2 bg-slate-600" /> {/* Skids */}
          </div>
        </div>
      </div>
    </div>
  );
}
export function PlaneContrails() { 
  const [trail, setTrail] = useState([]); 
  useEffect(() => { 
    const i = setInterval(() => { 
      const id = Date.now(); 
      setTrail(t => [...t.slice(-20), { id, x: 10 }]); 
      setTimeout(() => setTrail(t => t.filter(tt => tt.id !== id)), 2000); 
    }, 100); 
    return () => clearInterval(i); 
  }, []); 
  return <div className="w-full h-full min-h-[300px] bg-sky-900 rounded relative overflow-hidden border border-slate-700">{trail.map((t, i) => <motion.div key={t.id} className="absolute top-1/2 h-2 bg-white/60 rounded-full blur-sm" style={{ left: `${i * 5}%`, width: 40 }} initial={{ scale: 0.5, opacity: 1 }} animate={{ scale: 2, opacity: 0 }} transition={{ duration: 2 }} />)}<span className="absolute right-10 top-1/2 -translate-y-1/2 text-6xl" style={{ transform: "translateY(-50%) rotate(45deg)" }}>✈️</span></div>; 
}
export function SpeedometerGauge() { 
  const [speed, setSpeed] = useState(0); 
  useEffect(() => { 
    const i = setInterval(() => setSpeed(s => (s + 5) % 181), 100); 
    return () => clearInterval(i); 
  }, []); 
  return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center"><div className="relative w-48 h-48"><svg className="w-full h-full"><circle cx="96" cy="96" r="80" fill="none" stroke="#1e293b" strokeWidth="12" /><motion.circle cx="96" cy="96" r="80" fill="none" stroke="#06b6d4" strokeWidth="12" strokeDasharray={502} animate={{ strokeDashoffset: 502 - (speed / 180) * 502 }} className="-rotate-90 origin-center" style={{ transformOrigin: "96px 96px" }} /></svg><div className="absolute inset-0 flex flex-col items-center justify-center"><p className="text-5xl font-mono font-black text-white">{speed}</p><p className="text-sm text-slate-400">KM/H</p></div></div></div>; 
}
export function FuelGauge() { 
  const [fuel, setFuel] = useState(100); 
  useEffect(() => { 
    const i = setInterval(() => setFuel(f => f > 0 ? f - 1 : 100), 100); 
    return () => clearInterval(i); 
  }, []); 
  return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-4"><span className="text-7xl">⛽</span><div className="w-64 h-8 bg-slate-800 rounded-full overflow-hidden border-2 border-slate-600"><motion.div className={`h-full ${fuel > 30 ? "bg-green-500" : "bg-red-500 animate-pulse"}`} animate={{ width: `${fuel}%` }} /></div><p className={`text-xl font-mono ${fuel > 30 ? "text-green-400" : "text-red-400"}`}>{fuel}%</p></div>; 
}
export function NitroBar() { 
  const [nitro, setNitro] = useState(100); 
  const [using, setUsing] = useState(false); 
  useEffect(() => { 
    const i = setInterval(() => { 
      if (using && nitro > 0) setNitro(n => n - 5); 
      else if (!using && nitro < 100) setNitro(n => n + 2); 
      if (nitro <= 0) setUsing(false); 
    }, 100); 
    return () => clearInterval(i); 
  }, [using, nitro]); 
  return <div onMouseDown={() => nitro > 20 && setUsing(true)} onMouseUp={() => setUsing(false)} className="w-full h-full min-h-[300px] bg-black rounded flex flex-col items-center justify-center gap-6 cursor-pointer"><span className="text-7xl">{using ? "🔥" : "⚡"}</span><div className="w-80 h-8 bg-slate-800 rounded-full overflow-hidden border-2 border-orange-500"><motion.div className="h-full bg-gradient-to-r from-orange-500 to-red-500" animate={{ width: `${nitro}%` }} style={{ boxShadow: using ? "0 0 30px #f97316" : "none" }} /></div><p className="text-lg font-bold text-white">{using ? "BOOST ACTIVE!" : `Nitro: ${nitro}%`}</p><p className="text-xs text-slate-400">Hold to boost</p></div>; 
}

// ===== WEAPONS =====
export function BulletTracer() { 
  const [bullets, setBullets] = useState([]); 
  useEffect(() => { 
    const i = setInterval(() => { 
      const id = Date.now(); 
      setBullets(b => [...b.slice(-10), { id, y: 20 + Math.random() * 60 }]); 
      setTimeout(() => setBullets(b => b.filter(bb => bb.id !== id)), 400); 
    }, 200); 
    return () => clearInterval(i); 
  }, []); 
  return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative overflow-hidden border border-slate-700">{bullets.map(b => <motion.div key={b.id} className="absolute h-0.5 bg-yellow-300 w-12" style={{ left: "10%", top: `${b.y}%`, boxShadow: "0 0 10px #facc15" }} initial={{ x: 0, opacity: 1 }} animate={{ x: 400, opacity: 0 }} transition={{ duration: 0.3, ease: "linear" }} />)}<span className="absolute left-4 top-1/2 -translate-y-1/2 text-4xl" style={{ transform: "scaleX(-1)" }}>🔫</span></div>; 
}
export function ImpactSparks() { 
  const [impacts, setImpacts] = useState([]); 
  useEffect(() => { 
    const i = setInterval(() => { 
      const id = Date.now(); 
      setImpacts(imp => [...imp.slice(-5), { id, x: 60 + Math.random() * 20, y: 40 + Math.random() * 20 }]); 
      setTimeout(() => setImpacts(imp => imp.filter(ii => ii.id !== id)), 800); 
    }, 800); 
    return () => clearInterval(i); 
  }, []); 
  return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative"><div className="absolute right-1/4 top-1/2 -translate-y-1/2 w-24 h-32 bg-slate-700 border-2 border-slate-600" />{impacts.map(imp => <motion.span key={imp.id} className="absolute text-4xl" style={{ left: `${imp.x}%`, top: `${imp.y}%` }} initial={{ scale: 0, opacity: 1 }} animate={{ scale: 3, opacity: 0, rotate: 180 }} transition={{ duration: 0.5 }}>✨</motion.span>)}<p className="absolute bottom-4 left-4 text-xs text-yellow-400 bg-black/50 px-2 py-1 rounded">Impact effects</p></div>; 
}
export function LaserBeam({ showcase }) { 
  const [firing, setFiring] = useState(false); 
  useEffect(() => { 
    if (showcase) {
      const i = setInterval(() => { 
        setFiring(true); 
        setTimeout(() => setFiring(false), 1000); 
      }, 2000); 
      return () => clearInterval(i); 
    }
  }, [showcase]); 
  return (
    <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center relative" onMouseDown={() => setFiring(true)} onMouseUp={() => setFiring(false)}>
      {/* Gun on top */}
      <span className="absolute left-12 text-7xl z-20" style={{ transform: "scaleX(-1)" }}>🔫</span>
      {/* Beam underneath */}
      {firing && (
        <motion.div 
          className="absolute left-24 top-[48%] h-4 bg-red-500 z-10" 
          initial={{ width: 0 }} 
          animate={{ width: "80%" }} 
          style={{ 
            boxShadow: "0 0 20px #ef4444, 0 0 40px #ef4444",
            borderRadius: "0 100px 100px 0"
          }}
        />
      )}
    </div>
  ); 
}
export function ShotgunSpread() { 
  const [pellets, setPellets] = useState([]); 
  useEffect(() => { 
    const i = setInterval(() => { 
      const newPellets = [...Array(12)].map((_, i) => ({ id: Date.now() + i, angle: -30 + i * 5 })); 
      setPellets(newPellets); 
      setTimeout(() => setPellets([]), 600); 
    }, 1500); 
    return () => clearInterval(i); 
  }, []); 
  return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative"><span className="absolute left-8 top-1/2 -translate-y-1/2 text-7xl" style={{ transform: "scaleX(-1)" }}>🔫</span>{pellets.map(p => <motion.div key={p.id} className="absolute left-1/4 top-1/2 w-3 h-3 bg-yellow-400 rounded-full" style={{ boxShadow: "0 0 8px #facc15" }} initial={{ scale: 0, rotate: p.angle }} animate={{ scale: [1, 4], x: 200, opacity: 0 }} transition={{ duration: 0.5 }} />)}<p className="absolute bottom-4 left-4 text-xs text-yellow-400 bg-black/50 px-2 py-1 rounded">Shotgun spread</p></div>; 
}
export function SniperGlint() { 
  const [glint, setGlint] = useState(false); 
  useEffect(() => { 
    const i = setInterval(() => { 
      setGlint(true); 
      setTimeout(() => setGlint(false), 300); 
    }, 3000); 
    return () => clearInterval(i); 
  }, []); 
  return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center relative"><span className="text-7xl">🔭</span>{glint && <motion.div className="absolute w-12 h-12 bg-white rounded-full" initial={{ scale: 0, opacity: 1 }} animate={{ scale: 5, opacity: 0 }} transition={{ duration: 0.4 }} style={{ boxShadow: "0 0 60px #fff" }} />}<p className="absolute bottom-4 left-4 text-xs text-white bg-black/50 px-2 py-1 rounded">Scope glint</p></div>; 
}
export function RocketTrail({ showcase }) { 
  const [rockets, setRockets] = useState([]); 
  useEffect(() => { 
    if (showcase) {
      const i = setInterval(() => { 
        const id = Date.now(); 
        setRockets(r => [...r.slice(-3), { id, y: 20 + Math.random() * 60 }]); 
        setTimeout(() => setRockets(r => r.filter(rr => rr.id !== id)), 2000); 
      }, 1500); 
      return () => clearInterval(i); 
    }
  }, [showcase]); 
  return (
    <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative overflow-hidden group" onClick={() => !showcase && setRockets(r => [...r, { id: Date.now(), y: 50 }])}>
      {rockets.map(r => (
        <motion.div 
          key={r.id} 
          className="absolute left-0 flex items-center" 
          style={{ top: `${r.y}%` }} 
          initial={{ x: -50 }}
          animate={{ x: 500 }} 
          transition={{ duration: 2, ease: "linear" }}
        >
          {/* Trail first, then rocket */}
          <div className="flex items-center">
             <motion.div 
               className="h-2 w-24 bg-gradient-to-l from-orange-500 via-red-500 to-transparent rounded-l-full"
               animate={{ opacity: [0.6, 1, 0.6], width: [80, 100, 80] }}
               transition={{ duration: 0.2, repeat: Infinity }}
             />
             <span className="text-3xl -ml-2 z-10">🚀</span>
          </div>
        </motion.div>
      ))}
      <p className="absolute bottom-4 left-4 text-xs text-slate-500">Click to launch</p>
    </div>
  ); 
}
export function EnergyCharge() { 
  const [charge, setCharge] = useState(0); 
  useEffect(() => { 
    const i = setInterval(() => setCharge(c => (c + 5) % 101), 100); 
    return () => clearInterval(i); 
  }, []); 
  return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center relative"><motion.div className="absolute w-64 h-64 rounded-full" animate={{ opacity: charge / 100 }} style={{ background: `radial-gradient(circle, rgba(139, 92, 246, ${charge / 100}), transparent)`, boxShadow: `0 0 ${charge * 2}px rgba(139, 92, 246, 0.8)` }} /><span className="text-8xl relative z-10">⚡</span><p className="absolute bottom-4 text-xl font-mono text-violet-400">{charge}%</p></div>; 
}

// ===== CHARACTERS/AVATARS =====
export function IdleBreathing() { return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center"><motion.span className="text-6xl" animate={{ scale: [1, 1.05, 1], y: [0, -2, 0] }} transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}>🧍</motion.span></div>; }
export function WalkingCycle() { 
  return (
    <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative overflow-hidden">
      <div className="absolute bottom-10 w-full h-1 bg-slate-700" />
      <motion.div 
        className="text-6xl absolute bottom-10"
        animate={{ 
          x: ["-100%", "100%"],
          y: [0, -5, 0] 
        }} 
        transition={{ 
          x: { duration: 4, repeat: Infinity, ease: "linear" },
          y: { duration: 0.3, repeat: Infinity }
        }}
      >
        🚶
      </motion.div>
    </div>
  ); 
}
export function CharacterPortrait() { const [glow, setGlow] = useState(false); useEffect(() => { const i = setInterval(() => { setGlow(true); setTimeout(() => setGlow(false), 500); }, 3000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center"><motion.div className="w-24 h-24 rounded-full border-4 border-amber-500 bg-gradient-to-br from-amber-500/20 to-orange-500/10 flex items-center justify-center" animate={glow ? { boxShadow: "0 0 30px #facc15" } : { boxShadow: "0 0 5px #facc15" }} transition={{ duration: 0.3 }}><span className="text-5xl">🧙</span></motion.div></div>; }
export function CostumeChange() { const outfits = ["👔", "🦸", "🥷", "🤴"]; const [outfit, setOutfit] = useState(0); return <div onClick={() => setOutfit((outfit + 1) % outfits.length)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer"><motion.div key={outfit} initial={{ rotateY: -90, opacity: 0 }} animate={{ rotateY: 0, opacity: 1 }} transition={{ duration: 0.5 }}><span className="text-6xl">{outfits[outfit]}</span></motion.div></div>; }
export function ShadowEffect() { return <div className="w-full h-full min-h-[300px] bg-slate-800 rounded flex flex-col items-center justify-center gap-2"><motion.span className="text-6xl" animate={{ y: [-10, -30, -10] }} transition={{ duration: 2, repeat: Infinity }}>🤸</motion.span><motion.div className="w-16 h-4 bg-black/40 rounded-full" style={{ filter: "blur(4px)" }} animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 2, repeat: Infinity }} /></div>; }
export function FootstepDust() { 
  return (
    <div className="w-full h-full min-h-[300px] bg-slate-800 rounded relative overflow-hidden">
      <div className="absolute bottom-8 w-full h-2 bg-slate-700" />
      <motion.div
        className="absolute bottom-8 left-0 text-5xl z-10"
        animate={{ x: ["0%", "100%"] }}
        transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
        onUpdate={(latest) => {
          // In a real game engine we'd spawn particles here based on position
        }}
      >
        <div className="relative">
          🚶
          {/* Dust particles following feet */}
          <motion.div 
            className="absolute bottom-0 -left-4 text-2xl opacity-50"
            animate={{ scale: [0, 1.5], opacity: [0.8, 0], x: -20 }}
            transition={{ duration: 0.5, repeat: Infinity }}
          >
            💨
          </motion.div>
        </div>
      </motion.div>
    </div>
  ); 
}
export function JumpingArc() { return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-sky-600 to-slate-900 rounded flex items-center justify-center relative overflow-hidden"><div className="absolute bottom-0 w-full h-2 bg-green-700" /><motion.span className="text-5xl" animate={{ y: [40, -40, 40], x: [-40, 0, 40] }} transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}>🤸</motion.span></div>; }
export function CrouchingStealth() { const [crouched, setCrouched] = useState(false); return <div onClick={() => setCrouched(!crouched)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer"><motion.span className="text-6xl" animate={{ scaleY: crouched ? 0.6 : 1, y: crouched ? 20 : 0 }} transition={{ duration: 0.3 }}>{crouched ? "🙇" : "🧍"}</motion.span><p className="absolute bottom-2 text-xs text-white">{crouched ? "Crouching" : "Standing"}</p></div>; }

// ===== ENVIRONMENT/NATURE =====
export function SwayingTrees() { return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-sky-600 to-green-800 rounded flex items-end justify-center gap-4 px-8">{[...Array(5)].map((_, i) => <motion.span key={i} className="text-5xl" animate={{ rotate: [-5, 5, -5] }} transition={{ duration: 2 + i * 0.2, repeat: Infinity, ease: "easeInOut" }} style={{ transformOrigin: "bottom center" }}>🌲</motion.span>)}</div>; }
export function FallingLeaves() { const [leaves, setLeaves] = useState([]); useEffect(() => { const i = setInterval(() => { const id = Date.now(); setLeaves(l => [...l.slice(-10), { id, x: Math.random() * 90 + 5 }]); setTimeout(() => setLeaves(l => l.filter(ll => ll.id !== id)), 4000); }, 500); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-amber-100 to-orange-200 rounded relative overflow-hidden">{leaves.map(l => <motion.span key={l.id} className="absolute text-2xl" style={{ left: `${l.x}%` }} initial={{ top: -20, rotate: 0 }} animate={{ top: 200, rotate: 360, x: [0, 15, -15, 0] }} transition={{ duration: 3.5, ease: "linear" }}>🍂</motion.span>)}</div>; }
export function RainEffect() { 
  return (
    <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative overflow-hidden border border-slate-700">
      {/* Multiple layers of rain for depth */}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={`rain-back-${i}`}
          className="absolute w-0.5 h-8 bg-slate-500/30"
          style={{ left: `${Math.random() * 100}%`, top: -20 }}
          animate={{ top: ["0%", "100%"] }}
          transition={{ duration: 0.8 + Math.random() * 0.5, repeat: Infinity, ease: "linear", delay: Math.random() }}
        />
      ))}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={`rain-front-${i}`}
          className="absolute w-0.5 h-12 bg-blue-400/50"
          style={{ left: `${Math.random() * 100}%`, top: -20 }}
          animate={{ top: ["0%", "100%"] }}
          transition={{ duration: 0.5 + Math.random() * 0.3, repeat: Infinity, ease: "linear", delay: Math.random() }}
        />
      ))}
      <div className="absolute inset-0 bg-blue-900/10 pointer-events-none" />
    </div>
  ); 
}
export function SnowDrift() { const [flakes, setFlakes] = useState([]); useEffect(() => { const i = setInterval(() => { const id = Date.now(); setFlakes(f => [...f.slice(-25), { id, x: Math.random() * 100, size: 0.5 + Math.random() }]); setTimeout(() => setFlakes(f => f.filter(ff => ff.id !== id)), 6000); }, 200); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-slate-300 to-slate-400 rounded relative overflow-hidden">{flakes.map(f => <motion.span key={f.id} className="absolute" style={{ left: `${f.x}%`, fontSize: `${f.size}rem` }} initial={{ top: -20, rotate: 0 }} animate={{ top: 200, rotate: 360, x: [0, 10, -10, 0] }} transition={{ duration: 5, ease: "linear" }}>❄️</motion.span>)}</div>; }
export function FogLayer() { return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-slate-700 to-slate-900 rounded relative overflow-hidden"><motion.div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-slate-300/60 to-transparent" animate={{ opacity: [0.4, 0.7, 0.4], x: [-20, 20, -20] }} transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }} /><span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-5xl opacity-50">🏔️</span></div>; }
export function DayNightCycle() { const [time, setTime] = useState(0); useEffect(() => { const i = setInterval(() => setTime(t => (t + 1) % 360), 100); return () => clearInterval(i); }, []); const isDay = time < 180; const bgColor = isDay ? "from-sky-400 to-blue-300" : "from-slate-800 to-slate-950"; return <div className={`w-full h-full min-h-[300px] rounded relative overflow-hidden bg-gradient-to-b ${bgColor} transition-colors duration-1000`}><motion.div className="absolute text-5xl" animate={{ left: `${(time / 360) * 100}%`, top: `${50 - Math.sin((time * Math.PI) / 180) * 30}%` }}>{isDay ? "☀️" : "🌙"}</motion.div></div>; }
export function WaterRipples() { const [ripples, setRipples] = useState([]); const addRipple = () => { const id = Date.now(); setRipples(r => [...r.slice(-5), { id, x: 30 + Math.random() * 40, y: 30 + Math.random() * 40 }]); setTimeout(() => setRipples(r => r.filter(rr => rr.id !== id)), 2000); }; useEffect(() => { const i = setInterval(addRipple, 1500); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-blue-400 to-blue-600 rounded relative overflow-hidden">{ripples.map(r => <motion.div key={r.id} className="absolute border-2 border-white/50 rounded-full" style={{ left: `${r.x}%`, top: `${r.y}%` }} initial={{ width: 0, height: 0, opacity: 1 }} animate={{ width: 80, height: 80, opacity: 0 }} transition={{ duration: 1.5 }} />)}</div>; }
export function GrassRustle() { return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-green-600 to-green-900 rounded flex items-end justify-center gap-1 pb-2">{[...Array(12)].map((_, i) => <motion.span key={i} className="text-2xl" animate={{ rotate: [-10, 10, -10], y: [0, -5, 0] }} transition={{ duration: 1.5 + i * 0.1, repeat: Infinity, ease: "easeInOut" }} style={{ transformOrigin: "bottom center" }}>🌾</motion.span>)}</div>; }
export function LightningFlash({ showcase }) { 
  const [flash, setFlash] = useState(false); 
  useEffect(() => { 
    if (showcase) {
      const i = setInterval(() => { 
        setFlash(true); 
        setTimeout(() => setFlash(false), 100); 
        // Double flash effect
        setTimeout(() => {
           setFlash(true);
           setTimeout(() => setFlash(false), 200);
        }, 300);
      }, 4000); 
      return () => clearInterval(i); 
    }
  }, [showcase]); 
  return (
    <div 
      className="w-full h-full min-h-[300px] bg-slate-900 rounded relative overflow-hidden flex items-center justify-center" 
      onClick={() => !showcase && (setFlash(true), setTimeout(() => setFlash(false), 150))}
    >
      <div className="text-6xl z-10">⛈️</div>
      {/* Flash Overlay */}
      <div 
        className="absolute inset-0 bg-white transition-opacity duration-75 pointer-events-none" 
        style={{ opacity: flash ? 1 : 0 }}
      />
    </div>
  ); 
}

// ===== BUILDINGS/STRUCTURES =====
export function ConstructionProgress() { const [prog, setProg] = useState(0); useEffect(() => { const i = setInterval(() => setProg(p => (p + 2) % 101), 100); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative"><motion.div className="relative" animate={{ scale: prog / 100 }}><span className="text-6xl">🏗️</span></motion.div><div className="absolute bottom-4 w-3/4 h-3 bg-slate-800 rounded-full overflow-hidden"><motion.div className="h-full bg-amber-500" animate={{ width: `${prog}%` }} /></div><p className="absolute bottom-10 text-xs text-white">{prog}% Complete</p></div>; }
export function DamageCracks({ showcase }) { 
  const [damage, setDamage] = useState(0); 
  useEffect(() => { 
    if (showcase) {
      const i = setInterval(() => setDamage(d => (d + 20) % 120), 500); 
      return () => clearInterval(i); 
    }
  }, [showcase]); 
  return (
    <div className="w-full h-full min-h-[300px] bg-slate-800 rounded flex items-center justify-center relative" onClick={() => !showcase && setDamage(d => d + 20)}>
      <div className="w-32 h-32 bg-slate-600 rounded-lg relative overflow-hidden flex items-center justify-center border-4 border-slate-500">
        {damage > 20 && (
          <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 100 100">
            <path d="M 20 20 L 40 40 L 30 60" stroke="#1e293b" strokeWidth="2" fill="none" />
          </svg>
        )}
        {damage > 50 && (
          <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 100 100">
            <path d="M 80 20 L 60 40 L 70 70" stroke="#1e293b" strokeWidth="2" fill="none" />
          </svg>
        )}
        {damage > 80 && (
          <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 100 100">
            <path d="M 50 80 L 50 50 L 20 50" stroke="#1e293b" strokeWidth="3" fill="none" />
          </svg>
        )}
        <span className="text-4xl">🧱</span>
      </div>
      <div className="absolute bottom-4 w-full text-center">
        <div className="w-32 h-2 bg-black mx-auto rounded-full overflow-hidden">
          <motion.div className="h-full bg-red-500" animate={{ width: `${Math.min(100, damage)}%` }} />
        </div>
      </div>
    </div>
  ); 
}
export function BuildingOnFire() { 
  return (
    <div className="w-full h-full min-h-[300px] bg-slate-950 rounded flex items-center justify-center relative overflow-hidden">
      <div className="relative">
        <span className="text-8xl relative z-10 block">🏢</span>
        {/* Fire particles relative to building */}
        {[...Array(12)].map((_, i) => (
          <motion.div 
            key={i} 
            className="absolute text-2xl z-20" 
            style={{ 
              left: `${Math.random() * 80 + 10}%`, 
              bottom: `${Math.random() * 60 + 20}%` 
            }} 
            animate={{ 
              y: [0, -30], 
              opacity: [1, 0], 
              scale: [0.5, 1.5],
              x: (Math.random() - 0.5) * 20
            }} 
            transition={{ duration: 0.8 + Math.random(), repeat: Infinity, delay: Math.random() }}
          >
            🔥
          </motion.div>
        ))}
      </div>
    </div>
  ); 
}
export function DefenseTower() { 
  return (
    <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative">
      <div className="relative flex flex-col items-center">
        {/* Rotating Head */}
        <motion.div 
          className="w-16 h-16 rounded-full bg-slate-600 border-4 border-slate-500 relative z-10 flex items-center justify-center"
          animate={{ rotate: 360 }}
          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
        >
          {/* Gun Barrels */}
          <div className="absolute -right-4 w-8 h-2 bg-red-500" />
          <div className="absolute -right-4 w-8 h-2 bg-red-500 rotate-90" />
          <div className="w-8 h-8 rounded-full bg-slate-400" />
        </motion.div>
        {/* Base */}
        <div className="w-24 h-24 bg-slate-800 border-4 border-slate-700 -mt-2 rounded-lg" />
      </div>
    </div>
  ); 
}
export function DoorOpening({ showcase }) { 
  const [open, setOpen] = useState(false); 
  useEffect(() => {
    if (showcase) {
      const i = setInterval(() => setOpen(o => !o), 2000);
      return () => clearInterval(i);
    }
  }, [showcase]);
  return (
    <div onClick={() => setOpen(!open)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative perspective-1000">
      <div className="w-40 h-48 bg-slate-800 relative border-8 border-slate-700 flex overflow-hidden">
        {/* Left Door */}
        <motion.div 
          className="w-1/2 h-full bg-slate-600 border-r border-slate-900 flex items-center justify-end pr-2"
          animate={{ x: open ? "-90%" : "0%" }}
          transition={{ type: "spring", stiffness: 100 }}
        >
          <div className="w-2 h-8 bg-slate-400 rounded" />
        </motion.div>
        {/* Right Door */}
        <motion.div 
          className="w-1/2 h-full bg-slate-600 border-l border-slate-900 flex items-center justify-start pl-2"
          animate={{ x: open ? "90%" : "0%" }}
          transition={{ type: "spring", stiffness: 100 }}
        >
          <div className="w-2 h-8 bg-slate-400 rounded" />
        </motion.div>
        {/* Interior */}
        <div className="absolute inset-0 bg-black -z-10 flex items-center justify-center">
          <span className="text-4xl">💎</span>
        </div>
      </div>
    </div>
  ); 
}
export function WindowLight() { const [lit, setLit] = useState(true); useEffect(() => { const i = setInterval(() => setLit(l => !l), 2000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-slate-700 to-slate-900 rounded flex items-center justify-center"><div className="w-24 h-32 bg-slate-800 border-4 border-slate-700 relative"><motion.div className={`absolute inset-4 ${lit ? "bg-yellow-300" : "bg-slate-900"}`} animate={lit ? { opacity: [0.8, 1, 0.8] } : {}} transition={{ duration: 1, repeat: Infinity }} style={{ boxShadow: lit ? "0 0 20px #fde047" : "none" }} /></div></div>; }
export function RubbleCollapse() { const [collapsed, setCollapsed] = useState(false); const [debris, setDebris] = useState([]); const collapse = () => { setCollapsed(true); const newDebris = [...Array(12)].map((_, i) => ({ id: Date.now() + i, x: 40 + Math.random() * 20, y: 30 })); setDebris(newDebris); setTimeout(() => { setCollapsed(false); setDebris([]); }, 2000); }; return <div onClick={collapse} className="w-full h-full min-h-[300px] bg-slate-800 rounded flex items-center justify-center cursor-pointer relative">{!collapsed ? <span className="text-6xl">🏢</span> : <>{debris.map(d => <motion.div key={d.id} className="absolute text-2xl" initial={{ left: `${d.x}%`, top: `${d.y}%` }} animate={{ y: 100, x: (Math.random() - 0.5) * 60, rotate: Math.random() * 360 }} transition={{ duration: 1.5 }}>🧱</motion.div>)}</>}</div>; }
export function CheckpointStation() { const [active, setActive] = useState(true); return <div onClick={() => setActive(!active)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative">{active && <motion.div className="absolute w-24 h-full bg-cyan-500/20 border-2 border-cyan-400" animate={{ opacity: [0.4, 0.8, 0.4] }} transition={{ duration: 2, repeat: Infinity }} />}<span className="text-5xl relative z-10">🚩</span></div>; }
export function TeleporterPortal() { return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center relative"><motion.div className="absolute w-24 h-32 bg-gradient-to-r from-purple-500/40 via-cyan-500/40 to-purple-500/40 rounded-full" animate={{ rotate: 360, scale: [1, 1.1, 1] }} transition={{ rotate: { duration: 3, repeat: Infinity, ease: "linear" }, scale: { duration: 2, repeat: Infinity } }} /><span className="text-5xl relative z-10">🌀</span></div>; }

// ===== EXPLOSIONS/EFFECTS =====
export function NuclearBlast({ showcase }) { 
  const [blast, setBlast] = useState(false); 
  useEffect(() => { 
    if (showcase) {
      const i = setInterval(() => { setBlast(true); setTimeout(() => setBlast(false), 3000); }, 5000); 
      return () => clearInterval(i); 
    }
  }, [showcase]); 
  return (
    <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center relative overflow-hidden" onClick={() => !showcase && setBlast(true)}>
      {blast && (
        <>
          {/* Flash */}
          <motion.div className="absolute inset-0 bg-white" initial={{ opacity: 1 }} animate={{ opacity: 0 }} transition={{ duration: 0.5 }} />
          {/* Mushroom Cap */}
          <motion.div 
            className="absolute top-1/3 w-32 h-24 bg-orange-500 rounded-full filter blur-md"
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: [0, 2], opacity: [1, 0] }}
            transition={{ duration: 2 }}
          />
          {/* Stem */}
          <motion.div 
            className="absolute bottom-0 w-12 h-40 bg-orange-600 blur-sm"
            initial={{ height: 0 }}
            animate={{ height: "60%" }}
            transition={{ duration: 1 }}
          />
          {/* Shockwave */}
          <motion.div 
            className="absolute bottom-0 w-full h-8 bg-white/20 rounded-[50%]"
            initial={{ scale: 0 }}
            animate={{ scale: 4, opacity: 0 }}
            transition={{ duration: 1.5 }}
          />
        </>
      )}
      {!blast && <span className="text-4xl cursor-pointer">☢️</span>}
    </div>
  ); 
}
export function ShockwaveRing() { const [wave, setWave] = useState(false); useEffect(() => { const i = setInterval(() => { setWave(true); setTimeout(() => setWave(false), 1500); }, 3000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative overflow-hidden">{wave && <motion.div className="absolute w-8 h-8 border-4 border-cyan-400 rounded-full" initial={{ scale: 0, opacity: 1 }} animate={{ scale: 15, opacity: 0 }} transition={{ duration: 1.2 }} />}<span className="text-5xl">💥</span></div>; }
export function FireExplosion({ showcase }) { 
  const [explode, setExplode] = useState(false); 
  useEffect(() => { 
    if (showcase) {
      const i = setInterval(() => { setExplode(true); setTimeout(() => setExplode(false), 1000); }, 2000); 
      return () => clearInterval(i); 
    }
  }, [showcase]); 
  return (
    <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center relative overflow-hidden" onClick={() => setExplode(true)}>
      {explode && (
        <>
          <motion.div className="absolute w-20 h-20 bg-yellow-400 rounded-full blur-md" initial={{ scale: 0 }} animate={{ scale: 4, opacity: 0 }} transition={{ duration: 0.4 }} />
          {[...Array(16)].map((_, i) => (
            <motion.div 
              key={i} 
              className="absolute w-4 h-4 bg-orange-500 rounded-full"
              initial={{ x: 0, y: 0 }}
              animate={{ 
                x: (Math.random() - 0.5) * 200, 
                y: (Math.random() - 0.5) * 200,
                opacity: 0,
                scale: 0
              }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            />
          ))}
        </>
      )}
      {!explode && <span className="text-4xl cursor-pointer">💣</span>}
    </div>
  ); 
}
export function SmokePlume() { const [smoke, setSmoke] = useState([]); useEffect(() => { const i = setInterval(() => { const id = Date.now(); setSmoke(s => [...s.slice(-8), { id }]); setTimeout(() => setSmoke(s => s.filter(sm => sm.id !== id)), 3000); }, 400); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-slate-600 to-black rounded relative overflow-hidden">{smoke.map((s, i) => <motion.div key={s.id} className="absolute bottom-0 left-1/2 -translate-x-1/2 text-3xl" initial={{ y: 0, scale: 0.5, opacity: 0.8 }} animate={{ y: -120, scale: 2, opacity: 0, x: (Math.random() - 0.5) * 40 }} transition={{ duration: 2.5 }}>💨</motion.div>)}</div>; }
export function ElectricDischarge() { const [zap, setZap] = useState(false); useEffect(() => { const i = setInterval(() => { setZap(true); setTimeout(() => setZap(false), 200); }, 1500); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center relative">{zap && <><motion.div className="absolute inset-0 bg-blue-300/40" initial={{ opacity: 0 }} animate={{ opacity: [0, 1, 0] }} transition={{ duration: 0.2 }} />{[...Array(8)].map((_, i) => <motion.div key={i} className="absolute w-1 bg-cyan-400" style={{ height: "50%", left: "50%", top: "50%", transformOrigin: "top", rotate: i * 45 }} initial={{ scaleY: 0 }} animate={{ scaleY: [0, 1, 0] }} transition={{ duration: 0.15 }} />)}</>}<span className="text-5xl relative z-10">⚡</span></div>; }
export function FreezeBurst() { const [burst, setBurst] = useState(false); useEffect(() => { const i = setInterval(() => { setBurst(true); setTimeout(() => setBurst(false), 1500); }, 3500); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative overflow-hidden">{burst && <>{[...Array(16)].map((_, i) => <motion.div key={i} className="absolute text-2xl" initial={{ scale: 0, x: 0, y: 0 }} animate={{ scale: 1, x: Math.cos((i * 22.5 * Math.PI) / 180) * 80, y: Math.sin((i * 22.5 * Math.PI) / 180) * 80, opacity: 0 }} transition={{ duration: 0.8 }}>❄️</motion.div>)}<motion.div className="absolute w-20 h-20 bg-cyan-500/30 rounded-full border-4 border-cyan-400" initial={{ scale: 0 }} animate={{ scale: 2, opacity: 0 }} transition={{ duration: 1 }} /></>}<span className="text-5xl">🧊</span></div>; }
export function AcidSplash() { const [splash, setSplash] = useState(false); useEffect(() => { const i = setInterval(() => { setSplash(true); setTimeout(() => setSplash(false), 1000); }, 3000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center relative overflow-hidden">{splash && [...Array(10)].map((_, i) => <motion.div key={i} className="absolute bottom-1/2 left-1/2 w-2 h-2 bg-green-500 rounded-full" initial={{ scale: 0, x: 0, y: 0 }} animate={{ scale: 2, x: (Math.random() - 0.5) * 100, y: Math.random() * -60, opacity: 0 }} transition={{ duration: 0.8 }} />)}<span className="text-5xl">☣️</span></div>; }
export function DustCloud() { const [cloud, setCloud] = useState(false); useEffect(() => { const i = setInterval(() => { setCloud(true); setTimeout(() => setCloud(false), 2000); }, 4000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-amber-100 rounded flex items-center justify-center relative overflow-hidden">{cloud && <motion.div className="absolute inset-0 bg-amber-800/60" initial={{ scale: 0, opacity: 1 }} animate={{ scale: 3, opacity: 0 }} transition={{ duration: 1.5 }} />}<span className="text-5xl relative z-10">💥</span></div>; }
export function ScreenShake() { const [shake, setShake] = useState(false); useEffect(() => { const i = setInterval(() => { setShake(true); setTimeout(() => setShake(false), 500); }, 3000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative overflow-hidden"><motion.div className="text-center" animate={shake ? { x: [0, -5, 5, -3, 3, 0], y: [0, 3, -3, 2, -2, 0] } : {}} transition={{ duration: 0.4 }}><span className="text-6xl">💥</span><p className="text-white text-sm mt-2">{shake ? "IMPACT!" : "..."}</p></motion.div></div>; }

// ===== COMBAT UI =====
export function BlockIndicator() { const [incoming, setIncoming] = useState(false); useEffect(() => { const i = setInterval(() => { setIncoming(true); setTimeout(() => setIncoming(false), 1000); }, 3000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative">{incoming && <><motion.div className="absolute inset-0 border-4 border-red-500" animate={{ opacity: [0.3, 1, 0.3] }} transition={{ duration: 0.3, repeat: 3 }} /><motion.p className="text-yellow-400 font-bold text-xl absolute top-4" initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}>⚠️ BLOCK!</motion.p></>}<span className="text-5xl">🛡️</span></div>; }
export function CounterAttack() { const [counter, setCounter] = useState(false); return <div onClick={() => setCounter(true)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer">{counter ? <motion.div initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }} onAnimationComplete={() => setTimeout(() => setCounter(false), 800)} className="text-center"><p className="text-cyan-400 text-3xl font-black">COUNTER!</p><p className="text-white text-xs">+200 DMG</p></motion.div> : <span className="text-5xl">⚔️</span>}</div>; }
export function FinisherPrompt() { const [ready, setReady] = useState(false); useEffect(() => { const i = setInterval(() => { setReady(true); setTimeout(() => setReady(false), 2500); }, 5000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center">{ready && <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-center px-6 py-3 bg-gradient-to-r from-red-600 to-orange-600 rounded-xl border-4 border-white"><p className="text-white font-black text-2xl">FINISH HIM!</p><p className="text-xs text-white/80 mt-1">Press [F]</p></motion.div>}</div>; }
export function WeakPoint() { const [weak, setWeak] = useState(null); useEffect(() => { const i = setInterval(() => { setWeak({ x: 30 + Math.random() * 40, y: 30 + Math.random() * 40 }); setTimeout(() => setWeak(null), 2000); }, 4000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative"><span className="text-6xl">👹</span>{weak && <motion.div className="absolute w-8 h-8 border-4 border-yellow-400 rounded-full" style={{ left: `${weak.x}%`, top: `${weak.y}%` }} animate={{ scale: [1, 1.3, 1] }} transition={{ duration: 0.5, repeat: Infinity }} />}</div>; }
export function ComboString() { const [combo, setCombo] = useState([]); const moves = ["👊", "🦵", "⚔️"]; const hit = () => setCombo(c => [...c.slice(-4), moves[Math.floor(Math.random() * moves.length)]]); useEffect(() => { if (combo.length > 0) { const t = setTimeout(() => setCombo([]), 3000); return () => clearTimeout(t); } }, [combo]); return <div onClick={hit} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer"><div className="flex gap-2">{combo.length === 0 ? <p className="text-slate-500">Click to combo</p> : combo.map((m, i) => <motion.span key={i} initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-3xl">{m}</motion.span>)}</div></div>; }
export function GuardBreak() { const [broken, setBroken] = useState(false); useEffect(() => { const i = setInterval(() => { setBroken(true); setTimeout(() => setBroken(false), 1500); }, 4000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative">{broken ? <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-center"><p className="text-orange-500 text-3xl font-black">GUARD BROKEN!</p>{[...Array(6)].map((_, i) => <motion.div key={i} className="absolute text-2xl" initial={{ x: 0, y: 0 }} animate={{ x: (Math.random() - 0.5) * 80, y: (Math.random() - 0.5) * 80, opacity: 0, rotate: 360 }} transition={{ duration: 0.8 }}>💥</motion.div>)}</motion.div> : <span className="text-5xl">🛡️</span>}</div>; }
export function BackstabIndicator() { const [backstab, setBackstab] = useState(false); return <div onClick={() => setBackstab(true)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer">{backstab ? <motion.p initial={{ scale: 0, rotate: -20 }} animate={{ scale: 1, rotate: 0 }} onAnimationComplete={() => setTimeout(() => setBackstab(false), 1000)} className="text-red-500 text-4xl font-black">🗡️ BACKSTAB!</motion.p> : <span className="text-5xl">🥷</span>}</div>; }
export function RevengeMode() { const [revenge, setRevenge] = useState(false); return <div onClick={() => setRevenge(!revenge)} className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center cursor-pointer relative">{revenge && <><motion.div className="absolute inset-0 bg-red-500/30" animate={{ opacity: [0.2, 0.5, 0.2] }} transition={{ duration: 0.5, repeat: Infinity }} /><motion.div className="absolute inset-0 border-4 border-red-500" animate={{ scale: [1, 1.05, 1] }} transition={{ duration: 0.5, repeat: Infinity }} /></>}<span className="text-6xl">{revenge ? "😡" : "😐"}</span><p className="absolute bottom-2 text-xs text-red-400">{revenge ? "REVENGE MODE!" : ""}</p></div>; }
export function BattleStance() { const stances = [{ name: "Offensive", icon: "⚔️", color: "#ef4444" }, { name: "Defensive", icon: "🛡️", color: "#3b82f6" }, { name: "Balanced", icon: "⚖️", color: "#22c55e" }]; const [stance, setStance] = useState(0); return <div onClick={() => setStance((stance + 1) % stances.length)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-2 cursor-pointer"><motion.span key={stance} initial={{ scale: 0, rotate: -90 }} animate={{ scale: 1, rotate: 0 }} className="text-5xl">{stances[stance].icon}</motion.span><p className="text-sm font-bold" style={{ color: stances[stance].color }}>{stances[stance].name}</p></div>; }

// ===== PROJECTILES/AMMUNITION =====
export function ArrowFlight() { const [arrows, setArrows] = useState([]); useEffect(() => { const i = setInterval(() => { const id = Date.now(); setArrows(a => [...a.slice(-3), { id, y: 20 + Math.random() * 60 }]); setTimeout(() => setArrows(a => a.filter(ar => ar.id !== id)), 1500); }, 1000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-r from-green-900 to-slate-900 rounded relative overflow-hidden">{arrows.map(a => <motion.div key={a.id} className="absolute text-3xl" style={{ left: "10%", top: `${a.y}%` }} initial={{ rotate: 0 }} animate={{ x: 280, rotate: -10 }} transition={{ duration: 1.2 }}>➤</motion.div>)}<span className="absolute left-4 top-1/2 -translate-y-1/2 text-4xl">🏹</span></div>; }
export function GrenadeArcPreview() { const [preview, setPreview] = useState(false); return <div onMouseEnter={() => setPreview(true)} onMouseLeave={() => setPreview(false)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative">{preview && <svg className="absolute inset-0 w-full h-full"><motion.path d="M 20 80 Q 50 20, 80 80" fill="none" stroke="#facc15" strokeWidth="2" strokeDasharray="5,5" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 0.5 }} /></svg>}<span className="text-4xl relative z-10">💣</span></div>; }
export function BoomerangReturn() { const [throwing, setThrowing] = useState(false); return <div onClick={() => setThrowing(true)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative">{throwing && <motion.div className="absolute text-4xl" initial={{ left: "30%", top: "50%", rotate: 0 }} animate={{ left: ["30%", "80%", "30%"], top: ["50%", "30%", "50%"], rotate: [0, 720, 1440] }} transition={{ duration: 2 }} onAnimationComplete={() => setThrowing(false)}>🪃</motion.div>}<span className="text-5xl">🤾</span></div>; }
export function StickyBomb() { const [attached, setAttached] = useState(false); const [countdown, setCountdown] = useState(3); useEffect(() => { if (attached && countdown > 0) { const i = setInterval(() => setCountdown(c => c - 1), 1000); return () => clearInterval(i); } if (countdown === 0) { setTimeout(() => { setAttached(false); setCountdown(3); }, 500); } }, [attached, countdown]); return <div onClick={() => !attached && setAttached(true)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative">{attached && countdown > 0 ? <><motion.span className="text-5xl" animate={{ scale: countdown < 2 ? [1, 1.2, 1] : 1 }} transition={{ duration: 0.3, repeat: Infinity }}>💣</motion.span><p className={`absolute bottom-2 text-3xl font-mono font-black ${countdown < 2 ? "text-red-500" : "text-white"}`}>{countdown}</p></> : countdown === 0 ? <motion.div initial={{ scale: 0 }} animate={{ scale: 2, opacity: 0 }}><span className="text-6xl">💥</span></motion.div> : <span className="text-4xl">💣</span>}</div>; }
export function HomingMissile() { const [target, setTarget] = useState({ x: 70, y: 50 }); const [missile, setMissile] = useState({ x: 20, y: 50 }); useEffect(() => { const i = setInterval(() => { setTarget({ x: 30 + Math.random() * 40, y: 30 + Math.random() * 40 }); setMissile(m => ({ x: m.x + (target.x - m.x) * 0.1, y: m.y + (target.y - m.y) * 0.1 })); }, 100); return () => clearInterval(i); }, [target]); return <div className="w-full h-full min-h-[300px] bg-black rounded relative"><motion.div className="absolute w-4 h-4 bg-red-500 rounded-full" style={{ left: `${target.x}%`, top: `${target.y}%` }} animate={{ scale: [1, 1.3, 1] }} transition={{ duration: 0.5, repeat: Infinity }} /><motion.div className="absolute text-3xl" animate={{ left: `${missile.x}%`, top: `${missile.y}%` }}>🚀</motion.div></div>; }
export function RicochetBullet() { const [bullets, setBullets] = useState([]); useEffect(() => { const i = setInterval(() => { const id = Date.now(); setBullets(b => [...b.slice(-2), { id, bounces: 0 }]); setTimeout(() => setBullets(b => b.filter(bu => bu.id !== id)), 2000); }, 2500); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-950 rounded relative overflow-hidden">{bullets.map(b => <motion.div key={b.id} className="absolute w-2 h-2 bg-yellow-400 rounded-full" initial={{ left: "10%", top: "50%" }} animate={{ left: ["10%", "50%", "90%"], top: ["50%", "20%", "50%"] }} transition={{ duration: 1.5 }} />)}</div>; }
export function ChainLightning() { const [zaps, setZaps] = useState([]); useEffect(() => { const i = setInterval(() => { const newZaps = [...Array(4)].map((_, i) => ({ id: Date.now() + i, x: 20 + i * 20, y: 30 + Math.random() * 40 })); setZaps(newZaps); setTimeout(() => setZaps([]), 500); }, 2000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded relative">{zaps.map((z, i) => <motion.div key={z.id} className="absolute w-1 h-16 bg-cyan-400" style={{ left: `${z.x}%`, top: `${z.y}%`, rotate: (Math.random() - 0.5) * 40, boxShadow: "0 0 10px #22d3ee" }} initial={{ scaleY: 0 }} animate={{ scaleY: 1 }} transition={{ duration: 0.2 }} />)}</div>; }
export function PiercingShot() { const [piercing, setPiercing] = useState(false); useEffect(() => { const i = setInterval(() => { setPiercing(true); setTimeout(() => setPiercing(false), 1000); }, 2500); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded relative flex items-center justify-center">{piercing && <><motion.div className="absolute left-1/4 w-4 h-20 bg-slate-700 border-2 border-slate-600" /><motion.div className="absolute left-1/2 top-1/2 w-full h-0.5 bg-cyan-400" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ duration: 0.3 }} style={{ boxShadow: "0 0 10px #22d3ee" }} /></>}<span className="text-4xl relative z-10">🏹</span></div>; }
export function AreaGrenadePreview() { const [radius, setRadius] = useState(0); useEffect(() => { const i = setInterval(() => setRadius(r => (r + 5) % 81), 100); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center relative"><motion.div className="absolute w-32 h-32 border-2 border-red-500/50 rounded-full bg-red-500/10" animate={{ scale: 0.5 + radius / 100 }} /><span className="text-4xl relative z-10">💣</span><p className="absolute bottom-2 text-xs text-red-400">Blast: {radius}m</p></div>; }

// ===== UI OVERLAYS =====
export function VictoryScreen() { const [show, setShow] = useState(false); useEffect(() => { const i = setInterval(() => { setShow(true); setTimeout(() => setShow(false), 3000); }, 6000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-yellow-900 to-black rounded flex items-center justify-center relative overflow-hidden">{show && <><motion.div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-500/30 to-transparent" animate={{ x: ["-100%", "100%"] }} transition={{ duration: 1, repeat: 2 }} /><motion.div initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }} className="text-center"><p className="text-6xl font-black text-yellow-400">🏆</p><p className="text-3xl font-bold text-white mt-2">VICTORY!</p><p className="text-sm text-yellow-300">+1000 XP</p></motion.div></>}</div>; }
export function DefeatBanner() { const [show, setShow] = useState(false); useEffect(() => { const i = setInterval(() => { setShow(true); setTimeout(() => setShow(false), 3000); }, 6000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-gradient-to-b from-red-950 to-black rounded flex items-center justify-center">{show && <motion.div initial={{ opacity: 0, y: -50 }} animate={{ opacity: 1, y: 0 }} className="text-center"><p className="text-5xl font-black text-red-500">DEFEAT</p><p className="text-white text-sm mt-2">Better luck next time</p></motion.div>}</div>; }
export function PauseMenuOverlay() { const [paused, setPaused] = useState(false); return <div onClick={() => setPaused(!paused)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer">{paused ? <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-black/90 px-6 py-4 rounded-xl border border-white/20 text-center"><p className="text-white font-bold text-xl mb-3">PAUSED</p><button className="px-4 py-2 bg-green-600 rounded text-white text-sm mb-2 w-full">Resume</button><button className="px-4 py-2 bg-slate-700 rounded text-white text-sm w-full">Quit</button></motion.div> : <p className="text-slate-400">Click to pause</p>}</div>; }
export function OptionsSlider() { const [value, setValue] = useState(50); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex flex-col items-center justify-center gap-3 p-6"><p className="text-white text-sm">🔊 Master Volume</p><input type="range" min="0" max="100" value={value} onChange={(e) => setValue(e.target.value)} className="w-full accent-violet-500" /><p className="text-xs text-slate-400">{value}%</p></div>; }
export function KeybindDisplay() { const binds = [{ key: "W", action: "Forward" }, { key: "Space", action: "Jump" }, { key: "E", action: "Use" }]; return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded p-4">{binds.map((b, i) => <div key={i} className="flex justify-between items-center py-2 border-b border-slate-700 last:border-0"><span className="text-white text-xs">{b.action}</span><span className="px-2 py-1 bg-slate-800 border border-slate-600 rounded text-xs text-white font-mono">{b.key}</span></div>)}</div>; }
export function TutorialArrow() { const [show, setShow] = useState(true); return <div onClick={() => setShow(!show)} className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center cursor-pointer relative">{show && <><motion.div className="absolute right-1/4 top-1/2 -translate-y-1/2 text-5xl" animate={{ x: [0, 10, 0] }} transition={{ duration: 1, repeat: Infinity }}>👉</motion.div><p className="text-white text-sm">Click here!</p></>}</div>; }
export function NotificationStack() { const [notifs, setNotifs] = useState([]); useEffect(() => { const messages = ["New message!", "Quest complete", "Level up!", "Item found"]; const i = setInterval(() => { const id = Date.now(); setNotifs(n => [...n.slice(-3), { id, msg: messages[Math.floor(Math.random() * messages.length)] }]); setTimeout(() => setNotifs(n => n.filter(no => no.id !== id)), 3000); }, 2000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded p-2 flex flex-col-reverse gap-1 justify-start overflow-hidden">{notifs.map(n => <motion.div key={n.id} initial={{ x: 100, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -100, opacity: 0 }} className="bg-violet-600 px-3 py-2 rounded text-white text-xs">{n.msg}</motion.div>)}</div>; }
export function CurrencyPopup() { const [show, setShow] = useState(false); useEffect(() => { const i = setInterval(() => { setShow(true); setTimeout(() => setShow(false), 1500); }, 3000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-slate-900 rounded flex items-center justify-center">{show && <motion.p initial={{ y: 0, scale: 1, opacity: 1 }} animate={{ y: -40, scale: 1.5, opacity: 0 }} transition={{ duration: 1.2 }} className="text-yellow-400 text-2xl font-bold">+100 🪙</motion.p>}</div>; }
export function MissionComplete() { const [complete, setComplete] = useState(false); useEffect(() => { const i = setInterval(() => { setComplete(true); setTimeout(() => setComplete(false), 3000); }, 6000); return () => clearInterval(i); }, []); return <div className="w-full h-full min-h-[300px] bg-black rounded flex items-center justify-center">{complete && <motion.div initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center"><p className="text-green-400 text-4xl font-black">✓ MISSION</p><p className="text-white text-2xl font-bold mt-1">COMPLETE</p><p className="text-yellow-400 text-sm mt-2">+500 XP | +250 Gold</p></motion.div>}</div>; }