import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, Github, Linkedin, Moon, Sun, Zap, Globe, Eye, Copy, ChevronUp, Instagram, Facebook, Youtube } from "lucide-react";
import WilsonQuote from "@/components/effects/WilsonQuote";
import ComponentCounter from "@/components/footer/ComponentCounter";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

// X (Twitter) icon component
function XIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>);

}

// Animated starfield
function Starfield() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {[...Array(50)].map((_, i) =>
      <motion.div
        key={i}
        className="absolute w-1 h-1 bg-white rounded-full"
        style={{
          left: `${Math.random() * 100}%`,
          top: `${Math.random() * 100}%`
        }}
        animate={{
          opacity: [0.2, 1, 0.2],
          scale: [0.5, 1, 0.5]
        }}
        transition={{
          duration: 2 + Math.random() * 2,
          repeat: Infinity,
          delay: Math.random() * 2
        }} />

      )}
    </div>);

}

// Wave divider
function WaveDivider() {
  return (
    <div className="absolute -top-12 left-0 right-0 overflow-hidden">
      <svg viewBox="0 0 1200 120" className="w-full h-12" preserveAspectRatio="none">
        <defs>
          <linearGradient id="wave-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.3" />
            <stop offset="50%" stopColor="#06b6d4" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.3" />
          </linearGradient>
        </defs>
        <motion.path
          d="M0,60 C300,120 600,0 900,60 C1050,90 1150,30 1200,60 L1200,120 L0,120 Z"
          fill="url(#wave-gradient)"
          animate={{
            d: [
            "M0,60 C300,120 600,0 900,60 C1050,90 1150,30 1200,60 L1200,120 L0,120 Z",
            "M0,80 C300,20 600,100 900,40 C1050,70 1150,50 1200,80 L1200,120 L0,120 Z",
            "M0,60 C300,120 600,0 900,60 C1050,90 1150,30 1200,60 L1200,120 L0,120 Z"]

          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }} />

      </svg>
    </div>);

}

// Animated heartbeat
function HeartBeat() {
  return (
    <motion.span
      animate={{ scale: [1, 1.2, 1, 1.2, 1] }}
      transition={{ duration: 1.5, repeat: Infinity, repeatDelay: 1 }}
      className="inline-block text-red-500">

      ❤️
    </motion.span>);

}

// Glitching Team44 text - 5 random glitches within 30 seconds
function GlitchingTeam44() {
  const [isGlitching, setIsGlitching] = useState(false);

  useEffect(() => {
    const triggerRandomGlitches = () => {
      // Generate 5 random times within 30 seconds
      const glitchTimes = Array(5).fill(0).map(() => Math.random() * 30000);

      glitchTimes.forEach((time) => {
        setTimeout(() => {
          setIsGlitching(true);
          setTimeout(() => setIsGlitching(false), 300);
        }, time);
      });
    };

    triggerRandomGlitches();
    const interval = setInterval(triggerRandomGlitches, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <style>{`
        @keyframes team44-glitch {
          0%, 100% { text-shadow: none; transform: translate(0); }
          10% { text-shadow: -2px 0 #ff00ff, 2px 0 #00ffff; transform: translate(-1px, 1px); }
          20% { text-shadow: 2px 0 #ff00ff, -2px 0 #00ffff; transform: translate(1px, -1px); }
          30% { text-shadow: -1px 0 #00ffff, 1px 0 #ff00ff; transform: translate(-1px, 0); }
          40% { text-shadow: 1px 0 #00ffff, -1px 0 #ff00ff; transform: translate(1px, 1px); }
          50% { text-shadow: 0 -1px #ff00ff, 0 1px #00ffff; transform: translate(0, -1px); }
          60% { text-shadow: -2px 0 #00ffff, 2px 0 #ff00ff; transform: translate(-1px, 1px); }
          70% { text-shadow: 2px 0 #00ffff, -2px 0 #ff00ff; transform: translate(1px, 0); }
          80% { text-shadow: -1px 0 #ff00ff, 1px 0 #00ffff; transform: translate(0, 1px); }
          90% { text-shadow: 1px 0 #ff00ff, -1px 0 #00ffff; transform: translate(-1px, -1px); }
        }
        .team44-glitch-active {
          animation: team44-glitch 0.3s ease-in-out;
        }
      `}</style>
      <span className={`font-semibold bg-gradient-to-r from-cyan-500 via-cyan-300 to-cyan-500 bg-clip-text text-transparent ${isGlitching ? 'team44-glitch-active' : ''}`}>
        Team44
      </span>
    </>);

}

// Social icons with glow
function SocialIcon({ icon: Icon, href, color, glowColor }) {
  if (!href) return null;
  return (
    <motion.a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      whileHover={{ scale: 1.2, y: -2 }}
      className={`p-2 rounded-lg bg-slate-800 hover:bg-slate-700 transition-all text-slate-400 ${color}`}
      style={{ boxShadow: "none" }}
      onMouseEnter={(e) => e.currentTarget.style.boxShadow = `0 0 20px ${glowColor || "#8b5cf6"}40`}
      onMouseLeave={(e) => e.currentTarget.style.boxShadow = "none"}>

      <Icon className="w-5 h-5" />
    </motion.a>);

}

// App stats counter
function AppStats() {
  const [stats, setStats] = useState({ viewed: 0, copied: 0 });

  useEffect(() => {
    // Load stats
    const stored = localStorage.getItem('appStats');
    let currentStats = stored ? JSON.parse(stored) : { viewed: 0, copied: 0 };

    // Increment view count (simple tracking)
    currentStats.viewed += 1;
    localStorage.setItem('appStats', JSON.stringify(currentStats));
    setStats(currentStats);

    // Listen for copy events
    const handleCopyStat = () => {
      const updated = JSON.parse(localStorage.getItem('appStats') || '{"viewed":0,"copied":0}');
      setStats(updated);
    };

    window.addEventListener('statCopied', handleCopyStat);
    return () => window.removeEventListener('statCopied', handleCopyStat);
  }, []);

  return (
    <div className="flex gap-4 text-xs relative -left-3">
      <div className="flex items-center gap-1 text-slate-400">
        <Eye className="w-3 h-3" />
        <span>{stats.viewed || 0} viewed</span>
      </div>
      <div className="flex items-center gap-1 text-slate-400">
        <Copy className="w-3 h-3" />
        <span>{stats.copied || 0} copied</span>
      </div>
    </div>);

}

// Theme toggle
function ThemeToggle({ onThemeChange }) {
  const [theme, setTheme] = useState(() => localStorage.getItem('appTheme') || "dark");

  const handleThemeChange = (newTheme) => {
    setTheme(newTheme);
    localStorage.setItem('appTheme', newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);

    // Apply theme classes to body
    document.body.classList.remove('theme-dark', 'theme-light', 'theme-cyber');
    document.body.classList.add(`theme-${newTheme}`);

    if (onThemeChange) onThemeChange(newTheme);
  };

  // Apply on mount
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    document.body.classList.add(`theme-${theme}`);
  }, []);

  return (
    <div className="flex items-center gap-1 bg-slate-800 rounded-lg p-1">
      {[
      { id: "dark", icon: Moon, label: "Dark" },
      { id: "light", icon: Sun, label: "Light" },
      { id: "cyber", icon: Zap, label: "Cyber" }].
      map((t) =>
      <motion.button
        key={t.id}
        onClick={() => handleThemeChange(t.id)}
        whileTap={{ scale: 0.95 }}
        className={`p-1.5 rounded-md text-xs flex items-center gap-1 ${theme === t.id ? "bg-violet-500 text-white" : "text-slate-400 hover:text-white"}`}>

          <t.icon className="w-3 h-3" />
        </motion.button>
      )}
    </div>);

}

// Language selector
function LanguageSelector({ onLanguageChange }) {
  const [lang, setLang] = useState(() => localStorage.getItem('appLang') || "en");
  const languages = [
  { code: "en", flag: "🇺🇸", name: "English" },
  { code: "es", flag: "🇪🇸", name: "Español" },
  { code: "fr", flag: "🇫🇷", name: "Français" },
  { code: "de", flag: "🇩🇪", name: "Deutsch" },
  { code: "jp", flag: "🇯🇵", name: "日本語" }];


  const handleLangChange = (code) => {
    setLang(code);
    localStorage.setItem('appLang', code);
    document.documentElement.setAttribute('lang', code);
    if (onLanguageChange) onLanguageChange(code);
  };

  return (
    <div className="flex items-center gap-1 bg-slate-800 rounded-lg p-1">
      {languages.map((l) =>
      <motion.button
        key={l.code}
        onClick={() => handleLangChange(l.code)}
        whileTap={{ scale: 0.95 }}
        className={`p-1 rounded text-sm ${lang === l.code ? "bg-slate-700" : "opacity-50 hover:opacity-100"}`}
        title={l.name}>

          {l.flag}
        </motion.button>
      )}
    </div>);

}

// Back to top button with custom logo and glitch effect
function BackToTop() {
  const [show, setShow] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const { data: appSettings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || {};
    },
    initialData: {}
  });

  useEffect(() => {
    const handleScroll = () => setShow(window.scrollY > 400);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const logoUrl = appSettings?.back_to_top_logo || "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d0e11f7107236669e8813/aef9b2861_up2.png";

  return (
    <AnimatePresence>
      {show &&
      <motion.button
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 20 }}
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className="fixed bottom-8 right-8 rounded-full shadow-lg shadow-violet-500/30 z-40 overflow-visible"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}>

          <div className="relative w-14 h-14">
            <img src={logoUrl} alt="Back to top" className={`w-14 h-14 object-contain ${isHovered ? "back-to-top-glitch" : ""}`} />
            {isHovered &&
          <>
                <img src={logoUrl} alt="" className="absolute inset-0 w-14 h-14 object-contain opacity-50 back-to-top-glitch-r" style={{ mixBlendMode: "screen" }} />
                <img src={logoUrl} alt="" className="absolute inset-0 w-14 h-14 object-contain opacity-50 back-to-top-glitch-b" style={{ mixBlendMode: "screen" }} />
              </>
          }
          </div>
          <style>{`
            @keyframes btt-glitch {
              0%, 100% { transform: translate(0); filter: none; }
              20% { transform: translate(-2px, 1px); filter: hue-rotate(90deg); }
              40% { transform: translate(2px, -1px); filter: hue-rotate(-90deg); }
              60% { transform: translate(-1px, -1px); filter: hue-rotate(180deg); }
              80% { transform: translate(1px, 1px); filter: hue-rotate(-180deg); }
            }
            @keyframes btt-glitch-r { 0%, 100% { transform: translate(0); } 25% { transform: translate(3px, 0); } 75% { transform: translate(-3px, 0); } }
            @keyframes btt-glitch-b { 0%, 100% { transform: translate(0); } 25% { transform: translate(0, 3px); } 75% { transform: translate(0, -3px); } }
            .back-to-top-glitch { animation: btt-glitch 0.3s ease-in-out infinite; }
            .back-to-top-glitch-r { animation: btt-glitch-r 0.2s ease-in-out infinite; filter: hue-rotate(90deg); }
            .back-to-top-glitch-b { animation: btt-glitch-b 0.25s ease-in-out infinite; filter: hue-rotate(-90deg); }
          `}</style>
        </motion.button>
      }
    </AnimatePresence>);

}

// QR Code component
function QRCode() {
  return (
    <div className="p-2 bg-white rounded-lg">
      <div className="w-16 h-16 grid grid-cols-8 gap-0">
        {/* Simple QR pattern */}
        {[...Array(64)].map((_, i) =>
        <div
          key={i}
          className={`w-2 h-2 ${Math.random() > 0.5 ? "bg-black" : "bg-white"}`} />

        )}
      </div>
    </div>);

}

// Footer Effects Component
function FooterEffects({ effect }) {
  const [particles, setParticles] = useState([]);

  useEffect(() => {
    if (effect === "none" || !effect) return;

    const createParticle = () => ({
      id: Date.now() + Math.random(),
      x: Math.random() * 100,
      delay: Math.random() * 2
    });

    const interval = setInterval(() => {
      setParticles((p) => [...p.slice(-15), createParticle()]);
    }, 400);

    return () => clearInterval(interval);
  }, [effect]);

  useEffect(() => {
    const cleanup = setInterval(() => {
      setParticles((p) => p.filter((particle) => Date.now() - particle.id < 6000));
    }, 1000);
    return () => clearInterval(cleanup);
  }, []);

  if (!effect || effect === "none") return null;

  const getEmoji = () => {
    switch (effect) {
      case "snow":return "❄️";
      case "leaves":return "🍂";
      case "hearts":return "💕";
      case "stars":return "⭐";
      case "confetti":return "🎉";
      default:return "✨";
    }
  };

  return (
    <div className="fixed inset-0 pointer-events-none z-30 overflow-hidden">
      {particles.map((p) =>
      <motion.div
        key={p.id}
        className="absolute text-xl"
        style={{ left: `${p.x}%`, top: -30 }}
        initial={{ y: 0, opacity: 0, rotate: 0 }}
        animate={{
          y: typeof window !== 'undefined' ? window.innerHeight + 50 : 1000,
          opacity: [0, 1, 1, 0],
          rotate: effect === "leaves" ? [0, 180, 360] : effect === "confetti" ? [0, 720] : 0,
          x: effect === "snow" || effect === "leaves" ? [0, Math.sin(p.x) * 40] : 0
        }}
        transition={{
          duration: effect === "snow" ? 8 : effect === "leaves" ? 7 : 6,
          delay: p.delay,
          ease: "linear"
        }}>

          {getEmoji()}
        </motion.div>
      )}
    </div>);

}

export default function FooterEnhanced({ version = "1.0.0" }) {
  const { data: appSettings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || {};
    },
    initialData: {}
  });

  const socialLinks = appSettings?.social_links || {};
  const footerEffect = appSettings?.footer_effect || "none";
  const footerConfig = appSettings?.footer_config || { columns: 4, alignment: "left", style: "default" };

  const footerClasses = {
    default: "mt-4 pt-16 pb-8 relative border-t border-white/10",
    glass: "mt-4 pt-16 pb-8 relative border-t border-white/10 bg-white/5 backdrop-blur-md",
    gradient: "mt-4 pt-16 pb-8 relative border-t border-white/10 bg-gradient-to-b from-slate-900/50 to-slate-950",
    minimal: "mt-4 pt-16 pb-8 relative border-t border-slate-800/50"
  };

  return (
    <>
      <FooterEffects effect={footerEffect} />
      <BackToTop />
      <footer className={`${footerClasses[footerConfig.style] || footerClasses.default} overflow-hidden`}>
        <Starfield />
        <WaveDivider />

        <div className={`relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 ${footerConfig.alignment === 'center' ? 'text-center' : ''}`}>
          {/* Main Footer Content */}
          <div className={`grid grid-cols-1 gap-8 mb-8 ${
          footerConfig.alignment === 'center' ? 'md:flex md:flex-wrap md:justify-center' :
          footerConfig.alignment === 'justify' ? 'md:flex md:justify-between' :
          `md:grid-cols-${footerConfig.columns}`}`
          }>
            
            {/* Render dynamic columns */}
            {Array.from({ length: footerConfig.columns }).map((_, idx) => {
              const widgetType = footerConfig.column_widgets?.[idx] || (
              idx === 0 ? "brand" : idx === 1 ? "stats" : idx === 2 ? "settings" : "install");

              return (
                <div key={idx} className="space-y-4">
                  {widgetType === "brand" &&
                  <>
                      <h3 className="text-lg font-bold gradient-text">UI Effects Playground</h3>
                      <p className="text-slate-400 text-sm">
                        850+ components for modern web apps
                      </p>
                      <p className="text-slate-400 text-xs">
                        copy-paste-ship • updated weekly
                      </p>
                      <div className="flex gap-2 flex-wrap">
                        <SocialIcon icon={Github} href={socialLinks.github || "#"} color="hover:text-violet-400" glowColor="#8b5cf6" />
                        <SocialIcon icon={XIcon} href={socialLinks.twitter || "#"} color="hover:text-white" glowColor="#ffffff" isCustomIcon />
                        <SocialIcon icon={Instagram} href={socialLinks.instagram} color="hover:text-pink-400" glowColor="#ec4899" />
                      </div>
                    </>}
                  {widgetType === "links_social" &&
                  <>
                      <h4 className="text-white font-medium">Connect</h4>
                      <div className="flex gap-2 flex-wrap">
                        <SocialIcon icon={Github} href={socialLinks.github || "#"} color="hover:text-violet-400" glowColor="#8b5cf6" />
                        <SocialIcon icon={XIcon} href={socialLinks.twitter || "#"} color="hover:text-white" glowColor="#ffffff" isCustomIcon />
                        <SocialIcon icon={Instagram} href={socialLinks.instagram} color="hover:text-pink-400" glowColor="#ec4899" />
                        <SocialIcon icon={Facebook} href={socialLinks.facebook} color="hover:text-blue-400" glowColor="#3b82f6" />
                        <SocialIcon icon={Youtube} href={socialLinks.youtube} color="hover:text-red-400" glowColor="#ef4444" />
                        <SocialIcon icon={Linkedin} href={socialLinks.linkedin} color="hover:text-cyan-400" glowColor="#06b6d4" />
                      </div>
                    </>
                  }
                  {widgetType === "stats" &&
                  <>
                      <h4 className="text-white font-medium">Your Stats</h4>
                      <AppStats />
                      <p className="text-xs text-slate-500">Tracked locally only</p>
                    </>
                  }
                  {widgetType === "settings" &&
                  <>
                      <h4 className="text-white font-medium">Preferences</h4>
                      <div className="space-y-2">
                        <ThemeToggle />
                        <LanguageSelector />
                      </div>
                    </>
                  }
                  {widgetType === "install" &&
                  <>
                      <h4 className="text-white font-medium">Install App</h4>
                      <div className="flex items-start gap-3">
                        <QRCode />
                        <p className="text-xs text-slate-400">Scan to install PWA on your device</p>
                      </div>
                    </>
                  }
                  {widgetType === "newsletter" &&
                  <>
                      <h4 className="text-white font-medium">Newsletter</h4>
                      <p className="text-xs text-slate-400">Subscribe for weekly updates and new effects.</p>
                      <div className="flex gap-2">
                        <input type="email" placeholder="Email" className="bg-slate-800 rounded px-2 py-1 text-sm w-full" />
                        <button className="bg-violet-600 rounded px-2 text-xs">Go</button>
                      </div>
                    </>
                  }
                  {widgetType === "contact" &&
                  <>
                      <h4 className="text-white font-medium">Contact Us</h4>
                      <p className="text-sm text-slate-400">hello@base44.com</p>
                      <p className="text-sm text-slate-400">San Francisco, CA</p>
                    </>
                  }
                  {widgetType === "links_legal" &&
                  <>
                      <h4 className="text-white font-medium">Legal</h4>
                      <ul className="space-y-1 text-sm text-slate-400">
                        <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                        <li><a href="#" className="hover:text-white">Terms of Service</a></li>
                        <li><a href="#" className="hover:text-white">Cookie Policy</a></li>
                      </ul>
                    </>
                  }
                  {widgetType === "links_quick" &&
                  <>
                      <h4 className="text-white font-medium">Quick Links</h4>
                      <ul className="space-y-1 text-sm text-slate-400">
                        <li><a href="/VisualEffects" className="hover:text-white">Visual Effects</a></li>
                        <li><a href="/ButtonEffects" className="hover:text-white">Buttons</a></li>
                        <li><a href="/AdminLayouts" className="hover:text-white">Admin</a></li>
                      </ul>
                    </>
                  }
                  {widgetType === "map" &&
                  <>
                      <h4 className="text-white font-medium">Location</h4>
                      <div className="h-24 bg-slate-800 rounded-lg flex items-center justify-center text-xs text-slate-500">
                        [Map Widget Placeholder]
                      </div>
                    </>
                  }
                  {widgetType === "gallery" &&
                  <>
                      <h4 className="text-white font-medium">Gallery</h4>
                      <div className="grid grid-cols-3 gap-1">
                        {[...Array(6)].map((_, i) =>
                      <div key={i} className="aspect-square bg-slate-800 rounded hover:bg-violet-500 transition-colors" />
                      )}
                      </div>
                    </>
                  }
                </div>);

            })}
          </div>

          {/* Bottom Bar */}
          <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-slate-500 text-sm flex items-center gap-1">
              Built with <HeartBeat /> by{" "}
              <a href="https://team44.base44.app" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity">
                <GlitchingTeam44 />
              </a>
              {" "}on{" "}
              <span className="font-semibold bg-gradient-to-r from-orange-500 to-orange-400 bg-clip-text text-transparent">Base44</span>
            </p>
            <WilsonQuote version={version} />
          </div>
        </div>
      </footer>
    </>);

}