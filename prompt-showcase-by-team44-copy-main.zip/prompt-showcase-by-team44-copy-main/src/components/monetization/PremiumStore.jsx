import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Crown, Sparkles, Zap, Star, Check, Lock, Gift, Coffee, 
  Heart, CreditCard, Package, Rocket, Diamond, Shield
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";

// Premium Effect Packs
const effectPacks = [
  {
    id: "cyberpunk",
    name: "Cyberpunk Collection",
    price: 9.99,
    icon: Zap,
    color: "from-cyan-500 to-purple-500",
    effects: ["Neon Grid", "Hologram", "Data Stream", "Glitch Matrix", "Circuit Board"],
    popular: true,
  },
  {
    id: "nature",
    name: "Nature Elements",
    price: 7.99,
    icon: Sparkles,
    color: "from-green-500 to-emerald-500",
    effects: ["Rain Drops", "Falling Leaves", "Fireflies", "Snow Storm", "Aurora Borealis"],
  },
  {
    id: "retro",
    name: "Retro Gaming Pack",
    price: 8.99,
    icon: Star,
    color: "from-orange-500 to-red-500",
    effects: ["8-Bit Pixels", "CRT Screen", "Arcade Glow", "Game Over", "High Score"],
  },
  {
    id: "anime",
    name: "Anime Essentials",
    price: 11.99,
    icon: Heart,
    color: "from-pink-500 to-rose-500",
    effects: ["Speed Lines", "Power Aura", "Sparkle Eyes", "Dramatic Wind", "Chibi Bounce"],
    popular: true,
  },
  {
    id: "scifi",
    name: "Sci-Fi Interfaces",
    price: 12.99,
    icon: Rocket,
    color: "from-blue-500 to-indigo-500",
    effects: ["HUD Elements", "Scan Lines", "Targeting System", "Warp Drive", "Shield Effect"],
  },
  {
    id: "abstract",
    name: "Abstract Art",
    price: 6.99,
    icon: Diamond,
    color: "from-violet-500 to-fuchsia-500",
    effects: ["Liquid Morph", "Geometric Dance", "Color Bloom", "Wave Distortion", "Kaleidoscope"],
  },
];

// Subscription Tiers
const subscriptionTiers = [
  {
    id: "free",
    name: "Free",
    price: 0,
    period: "forever",
    features: [
      "Access to 50+ basic effects",
      "Copy code snippets",
      "Community support",
      "Basic effect builder",
    ],
    limits: ["Limited exports", "No premium packs", "Watermarked exports"],
  },
  {
    id: "pro",
    name: "Pro",
    price: 9.99,
    period: "month",
    features: [
      "All free features",
      "200+ premium effects",
      "Advanced effect builder",
      "AI effect suggestions",
      "Priority support",
      "No watermarks",
    ],
    popular: true,
  },
  {
    id: "team",
    name: "Team",
    price: 29.99,
    period: "month",
    features: [
      "All Pro features",
      "5 team members",
      "Shared effect library",
      "Custom branding",
      "API access",
      "Dedicated support",
    ],
  },
  {
    id: "lifetime",
    name: "Lifetime",
    price: 199,
    period: "once",
    features: [
      "All Pro features forever",
      "All future packs included",
      "Early access to new effects",
      "Exclusive Discord role",
      "Name in credits",
    ],
    special: true,
  },
];

function EffectPackCard({ pack, onPurchase }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      whileHover={{ y: -5 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <Card className={`relative overflow-hidden bg-slate-900/50 border-slate-700 ${pack.popular ? "ring-2 ring-violet-500" : ""}`}>
        {pack.popular && (
          <div className="absolute top-0 right-0 bg-violet-500 text-white text-xs px-3 py-1 rounded-bl-lg font-medium">
            Popular
          </div>
        )}
        <CardHeader className="pb-2">
          <div className={`inline-flex p-3 rounded-xl bg-gradient-to-br ${pack.color} w-fit mb-2`}>
            <pack.icon className="w-6 h-6 text-white" />
          </div>
          <CardTitle className="text-white">{pack.name}</CardTitle>
          <CardDescription className="text-slate-400">
            {pack.effects.length} premium effects
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <ul className="space-y-1">
            {pack.effects.map((effect, i) => (
              <li key={i} className="text-sm text-slate-300 flex items-center gap-2">
                <Check className="w-3 h-3 text-green-400" />
                {effect}
              </li>
            ))}
          </ul>
          <div className="flex items-end justify-between">
            <div>
              <span className="text-3xl font-bold text-white">${pack.price}</span>
              <span className="text-slate-400 text-sm"> one-time</span>
            </div>
            <Button
              onClick={() => onPurchase(pack)}
              className={`bg-gradient-to-r ${pack.color}`}
            >
              <CreditCard className="w-4 h-4 mr-2" />
              Purchase
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function SubscriptionCard({ tier, onSubscribe, currentTier }) {
  const isCurrent = currentTier === tier.id;

  return (
    <motion.div whileHover={{ y: -5 }}>
      <Card className={`relative h-full bg-slate-900/50 border-slate-700 ${tier.popular ? "ring-2 ring-cyan-500" : ""} ${tier.special ? "ring-2 ring-amber-500" : ""}`}>
        {tier.popular && (
          <div className="absolute top-0 right-0 bg-cyan-500 text-white text-xs px-3 py-1 rounded-bl-lg font-medium">
            Most Popular
          </div>
        )}
        {tier.special && (
          <div className="absolute top-0 right-0 bg-amber-500 text-black text-xs px-3 py-1 rounded-bl-lg font-medium">
            Best Value
          </div>
        )}
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            {tier.id === "pro" && <Crown className="w-5 h-5 text-cyan-400" />}
            {tier.id === "team" && <Shield className="w-5 h-5 text-violet-400" />}
            {tier.id === "lifetime" && <Diamond className="w-5 h-5 text-amber-400" />}
            {tier.name}
          </CardTitle>
          <div className="pt-2">
            <span className="text-4xl font-bold text-white">${tier.price}</span>
            <span className="text-slate-400">/{tier.period}</span>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <ul className="space-y-2">
            {tier.features.map((feature, i) => (
              <li key={i} className="text-sm text-slate-300 flex items-center gap-2">
                <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                {feature}
              </li>
            ))}
            {tier.limits?.map((limit, i) => (
              <li key={i} className="text-sm text-slate-500 flex items-center gap-2">
                <Lock className="w-4 h-4 text-slate-600 flex-shrink-0" />
                {limit}
              </li>
            ))}
          </ul>
          <Button
            onClick={() => onSubscribe(tier)}
            disabled={isCurrent}
            className={`w-full ${tier.popular ? "bg-gradient-to-r from-cyan-500 to-blue-500" : tier.special ? "bg-gradient-to-r from-amber-500 to-orange-500" : "bg-slate-700"}`}
          >
            {isCurrent ? "Current Plan" : tier.price === 0 ? "Get Started" : "Subscribe"}
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function DonationSection() {
  const [amount, setAmount] = useState(5);
  const amounts = [3, 5, 10, 25, 50];

  return (
    <Card className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border-amber-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Coffee className="w-5 h-5 text-amber-400" />
          Buy Us a Coffee ☕
        </CardTitle>
        <CardDescription className="text-slate-300">
          Love what we're building? Support development with a one-time donation!
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap gap-2">
          {amounts.map((a) => (
            <motion.button
              key={a}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setAmount(a)}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                amount === a
                  ? "bg-amber-500 text-black"
                  : "bg-slate-800 text-slate-300 hover:bg-slate-700"
              }`}
            >
              ${a}
            </motion.button>
          ))}
        </div>
        <Button className="w-full bg-gradient-to-r from-amber-500 to-orange-500 text-black font-semibold">
          <Heart className="w-4 h-4 mr-2" />
          Donate ${amount}
        </Button>
        <p className="text-xs text-slate-500 text-center">
          100% goes to development. Thank you! 💜
        </p>
      </CardContent>
    </Card>
  );
}

export default function PremiumStore() {
  const [currentTier] = useState("free");
  const [showPurchaseModal, setShowPurchaseModal] = useState(null);

  const handlePurchase = (pack) => {
    setShowPurchaseModal({ type: "pack", item: pack });
  };

  const handleSubscribe = (tier) => {
    setShowPurchaseModal({ type: "subscription", item: tier });
  };

  return (
    <div className="space-y-12">
      {/* Subscription Tiers */}
      <section>
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Choose Your Plan</h2>
          <p className="text-slate-400">Unlock premium features and effects</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {subscriptionTiers.map((tier) => (
            <SubscriptionCard
              key={tier.id}
              tier={tier}
              onSubscribe={handleSubscribe}
              currentTier={currentTier}
            />
          ))}
        </div>
      </section>

      {/* Effect Packs */}
      <section>
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Premium Effect Packs</h2>
          <p className="text-slate-400">One-time purchase, yours forever</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {effectPacks.map((pack) => (
            <EffectPackCard key={pack.id} pack={pack} onPurchase={handlePurchase} />
          ))}
        </div>
      </section>

      {/* Donation */}
      <section className="max-w-md mx-auto">
        <DonationSection />
      </section>

      {/* Purchase Modal */}
      <AnimatePresence>
        {showPurchaseModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4"
            onClick={() => setShowPurchaseModal(null)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-md w-full relative z-[101]"
            >
              <h3 className="text-xl font-bold text-white mb-4">
                {showPurchaseModal.type === "pack" ? "Purchase Pack" : "Subscribe"}
              </h3>
              <p className="text-slate-400 mb-6">
                {showPurchaseModal.type === "pack"
                  ? `Get the ${showPurchaseModal.item.name} for $${showPurchaseModal.item.price}`
                  : `Subscribe to ${showPurchaseModal.item.name} for $${showPurchaseModal.item.price}/${showPurchaseModal.item.period}`}
              </p>
              <div className="space-y-3">
                <Button className="w-full bg-gradient-to-r from-violet-500 to-cyan-500">
                  <CreditCard className="w-4 h-4 mr-2" />
                  Pay with Card
                </Button>
                <Button variant="outline" className="w-full text-blue-300 hover:text-blue-200 border-blue-500/50 hover:bg-blue-500/10">
                  Pay with PayPal
                </Button>
                <Button variant="ghost" className="w-full" onClick={() => setShowPurchaseModal(null)}>
                  Cancel
                </Button>
              </div>
              <p className="text-xs text-slate-500 text-center mt-4">
                Secure payment powered by Stripe
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export { effectPacks, subscriptionTiers };