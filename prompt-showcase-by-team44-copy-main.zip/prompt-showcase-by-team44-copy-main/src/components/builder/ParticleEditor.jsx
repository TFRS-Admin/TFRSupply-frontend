import React, { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Sparkles, Upload, RefreshCw, Sliders } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";

const PARTICLE_PRESETS = [
  { id: "snow", name: "❄️ Snow", config: { count: 50, size: [2, 6], speed: [1, 3], color: "#ffffff", gravity: 0.5, wind: 0.2 } },
  { id: "fire", name: "🔥 Fire", config: { count: 40, size: [3, 8], speed: [2, 5], color: "#ff6b35", gravity: -1, wind: 0, glow: true } },
  { id: "sparkle", name: "✨ Sparkles", config: { count: 30, size: [1, 4], speed: [0.5, 2], color: "#ffd700", gravity: 0, wind: 0, twinkle: true } },
  { id: "confetti", name: "🎉 Confetti", config: { count: 60, size: [4, 10], speed: [2, 6], colors: ["#ff6b6b", "#4ecdc4", "#ffe66d", "#95e1d3"], gravity: 0.8, wind: 0.5, rotate: true } },
  { id: "bubbles", name: "🫧 Bubbles", config: { count: 25, size: [5, 15], speed: [0.5, 2], color: "#87ceeb", gravity: -0.3, wind: 0.1, opacity: 0.6 } },
  { id: "stars", name: "⭐ Stars", config: { count: 100, size: [1, 3], speed: [0, 0], color: "#ffffff", gravity: 0, wind: 0, static: true, twinkle: true } },
  { id: "rain", name: "🌧️ Rain", config: { count: 80, size: [1, 2], speed: [8, 15], color: "#6ea8fe", gravity: 2, wind: 0.5, stretch: true } },
  { id: "leaves", name: "🍂 Leaves", config: { count: 20, size: [8, 15], speed: [1, 3], colors: ["#d4a373", "#bc6c25", "#606c38"], gravity: 0.3, wind: 1, rotate: true, sway: true } },
  { id: "sakura", name: "🌸 Sakura", config: { count: 30, size: [6, 12], speed: [0.5, 2], color: "#ffb7c5", gravity: 0.2, wind: 0.8, rotate: true, sway: true } },
  { id: "magic", name: "💫 Magic", config: { count: 40, size: [2, 5], speed: [1, 3], colors: ["#8b5cf6", "#06b6d4", "#ec4899"], gravity: -0.2, wind: 0, orbit: true, glow: true } },
];

function Particle({ config, index, containerSize }) {
  const [position, setPosition] = useState({
    x: Math.random() * 100,
    y: Math.random() * 100,
  });
  const size = config.size[0] + Math.random() * (config.size[1] - config.size[0]);
  const speed = config.speed[0] + Math.random() * (config.speed[1] - config.speed[0]);
  const color = config.colors ? config.colors[index % config.colors.length] : config.color;
  const delay = Math.random() * 2;

  if (config.static) {
    return (
      <motion.div
        className="absolute rounded-full"
        style={{
          left: `${position.x}%`,
          top: `${position.y}%`,
          width: size,
          height: size,
          backgroundColor: color,
          boxShadow: config.glow ? `0 0 ${size * 2}px ${color}` : "none",
        }}
        animate={config.twinkle ? { opacity: [0.3, 1, 0.3], scale: [0.8, 1.2, 0.8] } : {}}
        transition={{ duration: 1 + Math.random() * 2, repeat: Infinity, delay }}
      />
    );
  }

  const yDirection = config.gravity < 0 ? -1 : 1;

  return (
    <motion.div
      className="absolute"
      style={{
        left: `${position.x}%`,
        width: config.stretch ? size / 3 : size,
        height: config.stretch ? size * 3 : size,
        backgroundColor: color,
        borderRadius: config.stretch ? "50%" : "50%",
        opacity: config.opacity || 1,
        boxShadow: config.glow ? `0 0 ${size * 2}px ${color}` : "none",
      }}
      initial={{ y: yDirection > 0 ? "-10%" : "110%", opacity: 0 }}
      animate={{
        y: yDirection > 0 ? "110%" : "-10%",
        x: config.sway ? [0, 20, -20, 0] : config.wind * 50,
        rotate: config.rotate ? [0, 360] : 0,
        opacity: [0, config.opacity || 1, config.opacity || 1, 0],
        scale: config.twinkle ? [0.8, 1.2, 0.8] : 1,
      }}
      transition={{
        duration: 10 / speed,
        repeat: Infinity,
        delay,
        ease: "linear",
        x: config.sway ? { duration: 3, repeat: Infinity, ease: "easeInOut" } : {},
      }}
    />
  );
}

export default function ParticleEditor({ onConfigChange }) {
  const [selectedPreset, setSelectedPreset] = useState("snow");
  const [config, setConfig] = useState(PARTICLE_PRESETS[0].config);
  const [customTexture, setCustomTexture] = useState(null);
  const containerRef = useRef(null);

  const handlePresetChange = (presetId) => {
    const preset = PARTICLE_PRESETS.find((p) => p.id === presetId);
    if (preset) {
      setSelectedPreset(presetId);
      setConfig(preset.config);
      onConfigChange?.(preset.config);
    }
  };

  const updateConfig = (key, value) => {
    const newConfig = { ...config, [key]: value };
    setConfig(newConfig);
    onConfigChange?.(newConfig);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-white font-semibold flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-violet-400" />
          Advanced Particles
        </h3>
        <Button size="sm" variant="outline" onClick={() => handlePresetChange(selectedPreset)}>
          <RefreshCw className="w-4 h-4 mr-1" /> Reset
        </Button>
      </div>

      {/* Presets */}
      <div className="grid grid-cols-5 gap-2">
        {PARTICLE_PRESETS.map((preset) => (
          <button
            key={preset.id}
            onClick={() => handlePresetChange(preset.id)}
            className={`p-2 rounded-lg text-center transition-all ${
              selectedPreset === preset.id
                ? "bg-violet-500/30 border border-violet-500"
                : "bg-slate-800 border border-slate-700 hover:border-slate-600"
            }`}
          >
            <span className="text-lg">{preset.name.split(" ")[0]}</span>
            <p className="text-[10px] text-slate-400 mt-1">{preset.name.split(" ")[1]}</p>
          </button>
        ))}
      </div>

      {/* Preview */}
      <div
        ref={containerRef}
        className="relative h-48 rounded-xl bg-slate-950 overflow-hidden"
      >
        {Array.from({ length: config.count }).map((_, i) => (
          <Particle key={i} config={config} index={i} />
        ))}
      </div>

      {/* Physics Controls */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-xs text-slate-400">Particle Count: {config.count}</Label>
          <Slider
            value={[config.count]}
            min={5}
            max={100}
            onValueChange={([v]) => updateConfig("count", v)}
          />
        </div>
        <div>
          <Label className="text-xs text-slate-400">Gravity: {config.gravity}</Label>
          <Slider
            value={[config.gravity]}
            min={-2}
            max={2}
            step={0.1}
            onValueChange={([v]) => updateConfig("gravity", v)}
          />
        </div>
        <div>
          <Label className="text-xs text-slate-400">Wind: {config.wind}</Label>
          <Slider
            value={[config.wind]}
            min={-2}
            max={2}
            step={0.1}
            onValueChange={([v]) => updateConfig("wind", v)}
          />
        </div>
        <div>
          <Label className="text-xs text-slate-400">Min Size: {config.size[0]}px</Label>
          <Slider
            value={[config.size[0]]}
            min={1}
            max={20}
            onValueChange={([v]) => updateConfig("size", [v, config.size[1]])}
          />
        </div>
        <div>
          <Label className="text-xs text-slate-400">Max Size: {config.size[1]}px</Label>
          <Slider
            value={[config.size[1]]}
            min={1}
            max={30}
            onValueChange={([v]) => updateConfig("size", [config.size[0], v])}
          />
        </div>
        <div>
          <Label className="text-xs text-slate-400">Speed: {config.speed[0]} - {config.speed[1]}</Label>
          <Slider
            value={[config.speed[1]]}
            min={0.5}
            max={15}
            step={0.5}
            onValueChange={([v]) => updateConfig("speed", [config.speed[0], v])}
          />
        </div>
      </div>

      {/* Color */}
      <div>
        <Label className="text-xs text-slate-400 mb-2 block">Particle Color</Label>
        <div className="flex gap-2">
          {["#ffffff", "#ff6b35", "#ffd700", "#87ceeb", "#8b5cf6", "#ec4899", "#22c55e"].map((c) => (
            <button
              key={c}
              onClick={() => updateConfig("color", c)}
              className={`w-8 h-8 rounded-lg ${config.color === c ? "ring-2 ring-white" : ""}`}
              style={{ backgroundColor: c }}
            />
          ))}
          <input
            type="color"
            value={config.color || "#ffffff"}
            onChange={(e) => updateConfig("color", e.target.value)}
            className="w-8 h-8 rounded-lg cursor-pointer"
          />
        </div>
      </div>

      {/* Effects Toggles */}
      <div className="flex flex-wrap gap-2">
        {[
          { key: "glow", label: "Glow" },
          { key: "twinkle", label: "Twinkle" },
          { key: "rotate", label: "Rotate" },
          { key: "sway", label: "Sway" },
          { key: "stretch", label: "Stretch" },
        ].map((toggle) => (
          <button
            key={toggle.key}
            onClick={() => updateConfig(toggle.key, !config[toggle.key])}
            className={`px-3 py-1 rounded-lg text-xs ${
              config[toggle.key]
                ? "bg-violet-500 text-white"
                : "bg-slate-800 text-slate-400"
            }`}
          >
            {toggle.label}
          </button>
        ))}
      </div>
    </div>
  );
}

export { PARTICLE_PRESETS };