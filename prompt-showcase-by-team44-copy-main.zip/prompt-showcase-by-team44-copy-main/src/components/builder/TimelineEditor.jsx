import React, { useState, useRef } from "react";
import { motion } from "framer-motion";
import { Play, Pause, Plus, Trash2, ChevronLeft, ChevronRight, Layers, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";

const PROPERTIES = [
  { id: "opacity", name: "Opacity", min: 0, max: 1, step: 0.1, color: "#8b5cf6" },
  { id: "scale", name: "Scale", min: 0, max: 2, step: 0.1, color: "#06b6d4" },
  { id: "rotation", name: "Rotation", min: 0, max: 360, step: 1, color: "#ec4899" },
  { id: "x", name: "Position X", min: -100, max: 100, step: 1, color: "#22c55e" },
  { id: "y", name: "Position Y", min: -100, max: 100, step: 1, color: "#f59e0b" },
  { id: "blur", name: "Blur", min: 0, max: 20, step: 1, color: "#3b82f6" },
];

export default function TimelineEditor({ duration = 3, onKeyframesChange }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [keyframes, setKeyframes] = useState({
    opacity: [
      { time: 0, value: 0 },
      { time: 1, value: 1 },
      { time: 2.5, value: 1 },
      { time: 3, value: 0 },
    ],
    scale: [
      { time: 0, value: 0.5 },
      { time: 1.5, value: 1 },
      { time: 3, value: 0.5 },
    ],
  });
  const [selectedProperty, setSelectedProperty] = useState("opacity");
  const [zoom, setZoom] = useState(100);
  const timelineRef = useRef(null);

  const addKeyframe = (property, time, value) => {
    setKeyframes((prev) => {
      const propKeyframes = prev[property] || [];
      const newKeyframes = [...propKeyframes, { time, value }].sort((a, b) => a.time - b.time);
      const updated = { ...prev, [property]: newKeyframes };
      onKeyframesChange?.(updated);
      return updated;
    });
  };

  const removeKeyframe = (property, index) => {
    setKeyframes((prev) => {
      const propKeyframes = [...(prev[property] || [])];
      propKeyframes.splice(index, 1);
      const updated = { ...prev, [property]: propKeyframes };
      onKeyframesChange?.(updated);
      return updated;
    });
  };

  const updateKeyframe = (property, index, newValue) => {
    setKeyframes((prev) => {
      const propKeyframes = [...(prev[property] || [])];
      propKeyframes[index] = { ...propKeyframes[index], value: newValue };
      const updated = { ...prev, [property]: propKeyframes };
      onKeyframesChange?.(updated);
      return updated;
    });
  };

  const handleTimelineClick = (e) => {
    if (!timelineRef.current) return;
    const rect = timelineRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const time = (x / rect.width) * duration;
    setCurrentTime(Math.max(0, Math.min(duration, time)));
  };

  const handleAddKeyframeAtPlayhead = () => {
    const prop = PROPERTIES.find((p) => p.id === selectedProperty);
    if (!prop) return;
    const currentValue = interpolateValue(selectedProperty, currentTime);
    addKeyframe(selectedProperty, currentTime, currentValue);
  };

  const interpolateValue = (property, time) => {
    const propKeyframes = keyframes[property] || [];
    if (propKeyframes.length === 0) return 1;
    if (propKeyframes.length === 1) return propKeyframes[0].value;

    const before = propKeyframes.filter((k) => k.time <= time).pop();
    const after = propKeyframes.find((k) => k.time > time);

    if (!before) return propKeyframes[0].value;
    if (!after) return propKeyframes[propKeyframes.length - 1].value;

    const progress = (time - before.time) / (after.time - before.time);
    return before.value + (after.value - before.value) * progress;
  };

  // Animation loop
  React.useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setCurrentTime((t) => {
        if (t >= duration) {
          setIsPlaying(false);
          return 0;
        }
        return t + 0.05;
      });
    }, 50);
    return () => clearInterval(interval);
  }, [isPlaying, duration]);

  return (
    <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-white font-semibold flex items-center gap-2">
          <Clock className="w-4 h-4 text-cyan-400" />
          Timeline Editor
        </h3>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => setIsPlaying(!isPlaying)}
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </Button>
          <Button size="sm" variant="outline" onClick={handleAddKeyframeAtPlayhead}>
            <Plus className="w-4 h-4 mr-1" /> Add Keyframe
          </Button>
        </div>
      </div>

      {/* Property Selector */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {PROPERTIES.map((prop) => (
          <button
            key={prop.id}
            onClick={() => setSelectedProperty(prop.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
              selectedProperty === prop.id
                ? "text-white"
                : "bg-slate-800 text-slate-400 hover:text-white"
            }`}
            style={selectedProperty === prop.id ? { backgroundColor: prop.color } : {}}
          >
            {prop.name}
          </button>
        ))}
      </div>

      {/* Timeline Track */}
      <div
        ref={timelineRef}
        onClick={handleTimelineClick}
        className="relative h-16 bg-slate-950 rounded-lg cursor-crosshair overflow-hidden"
      >
        {/* Time markers */}
        <div className="absolute inset-x-0 top-0 h-4 border-b border-slate-800 flex">
          {Array.from({ length: Math.ceil(duration) + 1 }).map((_, i) => (
            <div
              key={i}
              className="flex-1 border-r border-slate-800 text-[10px] text-slate-500 px-1"
            >
              {i}s
            </div>
          ))}
        </div>

        {/* Keyframe dots */}
        {PROPERTIES.map((prop) => (
          <div key={prop.id} className="absolute inset-x-0" style={{ top: "1.5rem", height: "calc(100% - 1.5rem)" }}>
            {(keyframes[prop.id] || []).map((kf, index) => (
              <motion.div
                key={index}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className={`absolute w-3 h-3 rounded-full cursor-pointer transform -translate-x-1/2 ${
                  selectedProperty === prop.id ? "z-10" : "z-0 opacity-40"
                }`}
                style={{
                  left: `${(kf.time / duration) * 100}%`,
                  top: "50%",
                  transform: "translate(-50%, -50%)",
                  backgroundColor: prop.color,
                  boxShadow: selectedProperty === prop.id ? `0 0 10px ${prop.color}` : "none",
                }}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedProperty(prop.id);
                }}
                onDoubleClick={(e) => {
                  e.stopPropagation();
                  removeKeyframe(prop.id, index);
                }}
                title={`${prop.name}: ${kf.value} at ${kf.time.toFixed(2)}s (double-click to delete)`}
              />
            ))}
          </div>
        ))}

        {/* Playhead */}
        <motion.div
          className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-20"
          style={{ left: `${(currentTime / duration) * 100}%` }}
        >
          <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-3 h-3 bg-red-500 rounded-full" />
        </motion.div>
      </div>

      {/* Current Property Value Editor */}
      {selectedProperty && (
        <div className="p-3 rounded-lg bg-slate-800/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-slate-300">
              {PROPERTIES.find((p) => p.id === selectedProperty)?.name} at {currentTime.toFixed(2)}s
            </span>
            <span className="text-sm font-mono text-white">
              {interpolateValue(selectedProperty, currentTime).toFixed(2)}
            </span>
          </div>
          <Slider
            value={[interpolateValue(selectedProperty, currentTime)]}
            min={PROPERTIES.find((p) => p.id === selectedProperty)?.min || 0}
            max={PROPERTIES.find((p) => p.id === selectedProperty)?.max || 1}
            step={PROPERTIES.find((p) => p.id === selectedProperty)?.step || 0.1}
            onValueChange={([v]) => {
              const propKeyframes = keyframes[selectedProperty] || [];
              const existingIndex = propKeyframes.findIndex(
                (k) => Math.abs(k.time - currentTime) < 0.1
              );
              if (existingIndex >= 0) {
                updateKeyframe(selectedProperty, existingIndex, v);
              }
            }}
          />
        </div>
      )}

      {/* Preview */}
      <div className="p-4 rounded-lg bg-slate-950 flex items-center justify-center">
        <motion.div
          className="w-20 h-20 rounded-xl bg-gradient-to-br from-violet-500 to-cyan-500"
          style={{
            opacity: interpolateValue("opacity", currentTime),
            scale: interpolateValue("scale", currentTime),
            rotate: interpolateValue("rotation", currentTime),
            x: interpolateValue("x", currentTime),
            y: interpolateValue("y", currentTime),
            filter: `blur(${interpolateValue("blur", currentTime)}px)`,
          }}
        />
      </div>

      {/* Generated Code Preview */}
      <details className="text-xs">
        <summary className="text-slate-400 cursor-pointer hover:text-white">View Generated Animation</summary>
        <pre className="mt-2 p-3 rounded-lg bg-slate-950 overflow-x-auto text-slate-300">
{`const animation = {
  opacity: [${(keyframes.opacity || []).map((k) => k.value).join(", ")}],
  scale: [${(keyframes.scale || []).map((k) => k.value).join(", ")}],
  transition: { duration: ${duration}, times: [${(keyframes.opacity || []).map((k) => (k.time / duration).toFixed(2)).join(", ")}] }
};`}
        </pre>
      </details>
    </div>
  );
}

export { PROPERTIES };