import React from "react";

export default function NetflixTemplates() {
  return null;
}