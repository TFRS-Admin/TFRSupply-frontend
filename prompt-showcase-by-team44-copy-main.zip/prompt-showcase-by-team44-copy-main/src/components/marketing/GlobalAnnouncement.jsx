import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Bell, Megaphone, AlertCircle, Info, CheckCircle2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

export default function GlobalAnnouncement() {
  const [visible, setVisible] = useState(false);
  const [announcement, setAnnouncement] = useState(null);
  const [dismissedIds, setDismissedIds] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("dismissedAnnouncements") || "[]");
    } catch {
      return [];
    }
  });

  const { data: appSettings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || {};
    }
  });

  const { data: activeAnnouncements } = useQuery({
    queryKey: ['announcements'],
    queryFn: async () => {
      // In a real app, filtering by date would happen on the server
      const all = await base44.entities.Announcement.list();
      const now = new Date();
      return all.filter(a => {
        const start = a.start_date ? new Date(a.start_date) : null;
        const end = a.end_date ? new Date(a.end_date) : null;
        const isActive = a.status === 'active';
        const isStarted = !start || start <= now;
        const isEnded = end && end < now;
        return isActive && isStarted && !isEnded;
      });
    },
    initialData: []
  });

  useEffect(() => {
    if (appSettings?.announcements_enabled === false) {
      setVisible(false);
      return;
    }

    if (activeAnnouncements && activeAnnouncements.length > 0) {
      // Find the highest priority undismissed announcement
      const nextAnnouncement = activeAnnouncements
        .filter(a => !dismissedIds.includes(a.id))
        .sort((a, b) => {
          const priorityMap = { high: 3, medium: 2, low: 1 };
          return priorityMap[b.priority || 'medium'] - priorityMap[a.priority || 'medium'];
        })[0];

      if (nextAnnouncement) {
        setAnnouncement(nextAnnouncement);
        setVisible(true);
      }
    }
  }, [activeAnnouncements, dismissedIds, appSettings?.announcements_enabled]);

  // Check master toggle
  if (appSettings?.announcements_enabled === false) return null;

  const handleDismiss = () => {
    if (announcement) {
      const newDismissed = [...dismissedIds, announcement.id];
      setDismissedIds(newDismissed);
      localStorage.setItem("dismissedAnnouncements", JSON.stringify(newDismissed));
      setVisible(false);
    }
  };

  if (!announcement || !visible) return null;

  const getTypeStyles = (type) => {
    switch (type) {
      case "modal":
        return "fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4";
      case "toast":
        return "fixed bottom-6 right-6 z-[100] max-w-sm";
      default: // banner
        return "fixed top-0 left-0 right-0 z-[100]";
    }
  };

  const getPriorityColors = (priority) => {
    switch (priority) {
      case "high":
        return "bg-red-500/10 border-red-500/50 text-red-200";
      case "low":
        return "bg-blue-500/10 border-blue-500/50 text-blue-200";
      default:
        return "bg-violet-500/10 border-violet-500/50 text-violet-200";
    }
  };

  if (announcement.type === "modal") {
    return (
      <AnimatePresence>
        {visible && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className={getTypeStyles("modal")}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden"
            >
              <div className="p-6 relative">
                <button
                  onClick={handleDismiss}
                  className="absolute top-4 right-4 p-1 text-slate-400 hover:text-white rounded-full hover:bg-slate-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="flex items-start gap-4 mb-4">
                  <div className={`p-3 rounded-xl ${getPriorityColors(announcement.priority)}`}>
                    <Megaphone className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-1">{announcement.title}</h3>
                    <p className="text-slate-400 text-sm">{new Date(announcement.created_date).toLocaleDateString()}</p>
                  </div>
                </div>
                <div className="prose prose-invert prose-sm max-w-none mb-6">
                  <p>{announcement.content}</p>
                </div>
                <div className="flex justify-end gap-3">
                  {announcement.dismissible && (
                    <Button variant="ghost" onClick={handleDismiss}>Dismiss</Button>
                  )}
                  {announcement.action_url && (
                    <Button onClick={() => window.open(announcement.action_url, '_blank')} className="bg-violet-600 hover:bg-violet-700">
                      {announcement.action_text || "Learn More"}
                    </Button>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    );
  }

  // Toast Style
  if (announcement.type === "toast") {
    return (
      <AnimatePresence>
        {visible && (
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 50 }}
            className={`${getTypeStyles("toast")} bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-4 flex items-start gap-4`}
          >
            <button
              onClick={handleDismiss}
              className="absolute top-2 right-2 text-slate-500 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
            <div className={`p-2 rounded-lg mt-1 ${getPriorityColors(announcement.priority)}`}>
              <Bell className="w-5 h-5" />
            </div>
            <div className="flex-1 pr-4">
              <h4 className="font-semibold text-white text-sm mb-1">{announcement.title}</h4>
              <p className="text-slate-400 text-xs mb-3">{announcement.content}</p>
              {announcement.action_url && (
                <Button size="sm" onClick={() => window.open(announcement.action_url, '_blank')} className="h-8 text-xs bg-slate-800 hover:bg-slate-700">
                  {announcement.action_text || "View"}
                </Button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    );
  }

  // Default Banner Style
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          className={`${getTypeStyles("banner")} bg-gradient-to-r from-indigo-900 via-slate-900 to-indigo-900 border-b border-indigo-500/30 text-white`}
        >
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-1 min-w-0">
              <span className="flex-shrink-0 px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500 text-white uppercase tracking-wider">
                {announcement.priority === 'high' ? 'Alert' : 'New'}
              </span>
              <p className="text-sm font-medium truncate">
                <span className="font-bold mr-2">{announcement.title}:</span>
                <span className="text-slate-300">{announcement.content}</span>
              </p>
            </div>
            <div className="flex items-center gap-3 flex-shrink-0">
              {announcement.action_url && (
                <button 
                  onClick={() => window.open(announcement.action_url, '_blank')}
                  className="text-xs font-bold text-indigo-400 hover:text-indigo-300 underline"
                >
                  {announcement.action_text || "Learn More"}
                </button>
              )}
              <button onClick={handleDismiss} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}