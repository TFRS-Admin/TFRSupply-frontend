import React from "react";
import { motion } from "framer-motion";
import { ExternalLink, Sparkles, Zap, Code, ChevronRight, Play } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

// Style 1: Full Height Movie Poster (Original)
function Style1({ templates }) {
  return (
    <section className="relative py-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-cyan-400 via-blue-500 to-fuchsia-500 opacity-90">
        <div className="absolute inset-0" style={{ backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 50px, rgba(255,255,255,0.03) 50px, rgba(255,255,255,0.03) 100px)` }} />
      </div>
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(8)].map((_, i) =>
        <motion.div key={i} className="absolute" style={{ left: `${10 + i * 12}%`, top: `${10 + i % 3 * 30}%` }} animate={{ y: [0, -30, 0], rotate: [0, 360], scale: [1, 1.2, 1] }} transition={{ duration: 4 + i, repeat: Infinity, delay: i * 0.3 }}>
            {i % 3 === 0 ? <Sparkles className="w-8 h-8 text-white/30" /> : i % 3 === 1 ? <Zap className="w-6 h-6 text-yellow-300/40" /> : <Code className="w-7 h-7 text-pink-300/30" />}
          </motion.div>
        )}
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
          <motion.div animate={{ scale: [1, 1.05, 1] }} transition={{ duration: 2, repeat: Infinity }} className="inline-block px-6 py-3 bg-white/20 backdrop-blur-sm rounded-full border-4 border-white mb-6">
            <p className="text-sm font-black text-white uppercase tracking-wider">🎬 Now Showing • Fresh Templates</p>
          </motion.div>
          <h2 className="text-5xl md:text-6xl font-black text-white mb-4 leading-tight" style={{ textShadow: "4px 4px 0 rgba(0,0,0,0.3), 8px 8px 0 rgba(255,255,255,0.1)" }}>
            IN A WORLD WHERE<br /><span className="text-yellow-300">U</span> AND <span className="text-yellow-300">I</span> COMING TOGETHER<br />MEANS <span className="bg-gradient-to-r from-pink-300 to-purple-300 bg-clip-text text-transparent">USER INTERFACE</span>
          </h2>
          <p className="text-xl md:text-2xl font-bold text-white/90 italic max-w-3xl mx-auto">Beyond the Code... <span className="text-yellow-300">Prompt</span> the Code 🚀</p>
        </motion.div>
        <div className={`grid gap-8 mb-12 ${templates.length === 1 ? 'md:grid-cols-1 max-w-md mx-auto' : templates.length === 2 ? 'md:grid-cols-2 max-w-4xl mx-auto' : 'md:grid-cols-3'}`}>
          {templates.map((template, i) =>
          <motion.a key={template.id} href={template.link} target="_blank" rel="noopener noreferrer" initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.15 }} whileHover={{ y: -8, scale: 1.02 }} className="group relative">
              <div className="relative rounded-2xl overflow-hidden border-6 border-white shadow-[0_10px_40px_rgba(0,0,0,0.3)] bg-white">
                <div className="aspect-[3/4] relative overflow-hidden">
                  <img src={template.image} alt={template.title} className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  <motion.div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity" initial={{ scale: 0.8 }} whileHover={{ scale: 1 }}>
                    <div className="px-6 py-3 bg-pink-500 rounded-full font-black text-white text-lg flex items-center gap-2 shadow-xl">VIEW TEMPLATE<ExternalLink className="w-5 h-5" /></div>
                  </motion.div>
                </div>
                <div className="p-4 bg-gradient-to-r from-pink-500 to-purple-600"><h3 className="font-black text-white text-xl text-center uppercase tracking-wide">{template.title}</h3></div>
              </div>
              <motion.div animate={{ rotate: [0, 5, -5, 0] }} transition={{ duration: 2, repeat: Infinity }} className="absolute -top-3 -right-3 w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center font-black text-2xl border-4 border-white shadow-xl">⭐</motion.div>
            </motion.a>
          )}
        </div>
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center">
          <motion.a href="https://base44templates.com" target="_blank" rel="noopener noreferrer" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="inline-flex items-center gap-3 px-10 py-5 bg-white text-cyan-600 font-black text-xl rounded-2xl shadow-2xl hover:shadow-[0_0_40px_rgba(255,255,255,0.5)] transition-all border-4 border-pink-400">
            🎪 EXPLORE ALL TEMPLATES<ExternalLink className="w-6 h-6" />
          </motion.a>
        </motion.div>
      </div>
    </section>);

}

// Style 2: Half Height Compact Cards
function Style2({ templates }) {
  return (
    <section className="relative py-12 bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-black text-white mb-8 text-center">Featured Templates</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {templates.map((template, i) =>
          <motion.a key={template.id} href={template.link} target="_blank" rel="noopener noreferrer" whileHover={{ y: -4 }} className="group relative rounded-xl overflow-hidden border-2 border-violet-500 bg-slate-900 shadow-xl">
              <div className="aspect-video relative overflow-hidden">
                <img src={template.image} alt={template.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                <div className="absolute bottom-3 left-3 right-3"><h3 className="font-bold text-white text-lg">{template.title}</h3></div>
              </div>
            </motion.a>
          )}
        </div>
      </div>
    </section>);

}

// Style 3: Netflix Horizontal Scroll
function Style3({ templates }) {
  return (
    <section className="relative py-12 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3 mb-6">
          <h2 className="text-2xl font-bold text-white">Templates</h2>
          <ChevronRight className="w-6 h-6 text-white" />
        </div>
        <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
          {templates.map((template, i) =>
          <motion.a key={template.id} href={template.link} target="_blank" rel="noopener noreferrer" whileHover={{ scale: 1.05 }} className="flex-shrink-0 w-72 group relative rounded-lg overflow-hidden bg-slate-900">
              <div className="aspect-video relative">
                <img src={template.image} alt={template.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Play className="w-16 h-16 text-white" />
                </div>
              </div>
              <div className="p-3"><h3 className="font-semibold text-white text-sm">{template.title}</h3></div>
            </motion.a>
          )}
        </div>
      </div>
    </section>);

}

// Style 4: Blockbuster Tape Style
function Style4({ templates }) {
  return (
    <section className="relative py-12 bg-gradient-to-br from-blue-900 via-cyan-600 to-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-5xl font-black text-white mb-2" style={{ textShadow: "3px 3px 0 rgba(0,0,0,0.5)" }}>More TEAM44 TEMPLATES on BASE44!</h2>
          <p className="text-yellow-300 font-bold text-xl">❤️❤️❤️ Trending Templates Collection⚡⚡⚡</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {templates.map((template) =>
          <motion.a key={template.id} href={template.link} target="_blank" rel="noopener noreferrer" whileHover={{ rotate: -2, scale: 1.05 }} className="relative">
              <div className="bg-black rounded-lg overflow-hidden border-4 border-cyan-400 shadow-2xl">
                <div className="aspect-[3/4]"><img src={template.image} alt={template.title} className="w-full h-full object-cover" /></div>
                <div className="bg-cyan-100 p-3 border-t-4 border-black"><h3 className="font-black text-black text-center uppercase">{template.title}</h3></div>
              </div>
            </motion.a>
          )}
        </div>
      </div>
    </section>);

}

// Style 5: Minimalist Grid
function Style5({ templates }) {
  return (
    <section className="py-12 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-black mb-8">Explore Templates</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {templates.map((template) =>
          <a key={template.id} href={template.link} target="_blank" rel="noopener noreferrer" className="group">
              <div className="aspect-[4/3] bg-gray-100 rounded-lg overflow-hidden mb-3">
                <img src={template.image} alt={template.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
              </div>
              <h3 className="font-semibold text-black group-hover:text-violet-600 transition-colors">{template.title}</h3>
            </a>
          )}
        </div>
      </div>
    </section>);

}

// Style 6: Candy Store (Feastables Small)
function Style6({ templates }) {
  return (
    <section className="relative py-10 bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-400">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-4xl font-black text-white text-center mb-8" style={{ textShadow: "3px 3px 0 rgba(0,0,0,0.3)" }}>GRAB A TEMPLATE!</h2>
        <div className="grid md:grid-cols-4 gap-4">
          {templates.map((template) =>
          <motion.a key={template.id} href={template.link} target="_blank" rel="noopener noreferrer" whileHover={{ y: -5, rotate: 2 }} className="bg-white rounded-2xl p-4 shadow-lg border-4 border-yellow-300">
              <div className="aspect-square rounded-xl overflow-hidden mb-2"><img src={template.image} alt={template.title} className="w-full h-full object-cover" /></div>
              <h3 className="font-black text-center text-sm">{template.title}</h3>
            </motion.a>
          )}
        </div>
      </div>
    </section>);

}

// Style 7: Dark Neon
function Style7({ templates }) {
  return (
    <section className="relative py-12 bg-black">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-fuchsia-500 mb-8 text-center">Digital Templates</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {templates.map((template) =>
          <motion.a key={template.id} href={template.link} target="_blank" rel="noopener noreferrer" whileHover={{ scale: 1.05 }} className="group relative rounded-lg overflow-hidden border border-cyan-500 shadow-[0_0_20px_rgba(6,182,212,0.3)]">
              <div className="aspect-video"><img src={template.image} alt={template.title} className="w-full h-full object-cover group-hover:opacity-80 transition-opacity" /></div>
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4"><h3 className="font-bold text-cyan-400">{template.title}</h3></div>
            </motion.a>
          )}
        </div>
      </div>
    </section>);

}

// Style 8: Carousel Banner
function Style8({ templates }) {
  return (
    <section className="relative py-8 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4">
        <div className="bg-gradient-to-r from-violet-600 to-fuchsia-600 rounded-3xl p-8">
          <h2 className="text-3xl font-black text-white mb-6 text-center">Ready-Made Templates</h2>
          <div className="grid md:grid-cols-3 gap-4">
            {templates.map((template) =>
            <a key={template.id} href={template.link} target="_blank" rel="noopener noreferrer" className="bg-white/10 backdrop-blur rounded-xl p-3 hover:bg-white/20 transition-colors">
                <div className="aspect-video rounded-lg overflow-hidden mb-2"><img src={template.image} alt={template.title} className="w-full h-full object-cover" /></div>
                <h3 className="font-bold text-white text-sm text-center">{template.title}</h3>
              </a>
            )}
          </div>
        </div>
      </div>
    </section>);

}

export default function TemplateShowcase() {
  const { data: settings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || {};
    },
    initialData: {}
  });

  const showcase = settings?.template_showcase || {};
  if (!showcase?.enabled) return null;

  const templates = [
  { id: 1, image: showcase.poster_1_image || "", link: showcase.poster_1_link || "", title: showcase.poster_1_title || "Template 1" },
  { id: 2, image: showcase.poster_2_image || "", link: showcase.poster_2_link || "", title: showcase.poster_2_title || "Template 2" },
  { id: 3, image: showcase.poster_3_image || "", link: showcase.poster_3_link || "", title: showcase.poster_3_title || "Template 3" }].
  filter((t) => t.image);

  if (templates.length === 0) return null;

  const styleId = showcase.style_id || "style1";

  const styles = {
    style1: <Style1 templates={templates} />,
    style2: <Style2 templates={templates} />,
    style3: <Style3 templates={templates} />,
    style4: <Style4 templates={templates} />,
    style5: <Style5 templates={templates} />,
    style6: <Style6 templates={templates} />,
    style7: <Style7 templates={templates} />,
    style8: <Style8 templates={templates} />
  };

  return styles[styleId] || styles.style1;
}