import React from "react";
import { motion } from "framer-motion";
import { Heart, ExternalLink, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

export default function DonationBanner() {
  const { data: settings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || {};
    },
    initialData: {}
  });

  const donationBanner = settings?.donation_banner || {};

  if (!donationBanner?.enabled) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="relative my-16"
    >
      <div className="max-w-6xl mx-auto px-4">
        <Link to={createPageUrl("DonationGateway")}>
          <motion.div
            whileHover={{ scale: 1.02 }}
            className="relative overflow-hidden rounded-3xl border-6 border-white shadow-2xl cursor-pointer"
          >
            {/* Feastables-inspired gradient */}
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 via-pink-500 to-fuchsia-500">
              <div className="absolute inset-0" style={{
                backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 40px, rgba(255,255,255,0.1) 40px, rgba(255,255,255,0.1) 80px)`
              }} />
            </div>

            {/* Floating elements */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              {[...Array(8)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute text-4xl"
                  style={{ left: `${10 + i * 12}%`, top: `${20 + (i % 2) * 40}%` }}
                  animate={{
                    y: [0, -20, 0],
                    rotate: [0, 360],
                    scale: [1, 1.2, 1]
                  }}
                  transition={{ duration: 3 + i, repeat: Infinity, delay: i * 0.3 }}
                >
                  {['💰', '☕', '🎨', '💎', '⭐', '💙', '🚀', '💚'][i]}
                </motion.div>
              ))}
            </div>

            <div className="relative z-10 py-12 px-8 text-center">
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="inline-block mb-4"
              >
                <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-xl border-4 border-pink-400">
                  <Heart className="w-10 h-10 text-pink-500" fill="currentColor" />
                </div>
              </motion.div>

              <h2 className="text-4xl md:text-5xl font-black text-white mb-3 leading-tight" style={{
                textShadow: "4px 4px 0 rgba(0,0,0,0.3), 8px 8px 0 rgba(255,255,255,0.1)"
              }}>
                KEEP THE AWESOMENESS<br />
                <span className="text-yellow-300">FLOWING!</span>
              </h2>

              <p className="text-xl font-bold text-white/90 mb-6 max-w-2xl mx-auto">
                300+ Free Effects • Zero Ads • Pure Passion 🔥
              </p>

              <div className="inline-flex items-center gap-3 px-8 py-4 bg-white rounded-full font-black text-xl text-transparent bg-clip-text bg-gradient-to-r from-cyan-600 to-fuchsia-600 shadow-xl border-4 border-pink-400">
                <Sparkles className="w-6 h-6 text-pink-500" />
                SUPPORT US
                <ExternalLink className="w-6 h-6 text-cyan-500" />
              </div>

              <p className="text-sm text-white/70 mt-4 font-semibold">
                Click to see all donation options 🎁
              </p>
            </div>
          </motion.div>
        </Link>
      </div>
    </motion.div>
  );
}