import React, { createContext, useContext, useState, useEffect } from "react";

const ThemeContext = createContext({
  theme: "dark",
  setTheme: () => {},
  language: "en",
  setLanguage: () => {},
  t: (key) => key,
});

// Translation strings
const translations = {
  en: {
    home: "Home",
    visual: "Visual",
    audio: "Audio",
    transitions: "Transitions",
    buttons: "Buttons",
    more: "More",
    tools: "Tools",
    navigation: "Navigation",
    menus: "Menus",
    chat: "Chat",
    characters: "Characters",
    aiAgent: "AI Agent",
    icons: "Icons",
    spinners: "Spinners",
    admin: "Admin",
    marketing: "Marketing",
    creative: "Creative",
    content: "Content",
    comms: "Comms",
    social: "Social",
    productivity: "Productivity",
    ecommerce: "E-commerce",
    cart: "Cart",
    colors: "Colors",
    builder: "Builder",
    discover: "Discover",
    myEffects: "My Effects",
    learnUI: "Learn UI",
    tutorials: "Tutorials",
    builtWith: "Built with",
    by: "by",
    on: "on",
    preferences: "Preferences",
    yourStats: "Your Stats",
    installApp: "Install App",
    viewed: "viewed",
    copied: "copied",
    exploreEffects: "Explore Effects",
    interactiveEffects: "Interactive Effects",
  },
  es: {
    home: "Inicio",
    visual: "Visual",
    audio: "Audio",
    transitions: "Transiciones",
    buttons: "Botones",
    more: "Más",
    tools: "Herramientas",
    navigation: "Navegación",
    menus: "Menús",
    chat: "Chat",
    characters: "Personajes",
    aiAgent: "Agente IA",
    icons: "Iconos",
    spinners: "Cargadores",
    admin: "Admin",
    marketing: "Marketing",
    creative: "Creativo",
    content: "Contenido",
    comms: "Comunicación",
    social: "Social",
    productivity: "Productividad",
    ecommerce: "E-commerce",
    cart: "Carrito",
    colors: "Colores",
    builder: "Constructor",
    discover: "Descubrir",
    myEffects: "Mis Efectos",
    learnUI: "Aprender UI",
    tutorials: "Tutoriales",
    builtWith: "Hecho con",
    by: "por",
    on: "en",
    preferences: "Preferencias",
    yourStats: "Tus Estadísticas",
    installApp: "Instalar App",
    viewed: "vistos",
    copied: "copiados",
    exploreEffects: "Explorar Efectos",
    interactiveEffects: "Efectos Interactivos",
  },
  fr: {
    home: "Accueil",
    visual: "Visuel",
    audio: "Audio",
    transitions: "Transitions",
    buttons: "Boutons",
    more: "Plus",
    tools: "Outils",
    navigation: "Navigation",
    menus: "Menus",
    chat: "Chat",
    characters: "Personnages",
    aiAgent: "Agent IA",
    icons: "Icônes",
    spinners: "Chargeurs",
    admin: "Admin",
    marketing: "Marketing",
    creative: "Créatif",
    content: "Contenu",
    comms: "Communication",
    social: "Social",
    productivity: "Productivité",
    ecommerce: "E-commerce",
    cart: "Panier",
    colors: "Couleurs",
    builder: "Constructeur",
    discover: "Découvrir",
    myEffects: "Mes Effets",
    learnUI: "Apprendre UI",
    tutorials: "Tutoriels",
    builtWith: "Fait avec",
    by: "par",
    on: "sur",
    preferences: "Préférences",
    yourStats: "Vos Stats",
    installApp: "Installer l'App",
    viewed: "vus",
    copied: "copiés",
    exploreEffects: "Explorer les Effets",
    interactiveEffects: "Effets Interactifs",
  },
  de: {
    home: "Startseite",
    visual: "Visuell",
    audio: "Audio",
    transitions: "Übergänge",
    buttons: "Tasten",
    more: "Mehr",
    tools: "Werkzeuge",
    navigation: "Navigation",
    menus: "Menüs",
    chat: "Chat",
    characters: "Charaktere",
    aiAgent: "KI-Agent",
    icons: "Symbole",
    spinners: "Lader",
    admin: "Admin",
    marketing: "Marketing",
    creative: "Kreativ",
    content: "Inhalt",
    comms: "Kommunikation",
    social: "Sozial",
    productivity: "Produktivität",
    ecommerce: "E-Commerce",
    cart: "Warenkorb",
    colors: "Farben",
    builder: "Baukasten",
    discover: "Entdecken",
    myEffects: "Meine Effekte",
    learnUI: "UI Lernen",
    tutorials: "Tutorials",
    builtWith: "Erstellt mit",
    by: "von",
    on: "auf",
    preferences: "Einstellungen",
    yourStats: "Ihre Statistiken",
    installApp: "App Installieren",
    viewed: "angesehen",
    copied: "kopiert",
    exploreEffects: "Effekte Erkunden",
    interactiveEffects: "Interaktive Effekte",
  },
  jp: {
    home: "ホーム",
    visual: "ビジュアル",
    audio: "オーディオ",
    transitions: "トランジション",
    buttons: "ボタン",
    more: "もっと",
    tools: "ツール",
    navigation: "ナビ",
    menus: "メニュー",
    chat: "チャット",
    characters: "キャラクター",
    aiAgent: "AIエージェント",
    icons: "アイコン",
    spinners: "ローダー",
    admin: "管理者",
    marketing: "マーケティング",
    creative: "クリエイティブ",
    content: "コンテンツ",
    comms: "通信",
    social: "ソーシャル",
    productivity: "生産性",
    ecommerce: "Eコマース",
    cart: "カート",
    colors: "色",
    builder: "ビルダー",
    discover: "発見",
    myEffects: "マイエフェクト",
    learnUI: "UI学習",
    tutorials: "チュートリアル",
    builtWith: "で作成",
    by: "by",
    on: "on",
    preferences: "設定",
    yourStats: "統計",
    installApp: "アプリをインストール",
    viewed: "閲覧",
    copied: "コピー",
    exploreEffects: "エフェクトを探索",
    interactiveEffects: "インタラクティブエフェクト",
  },
};

export function ThemeProvider({ children }) {
  const [theme, setThemeState] = useState(() => localStorage.getItem("appTheme") || "dark");
  const [language, setLanguageState] = useState(() => localStorage.getItem("appLang") || "en");

  const setTheme = (newTheme) => {
    setThemeState(newTheme);
    localStorage.setItem("appTheme", newTheme);
    document.documentElement.setAttribute("data-theme", newTheme);
  };

  const setLanguage = (newLang) => {
    setLanguageState(newLang);
    localStorage.setItem("appLang", newLang);
    document.documentElement.setAttribute("lang", newLang);
  };

  const t = (key) => {
    return translations[language]?.[key] || translations.en[key] || key;
  };

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    document.documentElement.setAttribute("lang", language);
  }, []);

  return (
    <ThemeContext.Provider value={{ theme, setTheme, language, setLanguage, t }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}

export default ThemeProvider;