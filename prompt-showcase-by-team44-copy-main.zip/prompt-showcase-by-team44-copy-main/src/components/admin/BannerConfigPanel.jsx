import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { bannerOptions } from "@/components/ads/AdBannerManager";
import { Check, ExternalLink } from "lucide-react";
import ToggleSwitch from "@/components/ui/toggle-switch";

export default function BannerConfigPanel({ selectedBanner, setSelectedBanner, bannerConfigs, setBannerConfigs }) {
  const updateBannerConfig = (bannerId, field, value) => {
    setBannerConfigs(prev => ({
      ...prev,
      [bannerId]: { ...prev[bannerId], [field]: value }
    }));
  };

  const currentConfig = bannerConfigs[selectedBanner] || {};

  return (
    <Card className="bg-slate-900/50 border-slate-800">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <ExternalLink className="w-5 h-5" /> Ad Banner Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Banner Selection */}
        <div>
          <Label className="text-white text-sm mb-3 block">Select Banner Style</Label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {bannerOptions.map(banner => (
              <motion.button
                key={banner.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setSelectedBanner(banner.id)}
                className={`p-3 rounded-xl text-left transition-all ${
                  selectedBanner === banner.id 
                    ? "bg-gradient-to-r from-violet-500/30 to-cyan-500/30 border-2 border-violet-500" 
                    : "bg-slate-800/50 border border-slate-700 hover:border-slate-600"
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-medium text-sm text-white">{banner.name}</p>
                    <p className="text-xs text-slate-400">{banner.desc}</p>
                  </div>
                  {selectedBanner === banner.id && (
                    <Check className="w-4 h-4 text-green-400" />
                  )}
                </div>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Banner Configuration */}
        <div className="space-y-6 p-4 rounded-xl bg-slate-800/50 border border-slate-700">
          <h4 className="text-white font-medium">Customize "{bannerOptions.find(b => b.id === selectedBanner)?.name}"</h4>
          
          {/* Font & Animation */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-slate-400 text-xs mb-2 block">Font Family</Label>
              <select
                value={currentConfig.fontFamily || "Impact"}
                onChange={(e) => updateBannerConfig(selectedBanner, "fontFamily", e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg p-2 text-sm"
              >
                <option value="Impact">Impact (Default)</option>
                <option value="Arial Black">Arial Black</option>
                <option value="Roboto">Roboto</option>
                <option value="Open Sans">Open Sans</option>
                <option value="Lato">Lato</option>
                <option value="Montserrat">Montserrat</option>
                <option value="Poppins">Poppins</option>
                <option value="Raleway">Raleway</option>
                <option value="Oswald">Oswald</option>
                <option value="Ubuntu">Ubuntu</option>
                <option value="Nunito">Nunito</option>
                <option value="Playfair Display">Playfair Display</option>
                <option value="Merriweather">Merriweather</option>
                <option value="PT Sans">PT Sans</option>
                <option value="Cabin">Cabin</option>
                <option value="Quicksand">Quicksand</option>
                <option value="Bebas Neue">Bebas Neue</option>
                <option value="Anton">Anton</option>
                <option value="Righteous">Righteous</option>
                <option value="Fjalla One">Fjalla One</option>
                <option value="Archivo Black">Archivo Black</option>
                <option value="Pacifico">Pacifico</option>
                <option value="Lobster">Lobster</option>
                <option value="Dancing Script">Dancing Script</option>
                <option value="Permanent Marker">Permanent Marker</option>
                <option value="Press Start 2P">Press Start 2P</option>
                <option value="Orbitron">Orbitron</option>
                <option value="Russo One">Russo One</option>
                <option value="Bungee">Bungee</option>
                <option value="Concert One">Concert One</option>
              </select>
            </div>
            <div>
              <Label className="text-slate-400 text-xs mb-2 block">Animation Effect</Label>
              <select
                value={currentConfig.animation || "none"}
                onChange={(e) => updateBannerConfig(selectedBanner, "animation", e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg p-2 text-sm"
              >
                <option value="none">None</option>
                <option value="pulse">Pulse</option>
                <option value="bounce">Bounce</option>
                <option value="fadeIn">Fade In</option>
                <option value="scaleIn">Scale In</option>
                <option value="slideUp">Slide Up</option>
                <option value="glow">Glowing Text</option>
              </select>
            </div>
          </div>

          {/* Size Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-slate-400 text-xs mb-2 block">Banner Height</Label>
              <select
                value={currentConfig.height || "350px"}
                onChange={(e) => updateBannerConfig(selectedBanner, "height", e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg p-2 text-sm"
              >
                <option value="250px">Small (250px)</option>
                <option value="350px">Medium (350px) - Default</option>
                <option value="450px">Large (450px)</option>
                <option value="550px">Extra Large (550px)</option>
              </select>
            </div>
            <div>
              <Label className="text-slate-400 text-xs mb-2 block">Banner Width</Label>
              <select
                value={currentConfig.width || "100%"}
                onChange={(e) => updateBannerConfig(selectedBanner, "width", e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg p-2 text-sm"
              >
                <option value="100%">Full Width (100%)</option>
                <option value="90%">90%</option>
                <option value="80%">80%</option>
                <option value="70%">70%</option>
              </select>
            </div>
          </div>

          {/* Gradient Options */}
          <div>
            <Label className="text-slate-400 text-xs mb-3 block">Background Gradient</Label>
            <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
              {[
                { name: "Fire", colors: ["#1a0a0a", "#4a1c1c", "#ff4500"] },
                { name: "Space", colors: ["#000020", "#000040", "#0000aa"] },
                { name: "Horror", colors: ["#0a0a0a", "#1a0a1a", "#2a0a2a"] },
                { name: "Ocean", colors: ["#001a33", "#003366", "#0066cc"] },
                { name: "Sunset", colors: ["#33001a", "#660033", "#cc0066"] },
                { name: "Forest", colors: ["#0d1f0d", "#1a3d1a", "#2d662d"] },
                { name: "Gold", colors: ["#1a1300", "#332600", "#664d00"] },
                { name: "Neon", colors: ["#1a001a", "#330033", "#660066"] }
              ].map(grad => (
                <button
                  key={grad.name}
                  onClick={() => updateBannerConfig(selectedBanner, "gradientColors", grad.colors)}
                  className="h-16 rounded-lg border-2 border-transparent hover:border-white transition-all overflow-hidden"
                  style={{ background: `linear-gradient(180deg, ${grad.colors[0]} 0%, ${grad.colors[1]} 50%, ${grad.colors[2]} 100%)` }}
                >
                  <span className="text-[8px] font-bold text-white drop-shadow-lg">{grad.name}</span>
                </button>
              ))}
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-slate-400 text-xs">Title</Label>
              <Input
                value={currentConfig.title || "TEAM44"}
                onChange={(e) => updateBannerConfig(selectedBanner, "title", e.target.value)}
                className="bg-slate-900 border-slate-700 text-white"
                placeholder="TEAM44"
              />
            </div>
            <div>
              <Label className="text-slate-400 text-xs">Subtitle/Tagline</Label>
              <Input
                value={currentConfig.subtitle || currentConfig.tagline || ""}
                onChange={(e) => updateBannerConfig(selectedBanner, "subtitle", e.target.value)}
                className="bg-slate-900 border-slate-700 text-white"
                placeholder="Your tagline here"
              />
            </div>
            <div className="md:col-span-2 flex items-center justify-between p-3 bg-slate-950 rounded-lg border border-slate-800">
              <div>
                <Label className="text-white text-sm">Show Pricing</Label>
                <p className="text-xs text-slate-500">Display original and sale price (disable for free products)</p>
              </div>
              <ToggleSwitch 
                checked={currentConfig.showPrice !== false} 
                onCheckedChange={(v) => updateBannerConfig(selectedBanner, "showPrice", v)} 
              />
            </div>
            {currentConfig.showPrice !== false ? (
              <>
                <div>
                  <Label className="text-slate-400 text-xs">Original Price</Label>
                  <Input
                    value={currentConfig.originalPrice || "$199"}
                    onChange={(e) => updateBannerConfig(selectedBanner, "originalPrice", e.target.value)}
                    className="bg-slate-900 border-slate-700 text-white"
                    placeholder="$199"
                  />
                </div>
                <div>
                  <Label className="text-slate-400 text-xs">Sale Price</Label>
                  <Input
                    value={currentConfig.salePrice || "$49"}
                    onChange={(e) => updateBannerConfig(selectedBanner, "salePrice", e.target.value)}
                    className="bg-slate-900 border-slate-700 text-white"
                    placeholder="$49"
                  />
                </div>
              </>
            ) : (
              <div className="md:col-span-2">
                <Label className="text-slate-400 text-xs">Alternative Text (instead of price)</Label>
                <Input
                  value={currentConfig.priceAltText || ""}
                  onChange={(e) => updateBannerConfig(selectedBanner, "priceAltText", e.target.value)}
                  className="bg-slate-900 border-slate-700 text-white"
                  placeholder="e.g., 'FREE FOREVER' or '100% FREE'"
                />
              </div>
            )}
            <div>
              <Label className="text-slate-400 text-xs">Button Text</Label>
              <Input
                value={currentConfig.ctaText || "ORDER NOW"}
                onChange={(e) => updateBannerConfig(selectedBanner, "ctaText", e.target.value)}
                className="bg-slate-900 border-slate-700 text-white"
                placeholder="ORDER NOW"
              />
            </div>
            <div>
              <Label className="text-slate-400 text-xs">Button URL</Label>
              <Input
                value={currentConfig.ctaUrl || "https://base44.io"}
                onChange={(e) => updateBannerConfig(selectedBanner, "ctaUrl", e.target.value)}
                className="bg-slate-900 border-slate-700 text-white"
                placeholder="https://..."
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}