import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Scan, Save, X, CheckCircle, AlertCircle, Loader2, Code, ChevronDown, ChevronUp, Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { base44 } from "@/api/base44Client";

// Static manifest of known component and page files in this project.
// We read their source via fetch() against the Vite dev server / hosted origin.
// Add new file paths here as the project grows.
const FILE_MANIFEST = [
  // Admin
  "src/components/admin/BannerConfigPanel.jsx",
  // Ads
  "src/components/ads/AdBannerManager.jsx",
  "src/components/ads/BannerGenerator.jsx",
  "src/components/ads/RetroAdBanner.jsx",
  "src/components/ads/banners/MoviePosterAd1.jsx",
  "src/components/ads/banners/MoviePosterAd2.jsx",
  "src/components/ads/banners/MoviePosterAd3.jsx",
  "src/components/ads/banners/NeonCyberAd.jsx",
  "src/components/ads/banners/RetroInfomercialAd.jsx",
  // Builder
  "src/components/builder/ParticleEditor.jsx",
  "src/components/builder/TimelineEditor.jsx",
  // Donation
  "src/components/donation/BuyMeCoffeeCTA.jsx",
  // Effects
  "src/components/effects/CategoryHeader.jsx",
  "src/components/effects/CodeSnippet.jsx",
  "src/components/effects/DynamicEffectPreview.jsx",
  "src/components/effects/EffectCard.jsx",
  "src/components/effects/GlitchButton.jsx",
  "src/components/effects/GlitchLoader.jsx",
  "src/components/effects/ResponsivePreview.jsx",
  "src/components/effects/SearchFilter.jsx",
  "src/components/effects/SearchFilterEnhanced.jsx",
  "src/components/effects/TeachableMoment.jsx",
  "src/components/effects/WilsonQuote.jsx",
  "src/components/effects/WordSlider.jsx",
  "src/components/effects/TypewriterHero.jsx",
  // Fonts
  "src/components/fonts/FontGenreSection.jsx",
  "src/components/fonts/FontPairingSystem.jsx",
  "src/components/fonts/FontTipsSection.jsx",
  // Footer
  "src/components/footer/ComponentCounter.jsx",
  "src/components/footer/FooterEnhanced.jsx",
  // Marketing
  "src/components/marketing/DonationBanner.jsx",
  "src/components/marketing/GlobalAnnouncement.jsx",
  "src/components/marketing/NetflixTemplates.jsx",
  "src/components/marketing/TemplateShowcase.jsx",
  // Monetization
  "src/components/monetization/PremiumStore.jsx",
  // Navigation
  "src/components/navigation/GlobalSearch.jsx",
  // Onboarding
  "src/components/onboarding/OnboardingTour.jsx",
  "src/components/onboarding/TemplateInitializer.jsx",
  // PWA
  "src/components/pwa/InstallButton.jsx",
  // Theme
  "src/components/theme/ThemeProvider.jsx",
  // Tutorial
  "src/components/tutorial/TutorialSystem.jsx",
  "src/components/tutorial/TutorialTooltip.jsx",
  // Video
  "src/components/video/BlockbusterShowcase.jsx",
  "src/components/video/CinematicVideoModal.jsx",
  "src/components/video/ModernVideoShowcase.jsx",
  "src/components/video/RetroTVShowcase.jsx",
  "src/components/video/ThemedVideoShowcase.jsx",
  // Pages
  "src/pages/AIAgentEffects.jsx",
  "src/pages/AbstractAnimations.jsx",
  "src/pages/AdminDashboard.jsx",
  "src/pages/AudioEffects.jsx",
  "src/pages/ButtonEffects.jsx",
  "src/pages/ButtonShowcase.jsx",
  "src/pages/CartCheckout.jsx",
  "src/pages/CharacterEffects.jsx",
  "src/pages/ChatEffects.jsx",
  "src/pages/ColorSchemes.jsx",
  "src/pages/ContentEffects.jsx",
  "src/pages/CreativeEffects.jsx",
  "src/pages/DesignTerminology.jsx",
  "src/pages/Discover.jsx",
  "src/pages/DividerEffects.jsx",
  "src/pages/DonationComponents.jsx",
  "src/pages/DonationGateway.jsx",
  "src/pages/EcommerceEffects.jsx",
  "src/pages/EffectBuilder.jsx",
  "src/pages/Favorites.jsx",
  "src/pages/GamingEffects.jsx",
  "src/pages/Home.jsx",
  "src/pages/IconEffects.jsx",
  "src/pages/LoadingSpinners.jsx",
  "src/pages/MarketingEffects.jsx",
  "src/pages/MenuEffects.jsx",
  "src/pages/MyEffects.jsx",
  "src/pages/NavigationEffects.jsx",
  "src/pages/PageTemplates.jsx",
  "src/pages/PixelAssets.jsx",
  "src/pages/PremiumEffects.jsx",
  "src/pages/ProductivityEffects.jsx",
  "src/pages/SocialEffects.jsx",
  "src/pages/Suggestions.jsx",
  "src/pages/TeachableMode.jsx",
  "src/pages/TextEffects.jsx",
  "src/pages/Transitions.jsx",
  "src/pages/Tutorials.jsx",
  "src/pages/VideoEffects.jsx",
  "src/pages/VideoPlayerCustomization.jsx",
  "src/pages/VisualEffects.jsx",
];

async function fetchFileSource(filePath) {
  try {
    // In Vite dev/prod, source files are served from the origin
    const url = `${window.location.origin}/${filePath}`;
    const res = await fetch(url);
    if (!res.ok) return null;
    return await res.text();
  } catch (_e) {
    return null;
  }
}

function DiscoveryRow({ item, onSave, onIgnore }) {
  const [showCode, setShowCode] = useState(false);
  const [saving, setSaving] = useState(false);
  const [ignoring, setIgnoring] = useState(false);
  const [done, setDone] = useState(null);

  const handleSave = async () => {
    setSaving(true);
    await onSave(item);
    setSaving(false);
    setDone('saved');
  };

  const handleIgnore = async () => {
    setIgnoring(true);
    await onIgnore(item);
    setIgnoring(false);
    setDone('ignored');
  };

  if (done) {
    return (
      <motion.div
        initial={{ opacity: 1, height: "auto" }}
        animate={{ opacity: 0, height: 0 }}
        transition={{ duration: 0.4, delay: 0.5 }}
        className="overflow-hidden"
      >
        <div className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm ${done === 'saved' ? 'bg-green-500/10 text-green-400' : 'bg-slate-800/50 text-slate-500'}`}>
          <CheckCircle className="w-4 h-4" />
          {done === 'saved' ? `✓ Saved: ${item.componentName}` : `Ignored: ${item.componentName}`}
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900/50"
    >
      <div className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="font-mono text-sm font-bold text-white">{item.componentName}</span>
              {item.isDuplicate ? (
                <span className="px-2 py-0.5 rounded-full text-xs bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  ⚠ Possible Duplicate
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-full text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  ✓ New
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mb-2 font-mono truncate">{item.filePath}</p>
            <p className="text-sm text-slate-300 leading-relaxed">{item.analysis}</p>
            {item.isDuplicate && item.duplicateOf && (
              <p className="text-xs text-amber-500/80 mt-1">Possible duplicate of: <span className="font-mono">{item.duplicateOf}</span></p>
            )}
          </div>
          <div className="flex gap-2 flex-shrink-0">
            <Button size="sm" onClick={handleSave} disabled={saving || ignoring} className="bg-violet-600 hover:bg-violet-700 text-white gap-1">
              {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : <Save className="w-3 h-3" />}
              Save
            </Button>
            <Button size="sm" variant="outline" onClick={handleIgnore} disabled={saving || ignoring} className="border-slate-700 text-slate-400 hover:text-white gap-1">
              {ignoring ? <Loader2 className="w-3 h-3 animate-spin" /> : <X className="w-3 h-3" />}
              Ignore
            </Button>
          </div>
        </div>

        <button
          onClick={() => setShowCode(!showCode)}
          className="mt-3 flex items-center gap-1 text-xs text-slate-500 hover:text-slate-300 transition-colors"
        >
          <Code className="w-3 h-3" />
          {showCode ? 'Hide Code' : 'Preview Code'}
          {showCode ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
        </button>
      </div>

      <AnimatePresence>
        {showCode && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-slate-800"
          >
            <pre className="p-4 text-xs text-slate-400 overflow-x-auto max-h-48 bg-slate-950 font-mono leading-relaxed">
              {item.codeSnippet?.slice(0, 2000)}{item.codeSnippet?.length > 2000 ? '\n... (truncated)' : ''}
            </pre>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function LibraryIngestionPanel() {
  const [scanning, setScanning] = useState(false);
  const [discoveries, setDiscoveries] = useState([]);
  const [scanMeta, setScanMeta] = useState(null);
  const [error, setError] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const [collectingFiles, setCollectingFiles] = useState(false);

  const handleScan = async () => {
    setScanning(true);
    setCollectingFiles(true);
    setError("");
    setSuccessMsg("");
    setDiscoveries([]);
    setScanMeta(null);

    try {
      // Step 1: Collect file sources from the manifest
      const files = [];
      for (const filePath of FILE_MANIFEST) {
        const code = await fetchFileSource(filePath);
        if (code && code.length > 50) { // skip empty/404 files
          const componentName = filePath.split('/').pop().replace(/\.(jsx|js)$/, '');
          files.push({ filePath, componentName, codeSnippet: code });
        }
      }

      setCollectingFiles(false);

      if (files.length === 0) {
        setError("Could not read any source files. Make sure you're running the app in development mode.");
        setScanning(false);
        return;
      }

      // Step 2: Send to backend for comparison + AI analysis
      const response = await base44.functions.invoke('scanProjectComponents', {
        action: 'scan',
        files
      });

      const data = response.data;
      if (data.error) {
        setError(data.error);
      } else {
        setDiscoveries(data.discoveries || []);
        setScanMeta({
          totalScanned: data.totalScanned,
          newFound: data.newFound,
          returned: data.returned,
          message: data.message
        });
        if ((data.discoveries || []).length === 0) {
          setSuccessMsg(data.message || 'All components are already tracked!');
        }
      }
    } catch (e) {
      setError(e.message || 'Scan failed');
    } finally {
      setScanning(false);
      setCollectingFiles(false);
    }
  };

  const handleSave = async (item) => {
    try {
      await base44.functions.invoke('scanProjectComponents', {
        action: 'save',
        filePath: item.filePath,
        componentName: item.componentName,
        analysis: item.analysis,
        codeSnippet: item.codeSnippet
      });
      setSuccessMsg(`Saved ${item.componentName} to library!`);
      setTimeout(() => setSuccessMsg(""), 3000);
    } catch (e) {
      setError(`Failed to save ${item.componentName}: ${e.message}`);
    }
  };

  const handleIgnore = async (item) => {
    try {
      await base44.functions.invoke('scanProjectComponents', {
        action: 'ignore',
        filePath: item.filePath,
        componentName: item.componentName
      });
    } catch (e) {
      setError(`Failed to ignore: ${e.message}`);
    }
  };

  const handleSaveAll = async () => {
    for (const item of [...discoveries]) {
      await handleSave(item);
    }
    setDiscoveries([]);
    setSuccessMsg('All components saved to library!');
  };

  return (
    <Card className="bg-slate-900/50 border-slate-800 border-l-4 border-l-violet-500">
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <CardTitle className="text-white flex items-center gap-2">
              <Package className="w-5 h-5 text-violet-400" />
              Library Ingestion
            </CardTitle>
            <CardDescription className="text-slate-400">
              Scan project for new components and ingest them into the centralized Component Library database
            </CardDescription>
          </div>
          <div className="flex gap-2 flex-wrap">
            {discoveries.length > 1 && (
              <Button onClick={handleSaveAll} size="sm" className="bg-emerald-600 hover:bg-emerald-700 gap-2">
                <Save className="w-4 h-4" />
                Save All ({discoveries.length})
              </Button>
            )}
            <Button onClick={handleScan} disabled={scanning} className="bg-violet-600 hover:bg-violet-700 gap-2">
              {scanning ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> {collectingFiles ? 'Reading files...' : 'Analyzing...'}</>
              ) : (
                <><Scan className="w-4 h-4" /> Scan Project for New Components</>
              )}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            {error}
          </div>
        )}
        {successMsg && (
          <div className="flex items-center gap-2 p-3 bg-green-500/10 border border-green-500/30 rounded-lg text-green-400 text-sm">
            <CheckCircle className="w-4 h-4 flex-shrink-0" />
            {successMsg}
          </div>
        )}

        {scanMeta && discoveries.length > 0 && (
          <div className="flex gap-4 text-xs text-slate-500 flex-wrap">
            <span>📂 {scanMeta.totalScanned} files in manifest</span>
            <span>🆕 {scanMeta.newFound} new found</span>
            <span>🔍 {scanMeta.returned} analyzed</span>
            {scanMeta.message && <span className="text-amber-400">{scanMeta.message}</span>}
          </div>
        )}

        {scanning && (
          <div className="text-center py-12 text-slate-500">
            <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-violet-400" />
            <p className="text-sm">{collectingFiles ? 'Collecting source files from project...' : 'Generating AI analysis for new components...'}</p>
            <p className="text-xs mt-1 text-slate-600">This may take 20–40 seconds.</p>
          </div>
        )}

        {!scanning && discoveries.length > 0 && (
          <div className="space-y-3">
            <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
              {discoveries.length} New Discovery{discoveries.length !== 1 ? 'ies' : ''} Found
            </p>
            {discoveries.map((item) => (
              <DiscoveryRow
                key={item.filePath}
                item={item}
                onSave={handleSave}
                onIgnore={handleIgnore}
              />
            ))}
          </div>
        )}

        {!scanning && discoveries.length === 0 && !error && !successMsg && (
          <div className="text-center py-10 border border-dashed border-slate-800 rounded-xl text-slate-600">
            <Scan className="w-10 h-10 mx-auto mb-3 opacity-40" />
            <p className="text-sm">Click "Scan Project" to discover new components</p>
            <p className="text-xs mt-1 opacity-60">Checks {FILE_MANIFEST.length} known files against the Component Library database</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}