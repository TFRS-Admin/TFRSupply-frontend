import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Download, X, Smartphone, Sparkles, Apple, Monitor, ArrowRight, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

export default function InstallButton() {
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [showInstallPrompt, setShowInstallPrompt] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);
  const [platform, setPlatform] = useState(null);

  const { data: appSettings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || {};
    },
    initialData: {}
  });

  useEffect(() => {
    if (window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true) {
      setIsInstalled(true);
      return;
    }

    // Detect platform
    const ua = navigator.userAgent;
    if (/iPad|iPhone|iPod/.test(ua)) setPlatform('ios');
    else if (/Android/.test(ua)) setPlatform('android');
    else setPlatform('desktop');

    const handleBeforeInstallPrompt = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') setIsInstalled(true);
      setDeferredPrompt(null);
    } else {
      setShowInstallPrompt(true);
    }
  };

  if (isInstalled) {
    return (
      <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-gradient-to-r from-violet-500/20 to-purple-500/20 border border-violet-500/30">
        <motion.div animate={{ rotate: [0, 15, -15, 0] }} transition={{ duration: 2, repeat: Infinity }}>
          <Sparkles className="w-3.5 h-3.5 text-violet-400" />
        </motion.div>
        <span className="text-xs font-medium text-violet-400 hidden sm:inline">You Are Awesome!</span>
      </motion.div>
    );
  }

  return (
    <>
      <style>{`
        .install-btn-glitch:hover .install-btn-text,
        .install-btn-glitch:hover .install-btn-icon {
          animation: install-glitch 0.3s ease-in-out infinite;
        }
        @keyframes install-glitch {
          0%, 100% { text-shadow: none; filter: none; transform: translate(0); }
          20% { text-shadow: -2px 0 #ff00ff, 2px 0 #00ffff; transform: translate(-1px, 0); }
          40% { text-shadow: 2px 0 #ff00ff, -2px 0 #00ffff; transform: translate(1px, 0); }
          60% { text-shadow: -1px 0 #00ffff, 1px 0 #ff00ff; transform: translate(-1px, 0); }
          80% { text-shadow: 1px 0 #00ffff, -1px 0 #ff00ff; transform: translate(1px, 0); }
        }
      `}</style>
      <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={handleInstallClick} className="install-btn-glitch flex items-center gap-2 px-3 py-1.5 rounded-lg bg-gradient-to-r from-violet-500/20 to-teal-500/20 border border-violet-500/30 text-xs font-medium text-white hover:from-violet-500/30 hover:to-teal-500/30 transition-all whitespace-nowrap">
        <Download className="w-3.5 h-3.5 install-btn-icon" />
        <span className="hidden sm:inline install-btn-text">Install App</span>
      </motion.button>

      <AnimatePresence>
        {showInstallPrompt && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => setShowInstallPrompt(false)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={(e) => e.stopPropagation()} className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-md w-full shadow-2xl">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-xl bg-gradient-to-br from-violet-500 to-teal-500 relative overflow-hidden">
                    {appSettings?.logo_url ? (
                      <img src={appSettings.logo_url} alt="App Logo" className="w-8 h-8 object-contain relative z-10" />
                    ) : (
                      <Smartphone className="w-6 h-6 text-white relative z-10" />
                    )}
                    <div className="absolute inset-0 bg-white/10" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">Install {appSettings?.app_title || "App"}</h3>
                    <p className="text-xs text-slate-400">Get the best experience</p>
                  </div>
                </div>
                <button onClick={() => setShowInstallPrompt(false)} className="p-2 rounded-lg hover:bg-slate-800 text-slate-400">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4 text-slate-300">
                <p>Install this app on your device for quick access:</p>
                
                <div className="space-y-3">
                  {(platform === 'ios' || platform === null) && (
                    <div className={`p-4 rounded-lg ${platform === 'ios' ? 'bg-violet-500/20 border border-violet-500/50' : 'bg-slate-800/50'}`}>
                      <div className="flex items-center gap-2 mb-2">
                        <Apple className="w-5 h-5 text-white" />
                        <p className="font-medium text-white">iOS (Safari)</p>
                        {platform === 'ios' && <span className="text-xs bg-violet-500 text-white px-2 py-0.5 rounded-full">Your Device</span>}
                      </div>
                      <ol className="text-sm text-slate-400 space-y-1 ml-7">
                        <li>1. Tap the <strong className="text-white">Share</strong> button (square with arrow)</li>
                        <li>2. Scroll down and tap <strong className="text-white">"Add to Home Screen"</strong></li>
                        <li>3. Tap <strong className="text-white">"Add"</strong> in the top right</li>
                      </ol>
                    </div>
                  )}
                  
                  {(platform === 'android' || platform === null) && (
                    <div className={`p-4 rounded-lg ${platform === 'android' ? 'bg-violet-500/20 border border-violet-500/50' : 'bg-slate-800/50'}`}>
                      <div className="flex items-center gap-2 mb-2">
                        <Smartphone className="w-5 h-5 text-green-400" />
                        <p className="font-medium text-white">Android (Chrome)</p>
                        {platform === 'android' && <span className="text-xs bg-violet-500 text-white px-2 py-0.5 rounded-full">Your Device</span>}
                      </div>
                      <ol className="text-sm text-slate-400 space-y-1 ml-7">
                        <li>1. Tap the <strong className="text-white">menu (⋮)</strong> in Chrome</li>
                        <li>2. Tap <strong className="text-white">"Add to Home screen"</strong></li>
                        <li>3. Tap <strong className="text-white">"Add"</strong> to confirm</li>
                      </ol>
                    </div>
                  )}
                  
                  {(platform === 'desktop' || platform === null) && (
                    <div className={`p-4 rounded-lg ${platform === 'desktop' ? 'bg-violet-500/20 border border-violet-500/50' : 'bg-slate-800/50'}`}>
                      <div className="flex items-center gap-2 mb-2">
                        <Monitor className="w-5 h-5 text-blue-400" />
                        <p className="font-medium text-white">Desktop (Chrome/Edge)</p>
                        {platform === 'desktop' && <span className="text-xs bg-violet-500 text-white px-2 py-0.5 rounded-full">Your Device</span>}
                      </div>
                      <ol className="text-sm text-slate-400 space-y-1 ml-7">
                        <li>1. Look for the <strong className="text-white">install icon</strong> in the address bar</li>
                        <li>2. Click it and select <strong className="text-white">"Install"</strong></li>
                      </ol>
                    </div>
                  )}
                </div>
              </div>

              <motion.button
                onClick={() => setShowInstallPrompt(false)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="explore-hero-btn relative inline-flex items-center justify-center gap-2 px-8 py-3 rounded-xl font-semibold overflow-hidden w-full mt-6"
              >
                <div className="absolute inset-0 bg-slate-900/30 rounded-xl" />
                <div className="absolute inset-0 rounded-xl border-2 border-violet-500" />
                <span className="relative z-10 flex items-center gap-2 text-white explore-btn-content">
                  <Zap className="w-5 h-5 text-violet-400" />
                  <span>Got it!</span>
                  <ArrowRight className="w-4 h-4" />
                </span>
                <style>{`
                  .explore-hero-btn:hover .explore-btn-content { animation: explore-glitch 0.3s ease-in-out infinite; }
                  .explore-hero-btn:hover { animation: btn-shake 0.3s ease-in-out infinite; }
                `}</style>
              </motion.button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}