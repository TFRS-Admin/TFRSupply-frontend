import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Rocket, CheckCircle2, Loader2, AlertCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function TemplateInitializer({ previewMode = false }) {
  const [needsSetup, setNeedsSetup] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  // Logo from the template source to show before DB is ready
  const TEMPLATE_LOGO = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d0e11f7107236669e8813/ddacad611_Team44-Logo-Blue-Cyan.png";

  useEffect(() => {
    if (previewMode) {
      setNeedsSetup(true);
      return;
    }
    const checkSettings = async () => {
      try {
        // Check if we have app settings
        const settings = await base44.entities.AppSettings.list().catch(() => []);
        if (settings.length === 0) {
          setNeedsSetup(true);
        }
      } catch (e) {
        console.error("Failed to check settings:", e);
      }
    };
    checkSettings();
  }, [previewMode]);

  const handleInitialize = async () => {
    setIsInitializing(true);
    setError("");
    try {
      await base44.functions.invoke('seedApp', {});
      setSuccess(true);
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    } catch (e) {
      console.error("Initialization failed:", e);
      setError("Failed to initialize. Please check backend functions.");
      setIsInitializing(false);
    }
  };

  if (!needsSetup) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/95 backdrop-blur-md p-4"
      >
        <motion.div
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden"
        >
          {/* Header Graphic */}
          <div className="relative h-48 flex items-center justify-center overflow-hidden bg-slate-950">
            {/* Home Hero Gradients */}
            <div className="absolute inset-0 bg-gradient-to-b from-blue-950/60 via-blue-800/50 via-30% to-slate-950" />
            <div className="absolute inset-0 bg-gradient-radial from-transparent via-transparent to-black/40" />
            
            {/* Team 44 Overlay */}
            <div 
              className="absolute inset-0 opacity-40 z-0"
              style={{
                backgroundImage: 'url("https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d0e11f7107236669e8813/c9f0ed1a5_TEAM44-WATERMARK-BG-3-small.png")',
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                backgroundRepeat: 'no-repeat'
              }}
            />

            {/* Rotating Logo */}
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="relative z-10 w-32 h-32 flex items-center justify-center"
            >
              <img src={TEMPLATE_LOGO} alt="Logo" className="w-full h-full object-contain drop-shadow-[0_0_15px_rgba(139,92,246,0.5)]" />
            </motion.div>
          </div>

          {/* Content */}
          <div className="p-8 text-center space-y-6">
            <div className="space-y-2">
              <h2 className="text-2xl font-bold text-white">Welcome to Your New App!</h2>
              <p className="text-slate-400 text-sm leading-relaxed">
                This template requires a one-time setup to install the default configuration, themes, and 850+ effects.
              </p>
            </div>

            {error && (
              <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center gap-2 justify-center">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
            )}

            <motion.button
              onClick={handleInitialize}
              disabled={isInitializing || success}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`w-full py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all ${
                success 
                  ? "bg-green-500 text-white shadow-green-500/25 shadow-lg" 
                  : "bg-white text-slate-900 hover:bg-slate-100 shadow-white/10 shadow-lg"
              }`}
            >
              {success ? (
                <>
                  <CheckCircle2 className="w-6 h-6" />
                  All Set! Reloading...
                </>
              ) : isInitializing ? (
                <>
                  <Loader2 className="w-6 h-6 animate-spin" />
                  Installing...
                </>
              ) : (
                <>
                  <Rocket className="w-6 h-6 text-violet-600" />
                  Initialize App
                </>
              )}
            </motion.button>

            <p className="text-xs text-slate-500">
              By clicking Initialize, we'll populate your database with the template's default settings.
            </p>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}