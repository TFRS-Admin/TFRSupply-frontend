import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ChevronLeft, ChevronRight, Check, Sparkles, MousePointerClick, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";

const tours = {
  buttonGallery: {
    id: "buttonGallery",
    title: "Button Gallery Tour",
    steps: [
      {
        title: "Welcome to Button Gallery! 🎨",
        content: "This is your playground for discovering and testing 20+ interactive button effects. Let's take a quick tour!",
        target: null,
        position: "center"
      },
      {
        title: "Browse Effects",
        content: "Click any effect card to preview it in real-time. Each effect has unique animations and interactions.",
        target: "[data-tour='effect-list']",
        position: "right"
      },
      {
        title: "Live Preview",
        content: "Watch your selected effect come to life here. Hover and click the buttons to see the animations!",
        target: "[data-tour='preview-area']",
        position: "left"
      },
      {
        title: "Customize Parameters",
        content: "Adjust speed and intensity sliders to fine-tune the effect to your liking.",
        target: "[data-tour='controls']",
        position: "left"
      },
      {
        title: "Get the Code",
        content: "Click 'Copy Prompt' for AI assistance or 'Copy Code' to grab the implementation directly!",
        target: "[data-tour='export-buttons']",
        position: "top"
      }
    ]
  },
  adminDashboard: {
    id: "adminDashboard",
    title: "Admin Dashboard Tour",
    steps: [
      {
        title: "Welcome, Admin! 👑",
        content: "This powerful dashboard lets you customize every aspect of your app. Let's explore what you can do!",
        target: null,
        position: "center"
      },
      {
        title: "Navigation Tabs",
        content: "Switch between Branding, Features, Monetization, and Customization sections using these tabs.",
        target: "[data-tour='admin-tabs']",
        position: "bottom"
      },
      {
        title: "Branding Controls",
        content: "Upload your logo, customize app title, and configure visual effects here.",
        target: "[data-tour='branding-section']",
        position: "right"
      },
      {
        title: "Feature Toggles",
        content: "Enable or disable specific pages and features throughout your app with simple toggles.",
        target: "[data-tour='feature-toggles']",
        position: "left"
      },
      {
        title: "Save Your Changes",
        content: "Don't forget to save! This sticky button at the bottom will save all your customizations.",
        target: "[data-tour='save-button']",
        position: "top"
      }
    ]
  }
};

export default function OnboardingTour({ tourId, onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [hasCompletedTour, setHasCompletedTour] = useState(false);
  const location = useLocation();

  const tour = tours[tourId];

  useEffect(() => {
    // Check if user has completed this tour
    const completed = localStorage.getItem(`tour_completed_${tourId}`);
    if (completed) {
      setHasCompletedTour(true);
      return;
    }

    // Small delay before showing tour
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 500);

    return () => clearTimeout(timer);
  }, [tourId]);

  const handleNext = () => {
    if (currentStep < tour.steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSkip = () => {
    setIsVisible(false);
    if (onComplete) onComplete();
  };

  const handleComplete = () => {
    localStorage.setItem(`tour_completed_${tourId}`, "true");
    setIsVisible(false);
    if (onComplete) onComplete();
  };

  const step = tour.steps[currentStep];

  if (!isVisible || hasCompletedTour) return null;

  // Center modal for steps without targets
  if (!step.target || step.position === "center") {
    return (
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-slate-900 border-2 border-violet-500 rounded-2xl p-8 max-w-lg w-full shadow-2xl shadow-violet-500/20"
          >
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-gradient-to-br from-violet-500 to-cyan-500">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">{step.title}</h3>
                  <p className="text-xs text-slate-400">Step {currentStep + 1} of {tour.steps.length}</p>
                </div>
              </div>
              <button onClick={handleSkip} className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <p className="text-slate-300 text-base leading-relaxed mb-8">{step.content}</p>

            <div className="flex items-center justify-between">
              <button
                onClick={handleSkip}
                className="text-sm text-slate-400 hover:text-white transition-colors"
              >
                Skip Tour
              </button>

              <div className="flex items-center gap-2">
                {currentStep > 0 && (
                  <Button
                    variant="outline"
                    onClick={handlePrevious}
                    className="border-slate-700 text-slate-400 hover:text-white"
                  >
                    <ChevronLeft className="w-4 h-4 mr-1 text-slate-500" /> Back
                  </Button>
                )}
                <motion.button
                  onClick={handleNext}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="relative px-6 py-2 rounded-lg font-semibold overflow-hidden group"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-violet-500 to-cyan-500" />
                  <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-violet-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <span className="relative z-10 text-white flex items-center gap-1">
                    {currentStep < tour.steps.length - 1 ? (
                      <>Next <ChevronRight className="w-4 h-4" /></>
                    ) : (
                      <>Complete <Check className="w-4 h-4" /></>
                    )}
                  </span>
                </motion.button>
              </div>
            </div>

            {/* Progress dots */}
            <div className="flex justify-center gap-2 mt-6">
              {tour.steps.map((_, idx) => (
                <div
                  key={idx}
                  className={`h-1.5 rounded-full transition-all ${
                    idx === currentStep ? "w-8 bg-violet-500" : "w-1.5 bg-slate-700"
                  }`}
                />
              ))}
            </div>
          </motion.div>
        </motion.div>
      </AnimatePresence>
    );
  }

  // Tooltip style for targeted steps
  const targetElement = document.querySelector(step.target);
  if (!targetElement) return null;

  const rect = targetElement.getBoundingClientRect();
  const tooltipPosition = {
    top: step.position === "top" ? rect.top - 20 : 
         step.position === "bottom" ? rect.bottom + 20 :
         rect.top + rect.height / 2,
    left: step.position === "left" ? rect.left - 20 :
          step.position === "right" ? rect.right + 20 :
          rect.left + rect.width / 2
  };

  return (
    <AnimatePresence>
      {/* Overlay */}
      <div className="fixed inset-0 z-[99]" onClick={handleSkip}>
        <svg className="absolute inset-0 w-full h-full">
          <defs>
            <mask id="tour-mask">
              <rect x="0" y="0" width="100%" height="100%" fill="white" />
              <rect
                x={rect.left - 8}
                y={rect.top - 8}
                width={rect.width + 16}
                height={rect.height + 16}
                rx="12"
                fill="black"
              />
            </mask>
          </defs>
          <rect x="0" y="0" width="100%" height="100%" fill="rgba(0,0,0,0.8)" mask="url(#tour-mask)" />
        </svg>

        {/* Highlight pulse */}
        <motion.div
          animate={{ opacity: [0.3, 0.6, 0.3] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute border-4 border-violet-500 rounded-xl"
          style={{
            left: rect.left - 8,
            top: rect.top - 8,
            width: rect.width + 16,
            height: rect.height + 16
          }}
        />
      </div>

      {/* Tooltip */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="fixed z-[100] bg-slate-900 border-2 border-violet-500 rounded-xl p-6 shadow-2xl max-w-sm"
        style={{
          top: tooltipPosition.top,
          left: tooltipPosition.left,
          transform: 
            step.position === "left" ? "translate(-100%, -50%)" :
            step.position === "right" ? "translate(20px, -50%)" :
            step.position === "top" ? "translate(-50%, -100%)" :
            "translate(-50%, 20px)"
        }}
      >
        <div className="flex items-start justify-between mb-4">
          <h3 className="text-lg font-bold text-white">{step.title}</h3>
          <button onClick={handleSkip} className="p-1 hover:bg-slate-800 rounded transition-colors">
            <X className="w-4 h-4 text-slate-400" />
          </button>
        </div>

        <p className="text-slate-300 text-sm mb-4">{step.content}</p>

        <div className="flex items-center justify-between">
          <span className="text-xs text-slate-500">
            {currentStep + 1} / {tour.steps.length}
          </span>

          <div className="flex items-center gap-2">
            {currentStep > 0 && (
              <Button variant="outline" size="sm" onClick={handlePrevious} className="text-slate-400 hover:text-white">
                <ChevronLeft className="w-3 h-3 text-slate-500" />
              </Button>
            )}
            <motion.button
              size="sm"
              onClick={handleNext}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-violet-500 to-cyan-500 text-white text-sm font-medium"
            >
              {currentStep < tour.steps.length - 1 ? (
                <ChevronRight className="w-3 h-3" />
              ) : (
                <Check className="w-3 h-3" />
              )}
            </motion.button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}

// Export hook to trigger tour
export function useTour(tourId) {
  const [shouldShowTour, setShouldShowTour] = useState(false);

  useEffect(() => {
    const completed = localStorage.getItem(`tour_completed_${tourId}`);
    setShouldShowTour(!completed);
  }, [tourId]);

  const resetTour = () => {
    localStorage.removeItem(`tour_completed_${tourId}`);
    setShouldShowTour(true);
  };

  return { shouldShowTour, resetTour, setShouldShowTour };
}