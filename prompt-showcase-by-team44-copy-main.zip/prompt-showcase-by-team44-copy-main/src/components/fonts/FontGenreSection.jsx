import React, { useState } from "react";
import { motion } from "framer-motion";
import { ChevronDown, Info } from "lucide-react";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";

export default function FontGenreSection({ genre, fonts, index }) {
  const [isExpanded, setIsExpanded] = useState(false); // All closed by default

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="bg-slate-900/50 border border-slate-800 rounded-xl overflow-hidden"
    >
      {/* Genre Header */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-6 hover:bg-slate-800/50 transition-colors"
      >
        <div className="flex items-center gap-4">
          <motion.div 
            whileHover={{ rotate: 360 }}
            transition={{ duration: 0.6 }}
            className={`w-12 h-12 rounded-lg bg-slate-900 border-2 ${genre.borderColor} flex items-center justify-center`}
          >
            <genre.icon className="w-6 h-6 text-white" />
          </motion.div>
          <div className="text-left">
            <h3 className="text-2xl font-bold text-white">{genre.name}</h3>
            <p className="text-sm text-slate-400">{fonts.length} fonts • {genre.description}</p>
          </div>
        </div>
        <motion.div
          animate={{ rotate: isExpanded ? 180 : 0 }}
          transition={{ duration: 0.3 }}
        >
          <ChevronDown className="w-6 h-6 text-slate-400" />
        </motion.div>
      </button>

      {/* Font Grid */}
      <motion.div
        initial={false}
        animate={{
          height: isExpanded ? "auto" : 0,
          opacity: isExpanded ? 1 : 0
        }}
        transition={{ duration: 0.3 }}
        className="overflow-hidden"
      >
        <div className="p-6 pt-0 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {fonts.map((font, fontIndex) => (
            <HoverCard key={fontIndex} openDelay={200}>
              <HoverCardTrigger asChild>
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: fontIndex * 0.02 }}
                  className="group relative p-4 rounded-lg bg-slate-800/50 border border-slate-700 hover:border-violet-500 transition-all cursor-help"
                >
                  <div style={{ fontFamily: font.family }} className="text-xl text-white mb-2 truncate">
                    {font.name}
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">{font.category}</span>
                    <Info className="w-3 h-3 text-slate-600 group-hover:text-violet-400 transition-colors" />
                  </div>
                  <div className="absolute top-2 right-2 px-2 py-1 bg-violet-500/20 rounded-full text-xs text-violet-400">
                    {font.usage}
                  </div>
                </motion.div>
              </HoverCardTrigger>
              <HoverCardContent className="w-80 bg-slate-900/95 border-slate-700 backdrop-blur-xl">
                <div className="space-y-3">
                  <div style={{ fontFamily: font.family }} className="text-2xl text-white">
                    {font.name}
                  </div>
                  <div className="text-sm text-slate-400">
                    <span className="font-semibold text-violet-400">Best for:</span> {font.bestFor}
                  </div>
                  <div className="text-xs text-slate-500 leading-relaxed">
                    {font.tip}
                  </div>
                  <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-800">
                    {font.tags.map((tag, i) => (
                      <span key={i} className="px-2 py-1 bg-slate-800 rounded text-xs text-slate-400">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </HoverCardContent>
            </HoverCard>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
}