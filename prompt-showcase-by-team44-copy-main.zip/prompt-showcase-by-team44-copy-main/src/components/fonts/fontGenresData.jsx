import { Megaphone, Gamepad2, BookOpen, Sparkles, Ghost, Palette } from "lucide-react";

export const fontGenres = [
  {
    name: "Advertising & Marketing",
    icon: Megaphone,
    gradient: "from-orange-500 to-red-600",
    borderColor: "border-orange-500",
    description: "Bold, attention-grabbing fonts for ads and promotions",
    fonts: Array(40).fill(null).map((_, i) => ({
      name: `Impact Pro ${i + 1}`,
      family: i % 5 === 0 ? "'Arial Black', sans-serif" : i % 5 === 1 ? "'Helvetica', sans-serif" : i % 5 === 2 ? "'Bebas Neue', sans-serif" : i % 5 === 3 ? "'Oswald', sans-serif" : "'Anton', sans-serif",
      category: ["Display", "Sans-serif", "Bold", "Condensed", "Wide"][i % 5],
      usage: `${60 + i}%`,
      bestFor: "Headlines, banners, call-to-action buttons, promotional materials",
      tip: "Bold fonts grab attention quickly. Use for short, impactful messages. Pair with simpler body fonts for readability.",
      tags: ["High Impact", "Conversion", "Headlines"]
    }))
  },
  {
    name: "Gaming & Esports",
    icon: Gamepad2,
    gradient: "from-purple-500 to-pink-600",
    borderColor: "border-green-500",
    description: "Futuristic, edgy fonts for gaming interfaces",
    fonts: Array(40).fill(null).map((_, i) => ({
      name: `Cyber Game ${i + 1}`,
      family: i % 5 === 0 ? "'Orbitron', sans-serif" : i % 5 === 1 ? "'Exo 2', sans-serif" : i % 5 === 2 ? "'Press Start 2P', cursive" : i % 5 === 3 ? "'Rajdhani', sans-serif" : "'Audiowide', cursive",
      category: ["Futuristic", "Retro", "Tech", "Bold", "Angular"][i % 5],
      usage: `${55 + i}%`,
      bestFor: "Game UI, leaderboards, HUD elements, gaming websites",
      tip: "Gaming fonts should be readable at small sizes for UI elements. Balance style with clarity for long play sessions.",
      tags: ["Gaming", "UI", "Esports"]
    }))
  },
  {
    name: "Classic & Professional",
    icon: BookOpen,
    gradient: "from-slate-500 to-gray-700",
    borderColor: "border-blue-500",
    description: "Timeless, elegant fonts for corporate and formal use",
    fonts: Array(40).fill(null).map((_, i) => ({
      name: `Corporate ${i + 1}`,
      family: i % 5 === 0 ? "'Georgia', serif" : i % 5 === 1 ? "'Times New Roman', serif" : i % 5 === 2 ? "'Lato', sans-serif" : i % 5 === 3 ? "'Roboto', sans-serif" : "'Open Sans', sans-serif",
      category: ["Serif", "Sans-serif", "Modern", "Traditional", "Neutral"][i % 5],
      usage: `${70 + i}%`,
      bestFor: "Corporate sites, documents, presentations, professional apps",
      tip: "Classic fonts build trust and credibility. Use serif for printed materials, sans-serif for digital screens.",
      tags: ["Professional", "Corporate", "Trusted"]
    }))
  },
  {
    name: "Futuristic & Tech",
    icon: Sparkles,
    gradient: "from-cyan-500 to-blue-600",
    borderColor: "border-cyan-500",
    description: "Modern, sci-fi inspired fonts for tech products",
    fonts: Array(40).fill(null).map((_, i) => ({
      name: `Future Tech ${i + 1}`,
      family: i % 5 === 0 ? "'Space Mono', monospace" : i % 5 === 1 ? "'IBM Plex Mono', monospace" : i % 5 === 2 ? "'Orbitron', sans-serif" : i % 5 === 3 ? "'Exo 2', sans-serif" : "'Audiowide', cursive",
      category: ["Monospace", "Geometric", "Sharp", "Tech", "Minimal"][i % 5],
      usage: `${50 + i}%`,
      bestFor: "Tech startups, SaaS products, AI tools, developer tools",
      tip: "Futuristic fonts work best for tech-savvy audiences. Monospace fonts suggest precision and code.",
      tags: ["Tech", "Modern", "Innovation"]
    }))
  },
  {
    name: "Horror & Gothic",
    icon: Ghost,
    gradient: "from-red-600 to-black",
    borderColor: "border-red-500",
    description: "Dark, eerie fonts for horror and thriller themes",
    fonts: Array(40).fill(null).map((_, i) => ({
      name: `Dark Gothic ${i + 1}`,
      family: i % 5 === 0 ? "'Creepster', cursive" : i % 5 === 1 ? "'Nosifer', cursive" : i % 5 === 2 ? "'Eater', cursive" : i % 5 === 3 ? "'Butcherman', cursive" : "'Special Elite', cursive",
      category: ["Creepy", "Gothic", "Distressed", "Blood", "Vintage"][i % 5],
      usage: `${45 + i}%`,
      bestFor: "Horror games, Halloween sites, thriller books, dark themes",
      tip: "Horror fonts set the mood instantly. Use sparingly for readability. Perfect for titles, not body text.",
      tags: ["Horror", "Dark", "Atmospheric"]
    }))
  },
  {
    name: "Creative & Artistic",
    icon: Palette,
    gradient: "from-pink-500 to-purple-600",
    borderColor: "border-pink-500",
    description: "Unique, expressive fonts for creative projects",
    fonts: Array(40).fill(null).map((_, i) => ({
      name: `Creative Art ${i + 1}`,
      family: i % 5 === 0 ? "'Pacifico', cursive" : i % 5 === 1 ? "'Dancing Script', cursive" : i % 5 === 2 ? "'Satisfy', cursive" : i % 5 === 3 ? "'Caveat', cursive" : "'Indie Flower', cursive",
      category: ["Handwritten", "Script", "Playful", "Organic", "Casual"][i % 5],
      usage: `${50 + i}%`,
      bestFor: "Portfolios, art sites, creative agencies, personal brands",
      tip: "Creative fonts show personality. Use for brands targeting artists, designers, or creative audiences.",
      tags: ["Creative", "Artistic", "Unique"]
    }))
  }
];