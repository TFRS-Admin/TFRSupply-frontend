import React from "react";
import { motion } from "framer-motion";
import { Lightbulb } from "lucide-react";

const fontTips = [
  {
    title: "Pairing Rule",
    tip: "Pair a bold display font with a simple sans-serif for body text. Contrast is key!"
  },
  {
    title: "Hierarchy",
    tip: "Use 2-3 fonts max. Assign roles: headlines, body, accents. Don't mix too many styles."
  },
  {
    title: "Readability",
    tip: "Body text should be 16px+ for web. Line height 1.5-1.8 improves reading comfort."
  },
  {
    title: "Context Matters",
    tip: "Gaming fonts for games, serif for elegance, sans-serif for modern/tech. Match the vibe!"
  },
  {
    title: "Test Sizes",
    tip: "A font that looks great at 48px might be unreadable at 14px. Always test at target sizes."
  }
];

export default function FontTipsSection() {
  return (
    <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 h-full">
      <div className="flex items-center gap-2 mb-4">
        <Lightbulb className="w-6 h-6 text-yellow-400" />
        <h3 className="text-xl font-bold text-white">Font Tips for Beginners</h3>
      </div>
      
      <div className="space-y-4">
        {fontTips.map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-3 bg-slate-800/50 rounded-lg border border-slate-700 hover:border-violet-500 transition-colors"
          >
            <h4 className="text-sm font-semibold text-violet-400 mb-1">{item.title}</h4>
            <p className="text-xs text-slate-300">{item.tip}</p>
          </motion.div>
        ))}
      </div>
      
      <div className="mt-4 p-3 bg-violet-500/10 border border-violet-500/20 rounded-lg">
        <p className="text-xs text-purple-300">
          <span className="font-semibold">Pro Tip:</span> When in doubt, use system fonts like Roboto, Open Sans, or Inter for body text. They're optimized for screen reading.
        </p>
      </div>
    </div>
  );
}