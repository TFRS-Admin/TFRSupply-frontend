import React, { useState } from "react";
import { motion } from "framer-motion";
import { Sparkles, Save, Trash2, Wand2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

const fontOptions = [
  { name: "Arial Black", family: "'Arial Black', sans-serif", category: "Bold" },
  { name: "Georgia", family: "'Georgia', serif", category: "Serif" },
  { name: "Orbitron", family: "'Orbitron', sans-serif", category: "Tech" },
  { name: "Pacifico", family: "'Pacifico', cursive", category: "Creative" },
  { name: "Roboto", family: "'Roboto', sans-serif", category: "Modern" },
  { name: "Creepster", family: "'Creepster', cursive", category: "Horror" },
];

export default function FontPairingSystem() {
  const [primaryFont, setPrimaryFont] = useState(fontOptions[0]);
  const [secondaryFont, setSecondaryFont] = useState(fontOptions[1]);
  const [tertiaryFont, setTertiaryFont] = useState(fontOptions[4]);
  const [pairingName, setPairingName] = useState("");
  const [mood, setMood] = useState("");
  const [aesthetic, setAesthetic] = useState("");
  const [targetAudience, setTargetAudience] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const queryClient = useQueryClient();

  const { data: savedPairings = [] } = useQuery({
    queryKey: ['fontPairings'],
    queryFn: async () => {
      try {
        const user = await base44.auth.me();
        if (!user) return JSON.parse(localStorage.getItem('fontPairings') || '[]');
        // Would fetch from entity in production
        return JSON.parse(localStorage.getItem('fontPairings') || '[]');
      } catch {
        return JSON.parse(localStorage.getItem('fontPairings') || '[]');
      }
    }
  });

  const generateAISuggestions = () => {
    setIsGenerating(true);
    
    // Sophisticated AI pairing logic based on mood, aesthetic, and target audience
    setTimeout(() => {
      const moodMappings = {
        "energetic": ["Bold", "Tech"],
        "calm": ["Serif", "Modern"],
        "playful": ["Creative", "Bold"],
        "professional": ["Serif", "Modern"],
        "dark": ["Horror", "Bold"],
        "elegant": ["Serif", "Creative"]
      };

      const aestheticMappings = {
        "minimalist": ["Modern", "Serif"],
        "playful": ["Creative", "Bold"],
        "elegant": ["Serif", "Creative"],
        "modern": ["Tech", "Modern"],
        "vintage": ["Serif", "Creative"],
        "futuristic": ["Tech", "Bold"]
      };

      const audienceMappings = {
        "corporate": ["Serif", "Modern"],
        "youth": ["Bold", "Creative"],
        "luxury": ["Serif", "Creative"],
        "tech": ["Tech", "Modern"],
        "creative": ["Creative", "Bold"],
        "general": ["Modern", "Serif"]
      };

      // Combine all inputs to determine best pairing
      let preferredCategories = [];
      if (mood && moodMappings[mood.toLowerCase()]) {
        preferredCategories.push(...moodMappings[mood.toLowerCase()]);
      }
      if (aesthetic && aestheticMappings[aesthetic.toLowerCase()]) {
        preferredCategories.push(...aestheticMappings[aesthetic.toLowerCase()]);
      }
      if (targetAudience && audienceMappings[targetAudience.toLowerCase()]) {
        preferredCategories.push(...audienceMappings[targetAudience.toLowerCase()]);
      }

      // If no inputs, use default complementary logic
      if (preferredCategories.length === 0) {
        const complementary = {
          "Bold": fontOptions.find(f => f.category === "Modern" || f.category === "Serif"),
          "Serif": fontOptions.find(f => f.category === "Modern"),
          "Tech": fontOptions.find(f => f.category === "Bold"),
          "Creative": fontOptions.find(f => f.category === "Serif"),
          "Modern": fontOptions.find(f => f.category === "Serif"),
          "Horror": fontOptions.find(f => f.category === "Bold")
        };
        const suggested = complementary[primaryFont.category] || fontOptions[1];
        setSecondaryFont(suggested);
        setTertiaryFont(fontOptions.find(f => f.category === "Modern") || fontOptions[4]);
      } else {
        // Find fonts matching preferred categories
        const primaryCat = preferredCategories[0];
        const secondaryCat = preferredCategories[1] || preferredCategories[0];
        
        setPrimaryFont(fontOptions.find(f => f.category === primaryCat) || fontOptions[0]);
        setSecondaryFont(fontOptions.find(f => f.category === secondaryCat && f.category !== primaryCat) || fontOptions[1]);
        setTertiaryFont(fontOptions.find(f => f.category === "Modern") || fontOptions[4]);
      }

      setIsGenerating(false);
    }, 1000);
  };

  const savePairing = () => {
    if (!pairingName.trim()) {
      alert("Please enter a name for this pairing");
      return;
    }

    const newPairing = {
      id: Date.now(),
      name: pairingName,
      primary: primaryFont,
      secondary: secondaryFont,
      tertiary: tertiaryFont,
      created: new Date().toISOString()
    };

    const updated = [...savedPairings, newPairing];
    localStorage.setItem('fontPairings', JSON.stringify(updated));
    queryClient.invalidateQueries(['fontPairings']);
    setPairingName("");
    alert("Font pairing saved!");
  };

  const deletePairing = (id) => {
    const updated = savedPairings.filter(p => p.id !== id);
    localStorage.setItem('fontPairings', JSON.stringify(updated));
    queryClient.invalidateQueries(['fontPairings']);
  };

  const loadPairing = (pairing) => {
    setPrimaryFont(pairing.primary);
    setSecondaryFont(pairing.secondary);
    setTertiaryFont(pairing.tertiary);
  };

  return (
    <div className="space-y-6">
      {/* Font Pairing Builder */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-white">Font Pairing System</h3>
        </div>

        {/* AI Parameters */}
        <div className="mb-6 p-4 bg-slate-800/50 border border-slate-700 rounded-lg space-y-3">
          <h4 className="text-sm font-semibold text-violet-400 mb-3">AI Pairing Parameters</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-slate-400 mb-1 block">Mood</label>
              <Select value={mood} onValueChange={setMood}>
                <SelectTrigger className="bg-slate-900 border-slate-700">
                  <SelectValue placeholder="Select mood..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="energetic">Energetic</SelectItem>
                  <SelectItem value="calm">Calm</SelectItem>
                  <SelectItem value="playful">Playful</SelectItem>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="dark">Dark</SelectItem>
                  <SelectItem value="elegant">Elegant</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-slate-400 mb-1 block">Aesthetic</label>
              <Select value={aesthetic} onValueChange={setAesthetic}>
                <SelectTrigger className="bg-slate-900 border-slate-700">
                  <SelectValue placeholder="Select aesthetic..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="minimalist">Minimalist</SelectItem>
                  <SelectItem value="playful">Playful</SelectItem>
                  <SelectItem value="elegant">Elegant</SelectItem>
                  <SelectItem value="modern">Modern</SelectItem>
                  <SelectItem value="vintage">Vintage</SelectItem>
                  <SelectItem value="futuristic">Futuristic</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-slate-400 mb-1 block">Target Audience</label>
              <Select value={targetAudience} onValueChange={setTargetAudience}>
                <SelectTrigger className="bg-slate-900 border-slate-700">
                  <SelectValue placeholder="Select audience..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="corporate">Corporate</SelectItem>
                  <SelectItem value="youth">Youth</SelectItem>
                  <SelectItem value="luxury">Luxury</SelectItem>
                  <SelectItem value="tech">Tech</SelectItem>
                  <SelectItem value="creative">Creative</SelectItem>
                  <SelectItem value="general">General</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button 
            onClick={generateAISuggestions} 
            disabled={isGenerating}
            className="w-full bg-violet-600 hover:bg-violet-700"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Wand2 className="w-4 h-4 mr-2" />
                Generate AI Suggestions
              </>
            )}
          </Button>
        </div>

        {/* Font Selectors */}
        <div className="grid gap-4 mb-6">
          {/* Primary Font */}
          <div>
            <label className="text-sm text-slate-400 mb-2 block">Primary (Headlines)</label>
            <select
              value={primaryFont.name}
              onChange={(e) => setPrimaryFont(fontOptions.find(f => f.name === e.target.value))}
              className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
            >
              {fontOptions.map(font => (
                <option key={font.name} value={font.name}>{font.name} ({font.category})</option>
              ))}
            </select>
            <div style={{ fontFamily: primaryFont.family }} className="text-3xl text-white mt-2">
              Headline Example
            </div>
          </div>

          {/* Secondary Font */}
          <div>
            <label className="text-sm text-slate-400 mb-2 block">Secondary (Body Text)</label>
            <select
              value={secondaryFont.name}
              onChange={(e) => setSecondaryFont(fontOptions.find(f => f.name === e.target.value))}
              className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
            >
              {fontOptions.map(font => (
                <option key={font.name} value={font.name}>{font.name} ({font.category})</option>
              ))}
            </select>
            <div style={{ fontFamily: secondaryFont.family }} className="text-base text-slate-300 mt-2">
              Body text example for longer content and paragraphs.
            </div>
          </div>

          {/* Tertiary Font */}
          <div>
            <label className="text-sm text-slate-400 mb-2 block">Tertiary (Captions/Accents)</label>
            <select
              value={tertiaryFont.name}
              onChange={(e) => setTertiaryFont(fontOptions.find(f => f.name === e.target.value))}
              className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
            >
              {fontOptions.map(font => (
                <option key={font.name} value={font.name}>{font.name} ({font.category})</option>
              ))}
            </select>
            <div style={{ fontFamily: tertiaryFont.family }} className="text-sm text-slate-400 mt-2">
              Caption or accent text
            </div>
          </div>
        </div>

        {/* Save Pairing */}
        <div className="flex gap-2">
          <input
            type="text"
            value={pairingName}
            onChange={(e) => setPairingName(e.target.value)}
            placeholder="Name this pairing..."
            className="flex-1 px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder:text-slate-500"
          />
          <Button onClick={savePairing} className="bg-emerald-600 hover:bg-emerald-700">
            <Save className="w-4 h-4 mr-2" />
            Save
          </Button>
        </div>
      </div>

      {/* Saved Pairings */}
      {savedPairings.length > 0 && (
        <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
          <h4 className="text-lg font-bold text-white mb-4">Saved Pairings</h4>
          <div className="space-y-3">
            {savedPairings.map(pairing => (
              <motion.div
                key={pairing.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg border border-slate-700 hover:border-violet-500 transition-colors"
              >
                <div className="flex-1 cursor-pointer" onClick={() => loadPairing(pairing)}>
                  <h5 className="text-white font-semibold mb-1">{pairing.name}</h5>
                  <div className="flex gap-4 text-xs text-slate-400">
                    <span style={{ fontFamily: pairing.primary.family }}>Aa</span>
                    <span style={{ fontFamily: pairing.secondary.family }}>Aa</span>
                    <span style={{ fontFamily: pairing.tertiary.family }}>Aa</span>
                  </div>
                </div>
                <Button
                  onClick={() => deletePairing(pairing.id)}
                  size="sm"
                  variant="ghost"
                  className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}