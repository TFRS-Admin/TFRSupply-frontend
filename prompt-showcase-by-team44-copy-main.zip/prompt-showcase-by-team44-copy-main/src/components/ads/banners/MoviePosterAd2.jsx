import React from "react";
import { motion } from "framer-motion";
import { X, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function MoviePosterAd2({ config = {}, onClose }) {
  const {
    title = "TEAM44",
    subtitle = "BEYOND THE CODE",
    tagline = "IN A WORLD WHERE UI MATTERS...",
    originalPrice = "$199",
    salePrice = "$59",
    ctaText = "LAUNCH NOW",
    ctaUrl = "https://base44.io",
    showPrice = true,
    priceAltText = ""
  } = config;

  const bgGradient = config.gradientColors 
    ? `linear-gradient(180deg, ${config.gradientColors[0]} 0%, ${config.gradientColors[1]} 50%, ${config.gradientColors[2]} 100%)`
    : "linear-gradient(180deg, #000020 0%, #000040 30%, #000080 70%, #0000aa 100%)";

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="relative overflow-hidden rounded-2xl"
      style={{
        background: bgGradient,
        minHeight: config.height || "350px",
        maxWidth: config.width || "100%",
        margin: "0 auto",
        fontFamily: config.fontFamily || "Arial Black, sans-serif",
        animation: config.animation === 'pulse' ? 'bannerPulse 2s ease-in-out infinite' :
                   config.animation === 'bounce' ? 'bannerBounce 1s ease-in-out infinite' :
                   config.animation === 'fadeIn' ? 'bannerFadeIn 1s ease-in' :
                   config.animation === 'scaleIn' ? 'bannerScaleIn 0.5s ease-out' :
                   config.animation === 'slideUp' ? 'bannerSlideUp 0.5s ease-out' :
                   config.animation === 'glow' ? 'bannerGlow 2s ease-in-out infinite' : 'none'
      }}
    >
      <style>{`
        @keyframes bannerPulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.02); } }
        @keyframes bannerBounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
        @keyframes bannerFadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes bannerScaleIn { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        @keyframes bannerSlideUp { from { transform: translateY(50px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        @keyframes bannerGlow { 0%, 100% { box-shadow: 0 0 30px rgba(0, 255, 255, 0.5); } 50% { box-shadow: 0 0 60px rgba(0, 255, 255, 0.8); } }
      `}</style>
      <button onClick={onClose} className="absolute top-3 right-3 z-20 p-1.5 rounded-full bg-white/10 text-white hover:bg-white/20"><X className="w-4 h-4" /></button>

      {/* Stars background */}
      <div className="absolute inset-0">
        {[...Array(50)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full"
            style={{ left: `${Math.random() * 100}%`, top: `${Math.random() * 100}%` }}
            animate={{ opacity: [0.2, 1, 0.2], scale: [1, 1.5, 1] }}
            transition={{ duration: 2 + Math.random() * 2, repeat: Infinity, delay: Math.random() * 2 }}
          />
        ))}
      </div>

      {/* Planet/sphere */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2">
        <motion.div
          animate={{ boxShadow: ["0 0 60px #00ffff", "0 0 100px #00ffff", "0 0 60px #00ffff"] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-64 h-64 rounded-full bg-gradient-to-b from-cyan-400 to-blue-900"
        />
      </div>

      <div className="relative z-10 p-8 text-center">
        <p className="text-cyan-400 text-xs tracking-[0.5em] mb-2">{tagline}</p>
        
        <motion.h1
          animate={{ textShadow: ["0 0 30px #00ffff", "0 0 50px #00ffff", "0 0 30px #00ffff"] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="text-6xl md:text-8xl font-black text-white mb-2"
          style={{ fontFamily: "Arial Black, sans-serif" }}
        >
          {title}
        </motion.h1>

        <p className="text-2xl text-cyan-300 mb-6 tracking-widest">{subtitle}</p>

        {showPrice && originalPrice && salePrice ? (
          <div className="flex items-center justify-center gap-4 mb-6">
            <Sparkles className="w-5 h-5 text-cyan-400" />
            <div>
              <span className="text-lg text-gray-500 line-through">{originalPrice}</span>
              <span className="text-3xl font-black text-cyan-400 ml-2">{salePrice}</span>
            </div>
            <Sparkles className="w-5 h-5 text-cyan-400" />
          </div>
        ) : priceAltText ? (
        <div className="flex items-center justify-center gap-4 mb-6">
          <Sparkles className="w-5 h-5 text-cyan-400" />
          <span className="text-3xl font-black text-white">{priceAltText}</span>
          <Sparkles className="w-5 h-5 text-cyan-400" />
        </div>
        ) : null}

        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          <Button onClick={() => window.open(ctaUrl, "_blank")} className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-bold px-8 py-4 rounded-full">
            {ctaText}
          </Button>
        </motion.div>
      </div>

      <div className="absolute top-4 left-4 bg-cyan-500 text-black font-black text-xs px-3 py-1 rounded">TEAM44</div>
    </motion.div>
  );
}