import React from "react";
import { motion } from "framer-motion";
import { X, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function NeonCyberAd({ config = {}, onClose }) {
  const {
    title = "TEAM44",
    subtitle = "TEMPLATES",
    tagline = "ENTER THE GRID",
    originalPrice = "$179",
    salePrice = "$49",
    ctaText = "JACK IN",
    ctaUrl = "https://base44.io"
  } = config;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="relative overflow-hidden rounded-2xl bg-black"
      style={{ minHeight: "300px" }}
    >
      <button onClick={onClose} className="absolute top-3 right-3 z-20 p-1.5 rounded-full bg-purple-900/50 text-white hover:bg-purple-900"><X className="w-4 h-4" /></button>

      {/* Grid background */}
      <div className="absolute inset-0" style={{
        backgroundImage: "linear-gradient(#ff00ff22 1px, transparent 1px), linear-gradient(90deg, #ff00ff22 1px, transparent 1px)",
        backgroundSize: "40px 40px",
        perspective: "500px",
        transform: "rotateX(60deg)",
        transformOrigin: "center 120%"
      }} />

      {/* Neon glow bars */}
      <motion.div
        animate={{ x: ["-100%", "200%"] }}
        transition={{ duration: 3, repeat: Infinity }}
        className="absolute top-1/3 w-full h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent"
        style={{ boxShadow: "0 0 20px #00ffff, 0 0 40px #00ffff" }}
      />
      <motion.div
        animate={{ x: ["200%", "-100%"] }}
        transition={{ duration: 4, repeat: Infinity }}
        className="absolute top-2/3 w-full h-1 bg-gradient-to-r from-transparent via-pink-400 to-transparent"
        style={{ boxShadow: "0 0 20px #ff00ff, 0 0 40px #ff00ff" }}
      />

      <div className="relative z-10 p-8 text-center">
        <p className="text-cyan-400 text-xs tracking-[0.5em] mb-2">{tagline}</p>
        
        <motion.h1
          animate={{ 
            textShadow: [
              "0 0 10px #ff00ff, 0 0 20px #ff00ff, 0 0 40px #ff00ff",
              "0 0 20px #00ffff, 0 0 40px #00ffff, 0 0 60px #00ffff",
              "0 0 10px #ff00ff, 0 0 20px #ff00ff, 0 0 40px #ff00ff"
            ]
          }}
          transition={{ duration: 2, repeat: Infinity }}
          className="text-5xl md:text-7xl font-black text-white mb-0"
          style={{ fontFamily: "Arial Black, sans-serif" }}
        >
          {title}
        </motion.h1>

        <motion.p
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-cyan-500 mb-4"
        >
          {subtitle}
        </motion.p>

        <div className="flex items-center justify-center gap-4 mb-4">
          <Zap className="w-5 h-5 text-yellow-400" />
          <span className="text-gray-500 line-through">{originalPrice}</span>
          <motion.span
            animate={{ color: ["#ffffff", "#00ffff", "#ffffff"] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="text-3xl font-black"
          >
            {salePrice}
          </motion.span>
          <Zap className="w-5 h-5 text-yellow-400" />
        </div>

        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          <Button 
            onClick={() => window.open(ctaUrl, "_blank")} 
            className="bg-transparent border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black font-bold px-8 py-4 rounded-none"
            style={{ boxShadow: "0 0 20px #00ffff" }}
          >
            {ctaText}
          </Button>
        </motion.div>
      </div>

      <div className="absolute top-4 left-4 border border-pink-500 text-pink-400 font-black text-xs px-3 py-1" style={{ boxShadow: "0 0 10px #ff00ff" }}>TEAM44</div>
    </motion.div>
  );
}