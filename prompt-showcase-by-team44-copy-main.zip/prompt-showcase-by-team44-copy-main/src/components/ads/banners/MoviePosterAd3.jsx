import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { X, Skull } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function MoviePosterAd3({ config = {}, onClose }) {
  const [isGlitching, setIsGlitching] = useState(false);

  useEffect(() => {
    const triggerGlitch = () => {
      setIsGlitching(true);
      setTimeout(() => setIsGlitching(false), 300);
    };

    // Random intervals: 7s, 12s, 18s
    const intervals = [7000, 12000, 18000];
    const randomInterval = intervals[Math.floor(Math.random() * intervals.length)];

    const timer = setInterval(triggerGlitch, randomInterval);
    return () => clearInterval(timer);
  }, []);
  const {
    title = "TEAM44",
    subtitle = "THE TEMPLATE NIGHTMARE",
    tagline = "YOUR OLD CODE... WILL HAUNT YOU",
    originalPrice = "$129",
    salePrice = "$29",
    ctaText = "ESCAPE NOW",
    ctaUrl = "https://base44.io",
    showPrice = true
  } = config;

  const bgGradient = config.gradientColors 
    ? `linear-gradient(180deg, ${config.gradientColors[0]} 0%, ${config.gradientColors[1]} 50%, ${config.gradientColors[2]} 100%)`
    : "linear-gradient(180deg, #0a0a0a 0%, #1a0a1a 50%, #2a0a2a 100%)";

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="relative overflow-hidden rounded-2xl"
      style={{
        background: bgGradient,
        minHeight: config.height || "350px",
        maxWidth: config.width || "100%",
        margin: "0 auto",
        fontFamily: config.fontFamily || "Impact, sans-serif",
        animation: config.animation === 'pulse' ? 'bannerPulse 2s ease-in-out infinite' :
                   config.animation === 'bounce' ? 'bannerBounce 1s ease-in-out infinite' :
                   config.animation === 'fadeIn' ? 'bannerFadeIn 1s ease-in' :
                   config.animation === 'scaleIn' ? 'bannerScaleIn 0.5s ease-out' :
                   config.animation === 'slideUp' ? 'bannerSlideUp 0.5s ease-out' :
                   config.animation === 'glow' ? 'bannerGlow 2s ease-in-out infinite' : 'none'
      }}
    >
      <style>{`
        @keyframes bannerPulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.02); } }
        @keyframes bannerBounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
        @keyframes bannerFadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes bannerScaleIn { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        @keyframes bannerSlideUp { from { transform: translateY(50px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        @keyframes bannerGlow { 0%, 100% { box-shadow: 0 0 30px rgba(255, 0, 0, 0.5); } 50% { box-shadow: 0 0 60px rgba(255, 0, 0, 0.8); } }
      `}</style>
      <button onClick={onClose} className="absolute top-3 right-3 z-20 p-1.5 rounded-full bg-red-900/50 text-white hover:bg-red-900"><X className="w-4 h-4" /></button>

      {/* Fog effect */}
      <div className="absolute inset-0 opacity-30">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-full h-20 bg-gradient-to-r from-transparent via-purple-900 to-transparent"
            style={{ top: `${20 + i * 15}%` }}
            animate={{ x: ["-100%", "100%"], opacity: [0.1, 0.3, 0.1] }}
            transition={{ duration: 8 + i * 2, repeat: Infinity }}
          />
        ))}
      </div>

      {/* Dripping blood effect */}
      <div className="absolute top-0 left-0 right-0">
        {[...Array(10)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute top-0 w-2 bg-red-800 rounded-b-full"
            style={{ left: `${10 + i * 10}%`, height: 20 + Math.random() * 40 }}
            animate={{ height: [20, 40 + Math.random() * 30, 20] }}
            transition={{ duration: 3 + Math.random() * 2, repeat: Infinity, delay: Math.random() * 2 }}
          />
        ))}
      </div>

      <div className="relative z-10 p-8 text-center">
        <p className="text-red-500 text-xs tracking-[0.3em] mb-4 font-bold">{tagline}</p>
        
        <motion.h1
          animate={{ 
            textShadow: ["0 0 10px #ff0000", "0 0 30px #ff0000", "0 0 10px #ff0000"],
            scale: [1, 1.02, 1]
          }}
          transition={{ duration: 2, repeat: Infinity }}
          className="text-5xl md:text-7xl font-black text-red-600 mb-2"
          style={{ fontFamily: "Impact, sans-serif" }}
        >
          {title}
        </motion.h1>

        <p className="text-xl text-purple-400 mb-6 italic">{subtitle}</p>

        <div className="flex justify-center gap-2 mb-4">
          {[...Array(3)].map((_, i) => (
            <motion.div key={i} animate={{ rotate: [0, 10, -10, 0] }} transition={{ duration: 0.5, repeat: Infinity, delay: i * 0.2 }}>
              <Skull className="w-6 h-6 text-gray-600" />
            </motion.div>
          ))}
        </div>

        {showPrice && originalPrice && salePrice ? (
          <div className="mb-6">
            <span className="text-lg text-gray-600 line-through">{originalPrice}</span>
            <motion.span 
              animate={{ color: ["#ff0000", "#aa0000", "#ff0000"] }}
              transition={{ duration: 1, repeat: Infinity }}
              className="text-3xl font-black ml-2"
            >
              {salePrice}
            </motion.span>
          </div>
        ) : config.priceAltText ? (
          <div className="mb-6">
            <motion.span 
              animate={{ color: ["#ff0000", "#aa0000", "#ff0000"] }}
              transition={{ duration: 1, repeat: Infinity }}
              className="text-3xl font-black"
            >
              {config.priceAltText}
            </motion.span>
          </div>
        ) : null}

        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          <Button onClick={() => window.open(ctaUrl, "_blank")} className="bg-gradient-to-r from-red-800 to-purple-900 hover:from-red-900 hover:to-purple-950 text-white font-bold px-8 py-4 rounded-lg border border-red-600">
            {ctaText}
          </Button>
        </motion.div>

        <p className={`text-gray-600 text-xs mt-4 ${isGlitching ? 'glitch-active' : ''}`}>
          RATED R FOR RADICAL CODE @ Base44!
        </p>
        <style>{`
          @keyframes text-glitch {
            0%, 100% { text-shadow: none; filter: none; transform: translate(0); }
            20% { text-shadow: -2px 0 #06b6d4, 2px 0 #8b5cf6; filter: hue-rotate(10deg); transform: translate(-1px, 1px); }
            40% { text-shadow: 2px 0 #06b6d4, -2px 0 #8b5cf6; filter: hue-rotate(-10deg); transform: translate(1px, -1px); }
            60% { text-shadow: -1px 0 #8b5cf6, 1px 0 #06b6d4; filter: hue-rotate(5deg); transform: translate(-1px, 0); }
            80% { text-shadow: 1px 0 #8b5cf6, -1px 0 #06b6d4; filter: hue-rotate(-5deg); transform: translate(1px, 1px); }
          }
          .glitch-active {
            animation: text-glitch 0.3s ease-in-out;
          }
        `}</style>
      </div>

      <div className="absolute top-4 left-4 bg-red-900 text-red-300 font-black text-xs px-3 py-1 rounded border border-red-700">HORROR</div>
    </motion.div>
  );
}