import React from "react";
import { motion } from "framer-motion";
import { X, Flame, Star } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function MoviePosterAd1({ config = {}, onClose }) {
  const {
    title = "TEAM44 TEMPLATES",
    tagline = "THIS SUMMER... CODE LIKE NEVER BEFORE",
    originalPrice = "$149",
    salePrice = "$39",
    ctaText = "GET IT NOW",
    ctaUrl = "https://base44.io",
    quote = '"THE BEST UI TOOLKIT OF THE DECADE!" - Web Dev Weekly',
    showPrice = true,
    priceAltText = ""
  } = config;

  const bgGradient = config.gradientColors 
    ? `linear-gradient(180deg, ${config.gradientColors[0]} 0%, ${config.gradientColors[1]} 50%, ${config.gradientColors[2]} 100%)`
    : "linear-gradient(180deg, #1a0a0a 0%, #4a1c1c 50%, #ff4500 100%)";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden rounded-2xl"
      style={{
        background: bgGradient,
        minHeight: config.height || "350px",
        maxWidth: config.width || "100%",
        margin: "0 auto",
        fontFamily: config.fontFamily || "Impact, sans-serif",
        animation: config.animation === 'pulse' ? 'bannerPulse 2s ease-in-out infinite' :
                   config.animation === 'bounce' ? 'bannerBounce 1s ease-in-out infinite' :
                   config.animation === 'fadeIn' ? 'bannerFadeIn 1s ease-in' :
                   config.animation === 'scaleIn' ? 'bannerScaleIn 0.5s ease-out' :
                   config.animation === 'slideUp' ? 'bannerSlideUp 0.5s ease-out' :
                   config.animation === 'glow' ? 'bannerGlow 2s ease-in-out infinite' : 'none'
      }}
    >
      <style>{`
        @keyframes bannerPulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.02); } }
        @keyframes bannerBounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
        @keyframes bannerFadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes bannerScaleIn { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        @keyframes bannerSlideUp { from { transform: translateY(50px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        @keyframes bannerGlow { 0%, 100% { box-shadow: 0 0 30px rgba(255, 69, 0, 0.5); } 50% { box-shadow: 0 0 60px rgba(255, 69, 0, 0.8); } }
      `}</style>
      <button onClick={onClose} className="absolute top-3 right-3 z-20 p-1.5 rounded-full bg-black/50 text-white hover:bg-black/80"><X className="w-4 h-4" /></button>

      {/* Fire/explosion effect at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-32">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute bottom-0"
            style={{ left: `${i * 5}%`, width: "10%" }}
            animate={{ y: [0, -30, 0], opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 0.5 + Math.random() * 0.5, repeat: Infinity, delay: Math.random() * 0.5 }}
          >
            <Flame className="w-8 h-8 text-orange-500" />
          </motion.div>
        ))}
      </div>

      <div className="relative z-10 p-8 text-center">
        <p className="text-orange-400 text-sm tracking-[0.3em] mb-2 font-bold">{tagline}</p>
        
        <motion.h1
          animate={{ textShadow: ["0 0 20px #ff4500", "0 0 40px #ff4500", "0 0 20px #ff4500"] }}
          transition={{ duration: 1, repeat: Infinity }}
          className="text-5xl md:text-7xl font-black text-white mb-4"
          style={{ fontFamily: "Impact, sans-serif", letterSpacing: "-2px" }}
        >
          {title}
        </motion.h1>

        <div className="flex justify-center gap-1 mb-4">
          {[...Array(5)].map((_, i) => <Star key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />)}
        </div>

        <p className="text-gray-300 italic text-sm mb-6 max-w-md mx-auto">{quote}</p>

        {showPrice && originalPrice && salePrice ? (
          <div className="mb-4">
            <span className="text-xl text-gray-500 line-through">{originalPrice}</span>
            <span className="text-4xl font-black text-yellow-400 ml-3">{salePrice}</span>
          </div>
        ) : priceAltText ? (
          <div className="mb-4">
            <span className="text-3xl font-black text-yellow-400">{priceAltText}</span>
          </div>
        ) : null}

        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          <Button onClick={() => window.open(ctaUrl, "_blank")} className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-bold text-lg px-8 py-4 rounded-lg shadow-lg">
            {ctaText}
          </Button>
        </motion.div>

        <p className="text-gray-500 text-xs mt-4">COMING TO A BROWSER NEAR YOU</p>
      </div>

      {/* Corner badge */}
      <div className="absolute top-4 left-4 bg-red-600 text-white font-black text-xs px-3 py-1 rounded transform -rotate-12">BLOCKBUSTER</div>
    </motion.div>
  );
}