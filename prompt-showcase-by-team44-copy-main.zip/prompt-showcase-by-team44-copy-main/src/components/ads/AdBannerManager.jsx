import React from "react";
import RetroInfomercialAd from "./banners/RetroInfomercialAd";
import MoviePosterAd1 from "./banners/MoviePosterAd1";
import MoviePosterAd2 from "./banners/MoviePosterAd2";
import MoviePosterAd3 from "./banners/MoviePosterAd3";
import NeonCyberAd from "./banners/NeonCyberAd";

const bannerComponents = {
  moviePoster2: MoviePosterAd2,
  neonCyber: NeonCyberAd,
};

export const bannerOptions = [
  { id: "moviePoster2", name: "Sci-Fi Movie Poster", desc: "Futuristic space vibes" },
  { id: "neonCyber", name: "Neon Cyber", desc: "Synthwave aesthetic" },
];

export default function AdBannerManager({ bannerId, config, onClose }) {
  const BannerComponent = bannerComponents[bannerId] || MoviePosterAd2;
  return <BannerComponent config={config} onClose={onClose} />;
}