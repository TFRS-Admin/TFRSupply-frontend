import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Zap, Star, Flame, ArrowRight, X, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

const slogans = [
  "🔥 TOTALLY RADICAL TEMPLATES! 🔥",
  "⚡ EXTREME UI POWER! ⚡",
  "🚀 GET YOURS NOW!! 🚀",
  "💥 LIMITED TIME ONLY! 💥",
  "🎉 WOW! AMAZING! INCREDIBLE! 🎉"
];

export default function RetroAdBanner({ onClose }) {
  const [currentSlogan, setCurrentSlogan] = useState(0);
  const [flash, setFlash] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlogan(prev => (prev + 1) % slogans.length);
      setFlash(true);
      setTimeout(() => setFlash(false), 200);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ scale: 0, rotate: -10 }}
      animate={{ scale: 1, rotate: 0 }}
      exit={{ scale: 0, rotate: 10 }}
      className="relative overflow-hidden rounded-2xl border-4 border-yellow-400"
      style={{
        background: "linear-gradient(135deg, #ff0080, #ff8c00, #ffff00, #00ff00, #00ffff, #0080ff, #8000ff)",
        backgroundSize: "400% 400%",
        animation: "gradient-rave 3s ease infinite"
      }}
    >
      <style>{`
        @keyframes gradient-rave {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        @keyframes shake-crazy {
          0%, 100% { transform: translateX(0) rotate(0); }
          25% { transform: translateX(-5px) rotate(-2deg); }
          75% { transform: translateX(5px) rotate(2deg); }
        }
        @keyframes blink-fast {
          0%, 50%, 100% { opacity: 1; }
          25%, 75% { opacity: 0; }
        }
      `}</style>

      {/* Close Button */}
      <button onClick={onClose} className="absolute top-2 right-2 z-20 p-1 rounded-full bg-black/50 text-white hover:bg-black/80">
        <X className="w-4 h-4" />
      </button>

      {/* Flash Overlay */}
      <AnimatePresence>
        {flash && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-white z-10"
          />
        )}
      </AnimatePresence>

      {/* Scanlines */}
      <div className="absolute inset-0 z-10 pointer-events-none" style={{
        background: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.1) 2px, rgba(0,0,0,0.1) 4px)"
      }} />

      {/* Content */}
      <div className="relative z-5 p-6 text-center">
        {/* Stars */}
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute"
            style={{ left: `${10 + i * 12}%`, top: `${Math.random() * 30}%` }}
            animate={{ rotate: 360, scale: [1, 1.5, 1] }}
            transition={{ duration: 1, repeat: Infinity, delay: i * 0.1 }}
          >
            <Star className="w-6 h-6 text-yellow-300 fill-yellow-300" />
          </motion.div>
        ))}

        {/* Flaming Logo Area */}
        <motion.div
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 0.5, repeat: Infinity }}
          className="relative inline-block mb-4"
        >
          <motion.div animate={{ rotate: [0, 5, -5, 0] }} transition={{ duration: 0.3, repeat: Infinity }}>
            <span className="text-4xl md:text-6xl font-black text-white drop-shadow-[0_0_10px_rgba(255,0,0,1)] tracking-tight" style={{ textShadow: "3px 3px 0 #ff0000, 6px 6px 0 #ff8800" }}>
              BASE44
            </span>
          </motion.div>
          <div className="flex justify-center gap-1 -mt-2">
            {[...Array(5)].map((_, i) => (
              <motion.div key={i} animate={{ y: [0, -10, 0], opacity: [1, 0.5, 1] }} transition={{ duration: 0.5, repeat: Infinity, delay: i * 0.1 }}>
                <Flame className="w-6 h-6 text-orange-500" />
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Rotating Slogans */}
        <motion.div
          key={currentSlogan}
          initial={{ y: 20, opacity: 0, scale: 0.8 }}
          animate={{ y: 0, opacity: 1, scale: 1 }}
          className="text-2xl md:text-3xl font-black text-black bg-yellow-300 px-4 py-2 rounded-lg inline-block mb-4"
          style={{ animation: "shake-crazy 0.1s infinite" }}
        >
          {slogans[currentSlogan]}
        </motion.div>

        {/* Features */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          {["PRO TEMPLATES", "INSTANT DOWNLOAD", "24/7 SUPPORT"].map((feature, i) => (
            <motion.div
              key={i}
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 0.5, repeat: Infinity, delay: i * 0.2 }}
              className="bg-black/80 text-white px-2 py-1 rounded font-bold text-xs md:text-sm"
            >
              <Zap className="w-3 h-3 inline mr-1 text-yellow-400" />
              {feature}
            </motion.div>
          ))}
        </div>

        {/* Price */}
        <div className="mb-4">
          <span className="text-2xl text-white line-through opacity-60">$199</span>
          <motion.span
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 0.3, repeat: Infinity }}
            className="text-4xl md:text-5xl font-black text-yellow-300 ml-3"
            style={{ textShadow: "2px 2px 0 #000" }}
          >
            $49!
          </motion.span>
        </div>

        {/* CTA Button */}
        <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}>
          <Button
            size="lg"
            className="bg-red-600 hover:bg-red-700 text-white font-black text-lg px-8 py-6 rounded-full shadow-[0_0_20px_rgba(255,0,0,0.8)]"
            style={{ animation: "blink-fast 0.5s infinite" }}
            onClick={() => window.open("https://base44.io", "_blank")}
          >
            <Sparkles className="w-5 h-5 mr-2" />
            ORDER NOW!!!
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </motion.div>

        <p className="text-white text-xs mt-3 opacity-80">* Act now! This deal is INSANE! Call 1-800-BASE44 *</p>
      </div>

      {/* Corner Badges */}
      <motion.div
        animate={{ rotate: [0, 10, -10, 0] }}
        transition={{ duration: 0.5, repeat: Infinity }}
        className="absolute -top-2 -left-2 bg-red-500 text-white font-black text-xs px-4 py-2 rounded-full transform -rotate-12"
      >
        WOW!
      </motion.div>
      <motion.div
        animate={{ rotate: [0, -10, 10, 0] }}
        transition={{ duration: 0.5, repeat: Infinity }}
        className="absolute -bottom-2 -right-2 bg-green-500 text-white font-black text-xs px-4 py-2 rounded-full transform rotate-12"
      >
        75% OFF!
      </motion.div>
    </motion.div>
  );
}