import React, { useState } from "react";
import { motion } from "framer-motion";
import { Upload, X, Sparkles, Zap, Star, Heart, Flame, Gift, Music, Film, Gamepad2, Tv, Calendar, ShoppingBag, Cpu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { base44 } from "@/api/base44Client";

const ERA_STYLES = [
  { id: "50s", name: "1950s", desc: "Retro Americana", colors: ["#e8d5b7", "#c73e3a", "#1e3a5f"] },
  { id: "60s", name: "1960s", desc: "Mod & Psychedelic", colors: ["#ff6b35", "#f7c59f", "#004e89"] },
  { id: "70s", name: "1970s", desc: "Disco & Earth Tones", colors: ["#d4a373", "#bc6c25", "#606c38"] },
  { id: "80s", name: "1980s", desc: "Neon & Synth", colors: ["#ff00ff", "#00ffff", "#ffff00"] },
  { id: "90s", name: "1990s", desc: "Grunge & Web 1.0", colors: ["#7b2cbf", "#2dc653", "#ff4d6d"] },
  { id: "2000s", name: "2000s", desc: "Y2K & Bling", colors: ["#c0c0c0", "#00bfff", "#ff1493"] },
  { id: "2010s", name: "2010s", desc: "Flat & Minimal", colors: ["#3498db", "#2ecc71", "#9b59b6"] },
  { id: "2020s", name: "2020s", desc: "Glassmorphism & Neo", colors: ["#667eea", "#764ba2", "#f093fb"] },
];

const STYLE_CATEGORIES = [
  { id: "popculture", name: "Pop Culture", icon: Star },
  { id: "holiday", name: "Holiday", icon: Gift },
  { id: "vibe", name: "Vibe/Mood", icon: Heart },
  { id: "movie", name: "Movie Theme", icon: Film },
  { id: "game", name: "Game Theme", icon: Gamepad2 },
  { id: "gamer", name: "Gamer Style", icon: Cpu },
  { id: "anime", name: "Anime", icon: Tv },
  { id: "blackfriday", name: "Black Friday", icon: ShoppingBag },
  { id: "cybermonday", name: "Cyber Monday", icon: Zap },
];

const ANIME_STYLES = [
  { id: "general", name: "General Anime" },
  { id: "southpark", name: "South Park" },
  { id: "simpsons", name: "Simpsons" },
  { id: "ghibli", name: "Studio Ghibli" },
  { id: "shonen", name: "Shonen" },
  { id: "cyberpunk", name: "Cyberpunk Anime" },
];

const HOLIDAY_THEMES = [
  { id: "christmas", name: "Christmas", emoji: "🎄" },
  { id: "halloween", name: "Halloween", emoji: "🎃" },
  { id: "valentine", name: "Valentine's", emoji: "💕" },
  { id: "newyear", name: "New Year", emoji: "🎆" },
  { id: "easter", name: "Easter", emoji: "🐰" },
  { id: "july4", name: "4th of July", emoji: "🇺🇸" },
];

const VIBE_OPTIONS = [
  { id: "chill", name: "Chill", colors: ["#a8e6cf", "#dcedc1"] },
  { id: "hype", name: "Hype", colors: ["#ff4757", "#ff6b81"] },
  { id: "dark", name: "Dark", colors: ["#2f3542", "#57606f"] },
  { id: "cute", name: "Cute", colors: ["#ff9ff3", "#ffeaa7"] },
  { id: "professional", name: "Professional", colors: ["#2c3e50", "#3498db"] },
  { id: "creative", name: "Creative", colors: ["#e056fd", "#686de0"] },
];

export default function BannerGenerator({ onSave, initialConfig }) {
  const [config, setConfig] = useState(initialConfig || {
    era: "90s",
    category: "movie",
    subStyle: "",
    holiday: "",
    vibe: "hype",
    anime: "general",
    headline: "Check Out Our Apps!",
    subheadline: "Built on Base44",
    ctaText: "Explore Now",
    ctaUrl: "#",
    appImages: [null, null, null],
    appLinks: ["", "", ""],
    appTitles: ["App 1", "App 2", "App 3"],
  });

  const [uploading, setUploading] = useState([false, false, false]);

  const handleImageUpload = async (index, file) => {
    if (!file) return;
    const newUploading = [...uploading];
    newUploading[index] = true;
    setUploading(newUploading);

    try {
      const result = await base44.integrations.Core.UploadFile({ file });
      const newImages = [...config.appImages];
      newImages[index] = result.file_url;
      setConfig({ ...config, appImages: newImages });
    } catch (e) {
      console.error("Upload failed:", e);
    }

    newUploading[index] = false;
    setUploading(newUploading);
  };

  const removeImage = (index) => {
    const newImages = [...config.appImages];
    newImages[index] = null;
    setConfig({ ...config, appImages: newImages });
  };

  const updateAppLink = (index, value) => {
    const newLinks = [...config.appLinks];
    newLinks[index] = value;
    setConfig({ ...config, appLinks: newLinks });
  };

  const updateAppTitle = (index, value) => {
    const newTitles = [...config.appTitles];
    newTitles[index] = value;
    setConfig({ ...config, appTitles: newTitles });
  };

  const getEraStyle = () => ERA_STYLES.find(e => e.id === config.era) || ERA_STYLES[4];

  return (
    <div className="space-y-6">
      {/* Era Selection */}
      <div>
        <Label className="text-white mb-2 block">Select Era</Label>
        <div className="grid grid-cols-4 gap-2">
          {ERA_STYLES.map((era) => (
            <button
              key={era.id}
              onClick={() => setConfig({ ...config, era: era.id })}
              className={`p-2 rounded-lg text-xs transition-all ${config.era === era.id ? "ring-2 ring-violet-500" : "hover:bg-slate-700"}`}
              style={{ background: `linear-gradient(135deg, ${era.colors[0]}, ${era.colors[1]})` }}
            >
              <span className="font-bold text-white drop-shadow-lg">{era.name}</span>
              <p className="text-white/70 text-[10px]">{era.desc}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Category Selection */}
      <div>
        <Label className="text-white mb-2 block">Style Category</Label>
        <div className="grid grid-cols-3 gap-2">
          {STYLE_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setConfig({ ...config, category: cat.id })}
              className={`p-3 rounded-lg flex items-center gap-2 transition-all ${config.category === cat.id ? "bg-violet-500/30 border border-violet-500" : "bg-slate-800 border border-slate-700 hover:border-slate-600"}`}
            >
              <cat.icon className={`w-4 h-4 ${config.category === cat.id ? "text-violet-400" : "text-slate-400"}`} />
              <span className={`text-sm ${config.category === cat.id ? "text-white" : "text-slate-400"}`}>{cat.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Conditional Sub-options */}
      {config.category === "anime" && (
        <div>
          <Label className="text-white mb-2 block">Anime Style</Label>
          <div className="grid grid-cols-3 gap-2">
            {ANIME_STYLES.map((style) => (
              <button
                key={style.id}
                onClick={() => setConfig({ ...config, anime: style.id })}
                className={`p-2 rounded-lg text-xs ${config.anime === style.id ? "bg-pink-500/30 border border-pink-500 text-white" : "bg-slate-800 text-slate-400"}`}
              >
                {style.name}
              </button>
            ))}
          </div>
        </div>
      )}

      {config.category === "holiday" && (
        <div>
          <Label className="text-white mb-2 block">Holiday Theme</Label>
          <div className="grid grid-cols-3 gap-2">
            {HOLIDAY_THEMES.map((h) => (
              <button
                key={h.id}
                onClick={() => setConfig({ ...config, holiday: h.id })}
                className={`p-2 rounded-lg text-sm ${config.holiday === h.id ? "bg-green-500/30 border border-green-500 text-white" : "bg-slate-800 text-slate-400"}`}
              >
                {h.emoji} {h.name}
              </button>
            ))}
          </div>
        </div>
      )}

      {config.category === "vibe" && (
        <div>
          <Label className="text-white mb-2 block">Vibe/Mood</Label>
          <div className="grid grid-cols-3 gap-2">
            {VIBE_OPTIONS.map((v) => (
              <button
                key={v.id}
                onClick={() => setConfig({ ...config, vibe: v.id })}
                className={`p-2 rounded-lg text-sm ${config.vibe === v.id ? "ring-2 ring-white" : ""}`}
                style={{ background: `linear-gradient(135deg, ${v.colors[0]}, ${v.colors[1]})` }}
              >
                <span className="text-white font-medium drop-shadow">{v.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Text Content */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-slate-400 text-xs">Headline</Label>
          <Input
            value={config.headline}
            onChange={(e) => setConfig({ ...config, headline: e.target.value })}
            className="bg-slate-800 border-slate-700 text-white"
          />
        </div>
        <div>
          <Label className="text-slate-400 text-xs">Subheadline</Label>
          <Input
            value={config.subheadline}
            onChange={(e) => setConfig({ ...config, subheadline: e.target.value })}
            className="bg-slate-800 border-slate-700 text-white"
          />
        </div>
        <div>
          <Label className="text-slate-400 text-xs">CTA Button Text</Label>
          <Input
            value={config.ctaText}
            onChange={(e) => setConfig({ ...config, ctaText: e.target.value })}
            className="bg-slate-800 border-slate-700 text-white"
          />
        </div>
        <div>
          <Label className="text-slate-400 text-xs">CTA URL</Label>
          <Input
            value={config.ctaUrl}
            onChange={(e) => setConfig({ ...config, ctaUrl: e.target.value })}
            className="bg-slate-800 border-slate-700 text-white"
          />
        </div>
      </div>

      {/* App Screenshots */}
      <div>
        <Label className="text-white mb-2 block flex items-center gap-2">
          <Film className="w-4 h-4" /> App Screenshots (Movie Poster Style)
        </Label>
        <p className="text-xs text-slate-500 mb-3">Upload 3 app screenshots to display as movie posters on a wall</p>
        <div className="grid grid-cols-3 gap-4">
          {[0, 1, 2].map((index) => (
            <div key={index} className="space-y-2">
              <div className={`relative aspect-[2/3] rounded-lg border-2 border-dashed overflow-hidden ${config.appImages[index] ? "border-violet-500" : "border-slate-700"}`}>
                {config.appImages[index] ? (
                  <>
                    <img src={config.appImages[index]} alt={`App ${index + 1}`} className="w-full h-full object-cover" />
                    <button
                      onClick={() => removeImage(index)}
                      className="absolute top-1 right-1 p-1 bg-red-500 rounded-full"
                    >
                      <X className="w-3 h-3 text-white" />
                    </button>
                  </>
                ) : (
                  <label className="flex flex-col items-center justify-center h-full cursor-pointer hover:bg-slate-800/50">
                    {uploading[index] ? (
                      <div className="animate-spin w-6 h-6 border-2 border-violet-500 border-t-transparent rounded-full" />
                    ) : (
                      <>
                        <Upload className="w-6 h-6 text-slate-500 mb-1" />
                        <span className="text-xs text-slate-500">Poster {index + 1}</span>
                      </>
                    )}
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => handleImageUpload(index, e.target.files[0])}
                    />
                  </label>
                )}
              </div>
              <Input
                placeholder="App Title"
                value={config.appTitles[index]}
                onChange={(e) => updateAppTitle(index, e.target.value)}
                className="bg-slate-800 border-slate-700 text-white text-xs"
              />
              <Input
                placeholder="Link URL"
                value={config.appLinks[index]}
                onChange={(e) => updateAppLink(index, e.target.value)}
                className="bg-slate-800 border-slate-700 text-white text-xs"
              />
            </div>
          ))}
        </div>
      </div>

      {/* Preview */}
      <div>
        <Label className="text-white mb-2 block">Preview</Label>
        <BannerPreview config={config} />
      </div>

      {/* Save Button */}
      <Button
        onClick={() => onSave && onSave(config)}
        className="w-full bg-gradient-to-r from-violet-500 to-cyan-500"
      >
        <Sparkles className="w-4 h-4 mr-2" /> Save Banner Configuration
      </Button>
    </div>
  );
}

function BannerPreview({ config }) {
  const eraStyle = ERA_STYLES.find(e => e.id === config.era) || ERA_STYLES[4];
  
  const getBannerStyle = () => {
    let style = {
      background: `linear-gradient(135deg, ${eraStyle.colors[0]}, ${eraStyle.colors[1]}, ${eraStyle.colors[2] || eraStyle.colors[0]})`,
    };

    if (config.category === "blackfriday") {
      style.background = "linear-gradient(135deg, #000000, #1a1a1a, #333333)";
    } else if (config.category === "cybermonday") {
      style.background = "linear-gradient(135deg, #0a0a0a, #00ffff20, #0a0a0a)";
    } else if (config.category === "gamer") {
      style.background = "linear-gradient(135deg, #1a0033, #330066, #000)";
    }

    return style;
  };

  const getTextStyle = () => {
    if (config.era === "80s" || config.category === "cybermonday") {
      return "text-transparent bg-clip-text bg-gradient-to-r from-pink-500 via-cyan-400 to-pink-500";
    }
    if (config.category === "blackfriday") {
      return "text-yellow-400";
    }
    return "text-white";
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="relative rounded-xl overflow-hidden"
      style={getBannerStyle()}
    >
      {/* Scanlines for retro eras */}
      {["50s", "60s", "70s", "80s", "90s"].includes(config.era) && (
        <div className="absolute inset-0 pointer-events-none opacity-20" style={{
          background: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.3) 2px, rgba(0,0,0,0.3) 4px)"
        }} />
      )}

      {/* Cyber Monday grid */}
      {config.category === "cybermonday" && (
        <div className="absolute inset-0 pointer-events-none opacity-30" style={{
          backgroundImage: "linear-gradient(cyan 1px, transparent 1px), linear-gradient(90deg, cyan 1px, transparent 1px)",
          backgroundSize: "20px 20px"
        }} />
      )}

      <div className="relative p-6 flex flex-col md:flex-row items-center gap-6">
        {/* Movie Poster Wall */}
        <div className="flex-shrink-0 relative">
          <div className="flex gap-2 p-3 rounded-lg" style={{ background: "rgba(0,0,0,0.5)" }}>
            {config.appImages.map((img, i) => (
              <a
                key={i}
                href={config.appLinks[i] || "#"}
                target="_blank"
                rel="noopener noreferrer"
                className="relative group"
              >
                <div className="w-16 h-24 md:w-20 md:h-28 rounded overflow-hidden border-2 border-slate-600 shadow-lg transform transition-transform group-hover:scale-105 group-hover:-translate-y-1">
                  {img ? (
                    <img src={img} alt={config.appTitles[i]} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-slate-800 flex items-center justify-center">
                      <Film className="w-6 h-6 text-slate-600" />
                    </div>
                  )}
                </div>
                <p className="text-[8px] text-center text-white/70 mt-1 truncate w-16 md:w-20">
                  {config.appTitles[i]}
                </p>
              </a>
            ))}
          </div>
          <p className="text-[10px] text-center text-white/50 mt-1">🎬 Featured Apps</p>
        </div>

        {/* Content */}
        <div className="flex-1 text-center md:text-left">
          <h2 className={`text-2xl md:text-3xl font-bold mb-2 ${getTextStyle()}`}>
            {config.headline}
          </h2>
          <p className="text-white/80 mb-4">{config.subheadline}</p>
          <motion.a
            href={config.ctaUrl}
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`inline-block px-6 py-2 rounded-full font-bold text-sm ${
              config.category === "blackfriday" 
                ? "bg-yellow-400 text-black" 
                : config.category === "cybermonday"
                ? "bg-cyan-400 text-black"
                : "bg-white text-slate-900"
            }`}
          >
            {config.ctaText}
          </motion.a>
        </div>

        {/* Decorative elements */}
        {config.category === "blackfriday" && (
          <div className="absolute top-2 right-2 bg-red-600 text-white px-3 py-1 rounded-full text-xs font-bold animate-pulse">
            SALE!
          </div>
        )}
        {config.category === "cybermonday" && (
          <Zap className="absolute top-4 right-4 w-8 h-8 text-cyan-400 animate-pulse" />
        )}
      </div>
    </motion.div>
  );
}

export { BannerPreview };