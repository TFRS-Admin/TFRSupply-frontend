import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, X, Sparkles } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

// All searchable pages and effects
const searchableItems = [
  // Pages
  { name: "Visual Effects", page: "VisualEffects", type: "page", category: "Effects" },
  { name: "Audio Effects", page: "AudioEffects", type: "page", category: "Effects" },
  { name: "Transitions", page: "Transitions", type: "page", category: "Effects" },
  { name: "Button Effects", page: "ButtonEffects", type: "page", category: "Effects" },
  { name: "Navigation Effects", page: "NavigationEffects", type: "page", category: "Effects" },
  { name: "Menu Effects", page: "MenuEffects", type: "page", category: "Effects" },
  { name: "Chat Effects", page: "ChatEffects", type: "page", category: "Effects" },
  { name: "AI Agent Effects", page: "AIAgentEffects", type: "page", category: "Effects" },
  { name: "Character Effects", page: "CharacterEffects", type: "page", category: "Effects" },
  { name: "Icon Effects", page: "IconEffects", type: "page", category: "Effects" },
  { name: "Loading Spinners", page: "LoadingSpinners", type: "page", category: "Effects" },
  { name: "Text Effects", page: "TextEffects", type: "page", category: "Effects" },
  { name: "Divider Effects", page: "DividerEffects", type: "page", category: "Effects" },
  { name: "Video Effects", page: "VideoEffects", type: "page", category: "Effects" },
  { name: "Color Schemes", page: "ColorSchemes", type: "page", category: "Effects" },
  { name: "Admin Layouts", page: "AdminLayouts", type: "page", category: "Business" },
  { name: "Marketing Effects", page: "MarketingEffects", type: "page", category: "Business" },
  { name: "E-commerce Effects", page: "EcommerceEffects", type: "page", category: "Business" },
  { name: "Cart & Checkout", page: "CartCheckout", type: "page", category: "Business" },
  { name: "Creative Effects", page: "CreativeEffects", type: "page", category: "Creative" },
  { name: "Content Effects", page: "ContentEffects", type: "page", category: "Creative" },
  { name: "Communication Effects", page: "CommunicationEffects", type: "page", category: "Social" },
  { name: "Social Effects", page: "SocialEffects", type: "page", category: "Social" },
  { name: "Productivity Effects", page: "ProductivityEffects", type: "page", category: "Tools" },
  { name: "Gaming Effects", page: "GamingEffects", type: "page", category: "Gaming" },
  { name: "Abstract Animations", page: "AbstractAnimations", type: "page", category: "Creative" },
  { name: "Pixel Assets", page: "PixelAssets", type: "page", category: "Gaming" },
  { name: "Premium Effects", page: "PremiumEffects", type: "page", category: "Effects" },
  { name: "YouTube Video Player", page: "VideoPlayerCustomization", type: "page", category: "Effects" },
  { name: "Donation Components", page: "DonationComponents", type: "page", category: "Business" },
  
  // Tools
  { name: "Button Gallery", page: "ButtonShowcase", type: "tool", category: "Tools" },
  { name: "Design Terminology", page: "DesignTerminology", type: "tool", category: "Tools" },
  { name: "Tutorials", page: "Tutorials", type: "tool", category: "Tools" },
  { name: "Teachable Mode", page: "TeachableMode", type: "tool", category: "Tools" },
  { name: "Effect Builder", page: "EffectBuilder", type: "tool", category: "Tools" },
  { name: "Discover", page: "Discover", type: "tool", category: "Tools" },
  { name: "My Effects", page: "MyEffects", type: "tool", category: "Tools" },
  
  // Popular Effects
  { name: "Glitch Effect", page: "VisualEffects", type: "effect", category: "Visual", anchor: "glitch-effect" },
  { name: "VHS Effect", page: "VisualEffects", type: "effect", category: "Visual", anchor: "vhs-effect" },
  { name: "Neon Glow", page: "VisualEffects", type: "effect", category: "Visual", anchor: "neon-glow" },
  { name: "Particle System", page: "VisualEffects", type: "effect", category: "Visual", anchor: "particle-system" },
  { name: "Ripple Button", page: "ButtonEffects", type: "effect", category: "Buttons", anchor: "ripple-button" },
  { name: "Gradient Button", page: "ButtonEffects", type: "effect", category: "Buttons", anchor: "gradient-button" },
  { name: "Chat Bubble", page: "ChatEffects", type: "effect", category: "Chat", anchor: "chat-bubble" },
  { name: "Fade Transition", page: "Transitions", type: "effect", category: "Transitions", anchor: "fade-transition" },
  { name: "Wave Divider", page: "DividerEffects", type: "effect", category: "Dividers", anchor: "wave-divider" },
];

export default function GlobalSearch() {
  const [query, setQuery] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [filtered, setFiltered] = useState([]);
  const searchRef = useRef(null);
  const navigate = useNavigate();

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && filtered.length > 0) {
      const item = filtered[0];
      navigate(createPageUrl(item.page) + (item.anchor ? `#${item.anchor}` : ""));
      setIsOpen(false);
      setQuery("");
    }
  };

  useEffect(() => {
    if (query.trim().length > 0) {
      const results = searchableItems
        .filter(item => 
          item.name.toLowerCase().includes(query.toLowerCase()) ||
          item.category.toLowerCase().includes(query.toLowerCase())
        )
        .slice(0, 8);
      setFiltered(results);
      setIsOpen(results.length > 0);
    } else {
      setFiltered([]);
      setIsOpen(false);
    }
  }, [query]);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (searchRef.current && !searchRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const getCategoryColor = (category) => {
    const colors = {
      "Effects": "text-violet-400",
      "Business": "text-amber-400",
      "Creative": "text-pink-400",
      "Social": "text-cyan-400",
      "Tools": "text-emerald-400",
      "Gaming": "text-red-400",
      "Visual": "text-purple-400",
      "Buttons": "text-emerald-400",
      "Chat": "text-blue-400",
      "Transitions": "text-pink-400",
      "Dividers": "text-teal-400"
    };
    return colors[category] || "text-slate-400";
  };

  return (
    <div className="relative" ref={searchRef}>
      <style>{`
        .global-search-input:focus {
          animation: search-glow 2s ease-in-out infinite;
        }
        @keyframes search-glow {
          0%, 100% { box-shadow: 0 0 0 0 rgba(139, 92, 246, 0); }
          50% { box-shadow: 0 0 20px 2px rgba(139, 92, 246, 0.3); }
        }
        .search-result-glitch:hover .search-result-text {
          animation: result-glitch 0.3s ease-in-out;
        }
        @keyframes result-glitch {
          0%, 100% { text-shadow: none; }
          20% { text-shadow: -1px 0 #ff00ff, 1px 0 #00ffff; }
          40% { text-shadow: 1px 0 #ff00ff, -1px 0 #00ffff; }
          60% { text-shadow: -1px 0 #00ffff, 1px 0 #ff00ff; }
          80% { text-shadow: 1px 0 #00ffff, -1px 0 #ff00ff; }
        }
      `}</style>
      
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 z-10" />
        <input
          type="text"
          placeholder="Search effects..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          onFocus={() => query && setIsOpen(filtered.length > 0)}
          className="global-search-input w-40 sm:w-48 pl-10 pr-8 py-1.5 bg-slate-900/50 border border-slate-700 rounded-lg text-white text-sm placeholder:text-slate-500 focus:outline-none focus:border-violet-500 transition-all"
        />
        {query && (
          <button
            onClick={() => { setQuery(""); setIsOpen(false); }}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-slate-700 text-slate-400"
          >
            <X className="w-3 h-3" />
          </button>
        )}
      </div>

      {/* Results Dropdown */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-full left-0 right-0 mt-2 bg-slate-900/95 backdrop-blur-xl border border-slate-700 rounded-xl shadow-2xl overflow-hidden z-[100]"
          >
            <div className="max-h-96 overflow-y-auto">
              {filtered.map((item, i) => (
                <Link
                  key={i}
                  to={createPageUrl(item.page) + (item.anchor ? `#${item.anchor}` : "")}
                  onClick={() => { setIsOpen(false); setQuery(""); }}
                  className="flex items-center justify-between px-4 py-3 hover:bg-slate-800 transition-colors border-b border-slate-800 last:border-0 search-result-glitch"
                >
                  <div>
                    <p className="text-white text-sm font-medium search-result-text">{item.name}</p>
                    <p className={`text-xs ${getCategoryColor(item.category)}`}>{item.category} • {item.type}</p>
                  </div>
                  <Sparkles className="w-4 h-4 text-violet-400 opacity-0 group-hover:opacity-100" />
                </Link>
              ))}
            </div>
            <div className="px-4 py-2 bg-slate-950/80 border-t border-slate-800 text-center">
              <p className="text-xs text-slate-500">Press Enter to navigate • ESC to close</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}