import React, { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "./utils";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles, Menu, X, Home, Eye, Volume2,
  Layers, Navigation, MousePointerClick, ChevronRight,
  MessageCircle, Bot, Heart, Wand2, Users, BookOpen, Settings as SettingsIcon, Video } from
"lucide-react";
import { cn } from "@/lib/utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import InstallButton from "@/components/pwa/InstallButton";
import WilsonQuote from "@/components/effects/WilsonQuote";
import FooterEnhanced from "@/components/footer/FooterEnhanced";
import GlitchButton from "@/components/effects/GlitchButton";
import GlitchLoader from "@/components/effects/GlitchLoader";
import WordSlider from "@/components/effects/WordSlider";
import TemplateInitializer from "@/components/onboarding/TemplateInitializer";
import GlobalAnnouncement from "@/components/marketing/GlobalAnnouncement";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";
import GlobalSearch from "@/components/navigation/GlobalSearch";

// Feature to page mapping
const featurePageMap = {
  effectBuilder: "EffectBuilder",
  visualEffects: "VisualEffects",
  audioEffects: "AudioEffects",
  transitions: "Transitions",
  navigationEffects: "NavigationEffects",
  buttonEffects: "ButtonEffects",
  menuEffects: "MenuEffects",
  chatEffects: "ChatEffects",
  characterEffects: "CharacterEffects",
  aiAgentEffects: "AIAgentEffects",
  iconEffects: "IconEffects",
  loadingSpinners: "LoadingSpinners",
  tutorials: "Tutorials",
  discover: "Discover",
  myEffects: "MyEffects",
  teachableMode: "TeachableMode",
  suggestions: "Suggestions"
};

// App Master's witty tips for the Install button
const appMasterTips = [
"Installing this app is like giving your browser a comfy pair of slippers - same house, way more comfortable! 🛋️",
"Using a web app without installing is like eating soup with a fork - technically possible, but why torture yourself? 🥄",
"Think of installing as promoting your favorite restaurant from 'somewhere in that folder' to 'shortcut on the counter.' 📍",
"A web app lives in tabs. An installed app lives in your heart. And your dock. Mostly your dock. 💜",
"Installing is like finally putting your keys on that hook by the door - you'll always know where to find it! 🔑",
"Browsers collect tabs like cats collect sunbeams. Installing sets this one free! 🐱",
"It's like the difference between a house guest and a roommate - one you actually want around! 🏠"];


// Smoke effect CSS
const smokeStyles = `
  @keyframes smoke-rise {
    0% { opacity: 0; transform: translateY(0) scale(1); }
    50% { opacity: 0.3; }
    100% { opacity: 0; transform: translateY(-20px) scale(1.5); }
  }
  .smoke-particle {
    position: absolute;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(100,100,100,0.4) 0%, transparent 70%);
    animation: smoke-rise 2s ease-out infinite;
    pointer-events: none;
  }
`;

function InstallButtonWithPopover() {
  const [tip] = React.useState(() =>
  appMasterTips[Math.floor(Math.random() * appMasterTips.length)]
  );
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <HoverCard openDelay={200} closeDelay={200} onOpenChange={setIsOpen}>
      <HoverCardTrigger asChild>
        <div className="install-btn-wrapper">
          <InstallButton />
        </div>
      </HoverCardTrigger>
      <HoverCardContent
        side="bottom"
        align="end"
        sideOffset={8}
        className="w-80 bg-slate-900/95 border-slate-700 text-white p-4 z-[100] shadow-xl overflow-visible">

        <style>{smokeStyles}</style>
        {/* Smoke effect particles */}
        {isOpen &&
        <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 pointer-events-none">
            {[...Array(5)].map((_, i) =>
          <div
            key={i}
            className="smoke-particle"
            style={{
              left: `${-20 + i * 10}px`,
              animationDelay: `${i * 0.3}s`,
              opacity: 0
            }} />

          )}
          </div>
        }
        <div className="space-y-3 relative">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🧙‍♂️</span>
            <span className="font-semibold text-emerald-400">APP MASTER</span>
          </div>
          <p className="text-sm text-slate-300 italic leading-relaxed">
            "{tip}"
          </p>
          <p className="text-xs text-slate-500 flex items-center gap-1">
            *hits pipe of gassy stank* 💨
            {isOpen && <span className="opacity-50 animate-pulse">~~~</span>}
          </p>
        </div>
      </HoverCardContent>
    </HoverCard>);

}

// Primary nav items shown in header - Favorites only (Home via logo), rest are dynamic
const primaryNavBase = [
{ name: "Favorites", page: "Favorites", icon: Heart, featureId: null }];


// Dropdown "More" items - organized by category
const moreNavCategories = [
{
  title: "UI Components",
  items: [
  { name: "Visual", page: "VisualEffects", icon: Eye, featureId: "visualEffects" },
  { name: "Audio", page: "AudioEffects", icon: Volume2, featureId: "audioEffects" },
  { name: "Transitions", page: "Transitions", icon: Layers, featureId: "transitions" },
  { name: "Buttons", page: "ButtonEffects", icon: MousePointerClick, featureId: "buttonEffects" },
  { name: "Colors", page: "ColorSchemes", icon: Eye, featureId: null },
  { name: "Icons", page: "IconEffects", icon: Sparkles, featureId: "iconEffects" },
  { name: "Menus", page: "MenuEffects", icon: Menu, featureId: "menuEffects" },
  { name: "Navigation", page: "NavigationEffects", icon: Navigation, featureId: "navigationEffects" },
  { name: "Spinners", page: "LoadingSpinners", icon: Sparkles, featureId: "loadingSpinners" },
  { name: "Dividers", page: "DividerEffects", icon: Layers, featureId: "dividerEffects" }]

},
{
  title: "Interactive",
  items: [
  { name: "Chat", page: "ChatEffects", icon: MessageCircle, featureId: "chatEffects" },
  { name: "AI Agents", page: "AIAgentEffects", icon: Bot, featureId: "aiAgentEffects" },
  { name: "Characters", page: "CharacterEffects", icon: Users, featureId: "characterEffects" }]

},
{
  title: "Business",
  items: [
  { name: "Admin", page: "AdminLayouts", icon: Layers, featureId: null },
  { name: "Marketing", page: "MarketingEffects", icon: Sparkles, featureId: null },
  { name: "E-commerce", page: "EcommerceEffects", icon: MousePointerClick, featureId: null },
  { name: "Cart", page: "CartCheckout", icon: Sparkles, featureId: null }]

},
{
  title: "Content & Media",
  items: [
  { name: "Text", page: "TextEffects", icon: Sparkles, featureId: null },
  { name: "Creative", page: "CreativeEffects", icon: Eye, featureId: null },
  { name: "Content", page: "ContentEffects", icon: Layers, featureId: null },
  { name: "Social", page: "SocialEffects", icon: Heart, featureId: null },
  { name: "Comms", page: "CommunicationEffects", icon: MessageCircle, featureId: null },
  { name: "Video", page: "VideoEffects", icon: Video, featureId: "videoEffects" },
  { name: "YouTube", page: "VideoPlayerCustomization", icon: Video, featureId: null },
  { name: "Donations", page: "DonationComponents", icon: Heart, featureId: "donationComponents" }]

},
{
  title: "Specialty",
  items: [
  { name: "Productivity", page: "ProductivityEffects", icon: Sparkles, featureId: null },
  { name: "Abstract", page: "AbstractAnimations", icon: Sparkles, featureId: null },
  { name: "Gaming", page: "GamingEffects", icon: Layers, featureId: null },
  { name: "Pixel Assets", page: "PixelAssets", icon: Layers, featureId: null },
  { name: "Premium", page: "PremiumEffects", icon: Heart, featureId: "premiumEffects" }]

}];


// Flatten for mobile menu
const moreNavBase = moreNavCategories.flatMap((cat) => cat.items);

// Tools section
const toolsNavBase = [
{ name: "Button Gallery", page: "ButtonShowcase", icon: MousePointerClick, featureId: null },
{ name: "Terminology", page: "DesignTerminology", icon: BookOpen, featureId: null },
{ name: "Learn UI", page: "TeachableMode", icon: BookOpen, featureId: "teachableMode" },
{ name: "Tutorials", page: "Tutorials", icon: BookOpen, featureId: "tutorials" }];


export default function Layout({ children, currentPageName }) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showPageLoader, setShowPageLoader] = useState(false);
  const prevPageRef = useRef(currentPageName);
  const [promoGlitch, setPromoGlitch] = useState(false);
  const [moreDrawerOpen, setMoreDrawerOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [globalSearchEnabled, setGlobalSearchEnabled] = useState(true);

  // Page transition loader
  useEffect(() => {
    if (prevPageRef.current !== currentPageName) {
      setShowPageLoader(true);
      prevPageRef.current = currentPageName;
    }
  }, [currentPageName]);

  const { data: settings } = useQuery({
    queryKey: ['appSettings'],
    queryFn: async () => {
      const list = await base44.entities.AppSettings.list();
      return list[0] || { app_title: "Base44 Effects", version: "1.0.0", enabled_features: [] };
    },
    initialData: { app_title: "Base44 Effects", version: "1.0.0", enabled_features: [] }
  });

  // Check if user is admin and load global search setting
  useEffect(() => {
    base44.auth.me().then((user) => {
      setIsAdmin(user?.role === 'admin');
    }).catch(() => {
      setIsAdmin(false);
    });
  }, []);

  // Load global search setting from app settings
  useEffect(() => {
    if (settings?.global_search_enabled !== undefined) {
      setGlobalSearchEnabled(settings.global_search_enabled);
    }
  }, [settings]);

  // Filter nav items based on enabled features
  const enabledFeatures = settings?.enabled_features || [];

  const isFeatureEnabled = (featureId) => {
    if (!featureId) return true; // No feature ID means always show
    return enabledFeatures.includes(featureId);
  };

  // Get featured nav items (random or admin-selected) - exclude More, Tools, Favorites from random
  const allMoreItems = moreNavBase.filter((item) => isFeatureEnabled(item.featureId));
  const featuredNavRandom = settings?.featured_nav_random !== false; // Default true
  const featuredNavPages = Array.isArray(settings?.featured_nav_pages) ? settings.featured_nav_pages : [];

  // Items eligible for random selection (exclude Tools menu pages, Favorites, and Home from random)
  const randomEligibleItems = allMoreItems.filter((item) =>
  !["EffectBuilder", "PageTemplates", "ButtonShowcase", "Discover", "MyEffects", "DesignTerminology", "TeachableMode", "Tutorials", "Favorites", "Home"].includes(item.page)
  );

  let featuredItems = [];
  if (featuredNavRandom) {
    // Random 4 items from eligible items only
    const shuffled = [...randomEligibleItems].sort(() => 0.5 - Math.random());
    featuredItems = shuffled.slice(0, 4);
  } else if (featuredNavPages.length > 0) {
    // Admin selected items
    featuredItems = featuredNavPages.
    filter((pageName) => pageName && typeof pageName === 'string').
    map((pageName) => allMoreItems.find((item) => item.page === pageName)).
    filter(Boolean).
    slice(0, 4);
  }

  const primaryNav = [...primaryNavBase, ...featuredItems];
  const moreNav = moreNavBase.filter((item) => isFeatureEnabled(item.featureId));
  const toolsNav = toolsNavBase.filter((item) => isFeatureEnabled(item.featureId));
  const navItems = [...primaryNav, ...moreNav, ...toolsNav];

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMobileMenuOpen(false);
    // Scroll to anchor if present in URL, otherwise scroll to top
    const hash = window.location.hash;
    if (hash) {
      setTimeout(() => {
        // Use getElementById which handles special characters better than querySelector
        const id = hash.replace(/^#/, '');
        const element = document.getElementById(id);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 100);
    } else {
      window.scrollTo(0, 0);
    }
  }, [currentPageName]);

  // Promo bar text glitch effect
  useEffect(() => {
    if (!settings?.promo_bar?.textGlitch) return;

    const triggerGlitch = () => {
      setPromoGlitch(true);
      setTimeout(() => setPromoGlitch(false), 300);
    };

    const randomInterval = () => 12000 + Math.random() * 8000; // 12-20 seconds

    const scheduleNext = () => {
      const timer = setTimeout(() => {
        triggerGlitch();
        scheduleNext();
      }, randomInterval());
      return timer;
    };

    const timer = scheduleNext();
    return () => clearTimeout(timer);
  }, [settings?.promo_bar?.textGlitch]);

  // Promo bar settings - check override flag
  const promoBar = settings?.promo_bar?.override_template_link ?
  {
    ...(settings?.promo_bar || {}),
    link_url: settings?.promo_bar?.custom_template_url || "https://base44.com/u/team44",
    link_text: "Get This Template"
  } :
  settings?.promo_bar || {};
  const showPromoBar = promoBar?.enabled && promoBar?.text;

  return (
    <div className="min-h-screen bg-slate-950 text-white relative">
      <GlobalAnnouncement />
      <TemplateInitializer />
      {/* Background Overlay */}
      <div
        className="fixed inset-0 pointer-events-none z-0 opacity-50"
        style={{
          backgroundImage: 'url("https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d0e11f7107236669e8813/2579477f6_Team44-BG-Overlay.png")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }} />

      
      {/* Promo Header Bar - Sticky or Static */}
      {showPromoBar &&
      <div
        className={`${promoBar.sticky !== false ? 'fixed' : 'relative'} top-0 left-0 right-0 bg-gradient-to-r ${promoBar.gradient || 'from-violet-600 via-fuchsia-600 to-pink-600'} text-white text-center py-2.5 px-4 text-sm z-[70] overflow-hidden promo-bar-animated shadow-[0_2px_8px_rgba(0,0,0,0.15)] group cursor-default`}
        style={{
          fontFamily: promoBar.fontFamily || 'Arial',
          animation: promoBar.animation === 'pulse' ? 'promoPulse 2s ease-in-out infinite' :
          promoBar.animation === 'bounce' ? 'promoBounce 1s ease-in-out infinite' :
          promoBar.animation === 'slideDown' ? 'promoSlideDown 0.5s ease-out' :
          promoBar.animation === 'fadeIn' ? 'promoFadeIn 1s ease-in' :
          promoBar.animation === 'glow' ? 'promoGlow 2s ease-in-out infinite' :
          promoBar.animation === 'shake' ? 'promoShake 0.5s ease-in-out' :
          promoBar.animation === 'wave' ? 'promoWave 3s ease-in-out infinite' : 'none'
        }}>

          {promoBar.watermark_url &&
        <div className="absolute inset-0 opacity-30 pointer-events-none">
              <img src={promoBar.watermark_url} alt="" className="w-full h-full object-cover" />
            </div>
        }
          <div className="max-w-7xl mx-auto flex items-center justify-center gap-2 relative z-10">
            {promoBar.leftIconImage &&
          <img src={promoBar.leftIconImage} alt="" className="w-5 h-5 promo-icon-left" />
          }
            <span className={promoGlitch ? "promo-text-glitch" : ""}>{promoBar.text}</span>
            {promoBar.link_url &&
          <a href={promoBar.link_url} target="_blank" rel="noopener noreferrer" className={`font-semibold hover:text-white/80 ${promoGlitch ? "promo-text-glitch" : ""}`}>
                {promoBar.link_text || "Learn More →"}
              </a>
          }
            {promoBar.rightIconImage &&
          <img src={promoBar.rightIconImage} alt="" className="w-5 h-5 promo-icon-right" />
          }
          </div>
        </div>
      }
      <style>{`
        @keyframes promoPulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.02); } }
        @keyframes promoBounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-5px); } }
        @keyframes promoSlideDown { from { transform: translateY(-100%); } to { transform: translateY(0); } }
        @keyframes promoFadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes promoGlow { 0%, 100% { box-shadow: 0 0 20px rgba(139, 92, 246, 0.5); } 50% { box-shadow: 0 0 40px rgba(139, 92, 246, 0.8); } }
        @keyframes promoShake { 0%, 100% { transform: translateX(0); } 25% { transform: translateX(-5px); } 75% { transform: translateX(5px); } }
        @keyframes promoWave { 0%, 100% { transform: rotate(0deg); } 25% { transform: rotate(1deg); } 75% { transform: rotate(-1deg); } }
        @keyframes promoTextGlitch {
          0%, 100% { text-shadow: none; transform: translate(0); }
          20% { text-shadow: -1px 0 #ff00ff, 1px 0 #00ffff; transform: translate(-1px, 0); }
          40% { text-shadow: 1px 0 #ff00ff, -1px 0 #00ffff; transform: translate(1px, 0); }
          60% { text-shadow: -1px 0 #00ffff, 1px 0 #ff00ff; transform: translate(-1px, 0); }
          80% { text-shadow: 1px 0 #00ffff, -1px 0 #ff00ff; transform: translate(1px, 0); }
        }
        @keyframes promoIconRock {
          0%, 100% { transform: rotate(0deg); }
          25% { transform: rotate(-5deg); }
          75% { transform: rotate(5deg); }
        }
        .promo-text-glitch { animation: promoTextGlitch 0.3s ease-in-out; }
        .group:hover .promo-icon-left,
        .group:hover .promo-icon-right {
          animation: promoIconRock 0.8s ease-in-out infinite;
        }
      `}</style>
      <style>{`
        :root { --accent-violet: #8b5cf6; --accent-cyan: #06b6d4; --accent-teal: #14b8a6; }
        
        /* Dark Theme (Default) */
        [data-theme="dark"], .theme-dark {
          --bg-primary: #0f172a;
          --bg-secondary: #1e293b;
          --bg-tertiary: #334155;
          --text-primary: #f8fafc;
          --text-secondary: #94a3b8;
          --border-color: #334155;
        }
        
        /* Light Theme */
        [data-theme="light"], .theme-light {
          --bg-primary: #f8fafc;
          --bg-secondary: #e2e8f0;
          --bg-tertiary: #cbd5e1;
          --text-primary: #0f172a;
          --text-secondary: #475569;
          --border-color: #cbd5e1;
        }
        .theme-light { background: var(--bg-primary) !important; color: var(--text-primary) !important; }
        .theme-light .bg-slate-950 { background: var(--bg-secondary) !important; }
        .theme-light .bg-slate-900 { background: var(--bg-secondary) !important; }
        .theme-light .bg-slate-900\\/50 { background: rgba(226, 232, 240, 0.5) !important; }
        .theme-light .bg-slate-800 { background: var(--bg-tertiary) !important; }
        .theme-light .text-white { color: var(--text-primary) !important; }
        .theme-light .text-slate-400 { color: var(--text-secondary) !important; }
        .theme-light .text-slate-300 { color: var(--text-secondary) !important; }
        .theme-light .border-slate-800 { border-color: var(--border-color) !important; }
        .theme-light .border-slate-700 { border-color: var(--border-color) !important; }
        
        /* Cyber Theme */
        [data-theme="cyber"], .theme-cyber {
          --bg-primary: #0a0a0f;
          --bg-secondary: #1a1a2e;
          --bg-tertiary: #2a2a4e;
          --text-primary: #00ffff;
          --text-secondary: #ff00ff;
          --border-color: #00ffff;
        }
        .theme-cyber { background: var(--bg-primary) !important; }
        .theme-cyber .bg-slate-950 { background: #050508 !important; }
        .theme-cyber .bg-slate-900 { background: var(--bg-secondary) !important; }
        .theme-cyber .text-white { color: #00ffff !important; }
        .theme-cyber .text-slate-400 { color: #ff00ff !important; }
        .theme-cyber .border-slate-800 { border-color: #00ffff40 !important; }
        .theme-cyber .gradient-text { background: linear-gradient(135deg, #00ffff, #ff00ff) !important; -webkit-background-clip: text !important; }
        @keyframes gradient-shift { 0%, 100% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } }
        .gradient-text { background: linear-gradient(135deg, #8b5cf6, #06b6d4, #14b8a6); background-size: 200% 200%; animation: gradient-shift 3s ease infinite; -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
        .glass { background: rgba(15, 23, 42, 0.8); backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.1); }
        @keyframes logo-pulse { 0%, 100% { filter: drop-shadow(0 0 8px #8b5cf6); } 50% { filter: drop-shadow(0 0 20px #8b5cf6); } }
        @keyframes logo-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes logo-bounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-4px); } }
        .logo-effect-neon { animation: logo-pulse 2s ease-in-out infinite; }
        .logo-effect-sparkles { animation: logo-pulse 1s ease-in-out infinite; }
        @keyframes logo-morph-fade { 0%, 45% { opacity: 1; } 50%, 95% { opacity: 0; } 100% { opacity: 1; } }
        .logo-morph-1 { animation: logo-morph-fade var(--morph-speed, 6s) ease-in-out infinite; }
        .logo-morph-2 { animation: logo-morph-fade var(--morph-speed, 6s) ease-in-out infinite; }
        
        /* Logo Glitch Effect - uses CSS animation with proper timing */
        @keyframes logo-glitch-effect {
          0%, 85% { clip-path: inset(0 0 0 0); transform: translate(0); opacity: 1; }
          86% { clip-path: inset(40% 0 30% 0); transform: translate(-3px, 2px); }
          88% { clip-path: inset(10% 0 60% 0); transform: translate(3px, -2px); }
          90% { clip-path: inset(80% 0 5% 0); transform: translate(-2px, 1px); }
          92% { clip-path: inset(20% 0 50% 0); transform: translate(2px, -1px); }
          94% { clip-path: inset(60% 0 20% 0); transform: translate(-1px, 2px); }
          96% { clip-path: inset(30% 0 40% 0); transform: translate(1px, -2px); }
          98% { clip-path: inset(0 0 0 0); transform: translate(0); }
          100% { clip-path: inset(0 0 0 0); transform: translate(0); opacity: 1; }
        }
        @keyframes logo-glitch-alt-effect {
          0%, 85% { clip-path: inset(0 0 0 0); transform: translate(0); filter: none; }
          86% { clip-path: inset(20% 0 50% 0); transform: translate(2px, -1px); filter: hue-rotate(90deg); }
          88% { clip-path: inset(60% 0 20% 0); transform: translate(-2px, 1px); filter: hue-rotate(-90deg); }
          90% { clip-path: inset(30% 0 40% 0); transform: translate(1px, 2px); filter: hue-rotate(180deg); }
          92% { clip-path: inset(50% 0 30% 0); transform: translate(-1px, -1px); filter: hue-rotate(45deg); }
          94% { clip-path: inset(10% 0 70% 0); transform: translate(2px, 1px); filter: hue-rotate(-45deg); }
          96% { clip-path: inset(40% 0 20% 0); transform: translate(-2px, -2px); filter: hue-rotate(135deg); }
          98% { clip-path: inset(0 0 0 0); transform: translate(0); filter: none; }
          100% { clip-path: inset(0 0 0 0); transform: translate(0); filter: none; }
        }
        .logo-glitch-1 {
          animation: logo-glitch-alt-effect var(--glitch-total, 20s) ease-in-out infinite;
        }
        .logo-glitch-2 {
          animation: logo-glitch-effect var(--glitch-total, 20s) ease-in-out infinite;
          opacity: 0.7;
        }
        .title-effect-neon { text-shadow: 0 0 10px #8b5cf6, 0 0 20px #8b5cf6; }
        .title-effect-fire { text-shadow: 0 0 10px #f97316, 0 0 20px #ef4444; }
        .title-effect-confetti { animation: logo-bounce 0.5s ease-in-out infinite; }

                /* Nav Glitch Effect */
                .nav-glitch-link:hover .nav-glitch-text {
                  animation: nav-glitch 0.3s ease-in-out;
                }
                @keyframes nav-glitch {
                  0%, 100% { text-shadow: none; transform: translate(0); }
                  20% { text-shadow: -1px 0 #ff00ff, 1px 0 #00ffff; transform: translate(-1px, 0); }
                  40% { text-shadow: 1px 0 #ff00ff, -1px 0 #00ffff; transform: translate(1px, 0); }
                  60% { text-shadow: -1px 0 #00ffff, 1px 0 #ff00ff; transform: translate(-1px, 0); }
                  80% { text-shadow: 1px 0 #00ffff, -1px 0 #ff00ff; transform: translate(1px, 0); }
                }
                /* Submenu Glitch Effect - Text Only */
                .submenu-glitch-link:hover .submenu-glitch-text {
                  animation: submenu-glitch 0.3s ease-in-out;
                }
                @keyframes submenu-glitch {
                  0%, 100% { text-shadow: none; }
                  20% { text-shadow: -1px 0 #ff00ff, 1px 0 #00ffff; }
                  40% { text-shadow: 1px 0 #ff00ff, -1px 0 #00ffff; }
                  60% { text-shadow: -1px 0 #00ffff, 1px 0 #ff00ff; }
                  80% { text-shadow: 1px 0 #00ffff, -1px 0 #ff00ff; }
                }
                `}</style>

      {/* Floating Header */}
      <motion.header initial={{ y: -100 }} animate={{ y: 0 }} className={`fixed left-4 right-4 z-50 ${showPromoBar && promoBar.sticky !== false ? 'top-[52px]' : 'top-4'}`}>
        <div className={cn("max-w-7xl mx-auto rounded-2xl transition-all duration-500", isScrolled ? "glass py-2 px-4 shadow-xl shadow-black/20" : "bg-slate-900/50 backdrop-blur-sm border border-slate-800 py-3 px-4")}>
          <div className="flex items-center justify-between gap-4 relative">
            <div className="flex items-center gap-4">
            <Link to={createPageUrl("Home")} className="flex items-center gap-2 group">
              {settings?.logo_url ?
                <div className="relative w-8 h-8">
                    <img
                    src={settings.logo_url}
                    alt="Logo"
                    className={`absolute inset-0 w-8 h-8 rounded-xl object-contain ${
                    settings?.logo_glitch_enabled ? 'logo-glitch-1' :
                    settings?.logo_morph_enabled !== false && settings?.logo_url_2 ? 'logo-morph-1' : ''}`
                    }
                    style={
                    settings?.logo_glitch_enabled ?
                    { "--glitch-total": `${settings?.logo_glitch_interval || 20}s` } :
                    settings?.logo_morph_enabled !== false && settings?.logo_url_2 ?
                    { animationDuration: `${settings?.logo_morph_speed || 6}s` } :
                    {}
                    } />

                    {settings?.logo_glitch_enabled && settings?.logo_url_2 && settings?.logo_overlay_enabled !== false &&
                  <img
                    src={settings.logo_url_2}
                    alt="Logo 2"
                    className="absolute inset-0 w-8 h-8 rounded-xl object-contain logo-glitch-2"
                    style={{ "--glitch-total": `${settings?.logo_glitch_interval || 20}s` }} />

                  }
                    {!settings?.logo_glitch_enabled && settings?.logo_morph_enabled !== false && settings?.logo_url_2 && settings?.logo_overlay_enabled !== false &&
                  <img
                    src={settings.logo_url_2}
                    alt="Logo 2"
                    className="absolute inset-0 w-8 h-8 rounded-xl object-contain logo-morph-2"
                    style={{ animationDuration: `${settings?.logo_morph_speed || 6}s`, animationDelay: `-${(settings?.logo_morph_speed || 6) / 2}s` }} />

                  }
                  </div> :

                <motion.div whileHover={{ rotate: 180, scale: 1.1 }} transition={{ duration: 0.5 }} className="p-2 rounded-xl bg-gradient-to-br from-violet-500 to-teal-500">
                  <Sparkles className="w-5 h-5 text-white" />
                </motion.div>
                }
              <div className="hidden sm:block">
                <WordSlider />
              </div>
              </Link>


              </div>

            {/* Desktop Nav */}
            <nav className="hidden xl:flex items-center gap-0.5 absolute left-1/2 -translate-x-1/2">
              {primaryNav.map((item) =>
              <Link key={item.page} to={createPageUrl(item.page)} className="relative px-2.5 py-1.5 group nav-glitch-link">
                  <span className={cn("relative z-10 text-xs font-medium transition-colors flex items-center gap-1 nav-glitch-text", currentPageName === item.page ? "text-white" : "text-slate-400 group-hover:text-white")}>
                    <item.icon className="w-3.5 h-3.5" />
                    {item.name}
                  </span>
                  {currentPageName === item.page && <motion.div layoutId="activeTab" className="absolute inset-0 bg-white/10 rounded-lg" transition={{ type: "spring", bounce: 0.2, duration: 0.6 }} />}
                </Link>
              )}

              {/* More Drawer - Slide Down */}
              <div className="relative">
                <button
                  onClick={() => setMoreDrawerOpen(!moreDrawerOpen)}
                  onMouseEnter={() => setMoreDrawerOpen(true)}
                  className="relative px-2.5 py-1.5 flex items-center gap-1 text-xs font-medium text-purple-400 hover:text-white">

                  <Menu className="w-3.5 h-3.5" />
                  <span>More</span>
                  <motion.div animate={{ rotate: moreDrawerOpen ? 180 : 90 }}>
                    <ChevronRight className="w-3 h-3" />
                  </motion.div>
                </button>
              </div>

              <div className="w-px h-6 bg-slate-700 mx-1" />

              {/* Tools Dropdown */}
              <div className="relative group">
                <button className="relative px-2.5 py-1.5 flex items-center gap-1 text-xs font-medium text-purple-300 hover:text-white">
                  <Wand2 className="w-3.5 h-3.5" />
                  <span>Tools</span>
                  <ChevronRight className="w-3 h-3 rotate-90" />
                </button>
                <div className="absolute top-full right-0 mt-1 w-44 bg-slate-900 border border-slate-800 rounded-xl shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50">
                  <div className="p-2">
                      {toolsNav.map((item) =>
                    <Link key={item.page} to={createPageUrl(item.page)} className="flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs text-slate-400 hover:text-white hover:bg-slate-800 submenu-glitch-link">
                          <item.icon className="w-3.5 h-3.5" />
                          <span className="submenu-glitch-text">{item.name}</span>
                        </Link>
                    )}
                    </div>
                </div>
              </div>
            </nav>

            <div className="flex items-center gap-2 relative">
              {/* Global Search */}
              {globalSearchEnabled && <GlobalSearch />}

              <InstallButtonWithPopover />
              <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="xl:hidden p-2 rounded-lg hover:bg-white/10 transition-colors">
                <motion.div animate={{ rotate: mobileMenuOpen ? 90 : 0 }}>{mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}</motion.div>
              </button>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Floating Timestamp & Admin Button - Below Nav */}
      <div className={`fixed left-0 right-0 z-[45] transition-all duration-300 pointer-events-none ${showPromoBar && promoBar.sticky !== false ? 'top-[112px]' : 'top-[88px]'}`}>
        <div className="max-w-7xl mx-auto px-4 relative h-8">
          {/* Admin Button - Left Side */}
          {isAdmin &&
          <div className="absolute left-4 top-0 pointer-events-auto">
              <button
              onClick={() => window.location.href = createPageUrl("AdminDashboard")}
              className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/50 backdrop-blur-md hover:bg-slate-800 text-[10px] font-medium text-slate-300 transition-colors border border-slate-800/50 shadow-lg">

                <SettingsIcon className="w-3 h-3" />
                Admin
              </button>
            </div>
          }

          {/* Timestamp - Right Side */}
          <div className="absolute right-4 top-0 pointer-events-auto">
            <div className="text-[10px] text-slate-400 bg-slate-900/50 backdrop-blur-md px-3 py-1 rounded-full border border-slate-800/50 shadow-lg flex items-center gap-1.5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              Last updated {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
            </div>
          </div>
        </div>
      </div>

      {/* More Mega Menu Drawer */}
      <AnimatePresence>
        {moreDrawerOpen &&
        <>
            {/* Backdrop */}
            <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40"
            onClick={() => setMoreDrawerOpen(false)} />


            {/* Drawer */}
            <motion.div
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            onMouseLeave={() => setMoreDrawerOpen(false)}
            className={`fixed left-4 right-4 z-50 ${showPromoBar && promoBar.sticky !== false ? 'top-[100px]' : 'top-[76px]'} max-w-7xl mx-auto`}>

              <div className="relative bg-slate-900/95 backdrop-blur-xl border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
                <div className="p-6 grid grid-cols-5 gap-6">
                  {moreNavCategories.map((category) =>
                <div key={category.title}>
                      <p className="px-2 py-1 text-xs text-violet-400 font-semibold uppercase tracking-wide mb-2">{category.title}</p>
                      {category.items.filter((item) => isFeatureEnabled(item.featureId)).map((item) =>
                  <Link
                    key={item.page}
                    to={createPageUrl(item.page)}
                    onClick={() => setMoreDrawerOpen(false)}
                    className="flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs text-slate-400 hover:text-white hover:bg-slate-800 submenu-glitch-link transition-colors">

                          <item.icon className="w-3.5 h-3.5" />
                          <span className="submenu-glitch-text">{item.name}</span>
                        </Link>
                  )}
                    </div>
                )}
                </div>
              </div>
            </motion.div>
          </>
        }
      </AnimatePresence>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen &&
        <motion.div initial={{ opacity: 0, x: "100%" }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: "100%" }} transition={{ type: "spring", bounce: 0, duration: 0.4 }} className="fixed inset-0 z-40 xl:hidden">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setMobileMenuOpen(false)} />
            <motion.nav className="absolute right-0 top-0 bottom-0 w-72 glass py-24 px-6 overflow-y-auto">
              <div className="space-y-1">
                {navItems.map((item, index) =>
              <motion.div key={item.page} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.03 }}>
                    <Link to={createPageUrl(item.page)} className={cn("flex items-center gap-3 px-4 py-3 rounded-xl transition-all", currentPageName === item.page ? "bg-gradient-to-r from-violet-500/20 to-cyan-500/20 text-white" : "text-slate-400 hover:text-white hover:bg-white/5")}>
                      <item.icon className="w-5 h-5" />
                      <span className="font-medium">{item.name}</span>
                      <ChevronRight className="w-4 h-4 ml-auto" />
                    </Link>
                  </motion.div>
              )}
              </div>
              {/* User Settings at Bottom */}
              <div className="mt-8 pt-4 border-t border-slate-700">
                <Link to={createPageUrl("MyEffects")} className="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5">
                  <SettingsIcon className="w-5 h-5" />
                  <span className="font-medium">User Settings</span>
                </Link>
              </div>
            </motion.nav>
          </motion.div>
        }
      </AnimatePresence>

          {/* Glitch Page Loader */}
          {settings?.enabled_features?.includes("glitchLoader") &&
      <GlitchLoader isVisible={showPageLoader} onComplete={() => setShowPageLoader(false)} />
      }

          <main className="pt-24 relative z-10" key={currentPageName}>{children}</main>

          {/* Coffee Banner - Above Footer on All Pages (except Home) */}
          {settings?.coffee_banner?.enabled && settings?.coffee_banner?.show_on_all_pages && settings?.coffee_banner?.image_url && currentPageName !== "Home" &&
      <div className="px-4 sm:px-6 lg:px-8 pb-8">
              <div className="max-w-7xl mx-auto">
                <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative overflow-hidden rounded-2xl shadow-2xl"
            style={{
              height: settings.coffee_banner.size === 'small' ? '120px' :
              settings.coffee_banner.size === 'large' ? '300px' :
              settings.coffee_banner.size === 'xl' ? '400px' :
              settings.coffee_banner.size === 'xxl' ? '500px' :
              settings.coffee_banner.size === 'jumbo' ? '600px' : '200px'
            }}>

                  {!settings.coffee_banner.button_enabled ?
            <a
              href={settings.coffee_banner.link || "https://buymeacoffee.com/team44"}
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full h-full">

                      <motion.img
                whileHover={{ scale: 1.01 }}
                src={settings.coffee_banner.image_url}
                alt="Support us"
                className="w-full h-full object-cover cursor-pointer" />

                    </a> :

            <img
              src={settings.coffee_banner.image_url}
              alt="Support us"
              className="w-full h-full object-cover" />

            }

                  {settings.coffee_banner.button_enabled && settings.coffee_banner.button_image &&
            <div className="absolute inset-0 flex items-center justify-center">
                      <a
                href={settings.coffee_banner.link || "https://buymeacoffee.com/team44"}
                target="_blank"
                rel="noopener noreferrer">

                        <motion.img
                  src={settings.coffee_banner.button_image}
                  alt="Buy me a coffee"
                  className={`max-w-[300px] max-h-[80px] object-contain cursor-pointer coffee-btn-${settings.coffee_banner.button_effect}`}
                  whileHover={
                  settings.coffee_banner.button_effect === 'bounce' ? { scale: 1.1, y: -5 } :
                  settings.coffee_banner.button_effect === 'shimmer' ? { scale: 1.05 } :
                  settings.coffee_banner.button_effect === 'glow' ? { scale: 1.05 } :
                  settings.coffee_banner.button_effect === 'pulse' ? { scale: 1.05 } :
                  { scale: 1.05 }
                  }
                  whileTap={{ scale: 0.95 }} />

                      </a>
                    </div>
            }
                </motion.div>
                <style>{`
                  @keyframes shimmer {
                    0% { filter: brightness(1); }
                    50% { filter: brightness(1.3); }
                    100% { filter: brightness(1); }
                  }
                  @keyframes glow-pulse {
                    0%, 100% { filter: drop-shadow(0 0 10px rgba(255,200,0,0.6)); }
                    50% { filter: drop-shadow(0 0 30px rgba(255,200,0,1)); }
                  }
                  @keyframes pulse-scale {
                    0%, 100% { transform: scale(1); }
                    50% { transform: scale(1.05); }
                  }
                  .coffee-btn-shimmer:hover { animation: shimmer 1.5s infinite; }
                  .coffee-btn-glow { animation: glow-pulse 2s infinite; }
                  .coffee-btn-pulse { animation: pulse-scale 1.5s infinite; }
                  .coffee-btn-shadow { filter: drop-shadow(0 10px 20px rgba(0,0,0,0.5)); }
                  .coffee-btn-shadow:hover { filter: drop-shadow(0 15px 30px rgba(0,0,0,0.7)); }
                `}</style>
              </div>
            </div>
      }

          <div className="relative z-10 bg-slate-950">
            <FooterEnhanced version={settings?.version || "1.0.0"} />
          </div>
    </div>);

}