import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const defaultSettings = {
      app_title: "UI Effects Playground",
      version: "2.0.1",
      logo_url: "",
      logo_url_2: "",
      logo_morph_enabled: true,
      logo_morph_speed: 6,
      logo_glitch_enabled: false,
      logo_glitch_interval: 20,
      logo_overlay_enabled: true,
      logo_effects: [],
      title_effects: [],
      enabled_features: ["dividerEffects"],
      selected_banner: "moviePoster2",
      banner_configs: {},
      social_links: {},
      donation_settings: {},
      back_to_top_logo: "",
      bottom_banner_url: "",
      bottom_banner_link: "",
      footer_effect: "none",
      footer_widgets: [],
      hero_style: {
        gradient_start: "#7c3aed",
        gradient_middle: "#8b5cf6",
        gradient_end: "#db2777",
        opacity: 0.6,
        effects: []
      },
      promo_bar: {
        enabled: false,
        text: "Welcome to UI Effects Playground",
        link_url: "",
        link_text: "Explore Effects",
        gradient: "from-violet-600 via-fuchsia-600 to-pink-600",
        sticky: true,
        shadow: false,
        autoHide: false,
        watermark_url: "",
        leftIconImage: "",
        rightIconImage: "",
        fontFamily: "Arial",
        textGlitch: false,
        override_template_link: false,
        custom_template_url: ""
      },
      modern_video: { enabled: false, youtube_url: "", title: "", description: "" },
      walkthrough_video: { enabled: false, youtube_url: "", title: "", description: "", theme: "default" },
      see_it_in_action_enabled: false,
      coffee_banner: {
        enabled: false,
        image_url: "",
        link: "https://buymeacoffee.com/team44",
        size: "medium",
        button_enabled: false,
        button_image: "",
        button_effect: "bounce",
        show_on_all_pages: false
      },
      footer_config: {
        columns: 4,
        column_widgets: ["brand", "stats", "settings", "install"],
        alignment: "left",
        style: "default"
      },
      cta_section: { enabled: true, visible_buttons: [] },
      featured_nav_random: true,
      featured_nav_pages: [],
      template_showcase: {
        enabled: false,
        poster_1_image: "",
        poster_1_link: "",
        poster_1_title: "",
        poster_2_image: "",
        poster_2_link: "",
        poster_2_title: "",
        poster_3_image: "",
        poster_3_link: "",
        poster_3_title: ""
      },
      donation_banner: { enabled: false },
      hero_layout: "default",
      youtube_overlay_image_url: "",
      youtube_overlay_enabled: true,
      announcements_enabled: false,
      global_search_enabled: true
    };

    // Find existing settings record
    const existingList = await base44.asServiceRole.entities.AppSettings.list();
    const existing = existingList[0];

    if (existing) {
      await base44.asServiceRole.entities.AppSettings.update(existing.id, defaultSettings);
    } else {
      await base44.asServiceRole.entities.AppSettings.create(defaultSettings);
    }

    return Response.json({ success: true, message: "App settings reset to defaults successfully." });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});