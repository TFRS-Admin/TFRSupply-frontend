import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Unauthorized' }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const action = body.action || 'scan';

    // --- SAVE action ---
    if (action === 'save') {
      const { filePath, componentName, analysis, codeSnippet } = body;
      if (!filePath || !componentName) {
        return Response.json({ error: 'filePath and componentName required' }, { status: 400 });
      }

      const existing = await base44.asServiceRole.entities.ComponentLibrary.filter({ filePath });
      if (existing.length > 0) {
        await base44.asServiceRole.entities.ComponentLibrary.update(existing[0].id, {
          purpose: analysis,
          codeSnippet: codeSnippet || '',
          status: 'active',
          isDuplicate: false
        });
        return Response.json({ success: true, action: 'updated', id: existing[0].id });
      } else {
        const record = await base44.asServiceRole.entities.ComponentLibrary.create({
          componentName,
          filePath,
          purpose: analysis,
          codeSnippet: codeSnippet || '',
          isDuplicate: false,
          status: 'active'
        });
        return Response.json({ success: true, action: 'created', id: record.id });
      }
    }

    // --- IGNORE action ---
    if (action === 'ignore') {
      const { filePath, componentName } = body;
      if (!filePath) return Response.json({ error: 'filePath required' }, { status: 400 });

      const existing = await base44.asServiceRole.entities.ComponentLibrary.filter({ filePath });
      if (existing.length > 0) {
        await base44.asServiceRole.entities.ComponentLibrary.update(existing[0].id, { status: 'ignored' });
      } else {
        await base44.asServiceRole.entities.ComponentLibrary.create({
          componentName: componentName || filePath.split('/').pop(),
          filePath,
          status: 'ignored',
          isDuplicate: false,
          purpose: 'Ignored by admin',
          codeSnippet: ''
        });
      }
      return Response.json({ success: true });
    }

    // --- SCAN action ---
    // The frontend sends the file manifest (names + code) because Deno sandbox
    // does not expose the host filesystem. The frontend reads files via fetch.
    if (action === 'scan') {
      const { files = [] } = body; // [{ filePath, componentName, codeSnippet }]

      if (!files.length) {
        return Response.json({
          discoveries: [],
          message: 'No files provided. Use the UI scanner to collect files first.'
        });
      }

      // Get existing tracked paths
      const existingRecords = await base44.asServiceRole.entities.ComponentLibrary.list();
      const trackedPaths = new Set(existingRecords.map(r => r.filePath));
      const ignoredPaths = new Set(
        existingRecords.filter(r => r.status === 'ignored').map(r => r.filePath)
      );

      // Filter to only new + non-ignored files
      const newFiles = files.filter(f => !trackedPaths.has(f.filePath) && !ignoredPaths.has(f.filePath));

      if (newFiles.length === 0) {
        return Response.json({
          discoveries: [],
          totalScanned: files.length,
          newFound: 0,
          returned: 0,
          message: 'All components are already tracked or ignored!'
        });
      }

      // Analyze each new file with AI
      const discoveries = [];
      for (const file of newFiles.slice(0, 15)) {
        const truncated = (file.codeSnippet || '').slice(0, 2500);
        let analysis = `A React component named ${file.componentName}.`;

        try {
          const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
            prompt: `You are a React component analyzer. In ONE concise sentence (max 20 words), describe what this UI component does. File: ${file.componentName}\n\nCode:\n${truncated}`,
            model: 'gpt_5_mini'
          });
          analysis = typeof result === 'string' ? result.trim() : analysis;
        } catch (_e) {
          // keep default
        }

        // Check for duplicates by name
        const duplicateCheck = existingRecords.find(
          r => r.componentName === file.componentName && r.filePath !== file.filePath && r.status === 'active'
        );

        discoveries.push({
          filePath: file.filePath,
          componentName: file.componentName,
          analysis,
          isDuplicate: !!duplicateCheck,
          duplicateOf: duplicateCheck?.filePath || null,
          codeSnippet: file.codeSnippet || ''
        });
      }

      return Response.json({
        discoveries,
        totalScanned: files.length,
        newFound: newFiles.length,
        returned: discoveries.length,
        message: newFiles.length > 15
          ? `Showing first 15 of ${newFiles.length} new components. Run scan again for more.`
          : null
      });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});