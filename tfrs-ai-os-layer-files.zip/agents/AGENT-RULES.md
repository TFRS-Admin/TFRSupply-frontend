# Agent Rules for TFR Supply Frontend

These rules are mandatory for coding agents working in this repository.

## 1. Work from issues

Every change should connect to a GitHub Issue or clearly stated user request.

If the request is vague, ask for clarification or produce a small planning-only PR.

## 2. One task per branch

Create branches from `develop`.

Branch naming:

```text
feature/<short-name>
fix/<short-name>
docs/<short-name>
chore/<short-name>
```

Examples:

```text
feature/valor-package-builder
fix/sku-table-pricing
docs/ai-agent-rules
```

## 3. Do not touch unrelated files

Only modify files needed for the task.

Do not reformat entire files unless the task is formatting.

Do not rewrite components because you prefer a different style.

## 4. Protect product architecture

Product pages are not configurators.

The configurator must plug into the existing product page structure.

Do not remove:

- product hero
- image/gallery sections
- product tabs
- specifications/downloads/docs
- existing route structure

## 5. Configurator rules

Configurator data may contain:

- SKU
- SKU attributes
- filters
- option rules
- dependency rules
- package builder rules
- vehicle fitment rules
- review flags

Configurator data must not contain live commerce truth:

- no hardcoded price source of truth
- no invented Shopify variant IDs
- no invented availability
- no invented images

Commerce comes from the Shopify index/service.

## 6. Shopify rules

Shopify owns:

- price
- product handle
- product title
- product image
- availability
- variant ID
- cart/checkout readiness

If a SKU is missing from Shopify data, flag it as Needs Review.

Never invent commerce data.

## 7. QA required in every PR

Every PR must include:

- files created
- files changed
- what was tested
- route(s) tested
- screenshots if UI changed
- known risks
- remaining blockers

## 8. Stop after scope

When the requested task is done, stop.

Do not opportunistically add new features.

Do not continue into the next product family unless explicitly asked.

## 9. Escalate instead of guessing

Escalate when:

- a SKU classification is unclear
- a price is missing
- Shopify data is unavailable
- a route conflicts with the vertical/category model
- the requested change would remove existing page functionality

## 10. Definition of Done

A task is done only when:

- the requested files are changed
- the app builds
- relevant tests/checks pass
- no unrelated files changed
- QA report is included
- blockers are documented honestly
