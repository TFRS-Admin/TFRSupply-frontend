---
name: Agent Task
about: A scoped task for Codex, Copilot, Claude, or another coding agent
title: "[Agent Task] "
labels: ["agent-task"]
assignees: ""
---

## Goal

What should the agent accomplish?

## Scope

The agent may change:

- [ ] Documentation only
- [ ] Data only
- [ ] UI component(s)
- [ ] Service/business logic
- [ ] Tests
- [ ] Deployment/config

Allowed files or folders:

```text
<!-- List allowed files/folders here -->
```

Do not change:

```text
<!-- List files/folders that are off limits -->
```

## Context

Relevant product/business context:

```text
<!-- Explain why this task matters -->
```

## Acceptance Criteria

- [ ] Requirement 1
- [ ] Requirement 2
- [ ] Requirement 3
- [ ] Build/checks pass
- [ ] QA report included

## Testing / QA

Routes or flows to test:

```text
<!-- Example: /police/light-bars/valor -->
```

Expected QA report must include:

- files created
- files changed
- what was tested
- screenshots if UI changed
- remaining blockers

## Agent Instructions

- Work on a feature branch from `develop`.
- Keep the change small.
- Do not modify unrelated files.
- Do not invent data.
- Stop after this task.
