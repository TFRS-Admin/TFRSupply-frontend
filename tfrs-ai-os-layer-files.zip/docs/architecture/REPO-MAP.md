# Repository Map

This document explains the expected structure of `TFRSupply-frontend` for agents and future developers.

## Top-level areas

```text
src/
  components/
  pages/
  data/
  services/
  context/
  lib/
  styles/

docs/
agents/
.github/
```

## `src/components`

Reusable UI components.

Expected areas:

```text
components/configurator/
components/navigator/
components/product/
components/ui/
```

Rules:

- Shared components should be generic and data-driven.
- Do not create product-family-specific React components unless approved.
- Product-specific behavior should usually live in JSON data, not JSX.

## `src/pages`

Route-level page templates.

Important:

- `ProductDetailTemplate` should preserve product page layout.
- Configurator modules should be embedded inside the intended Build & Configure area only.
- Do not replace the product page with a configurator.

## `src/data`

Static product/configurator/category data.

Expected areas:

```text
data/products/
data/configurators/
data/categories/
data/verticals/
data/shopify/
```

### Product JSON

Owns product-page content:

- title
- description
- hero/gallery
- tabs
- documentation
- route/category metadata
- configurator reference

### Configurator JSON

Owns package-builder logic:

- SKU rows
- explicit attributes
- SKU filters
- required components
- optional upgrades
- compatibility rules
- review flags

Should not own live commerce pricing.

### Shopify index

Expected:

```text
src/data/shopify/shopify-variant-index.json
```

Owns commerce lookup by SKU:

- SKU
- price
- product handle
- product title
- image
- availability
- Shopify variant ID when collected

## `src/services`

Business/data services.

Important service:

```text
services/commerceLookupService.js
```

Expected behavior:

1. Look up SKU in Shopify variant index.
2. Fall back to product JSON mapping only if needed.
3. Return `matched`, `price_only`, or `unmatched`.
4. Never invent commerce data.

## `src/context`

Application-wide state.

Important:

- vehicle selection should come from VehicleContext
- configurator should not create a duplicate vehicle selector

## `.github`

Repository automation:

```text
.github/workflows/ci.yml
.github/ISSUE_TEMPLATE/agent_task.md
```

CI should run on PRs to `develop` and `main`.

## Agent-safe development flow

```text
GitHub Issue
  ↓
feature branch from develop
  ↓
small scoped change
  ↓
PR into develop
  ↓
CI
  ↓
review
  ↓
merge
```

## Current known architecture decisions

1. The configurator is a package builder, not a product page.
2. Product education belongs in product page tabs.
3. Base SKU selection happens through filters and an Available SKUs table.
4. Optional upgrades add real SKUs to a quote.
5. No new bundle SKUs are created.
6. Shopify checkout is disabled until variant GIDs are collected.
