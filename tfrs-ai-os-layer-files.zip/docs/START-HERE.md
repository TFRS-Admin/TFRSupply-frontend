# TFR Supply Frontend — Start Here

This repository is being developed with coding agents first, but it should remain clean enough for a future development team to inherit.

## Current operating rule

Do not let agents work directly on `main`.

All development should follow this path:

```text
Issue → feature branch → pull request → CI checks → review → merge
```

## Branch strategy

Use:

- `main` — production-ready code only
- `develop` — integration/staging branch
- `feature/<short-task-name>` — one task per branch

If `develop` does not exist yet, create it from `main` before starting new work.

## Agent workflow

1. Create or pick up a GitHub Issue.
2. Make a new branch from `develop`.
3. Make the smallest useful change.
4. Do not modify unrelated files.
5. Run checks locally if possible.
6. Open a PR into `develop`.
7. Include a clear QA report in the PR.
8. Stop after the requested scope.

## What agents must not do

- Do not push directly to `main`.
- Do not redesign unrelated UI.
- Do not rewrite architecture unless requested.
- Do not invent SKUs, prices, compatibility, or Shopify IDs.
- Do not hide failures.
- Do not modify production/deployment settings without explicit approval.

## TFR Supply product architecture

The app is a storefront and package builder for emergency vehicle equipment.

Key principles:

- Product pages keep their existing layout and tabs.
- The configurator is embedded only in the Build & Configure section.
- Configurator JSON owns SKU attributes, filters, and package rules.
- Shopify commerce data owns price, availability, images, and variant IDs.
- Quote-ready is not the same as checkout-ready.
- Checkout requires Shopify variant IDs.

## First priority

Before adding new features, make the repository safe for agent work:

- CI workflow
- issue template
- agent rules
- repo map
- branch protection
- PR workflow
